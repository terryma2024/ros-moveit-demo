#include <gtest/gtest.h>

#include <algorithm>
#include <array>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <string>
#include <vector>
#include <thread>

#include "control_msgs/action/follow_joint_trajectory.hpp"
#include "rclcpp/serialization.hpp"
#include "rclcpp/serialized_message.hpp"
#include "so101_mujoco_support/controller_goal_admission.hpp"

namespace
{
using so101_mujoco_support::ControllerGoalAdmission;
using Goal = control_msgs::action::FollowJointTrajectory::Goal;
using Result = ControllerGoalAdmission::Result;

ControllerGoalAdmission::GoalUUID uuid(uint8_t value)
{
  ControllerGoalAdmission::GoalUUID id{};
  id.fill(value);
  return id;
}

Goal expected_goal()
{
  Goal goal;
  goal.trajectory.header.stamp.sec = 123;
  goal.trajectory.header.stamp.nanosec = 456;
  goal.trajectory.header.frame_id = "base_link";
  goal.trajectory.joint_names = {"1", "2"};
  trajectory_msgs::msg::JointTrajectoryPoint point;
  point.positions = {0.125, -0.25};
  point.velocities = {0.0, 0.5};
  point.accelerations = {0.125, -0.125};
  point.time_from_start.nanosec = 2000000;
  goal.trajectory.points = {point};
  control_msgs::msg::JointTolerance path;
  path.name = "1";
  path.position = 0.001;
  path.velocity = 0.002;
  path.acceleration = 0.003;
  goal.path_tolerance = {path};
  control_msgs::msg::JointTolerance terminal;
  terminal.name = "2";
  terminal.position = 0.004;
  terminal.velocity = 0.005;
  terminal.acceleration = 0.006;
  goal.goal_tolerance = {terminal};
  goal.goal_time_tolerance.nanosec = 50000000;
  return goal;
}

std::vector<uint8_t> python_fixture()
{
  const auto path = std::filesystem::path(__FILE__).parent_path() /
    "fixtures/follow_joint_trajectory_goal.cdr.hex";
  std::ifstream input(path);
  std::string hex;
  input >> hex;
  if (hex.size() % 2 != 0) {
    return {};
  }
  std::vector<uint8_t> bytes;
  bytes.reserve(hex.size() / 2);
  for (size_t i = 0; i < hex.size(); i += 2) {
    bytes.push_back(static_cast<uint8_t>(std::stoul(hex.substr(i, 2), nullptr, 16)));
  }
  return bytes;
}
}  // namespace

namespace
{
using GateReason = ControllerGoalAdmission::GateReason;
using CloseStatus = ControllerGoalAdmission::ScopedCloseStatus;
using Role = so101_mujoco_support::ControllerReservationRole;
so101_mujoco_support::ServiceControllerIdentity startup_identity()
{return {Role::NECK, "startup-inc", "startup-boot"};}
}

TEST(ControllerGoalAdmission, prearm_scope_reads_configured_identity_without_opening_gate)
{
  ControllerGoalAdmission gate([] {return 1000;}, 100, 1024, 2048, startup_identity());
  const auto scope = gate.prearm_scope(17);
  ASSERT_TRUE(scope.identity);
  EXPECT_EQ(scope.identity->incarnation, "startup-inc");
  EXPECT_EQ(scope.stored_generation, 0u);
  EXPECT_TRUE(scope.eligible());
  EXPECT_EQ(gate.generation(), 0u);
  EXPECT_FALSE(gate.service_identity());
  EXPECT_EQ(gate.prearm_scope(0).reason, GateReason::ZERO_GENERATION);
  ASSERT_TRUE(gate.arm(17));
  EXPECT_EQ(gate.prearm_scope(17).reason, GateReason::NONINCREASING_GENERATION);
  EXPECT_EQ(gate.generation(), 17u);
}

TEST(ControllerGoalAdmission, close_scoped_zero_latches_and_returns_not_armed)
{
  auto latch = std::make_shared<std::atomic<bool>>(false);
  ControllerGoalAdmission gate([] {return 1000;}, 100, 1024, 2048, startup_identity(), latch);
  const auto result = gate.close_scoped(17, Role::NECK, "startup-inc", "startup-boot");
  EXPECT_EQ(result.status, CloseStatus::NOT_ARMED_CLOSED);
  EXPECT_EQ(result.stored_generation, 0u);
  EXPECT_TRUE(latch->load());
  EXPECT_FALSE(gate.arm(17));
  ControllerGoalAdmission replacement([] {return 1000;}, 100, 1024, 2048, startup_identity(), latch);
  EXPECT_FALSE(replacement.arm(18));
}

TEST(ControllerGoalAdmission, close_scoped_matching_after_fail_closes_armed)
{
  ControllerGoalAdmission gate([] {return 1000;}, 100, 1024, 2048, startup_identity());
  ASSERT_TRUE(gate.arm(17));
  gate.close();
  EXPECT_EQ(gate.generation(), 0u);
  const auto result = gate.close_scoped(17, Role::NECK, "startup-inc", "startup-boot");
  EXPECT_EQ(result.status, CloseStatus::ARMED_CLOSED);
  EXPECT_EQ(result.stored_generation, 17u);
  EXPECT_FALSE(gate.arm(18));
}

TEST(ControllerGoalAdmission, close_scoped_different_generation_or_identity_preserves_gate)
{
  ControllerGoalAdmission gate([] {return 1000;}, 100, 1024, 2048, startup_identity());
  ASSERT_TRUE(gate.arm(17));
  EXPECT_EQ(gate.close_scoped(18, Role::NECK, "startup-inc", "startup-boot").status,
    CloseStatus::REJECT_GENERATION);
  EXPECT_EQ(gate.close_scoped(17, Role::NECK, "old-inc", "startup-boot").status,
    CloseStatus::REJECT_IDENTITY);
  EXPECT_EQ(gate.close_scoped(17, Role::ARM, "startup-inc", "startup-boot").status,
    CloseStatus::REJECT_IDENTITY);
  EXPECT_EQ(gate.close_scoped(0, Role::NECK, "startup-inc", "startup-boot").status,
    CloseStatus::REJECT_GENERATION);
  EXPECT_EQ(gate.generation(), 17u);
  EXPECT_TRUE(gate.arm(18));
}

TEST(ControllerGoalAdmission, concurrent_arm_and_scoped_close_linearize)
{
  for (int i = 0; i < 50; ++i) {
    ControllerGoalAdmission gate([] {return 1000;}, 100, 1024, 2048, startup_identity());
    std::atomic<bool> start{false};
    bool armed = false;
    ControllerGoalAdmission::ScopedCloseResult closed;
    std::thread arm([&] {while (!start.load()) {} armed = gate.arm(17);});
    std::thread close([&] {while (!start.load()) {}
        closed = gate.close_scoped(17, Role::NECK, "startup-inc", "startup-boot");});
    start.store(true);
    arm.join(); close.join();
    EXPECT_EQ(closed.status, armed ? CloseStatus::ARMED_CLOSED : CloseStatus::NOT_ARMED_CLOSED);
    EXPECT_EQ(closed.stored_generation, armed ? 17u : 0u);
    EXPECT_EQ(gate.generation(), 0u);
    EXPECT_FALSE(gate.arm(18));
  }
}

TEST(ControllerGoalAdmission, detailed_arm_reports_first_legacy_branch)
{
  int64_t now = -1;
  ControllerGoalAdmission gate([&] {return now;});
  EXPECT_EQ(gate.arm_detailed(0).reason, GateReason::CLOCK_INVALID);
  now = 1000;
  EXPECT_EQ(gate.arm_detailed(0).reason, GateReason::ZERO_GENERATION);
  EXPECT_EQ(gate.arm_detailed(17).reason, GateReason::CLOCK_FAULT);
  ControllerGoalAdmission clean([] {return 1000;});
  EXPECT_TRUE(clean.arm_detailed(17).allowed);
  EXPECT_EQ(clean.arm_detailed(17).reason, GateReason::NONINCREASING_GENERATION);
}

TEST(ControllerGoalAdmission, PythonCdrDecodesToEveryExpectedTypedField)
{
  const auto bytes = python_fixture();
  ASSERT_EQ(bytes.size(), 256u);
  rclcpp::SerializedMessage serialized(bytes.size());
  auto & raw = serialized.get_rcl_serialized_message();
  std::copy(bytes.begin(), bytes.end(), raw.buffer);
  raw.buffer_length = bytes.size();
  Goal decoded;
  rclcpp::Serialization<Goal>().deserialize_message(&serialized, &decoded);
  EXPECT_EQ(decoded, expected_goal());
}

TEST(ControllerGoalAdmission, DefaultsClosedAndConsumesExactTypedReservationOnce)
{
  int64_t now = 1000;
  ControllerGoalAdmission gate([&now]() {return now;}, 100, 1024);
  const auto id = uuid(1);
  const auto goal = expected_goal();
  EXPECT_EQ(gate.admit(id, goal, 1), Result::DENY_CLOSED);
  ASSERT_TRUE(gate.arm(1));
  ASSERT_TRUE(gate.reserve(id, goal, 1));
  now = 1099;
  EXPECT_EQ(gate.admit(id, goal, 1), Result::ALLOW);
  EXPECT_EQ(gate.admit(id, goal, 1), Result::DENY_FAULT);
  EXPECT_FALSE(gate.arm(1));
  EXPECT_TRUE(gate.arm(2));
}

TEST(ControllerGoalAdmission, AlteredTypedFieldOrUuidClosesTheGeneration)
{
  int64_t now = 1000;
  ControllerGoalAdmission gate([&now]() {return now;}, 100, 1024);
  const auto goal = expected_goal();
  auto altered = goal;
  altered.goal_tolerance[0].velocity = 0.007;
  ASSERT_TRUE(gate.arm(5));
  ASSERT_TRUE(gate.reserve(uuid(1), goal, 5));
  EXPECT_EQ(gate.admit(uuid(1), altered, 5), Result::DENY_FAULT);
  EXPECT_EQ(gate.admit(uuid(1), goal, 5), Result::DENY_CLOSED);
  ASSERT_TRUE(gate.arm(6));
  ASSERT_TRUE(gate.reserve(uuid(1), goal, 6));
  EXPECT_EQ(gate.admit(uuid(2), goal, 6), Result::DENY_FAULT);
  EXPECT_EQ(gate.admit(uuid(1), goal, 6), Result::DENY_CLOSED);
}

TEST(ControllerGoalAdmission, DeadlineAndClockRegressionFailClosed)
{
  int64_t now = 1000;
  ControllerGoalAdmission gate([&now]() {return now;}, 100, 1024);
  const auto goal = expected_goal();
  ASSERT_TRUE(gate.arm(1));
  ASSERT_TRUE(gate.reserve(uuid(1), goal, 1));
  now = 1100;
  EXPECT_EQ(gate.admit(uuid(1), goal, 1), Result::DENY_FAULT);
  ASSERT_TRUE(gate.arm(2));
  ASSERT_TRUE(gate.reserve(uuid(1), goal, 2));
  now = 1099;
  EXPECT_EQ(gate.admit(uuid(1), goal, 2), Result::DENY_FAULT);
}

TEST(ControllerGoalAdmission, RejectsEmptyOversizedAndDuplicateReservations)
{
  int64_t now = 1000;
  ControllerGoalAdmission gate([&now]() {return now;}, 100, 1024);
  const auto goal = expected_goal();
  ASSERT_TRUE(gate.arm(1));
  EXPECT_FALSE(gate.reserve(uuid(0), goal, 1));
  EXPECT_EQ(gate.admit(uuid(1), goal, 1), Result::DENY_CLOSED);
  ASSERT_TRUE(gate.arm(2));
  EXPECT_FALSE(gate.reserve(uuid(1), Goal{}, 2));
  ASSERT_TRUE(gate.arm(3));
  ControllerGoalAdmission tiny_gate([&now]() {return now;}, 100, 4);
  ASSERT_TRUE(tiny_gate.arm(1));
  EXPECT_FALSE(tiny_gate.reserve(uuid(1), goal, 1));
  ASSERT_TRUE(gate.reserve(uuid(1), goal, 3));
  EXPECT_FALSE(gate.reserve(uuid(1), goal, 3));
  EXPECT_EQ(gate.admit(uuid(1), goal, 3), Result::DENY_CLOSED);
}

TEST(ControllerGoalAdmission, ExplicitCloseRevokesPendingReservation)
{
  int64_t now = 1000;
  ControllerGoalAdmission gate([&now]() {return now;}, 100, 1024);
  const auto goal = expected_goal();
  ASSERT_TRUE(gate.arm(1));
  ASSERT_TRUE(gate.reserve(uuid(1), goal, 1));
  gate.close();
  EXPECT_EQ(gate.admit(uuid(1), goal, 1), Result::DENY_CLOSED);
  EXPECT_TRUE(gate.arm(2));
}

TEST(ControllerGoalAdmission, ConsumedUuidCannotBeReservedAgain)
{
  int64_t now = 1000;
  ControllerGoalAdmission gate([&now]() {return now;}, 100, 1024);
  const auto goal = expected_goal();
  ASSERT_TRUE(gate.arm(5));
  ASSERT_TRUE(gate.reserve(uuid(1), goal, 5));
  ASSERT_EQ(gate.admit(uuid(1), goal, 5), Result::ALLOW);
  EXPECT_FALSE(gate.reserve(uuid(1), goal, 5));
  EXPECT_EQ(gate.admit(uuid(1), goal, 5), Result::DENY_CLOSED);
  ASSERT_TRUE(gate.arm(6));
  EXPECT_TRUE(gate.reserve(uuid(1), goal, 6));
}

TEST(ControllerGoalAdmission, DistinctGoalsCanBeReservedSequentiallyInOneOwnerGeneration)
{
  int64_t now = 1000;
  ControllerGoalAdmission gate([&now]() {return now;}, 100, 1024);
  const auto first = expected_goal();
  auto second = first;
  second.trajectory.points[0].positions[0] = 0.25;
  ASSERT_TRUE(gate.arm(5));
  ASSERT_TRUE(gate.reserve(uuid(1), first, 5));
  ASSERT_EQ(gate.admit(uuid(1), first, 5), Result::ALLOW);
  ASSERT_TRUE(gate.reserve(uuid(2), second, 5));
  ASSERT_EQ(gate.admit(uuid(2), second, 5), Result::ALLOW);
  EXPECT_FALSE(gate.reserve(uuid(1), first, 5));
  EXPECT_EQ(gate.admit(uuid(1), first, 5), Result::DENY_CLOSED);
}

TEST(ControllerGoalAdmission, OverlappingReservationAndBoundedHistoryCloseTheLease)
{
  int64_t now = 1000;
  const auto goal = expected_goal();
  ControllerGoalAdmission overlap([&now]() {return now;}, 100, 1024, 2);
  ASSERT_TRUE(overlap.arm(5));
  ASSERT_TRUE(overlap.reserve(uuid(1), goal, 5));
  EXPECT_FALSE(overlap.reserve(uuid(2), goal, 5));
  EXPECT_EQ(overlap.admit(uuid(1), goal, 5), Result::DENY_CLOSED);

  ControllerGoalAdmission bounded([&now]() {return now;}, 100, 1024, 2);
  ASSERT_TRUE(bounded.arm(5));
  ASSERT_TRUE(bounded.reserve(uuid(1), goal, 5));
  ASSERT_EQ(bounded.admit(uuid(1), goal, 5), Result::ALLOW);
  ASSERT_TRUE(bounded.reserve(uuid(2), goal, 5));
  ASSERT_EQ(bounded.admit(uuid(2), goal, 5), Result::ALLOW);
  EXPECT_FALSE(bounded.reserve(uuid(3), goal, 5));
  EXPECT_EQ(bounded.admit(uuid(3), goal, 5), Result::DENY_CLOSED);
  ASSERT_TRUE(bounded.arm(6));
  EXPECT_TRUE(bounded.reserve(uuid(1), goal, 6));
}

TEST(ControllerGoalAdmission, CloseGenerationDoesNotRevokeANewerGeneration)
{
  int64_t now = 1000;
  ControllerGoalAdmission gate([&now]() {return now;}, 100, 1024);
  const auto goal = expected_goal();
  ASSERT_TRUE(gate.arm(5));
  ASSERT_TRUE(gate.reserve(uuid(1), goal, 5));
  EXPECT_FALSE(gate.close_generation(4));
  EXPECT_EQ(gate.admit(uuid(1), goal, 5), Result::ALLOW);
  ASSERT_TRUE(gate.arm(6));
  ASSERT_TRUE(gate.reserve(uuid(1), goal, 6));
  EXPECT_TRUE(gate.close_generation(6));
  EXPECT_EQ(gate.admit(uuid(1), goal, 6), Result::DENY_CLOSED);
}
