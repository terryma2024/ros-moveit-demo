// Copyright 2026 SO-101 maintainers

#include <gtest/gtest.h>
#include <mujoco/mujoco.h>

#include <algorithm>
#include <chrono>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <limits>
#include <memory>
#include <string>
#include <thread>
#include <type_traits>
#include <vector>

#include <mujoco_ros2_control_plugins/mujoco_ros2_control_plugin_capabilities.hpp>

#define private public
#include "so101_mujoco_support/simulation_evidence_plugin.hpp"
#undef private

static_assert(std::is_base_of_v<
  mujoco_ros2_control_plugins::MuJoCoROS2ControlSimulationObserver,
  so101_mujoco_support::SimulationEvidencePlugin>);

namespace
{
using so101_mujoco_support::EvidenceBuilder;
using so101_mujoco_support::EvidenceState;
using so101_mujoco_support::PhysicsStepEvidenceBuffer;
using so101_mujoco_support::SimulationEvidencePlugin;
using so101_mujoco_support::make_physics_step_evidence;
using so101_mujoco_support::make_cancellation_ack;
using so101_mujoco_support::msg::ContactSample;
using so101_mujoco_support::msg::PhysicsStepEvidence;
using so101_mujoco_support::msg::PhysicsStepEvidenceChunk;
using so101_mujoco_support::msg::PhysicsStepFenceAck;
using so101_mujoco_support::msg::PhysicsStepFenceRequest;
using so101_mujoco_support::msg::SimulationEvidence;

struct ModelDeleter
{
  void operator()(mjModel * value) const
  {
    mj_deleteModel(value);
  }
};
struct DataDeleter
{
  void operator()(mjData * value) const
  {
    mj_deleteData(value);
  }
};

class AtomicEvidenceTest : public ::testing::Test
{
protected:
  void SetUp() override
  {
    const auto xml_path = std::filesystem::temp_directory_path() / "so101_atomic_evidence.xml";
    std::ofstream(xml_path) <<
      R"(<mujoco><option timestep="0.001" gravity="0 0 -9.81"/>
      <worldbody><geom name="table" type="plane" size="1 1 .1"/>
      <body name="cup" pos="0 0 .08"><freejoint name="cup_joint"/><geom name="cup_geom" type="sphere" size=".05" mass=".1"/></body>
      <body name="left"><freejoint name="left_joint"/><geom name="left_tip" type="sphere" size=".02" mass=".1"/></body>
      <body name="right"><freejoint name="right_joint"/><geom name="right_tip" type="sphere" size=".02" mass=".1"/></body>
      <body name="mast" pos=".7 .2 .2"><freejoint name="mast_joint"/><geom name="mast_geom" type="sphere" size=".02" mass=".1"/></body>
      </worldbody></mujoco>)";
    char error[1024]{};
    model_.reset(mj_loadXML(xml_path.c_str(), nullptr, error, sizeof(error)));
    ASSERT_NE(model_, nullptr) << error;
    data_.reset(mj_makeData(model_.get()));
    ASSERT_NE(data_, nullptr);
    ASSERT_TRUE(builder_.configure(model_.get(), "cup", "left_tip", "right_tip", {"table"}, 32));
    state_.simulation_session_id = "session-a";
  }

  void place_free_body(const char * joint, double x, double y, double z)
  {
    const int id = mj_name2id(model_.get(), mjOBJ_JOINT, joint);
    ASSERT_GE(id, 0);
    const int address = model_->jnt_qposadr[id];
    data_->qpos[address] = x;
    data_->qpos[address + 1] = y;
    data_->qpos[address + 2] = z;
    data_->qpos[address + 3] = 1.0;
  }

  std::unique_ptr<mjModel, ModelDeleter> model_;
  std::unique_ptr<mjData, DataDeleter> data_;
  EvidenceBuilder builder_;
  EvidenceState state_;
};

TEST_F(AtomicEvidenceTest, ZeroContactSnapshotIsAtomicAndFinite)
{
  place_free_body("left_joint", -.3, 0, .2);
  place_free_body("right_joint", .3, 0, .2);
  mj_forward(model_.get(), data_.get());
  const auto message = builder_.build(model_.get(), data_.get(), false, state_);
  EXPECT_EQ(message.simulation_session_id, "session-a");
  EXPECT_EQ(message.reset_epoch, 0U);
  EXPECT_EQ(message.simulation_step, 0U);
  EXPECT_EQ(message.publisher_sequence, 0U);
  EXPECT_FALSE(message.paused);
  EXPECT_FALSE(message.has_contact);
  EXPECT_DOUBLE_EQ(message.minimum_signed_distance_m, 0.0);
  EXPECT_DOUBLE_EQ(message.maximum_normal_force_n, 0.0);
  EXPECT_TRUE(message.left_fingertip_contacts.empty());
  EXPECT_TRUE(message.right_fingertip_contacts.empty());
  EXPECT_TRUE(message.other_object_contacts.empty());
  EXPECT_EQ(message.object_body, "cup");
  EXPECT_GE(message.object_body_id, 0);
  EXPECT_EQ(message.header.frame_id, "world");
  EXPECT_TRUE(std::isfinite(message.object_pose_world.position.z));
}

TEST_F(AtomicEvidenceTest, PhysicsStepPoseMatchesPostIntegrationFreeJointState)
{
  place_free_body("cup_joint", 0, 0, .2);
  place_free_body("left_joint", -.3, 0, .2);
  place_free_body("right_joint", .3, 0, .2);
  mj_forward(model_.get(), data_.get());
  const int cup_joint = mj_name2id(model_.get(), mjOBJ_JOINT, "cup_joint");
  const int cup_body = mj_name2id(model_.get(), mjOBJ_BODY, "cup");
  const int address = model_->jnt_qposadr[cup_joint];
  mj_step(model_.get(), data_.get());
  ASSERT_GT(std::abs(data_->qpos[address + 2] - data_->xpos[3 * cup_body + 2]), 1e-8)
    << "this test must exercise MuJoCo's post-step derived-state lag";

  const auto step = builder_.build_step(model_.get(), data_.get(), false, state_, 0, 1.0, 10.0);
  ASSERT_EQ(step.model_qpos.size(), static_cast<std::size_t>(model_->nq));
  EXPECT_DOUBLE_EQ(step.object_pose_world.position.x, step.model_qpos[address]);
  EXPECT_DOUBLE_EQ(step.object_pose_world.position.y, step.model_qpos[address + 1]);
  EXPECT_DOUBLE_EQ(step.object_pose_world.position.z, step.model_qpos[address + 2]);
  EXPECT_DOUBLE_EQ(step.object_pose_world.orientation.w, step.model_qpos[address + 3]);
  EXPECT_DOUBLE_EQ(step.object_pose_world.orientation.x, step.model_qpos[address + 4]);
  EXPECT_DOUBLE_EQ(step.object_pose_world.orientation.y, step.model_qpos[address + 5]);
  EXPECT_DOUBLE_EQ(step.object_pose_world.orientation.z, step.model_qpos[address + 6]);
}

TEST_F(AtomicEvidenceTest, ResetGenerationIsTheOnlyEpochAuthority)
{
  mj_forward(model_.get(), data_.get());
  const auto first = builder_.build(model_.get(), data_.get(), false, state_, 0);
  data_->time = .001;
  const auto second = builder_.build(model_.get(), data_.get(), false, state_, 0);
  data_->time = 0.0;
  const auto time_decrease = builder_.build(model_.get(), data_.get(), false, state_, 0);
  const auto reset = builder_.build(model_.get(), data_.get(), false, state_, 1);
  EXPECT_EQ(second.publisher_sequence, first.publisher_sequence + 1);
  EXPECT_EQ(second.simulation_step, first.simulation_step + 1);
  EXPECT_EQ(time_decrease.reset_epoch, first.reset_epoch);
  EXPECT_EQ(time_decrease.simulation_step, second.simulation_step);
  EXPECT_EQ(reset.reset_epoch, first.reset_epoch + 1);
  EXPECT_EQ(reset.simulation_step, 0U);
  EXPECT_EQ(reset.simulation_session_id, first.simulation_session_id);
  EXPECT_EQ(reset.publisher_sequence, time_decrease.publisher_sequence + 1);
}

TEST(CancellationEvidenceTest, AckUsesPluginPhysicsStepAsConservativeRequestUpperBound)
{
  so101_mujoco_support::msg::PhysicsCancellationRequest request;
  request.simulation_session_id = "session-a";
  request.reset_epoch = 4;
  request.hazard_physics_step = 100;
  request.request_sequence = 7;

  const auto ack = make_cancellation_ack(request, 4, 123, 0.246);

  EXPECT_EQ(ack.simulation_session_id, "session-a");
  EXPECT_EQ(ack.reset_epoch, 4U);
  EXPECT_EQ(ack.hazard_physics_step, 100U);
  EXPECT_EQ(ack.request_sequence, 7U);
  EXPECT_EQ(ack.observed_physics_step, 123U);
  EXPECT_DOUBLE_EQ(ack.observed_simulation_time_s, 0.246);
  EXPECT_EQ(ack.observed_physics_step - ack.hazard_physics_step, 23U);
}

TEST(SimulationEvidencePluginParameterScopeTest,
     SubNodeTypedLookupUsesSlashScopedOverrideWhilePluginLookupReadsRoot)
{
  if (!rclcpp::ok()) {
    rclcpp::init(0, nullptr);
  }
  auto root_only_options = rclcpp::NodeOptions()
    .parameter_overrides({rclcpp::Parameter("simulation_session_id", "root-session")})
    .automatically_declare_parameters_from_overrides(true);
  auto root_only = std::make_shared<rclcpp::Node>("root_only_session", root_only_options);
  auto root_only_plugin = root_only->create_sub_node("simulation_evidence");
  std::string resolved;
  EXPECT_EQ(root_only_plugin->get_sub_namespace(), "simulation_evidence");
  EXPECT_FALSE(root_only_plugin->get_parameter("simulation_session_id", resolved));
  ASSERT_TRUE(root_only_plugin->has_parameter("simulation_session_id"));
  EXPECT_EQ(
    root_only_plugin->get_parameter("simulation_session_id").as_string(), "root-session");

  auto scoped_options = rclcpp::NodeOptions()
    .parameter_overrides({
      rclcpp::Parameter("simulation_session_id", "root-session"),
      rclcpp::Parameter("simulation_evidence/simulation_session_id", "plugin-session"),
    })
    .automatically_declare_parameters_from_overrides(true);
  auto scoped = std::make_shared<rclcpp::Node>("scoped_session", scoped_options);
  auto scoped_plugin = scoped->create_sub_node("simulation_evidence");
  ASSERT_TRUE(scoped_plugin->get_parameter("simulation_session_id", resolved));
  EXPECT_EQ(resolved, "plugin-session");
  rclcpp::shutdown();
}

TEST_F(AtomicEvidenceTest, ConsumesAllResetGenerationIncrementsWithoutLoss)
{
  mj_forward(model_.get(), data_.get());
  const auto first = builder_.build(model_.get(), data_.get(), false, state_, 0);
  const auto reset_twice = builder_.build(model_.get(), data_.get(), false, state_, 2);
  const auto unchanged = builder_.build(model_.get(), data_.get(), false, state_, 2);
  EXPECT_EQ(reset_twice.reset_epoch, first.reset_epoch + 2);
  EXPECT_EQ(reset_twice.simulation_step, 0U);
  EXPECT_EQ(unchanged.reset_epoch, reset_twice.reset_epoch);
  EXPECT_EQ(unchanged.simulation_step, reset_twice.simulation_step);
}

TEST_F(AtomicEvidenceTest, ClassifiesLeftRightAndOtherContactsWithIdsAndAggregates)
{
  place_free_body("left_joint", -.045, 0, .08);
  place_free_body("right_joint", .045, 0, .08);
  mj_forward(model_.get(), data_.get());
  const auto message = builder_.build(model_.get(), data_.get(), false, state_);
  ASSERT_TRUE(message.has_contact);
  EXPECT_FALSE(message.left_fingertip_contacts.empty());
  EXPECT_FALSE(message.right_fingertip_contacts.empty());
  EXPECT_LE(message.minimum_signed_distance_m, 0.0);
  EXPECT_GE(message.maximum_normal_force_n, 0.0);
  double observed_minimum = std::numeric_limits<double>::infinity();
  double observed_maximum_force = 0.0;
  for (const auto * contacts :
    {&message.left_fingertip_contacts, &message.right_fingertip_contacts})
  {
    for (const auto & contact : *contacts) {
      EXPECT_GE(contact.body1_id, 0);
      EXPECT_GE(contact.geom1_id, 0);
      EXPECT_GE(contact.body2_id, 0);
      EXPECT_GE(contact.geom2_id, 0);
      EXPECT_FALSE(contact.body1.empty());
      EXPECT_FALSE(contact.geom1.empty());
      EXPECT_FALSE(contact.body2.empty());
      EXPECT_FALSE(contact.geom2.empty());
      EXPECT_EQ(contact.body1, mj_id2name(model_.get(), mjOBJ_BODY, contact.body1_id));
      EXPECT_EQ(contact.geom1, mj_id2name(model_.get(), mjOBJ_GEOM, contact.geom1_id));
      EXPECT_EQ(contact.body2, mj_id2name(model_.get(), mjOBJ_BODY, contact.body2_id));
      EXPECT_EQ(contact.geom2, mj_id2name(model_.get(), mjOBJ_GEOM, contact.geom2_id));
      EXPECT_GE(contact.normal_force_n, 0.0);
      EXPECT_TRUE(std::isfinite(contact.signed_distance_m));
      EXPECT_TRUE(std::isfinite(contact.position_world.x));
      EXPECT_TRUE(std::isfinite(contact.normal_world.x));
      observed_minimum = std::min(observed_minimum, contact.signed_distance_m);
      observed_maximum_force = std::max(observed_maximum_force, contact.normal_force_n);
    }
  }
  EXPECT_DOUBLE_EQ(message.minimum_signed_distance_m, observed_minimum);
  EXPECT_DOUBLE_EQ(message.maximum_normal_force_n, observed_maximum_force);
}

TEST_F(AtomicEvidenceTest, CopiedContactSnapshotWithoutSolverForcesFailsClosed)
{
  place_free_body("left_joint", -.045, 0, .08);
  place_free_body("right_joint", .045, 0, .08);
  mj_forward(model_.get(), data_.get());
  ASSERT_GT(data_->ncon, 0);

  std::unique_ptr<mjData, DataDeleter> snapshot(mj_makeData(model_.get()));
  ASSERT_NE(snapshot, nullptr);
  ASSERT_NE(mj_copyData(snapshot.get(), model_.get(), data_.get()), nullptr);
  ASSERT_GT(snapshot->ncon, 0);

  auto * solver_forces = snapshot->efc_force;
  ASSERT_GT(snapshot->nefc, 0);
  ASSERT_NE(solver_forces, nullptr);
  snapshot->efc_force = nullptr;
  const auto message = builder_.build(model_.get(), snapshot.get(), false, state_);
  snapshot->efc_force = solver_forces;

  EXPECT_TRUE(message.truncated);
  EXPECT_FALSE(message.has_contact);
  EXPECT_TRUE(message.left_fingertip_contacts.empty());
  EXPECT_TRUE(message.right_fingertip_contacts.empty());
}

TEST(SimulationEvidencePluginContactSets,
     ClassifiesEveryConfiguredFingertipGeomWithoutAggregateCollision)
{
  const auto xml_path =
    std::filesystem::temp_directory_path() / "so101_atomic_evidence_contact_sets.xml";
  std::ofstream(xml_path) <<
      R"(<mujoco><option gravity="0 0 0"/>
    <worldbody>
      <body name="cup"><freejoint name="cup_joint"/>
        <geom name="cup_geom" type="sphere" size=".02" mass=".02"/>
      </body>
      <body name="left"><freejoint name="left_joint"/>
        <geom name="left_a" type="sphere" pos="-.04 0 0" size=".02" mass=".01"/>
        <geom name="left_b" type="sphere" pos=".04 0 0" size=".02" mass=".01"/>
      </body>
      <body name="right"><freejoint name="right_joint"/>
        <geom name="right_a" type="sphere" pos="-.04 0 0" size=".02" mass=".01"/>
        <geom name="right_b" type="sphere" pos=".04 0 0" size=".02" mass=".01"/>
      </body>
    </worldbody></mujoco>)";
  char error[1024]{};
  std::unique_ptr<mjModel, ModelDeleter> model(
    mj_loadXML(xml_path.c_str(), nullptr, error, sizeof(error)));
  ASSERT_NE(model, nullptr) << error;
  std::unique_ptr<mjData, DataDeleter> data(mj_makeData(model.get()));
  ASSERT_NE(data, nullptr);
  EvidenceBuilder builder;
  ASSERT_TRUE(builder.configure(model.get(), "cup", std::vector<std::string>{"left_a", "left_b"},
                                std::vector<std::string>{"right_a", "right_b"}, {}, 32));

  EvidenceState state;
  state.simulation_session_id = "contact-set-test";
  const int left_address = model->jnt_qposadr[mj_name2id(model.get(), mjOBJ_JOINT, "left_joint")];
  const int right_address = model->jnt_qposadr[mj_name2id(model.get(), mjOBJ_JOINT, "right_joint")];
  data->qpos[left_address] = 0.04;
  data->qpos[left_address + 3] = 1.0;
  data->qpos[right_address] = -0.04;
  data->qpos[right_address + 3] = 1.0;
  mj_forward(model.get(), data.get());

  const auto first = builder.build(model.get(), data.get(), false, state);
  ASSERT_FALSE(first.left_fingertip_contacts.empty());
  ASSERT_FALSE(first.right_fingertip_contacts.empty());
  EXPECT_EQ(first.left_fingertip_contacts.front().geom2, "left_a");
  EXPECT_EQ(first.right_fingertip_contacts.front().geom2, "right_b");

  data->qpos[left_address] = -0.04;
  data->qpos[right_address] = 0.04;
  mj_forward(model.get(), data.get());
  const auto second = builder.build(model.get(), data.get(), false, state);
  ASSERT_FALSE(second.left_fingertip_contacts.empty());
  ASSERT_FALSE(second.right_fingertip_contacts.empty());
  EXPECT_EQ(second.left_fingertip_contacts.front().geom2, "left_b");
  EXPECT_EQ(second.right_fingertip_contacts.front().geom2, "right_a");
}

TEST_F(AtomicEvidenceTest, MarksPausedAndTruncatesBoundedContacts)
{
  mj_forward(model_.get(), data_.get());
  const auto running = builder_.build(model_.get(), data_.get(), false, state_);
  const auto paused = builder_.build(model_.get(), data_.get(), true, state_);
  EXPECT_TRUE(paused.paused);
  EXPECT_EQ(paused.publisher_sequence, 1U);
  EXPECT_EQ(paused.simulation_step, running.simulation_step);
}

TEST_F(AtomicEvidenceTest, PluginPublishesAuthoritativePausedResetOnlyFromSnapshotHook)
{
  if (!rclcpp::ok()) {
    rclcpp::init(0, nullptr);
  }
  const auto topic = "/test/so101/authoritative_pause";
  auto options = rclcpp::NodeOptions().parameter_overrides({
      rclcpp::Parameter("object_body", "cup"),
      rclcpp::Parameter("left_fingertip_geoms", std::vector<std::string>{"left_tip"}),
      rclcpp::Parameter("right_fingertip_geoms", std::vector<std::string>{"right_tip"}),
      rclcpp::Parameter("other_contact_geoms", std::vector<std::string>{"table"}),
      rclcpp::Parameter("simulation_session_id", "pause-test"),
      rclcpp::Parameter("publish_rate", 100.0),
      rclcpp::Parameter("topic", topic),
  });
  auto plugin_node = std::make_shared<rclcpp::Node>("authoritative_pause_plugin", options);
  auto observer_node = std::make_shared<rclcpp::Node>("authoritative_pause_observer");
  std::vector<SimulationEvidence> messages;
  const auto subscription = observer_node->create_subscription<SimulationEvidence>(
    topic, rclcpp::SensorDataQoS(),
    [&messages](const SimulationEvidence & message) {messages.push_back(message);});
  (void)subscription;
  SimulationEvidencePlugin plugin;
  ASSERT_TRUE(plugin.init(plugin_node, model_.get(), data_.get()));
  rclcpp::executors::SingleThreadedExecutor executor;
  executor.add_node(plugin_node);
  executor.add_node(observer_node);

  const auto spin_until = [&executor, &messages](std::size_t expected) {
      const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(2);
      while (messages.size() < expected && std::chrono::steady_clock::now() < deadline) {
        executor.spin_some();
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
      }
    };

  plugin.on_pause(false);
  plugin.update(model_.get(), data_.get());
  spin_until(1);
  ASSERT_EQ(messages.size(), 1U);
  EXPECT_FALSE(messages.back().paused);
  EXPECT_EQ(messages.back().reset_epoch, 0U);

  plugin.on_pause(true);
  plugin.on_reset();
  data_->time = 0.001;
  plugin.update(model_.get(), data_.get());
  executor.spin_some();
  ASSERT_EQ(messages.size(), 1U) << "running update must retain pending reset generation";
  plugin.on_state_snapshot(model_.get(), data_.get(), true);
  spin_until(2);
  ASSERT_EQ(messages.size(), 2U) << "paused snapshot must bypass the ordinary rate gate";
  EXPECT_TRUE(messages.back().paused);
  EXPECT_EQ(messages.back().reset_epoch, 1U);
  EXPECT_EQ(messages.back().simulation_step, 0U);

  plugin.on_pause(false);
  data_->time = 0.002;
  plugin.update(model_.get(), data_.get());
  executor.spin_some();
  EXPECT_EQ(messages.size(), 2U) << "ordinary updates remain rate limited";

  data_->time = 0.02;
  plugin.update(model_.get(), data_.get());
  spin_until(3);
  ASSERT_EQ(messages.size(), 3U);
  EXPECT_FALSE(messages.back().paused);
  plugin.cleanup();
  executor.remove_node(observer_node);
  executor.remove_node(plugin_node);
  rclcpp::shutdown();
}

TEST_F(AtomicEvidenceTest, LateJoiningObserverReceivesLatestAuthoritativePausedSnapshot)
{
  if (!rclcpp::ok()) {
    rclcpp::init(0, nullptr);
  }
  const auto topic = "/test/so101/late_join_paused_snapshot";
  auto options = rclcpp::NodeOptions().parameter_overrides({
      rclcpp::Parameter("object_body", "cup"),
      rclcpp::Parameter("left_fingertip_geoms", std::vector<std::string>{"left_tip"}),
      rclcpp::Parameter("right_fingertip_geoms", std::vector<std::string>{"right_tip"}),
      rclcpp::Parameter("other_contact_geoms", std::vector<std::string>{"table"}),
      rclcpp::Parameter("simulation_session_id", "late-join-test"),
      rclcpp::Parameter("publish_rate", 100.0),
      rclcpp::Parameter("topic", topic),
  });
  auto plugin_node = std::make_shared<rclcpp::Node>("late_join_snapshot_plugin", options);
  SimulationEvidencePlugin plugin;
  ASSERT_TRUE(plugin.init(plugin_node, model_.get(), data_.get()));

  plugin.on_pause(true);
  plugin.on_state_snapshot(model_.get(), data_.get(), true);

  auto observer_node = std::make_shared<rclcpp::Node>("late_join_snapshot_observer");
  std::vector<SimulationEvidence> messages;
  const auto qos = rclcpp::QoS(rclcpp::KeepLast(1)).reliable().transient_local();
  const auto subscription = observer_node->create_subscription<SimulationEvidence>(
    topic, qos, [&messages](const SimulationEvidence & message) {messages.push_back(message);});
  (void)subscription;
  rclcpp::executors::SingleThreadedExecutor executor;
  executor.add_node(plugin_node);
  executor.add_node(observer_node);
  const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(2);
  while (messages.empty() && std::chrono::steady_clock::now() < deadline) {
    executor.spin_some();
    std::this_thread::sleep_for(std::chrono::milliseconds(1));
  }

  ASSERT_EQ(messages.size(), 1U);
  EXPECT_TRUE(messages.back().paused);
  EXPECT_EQ(messages.back().simulation_session_id, "late-join-test");
  plugin.cleanup();
  executor.remove_node(observer_node);
  executor.remove_node(plugin_node);
  rclcpp::shutdown();
}

TEST_F(AtomicEvidenceTest,
       RunningUpdateRetainsPendingGenerationUntilPausedSnapshotPublishesStepZero)
{
  if (!rclcpp::ok()) {
    rclcpp::init(0, nullptr);
  }
  const auto topic = "/test/so101/pending_until_snapshot";
  auto options = rclcpp::NodeOptions().parameter_overrides({
      rclcpp::Parameter("object_body", "cup"),
      rclcpp::Parameter("left_fingertip_geom", "left_tip"),
      rclcpp::Parameter("right_fingertip_geom", "right_tip"),
      rclcpp::Parameter("other_contact_geoms", std::vector<std::string>{"table"}),
      rclcpp::Parameter("simulation_session_id", "snapshot-test"),
      rclcpp::Parameter("publish_rate", 100.0),
      rclcpp::Parameter("topic", topic),
  });
  auto plugin_node = std::make_shared<rclcpp::Node>("pending_snapshot_plugin", options);
  auto observer_node = std::make_shared<rclcpp::Node>("pending_snapshot_observer");
  std::vector<SimulationEvidence> messages;
  const auto subscription = observer_node->create_subscription<SimulationEvidence>(
    topic, rclcpp::SensorDataQoS(),
    [&messages](const SimulationEvidence & message) {messages.push_back(message);});
  (void)subscription;
  SimulationEvidencePlugin plugin;
  ASSERT_TRUE(plugin.init(plugin_node, model_.get(), data_.get()));
  rclcpp::executors::SingleThreadedExecutor executor;
  executor.add_node(plugin_node);
  executor.add_node(observer_node);
  const auto spin_until = [&executor, &messages](std::size_t expected) {
      const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(2);
      while (messages.size() < expected && std::chrono::steady_clock::now() < deadline) {
        executor.spin_some();
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
      }
    };

  plugin.on_pause(false);
  plugin.update(model_.get(), data_.get());
  spin_until(1);
  ASSERT_EQ(messages.size(), 1U);
  plugin.on_reset();
  data_->time = 0.001;
  plugin.update(model_.get(), data_.get());
  executor.spin_some();
  EXPECT_EQ(messages.size(), 1U) << "running update must not expose or consume pending epoch";

  const std::vector<mjtNum> qpos(data_->qpos, data_->qpos + model_->nq);
  const std::vector<mjtNum> qvel(data_->qvel, data_->qvel + model_->nv);
  const std::vector<mjtNum> ctrl(data_->ctrl, data_->ctrl + model_->nu);
  const std::vector<mjtNum> xfrc(data_->xfrc_applied, data_->xfrc_applied + 6 * model_->nbody);
  plugin.on_pause(true);
  plugin.on_state_snapshot(model_.get(), data_.get(), true);
  spin_until(2);
  ASSERT_EQ(messages.size(), 2U);
  EXPECT_EQ(messages.back().reset_epoch, 1U);
  EXPECT_EQ(messages.back().simulation_step, 0U);
  EXPECT_TRUE(messages.back().paused);
  EXPECT_EQ(plugin.physics_state_.reset_epoch, 1U);
  EXPECT_EQ(plugin.physics_state_.consumed_reset_generation, 1U);
  EXPECT_EQ(plugin.physics_state_.simulation_step, 0U);
  EXPECT_DOUBLE_EQ(plugin.physics_state_.previous_time, 0.001);
  EXPECT_EQ(std::vector<mjtNum>(data_->qpos, data_->qpos + model_->nq), qpos);
  EXPECT_EQ(std::vector<mjtNum>(data_->qvel, data_->qvel + model_->nv), qvel);
  EXPECT_EQ(std::vector<mjtNum>(data_->ctrl, data_->ctrl + model_->nu), ctrl);
  EXPECT_EQ(std::vector<mjtNum>(data_->xfrc_applied, data_->xfrc_applied + 6 * model_->nbody),
            xfrc);

  plugin.on_pause(false);
  data_->time = 0.002;
  plugin.on_physics_step(model_.get(), data_.get());
  const auto first_post_reset_chunk = plugin.physics_step_buffer_->prepare_chunk();
  ASSERT_EQ(first_post_reset_chunk.samples.size(), 1U);
  EXPECT_EQ(first_post_reset_chunk.simulation_session_id, "snapshot-test");
  EXPECT_EQ(first_post_reset_chunk.reset_epoch, 1U);
  EXPECT_EQ(first_post_reset_chunk.first_physics_step, 1U);

  plugin.cleanup();
  executor.remove_node(observer_node);
  executor.remove_node(plugin_node);
  rclcpp::shutdown();
}

TEST_F(AtomicEvidenceTest, SnapshotPublisherContentionKeepsGenerationPendingForIdempotentRetry)
{
  if (!rclcpp::ok()) {
    rclcpp::init(0, nullptr);
  }
  const auto topic = "/test/so101/snapshot_contention";
  auto options = rclcpp::NodeOptions().parameter_overrides({
      rclcpp::Parameter("object_body", "cup"),
      rclcpp::Parameter("left_fingertip_geom", "left_tip"),
      rclcpp::Parameter("right_fingertip_geom", "right_tip"),
      rclcpp::Parameter("other_contact_geoms", std::vector<std::string>{"table"}),
      rclcpp::Parameter("simulation_session_id", "contention-test"),
      rclcpp::Parameter("publish_rate", 100.0),
      rclcpp::Parameter("topic", topic),
  });
  auto plugin_node = std::make_shared<rclcpp::Node>("snapshot_contention_plugin", options);
  auto observer_node = std::make_shared<rclcpp::Node>("snapshot_contention_observer");
  std::vector<SimulationEvidence> messages;
  const auto subscription = observer_node->create_subscription<SimulationEvidence>(
    topic, rclcpp::SensorDataQoS(),
    [&messages](const SimulationEvidence & message) {messages.push_back(message);});
  (void)subscription;
  SimulationEvidencePlugin plugin;
  ASSERT_TRUE(plugin.init(plugin_node, model_.get(), data_.get()));
  rclcpp::executors::SingleThreadedExecutor executor;
  executor.add_node(plugin_node);
  executor.add_node(observer_node);

  plugin.on_reset();
  plugin.on_pause(true);
  ASSERT_TRUE(plugin.realtime_publisher_->trylock());
  plugin.on_state_snapshot(model_.get(), data_.get(), true);
  plugin.realtime_publisher_->unlock();
  executor.spin_some();
  EXPECT_TRUE(messages.empty()) << "contended snapshot must not publish or consume generation";

  plugin.on_state_snapshot(model_.get(), data_.get(), true);
  const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(2);
  while (messages.empty() && std::chrono::steady_clock::now() < deadline) {
    executor.spin_some();
    std::this_thread::sleep_for(std::chrono::milliseconds(1));
  }
  ASSERT_EQ(messages.size(), 1U);
  EXPECT_EQ(messages.back().reset_epoch, 1U);
  EXPECT_EQ(messages.back().simulation_step, 0U);
  EXPECT_TRUE(messages.back().paused);

  data_->time = 0.001;
  plugin.update(model_.get(), data_.get());
  executor.spin_some();
  EXPECT_EQ(messages.size(), 1U) << "no-pending ordinary update must keep the existing cadence";
  plugin.cleanup();
  executor.remove_node(observer_node);
  executor.remove_node(plugin_node);
  rclcpp::shutdown();
}

TEST_F(AtomicEvidenceTest, SeparatesOtherObjectContactAndHonorsGlobalBound)
{
  place_free_body("cup_joint", 0, 0, .04);
  place_free_body("left_joint", -.3, 0, .2);
  place_free_body("right_joint", .3, 0, .2);
  mj_forward(model_.get(), data_.get());
  const auto table_contact = builder_.build(model_.get(), data_.get(), false, state_);
  ASSERT_FALSE(table_contact.other_object_contacts.empty());
  EXPECT_EQ(table_contact.other_object_contacts.front().geom2, "table");

  EvidenceBuilder bounded;
  ASSERT_TRUE(bounded.configure(model_.get(), "cup", "left_tip", "right_tip", {"table"}, 0));
  EvidenceState bounded_state;
  bounded_state.simulation_session_id = "bounded";
  const auto truncated = bounded.build(model_.get(), data_.get(), false, bounded_state);
  EXPECT_TRUE(truncated.truncated);
  EXPECT_TRUE(truncated.other_object_contacts.empty());
}

PhysicsStepEvidence physics_step_sample(uint64_t step, double force_n)
{
  PhysicsStepEvidence sample;
  sample.simulation_session_id = "phase-aware-test";
  sample.reset_epoch = 3;
  sample.physics_step = step;
  sample.simulation_time_s = static_cast<double>(step) * 0.002;
  sample.maximum_normal_force_n = force_n;
  sample.global_max_single_contact_force_n = force_n;
  sample.total_normal_force_n = force_n;
  return sample;
}

TEST(PhysicsStepEvidenceBufferTest, KeepsIntermediateFiveHundredHertzSpikeInHundredHertzChunk)
{
  PhysicsStepEvidenceBuffer buffer(64, 5, 11.60);
  const std::vector<double> forces{1.0, 2.0, 12.0, 2.0, 1.0};
  for (std::size_t index = 0; index < forces.size(); ++index) {
    ASSERT_TRUE(buffer.append(physics_step_sample(index + 1, forces[index])));
  }

  ASSERT_TRUE(buffer.ready());
  const auto chunk = buffer.prepare_chunk();
  ASSERT_EQ(chunk.samples.size(), 5U);
  EXPECT_EQ(chunk.first_physics_step, 1U);
  EXPECT_EQ(chunk.last_physics_step, 5U);
  EXPECT_DOUBLE_EQ(chunk.samples[2].global_max_single_contact_force_n, 12.0);
  EXPECT_FALSE(chunk.evidence_loss);
}

TEST(PhysicsStepEvidenceBufferTest, FailedPublishAttemptRetainsContinuousRangeAndIsDetectable)
{
  PhysicsStepEvidenceBuffer buffer(64, 5, 11.60);
  for (uint64_t step = 1; step <= 5; ++step) {
    ASSERT_TRUE(buffer.append(physics_step_sample(step, static_cast<double>(step))));
  }
  const auto first_attempt = buffer.prepare_chunk();
  buffer.mark_publish_failed();
  const auto retry = buffer.prepare_chunk();

  ASSERT_EQ(first_attempt.samples.size(), retry.samples.size());
  EXPECT_EQ(retry.first_physics_step, 1U);
  EXPECT_EQ(retry.last_physics_step, 5U);
  EXPECT_EQ(retry.failed_publish_attempts, 1U);
  for (std::size_t index = 0; index < retry.samples.size(); ++index) {
    EXPECT_EQ(retry.samples[index].physics_step, index + 1);
  }
}

TEST(PhysicsStepEvidenceBufferTest, EmptyLossSentinelRetainsTheLastObservedIdentity)
{
  PhysicsStepEvidenceBuffer buffer(64, 5, 11.60);
  for (uint64_t step = 1; step <= 5; ++step) {
    ASSERT_TRUE(buffer.append(physics_step_sample(step, 1.0)));
  }
  ASSERT_TRUE(buffer.ready());
  buffer.mark_published();
  ASSERT_FALSE(buffer.append(physics_step_sample(7, 1.0)));

  const auto sentinel = buffer.prepare_chunk();

  EXPECT_TRUE(sentinel.evidence_loss);
  EXPECT_TRUE(sentinel.samples.empty());
  EXPECT_EQ(sentinel.simulation_session_id, "phase-aware-test");
  EXPECT_EQ(sentinel.reset_epoch, 3U);
}

TEST(PhysicsStepEvidenceBufferTest, EqualityBreachesAndFirstHazardLatchCannotBeOverwritten)
{
  PhysicsStepEvidenceBuffer buffer(64, 5, 11.60);
  ASSERT_TRUE(buffer.append(physics_step_sample(1, 11.59)));
  ASSERT_TRUE(buffer.append(physics_step_sample(2, 11.60)));
  ASSERT_TRUE(buffer.append(physics_step_sample(3, 15.0)));
  ASSERT_TRUE(buffer.append(physics_step_sample(4, 1.0)));

  const auto hazard = buffer.hazard_latch();
  ASSERT_TRUE(hazard.has_value());
  EXPECT_EQ(hazard->physics_step, 2U);
  EXPECT_DOUBLE_EQ(hazard->simulation_time_s, 0.004);
  EXPECT_DOUBLE_EQ(hazard->force_n, 11.60);
  EXPECT_EQ(hazard->simulation_session_id, "phase-aware-test");
  EXPECT_EQ(hazard->reset_epoch, 3U);
}

TEST(PhysicsStepEvidenceBufferTest, SummedContactsLatchBeforeAnySingleContactReachesLimit)
{
  PhysicsStepEvidenceBuffer buffer(64, 5, 11.60);
  auto sample = physics_step_sample(1, 6.0);
  sample.total_normal_force_n = 12.0;
  ASSERT_TRUE(buffer.append(sample));
  const auto hazard = buffer.hazard_latch();
  ASSERT_TRUE(hazard.has_value());
  EXPECT_EQ(hazard->physics_step, 1U);
  EXPECT_DOUBLE_EQ(hazard->force_n, 12.0);
}

TEST(PhysicsStepEvidenceMetricsTest, KeepsForceSemanticsSeparateAndCompressionFingertipOnly)
{
  SimulationEvidence snapshot;
  snapshot.simulation_session_id = "metric-test";
  snapshot.reset_epoch = 4;
  snapshot.simulation_step = 10;
  snapshot.has_contact = true;
  snapshot.maximum_normal_force_n = 5.0;
  const auto contact = [](double force, double distance, double nx, double ny, double nz) {
      ContactSample sample;
      sample.normal_force_n = force;
      sample.signed_distance_m = distance;
      sample.normal_world.x = nx;
      sample.normal_world.y = ny;
      sample.normal_world.z = nz;
      return sample;
    };
  snapshot.left_fingertip_contacts = {
    contact(2.0, -0.001, 1.0, 0.0, 0.0),
    contact(3.0, -0.002, 1.0, 0.0, 0.0),
  };
  snapshot.right_fingertip_contacts = {
    contact(4.0, -0.003, 0.0, 1.0, 0.0),
  };
  snapshot.other_object_contacts = {
    contact(5.0, -0.010, 0.0, 0.0, 1.0),
  };

  const auto sample = make_physics_step_evidence(snapshot, 0.020, 1.1579004532160448, 11.60);

  EXPECT_DOUBLE_EQ(sample.maximum_normal_force_n, 5.0);
  EXPECT_DOUBLE_EQ(sample.global_max_single_contact_force_n, 5.0);
  EXPECT_DOUBLE_EQ(sample.total_normal_force_n, 14.0);
  EXPECT_DOUBLE_EQ(sample.left_fingertip_total_normal_force_n, 5.0);
  EXPECT_DOUBLE_EQ(sample.right_fingertip_total_normal_force_n, 4.0);
  EXPECT_DOUBLE_EQ(sample.fingertip_max_single_contact_force_n, 4.0);
  EXPECT_DOUBLE_EQ(sample.left_fingertip_compression_m, 0.002);
  EXPECT_DOUBLE_EQ(sample.right_fingertip_compression_m, 0.003);
  EXPECT_DOUBLE_EQ(sample.net_contact_force_world_n.x, 5.0);
  EXPECT_DOUBLE_EQ(sample.net_contact_force_world_n.y, 4.0);
  EXPECT_DOUBLE_EQ(sample.net_contact_force_world_n.z, 5.0);
  EXPECT_TRUE(sample.static_shadow_crossed);
  EXPECT_TRUE(sample.diagnostic_hazard_breached);
}

TEST_F(AtomicEvidenceTest, PhysicsHookAdvancesAtFiveHundredHertzNotControllerCadence)
{
  if (!rclcpp::ok()) {
    rclcpp::init(0, nullptr);
  }
  model_->opt.timestep = 0.002;
  const auto chunk_topic = "/test/so101/physics_step_chunks";
  auto options = rclcpp::NodeOptions().parameter_overrides({
      rclcpp::Parameter("object_body", "cup"),
      rclcpp::Parameter("left_fingertip_geom", "left_tip"),
      rclcpp::Parameter("right_fingertip_geom", "right_tip"),
      rclcpp::Parameter("other_contact_geoms", std::vector<std::string>{"table"}),
      rclcpp::Parameter("simulation_session_id", "physics-step-test"),
      rclcpp::Parameter("publish_rate", 100.0),
      rclcpp::Parameter("topic", "/test/so101/physics_step_snapshot"),
      rclcpp::Parameter("physics_step_topic", chunk_topic),
  });
  auto node = std::make_shared<rclcpp::Node>("physics_step_plugin", options);
  auto observer = std::make_shared<rclcpp::Node>("physics_step_observer");
  std::vector<PhysicsStepEvidenceChunk> chunks;
  const auto subscription = observer->create_subscription<PhysicsStepEvidenceChunk>(
    chunk_topic, rclcpp::QoS(rclcpp::KeepLast(10)).reliable(),
    [&chunks](const PhysicsStepEvidenceChunk & message) {chunks.push_back(message);});
  (void)subscription;
  SimulationEvidencePlugin plugin;
  ASSERT_TRUE(plugin.init(node, model_.get(), data_.get()));
  EXPECT_GE(plugin.publisher_->get_actual_qos().get_rmw_qos_profile().depth, 256U);
  rclcpp::executors::SingleThreadedExecutor executor;
  executor.add_node(node);
  executor.add_node(observer);

  plugin.on_physics_step(model_.get(), data_.get());
  for (uint64_t step = 1; step <= 5; ++step) {
    data_->time = static_cast<double>(step) * model_->opt.timestep;
    plugin.on_physics_step(model_.get(), data_.get());
  }

  EXPECT_EQ(plugin.physics_state_.simulation_step, 5U);
  EXPECT_FALSE(plugin.physics_step_buffer_->evidence_loss_latched());
  const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(2);
  while (chunks.empty() && std::chrono::steady_clock::now() < deadline) {
    executor.spin_some();
    std::this_thread::sleep_for(std::chrono::milliseconds(1));
  }
  ASSERT_EQ(chunks.size(), 1U);
  ASSERT_EQ(chunks.front().samples.size(), 5U);
  int64_t previous_clock_end_ns = 0;
  for (const auto & sample : chunks.front().samples) {
    EXPECT_GT(sample.clock_interval_begin_monotonic_ns, previous_clock_end_ns);
    EXPECT_GE(sample.clock_interval_end_monotonic_ns,
      sample.clock_interval_begin_monotonic_ns);
    previous_clock_end_ns = sample.clock_interval_end_monotonic_ns;
    EXPECT_EQ(sample.model_qpos.size(), static_cast<std::size_t>(model_->nq));
    EXPECT_EQ(sample.model_qvel.size(), static_cast<std::size_t>(model_->nv));
    for (int i = 0; i < model_->nq; ++i) {
      EXPECT_DOUBLE_EQ(sample.model_qpos[i], data_->qpos[i]);
    }
    for (int i = 0; i < model_->nv; ++i) {
      EXPECT_DOUBLE_EQ(sample.model_qvel[i], data_->qvel[i]);
    }
  }
  EXPECT_EQ(chunks.front().first_physics_step, 1U);
  EXPECT_EQ(chunks.front().last_physics_step, 5U);
  EXPECT_EQ(chunks.front().simulation_session_id, "physics-step-test");
  plugin.cleanup();
  executor.remove_node(observer);
  executor.remove_node(node);
  rclcpp::shutdown();
}

TEST_F(AtomicEvidenceTest, PhysicsFenceAckCarriesClockBoundsFromTheActualStepHook)
{
  if (!rclcpp::ok()) {
    rclcpp::init(0, nullptr);
  }
  model_->opt.timestep = .002;
  const auto ack_topic = "/test/so101/physics_clock_ack";
  auto options = rclcpp::NodeOptions().parameter_overrides({
      rclcpp::Parameter("object_body", "cup"),
      rclcpp::Parameter("left_fingertip_geom", "left_tip"),
      rclcpp::Parameter("right_fingertip_geom", "right_tip"),
      rclcpp::Parameter("other_contact_geoms", std::vector<std::string>{"table"}),
      rclcpp::Parameter("simulation_session_id", "clock-test"),
      rclcpp::Parameter("physics_step_fence_ack_topic", ack_topic),
  });
  auto node = std::make_shared<rclcpp::Node>("physics_clock_plugin", options);
  auto observer = std::make_shared<rclcpp::Node>("physics_clock_observer");
  std::vector<PhysicsStepFenceAck> acknowledgements;
  const auto subscription = observer->create_subscription<PhysicsStepFenceAck>(
    ack_topic, rclcpp::QoS(rclcpp::KeepLast(5)).reliable(),
    [&acknowledgements](const PhysicsStepFenceAck & ack) {acknowledgements.push_back(ack);});
  (void)subscription;
  SimulationEvidencePlugin plugin;
  ASSERT_TRUE(plugin.init(node, model_.get(), data_.get()));
  rclcpp::executors::SingleThreadedExecutor executor;
  executor.add_node(node);
  executor.add_node(observer);
  const auto discovery_deadline = std::chrono::steady_clock::now() + std::chrono::seconds(2);
  while (plugin.step_fence_ack_publisher_->get_subscription_count() == 0 &&
    std::chrono::steady_clock::now() < discovery_deadline)
  {
    executor.spin_some();
    std::this_thread::sleep_for(std::chrono::milliseconds(1));
  }
  ASSERT_GT(plugin.step_fence_ack_publisher_->get_subscription_count(), 0U);

  plugin.on_reset();
  plugin.on_pause(true);
  plugin.on_state_snapshot(model_.get(), data_.get(), true);
  plugin.on_pause(false);
  PhysicsStepFenceRequest request;
  request.simulation_session_id = "clock-test";
  request.reset_epoch = 1;
  request.request_sequence = 1;
  ASSERT_TRUE(plugin.step_fence_.request(request));
  data_->time = .002;
  const auto steady_ns = [] {
      return std::chrono::duration_cast<std::chrono::nanoseconds>(
        std::chrono::steady_clock::now().time_since_epoch()).count();
    };
  const auto outer_begin_ns = steady_ns();
  plugin.on_physics_step(model_.get(), data_.get());
  const auto outer_end_ns = steady_ns();
  const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(2);
  while (acknowledgements.empty() && std::chrono::steady_clock::now() < deadline) {
    executor.spin_some();
    std::this_thread::sleep_for(std::chrono::milliseconds(1));
  }
  ASSERT_EQ(acknowledgements.size(), 1U);
  const auto & ack = acknowledgements.front();
  EXPECT_EQ(ack.reset_epoch, 1U);
  EXPECT_EQ(ack.marked_physics_step, 1U);
  EXPECT_DOUBLE_EQ(ack.marked_simulation_time_s, .002);
  EXPECT_EQ(ack.marked_sample.simulation_session_id, ack.simulation_session_id);
  EXPECT_EQ(ack.marked_sample.reset_epoch, ack.reset_epoch);
  EXPECT_EQ(ack.marked_sample.physics_step, ack.marked_physics_step);
  EXPECT_DOUBLE_EQ(ack.marked_sample.simulation_time_s, ack.marked_simulation_time_s);
  EXPECT_EQ(ack.marked_sample.model_qpos,
    std::vector<double>(data_->qpos, data_->qpos + model_->nq));
  EXPECT_EQ(ack.marked_sample.model_qvel,
    std::vector<double>(data_->qvel, data_->qvel + model_->nv));
  EXPECT_LE(outer_begin_ns, ack.clock_interval_begin_monotonic_ns);
  EXPECT_LE(ack.clock_interval_begin_monotonic_ns, ack.clock_interval_end_monotonic_ns);
  EXPECT_LE(ack.clock_interval_end_monotonic_ns, outer_end_ns);
  EXPECT_EQ(ack.marked_sample.clock_interval_begin_monotonic_ns,
    ack.clock_interval_begin_monotonic_ns);
  EXPECT_LE(ack.marked_sample.clock_interval_begin_monotonic_ns,
    ack.marked_sample.clock_interval_end_monotonic_ns);
  EXPECT_LE(ack.marked_sample.clock_interval_end_monotonic_ns,
    ack.clock_interval_end_monotonic_ns);
  plugin.cleanup();
  executor.remove_node(observer);
  executor.remove_node(node);
  rclcpp::shutdown();
}

TEST_F(AtomicEvidenceTest, ControllerUpdatesDoNotInventPhysicsStepEvidence)
{
  if (!rclcpp::ok()) {
    rclcpp::init(0, nullptr);
  }
  auto options = rclcpp::NodeOptions().parameter_overrides({
      rclcpp::Parameter("object_body", "cup"),
      rclcpp::Parameter("left_fingertip_geom", "left_tip"),
      rclcpp::Parameter("right_fingertip_geom", "right_tip"),
      rclcpp::Parameter("other_contact_geoms", std::vector<std::string>{"table"}),
      rclcpp::Parameter("simulation_session_id", "non-advancing-test"),
      rclcpp::Parameter("publish_rate", 100.0),
      rclcpp::Parameter("topic", "/test/so101/non_advancing_snapshot"),
  });
  auto node = std::make_shared<rclcpp::Node>("non_advancing_plugin", options);
  SimulationEvidencePlugin plugin;
  ASSERT_TRUE(plugin.init(node, model_.get(), data_.get()));

  plugin.update(model_.get(), data_.get());
  data_->time = 0.02;
  plugin.update(model_.get(), data_.get());

  EXPECT_EQ(plugin.physics_state_.simulation_step, 0U);
  ASSERT_NE(plugin.physics_step_buffer_, nullptr);
  EXPECT_TRUE(plugin.physics_step_buffer_->prepare_chunk().samples.empty());
  EXPECT_FALSE(plugin.physics_step_buffer_->evidence_loss_latched());
  plugin.cleanup();
  rclcpp::shutdown();
}
}  // namespace

TEST(ScalarJointEvidenceTest, NamedHingeSnapshotUsesActualAddressesAndResetScope)
{
  const auto path = std::filesystem::temp_directory_path() / "so101_scalar_evidence.xml";
  std::ofstream(path) << R"(<mujoco><worldbody><body name="robot">
    <joint name="neck_yaw_joint" type="hinge"/><geom type="sphere" size=".02"/>
    <body name="arm"><joint name="1" type="hinge"/><geom type="sphere" size=".02"/></body>
    </body><body name="cup"><freejoint/><geom type="sphere" size=".02"/></body>
    </worldbody></mujoco>)";
  char error[1024]{};
  std::unique_ptr<mjModel, ModelDeleter> model(mj_loadXML(path.c_str(), nullptr, error, sizeof(error)));
  ASSERT_NE(model, nullptr) << error;
  std::unique_ptr<mjData, DataDeleter> data(mj_makeData(model.get()));
  data->qpos[0] = -.4; data->qpos[1] = .2; data->qvel[0] = .01;
  data->time = 3.5;
  const auto message = so101_mujoco_support::make_scalar_joint_evidence(
    model.get(), data.get(), {"1", "neck_yaw_joint"}, "session-a", 4, 0, true);
  EXPECT_EQ(message.simulation_session_id, "session-a");
  EXPECT_EQ(message.reset_epoch, 4U); EXPECT_EQ(message.simulation_step, 0U);
  EXPECT_TRUE(message.paused); EXPECT_EQ(message.joint_names, (std::vector<std::string>{"1", "neck_yaw_joint"}));
  EXPECT_EQ(message.positions_rad, (std::vector<double>{.2, -.4}));
  EXPECT_EQ(message.velocities_rad_s, (std::vector<double>{0., .01}));
  EXPECT_EQ(message.header.stamp.sec, 3); EXPECT_EQ(message.header.stamp.nanosec, 500000000U);
  EXPECT_THROW(so101_mujoco_support::make_scalar_joint_evidence(
    model.get(), data.get(), {"missing"}, "s", 0, 0, true), std::invalid_argument);
}

TEST_F(AtomicEvidenceTest, WholeRobotBuilderKeepsNonCupContactAndLegacyFilter)
{
  so101_mujoco_support::RobotContactBuilder robot;
  ASSERT_TRUE(robot.configure(model_.get(), {"left", "right"}, 128));
  place_free_body("cup_joint", .5, 0, .2);
  place_free_body("left_joint", 0, 0, .01);
  place_free_body("right_joint", 0, 0, .03);
  mj_forward(model_.get(), data_.get());
  const auto output = robot.build(model_.get(), data_.get(), "session-a", 1, 1);
  EXPECT_FALSE(output.truncated);
  EXPECT_GE(output.geom_a.size(), 2u);
  EXPECT_EQ(output.geom_a.size(), output.geom_b.size());
  const auto legacy = builder_.build(model_.get(), data_.get(), false, state_);
  EXPECT_FALSE(legacy.has_contact);
}

TEST(RobotContactBufferTest, OverflowAndTransientContactPersistUntilExplicitEpochReset)
{
  so101_mujoco_support::RobotContactBuffer buffer(2);
  so101_mujoco_support::msg::RobotContactEvidence sample;
  sample.simulation_session_id = "s";
  sample.reset_epoch = 1;
  sample.physics_step = 1;
  sample.simulation_time_s = .002;
  sample.geom_a = {"arm"}; sample.geom_b = {"table"};
  sample.signed_distance_m = {-.001}; sample.normal_force_n = {2.};
  ASSERT_TRUE(buffer.append(sample));
  sample.physics_step = 2;sample.simulation_time_s = .004;
  sample.geom_a.clear();sample.geom_b.clear();sample.signed_distance_m.clear();sample.normal_force_n.clear();
  ASSERT_TRUE(buffer.append(sample));
  sample.physics_step = 3;sample.simulation_time_s = .006;
  EXPECT_FALSE(buffer.append(sample));
  EXPECT_TRUE(buffer.front().evidence_loss);
  EXPECT_EQ(buffer.front().geom_a.front(), "arm");
  buffer.pop_published();
  EXPECT_TRUE(buffer.front().evidence_loss);
  buffer.reset(2);
  sample.reset_epoch = 2;sample.physics_step = 1;sample.simulation_time_s = .008;
  ASSERT_TRUE(buffer.append(sample));
  EXPECT_FALSE(buffer.front().evidence_loss);
}

TEST_F(AtomicEvidenceTest, WholeRobotRetainsArmTableArmArmAndArmMastPairs)
{
  so101_mujoco_support::RobotContactBuilder robot;
  ASSERT_TRUE(robot.configure(model_.get(), {"left", "right", "mast"}, 128));
  place_free_body("cup_joint", .5, 0, .2);
  place_free_body("left_joint", 0, 0, .01);
  place_free_body("right_joint", 0, 0, .03);
  place_free_body("mast_joint", 0, 0, .06);
  mj_forward(model_.get(), data_.get());
  const auto output = robot.build(model_.get(), data_.get(), "session-a", 1, 1);
  const auto has_pair = [&output](const std::string & first, const std::string & second) {
      for (std::size_t i = 0; i < output.geom_a.size(); ++i) {
        if ((output.geom_a[i] == first && output.geom_b[i] == second) ||
          (output.geom_a[i] == second && output.geom_b[i] == first)) {return true;}
      }
      return false;
    };
  EXPECT_TRUE(has_pair("left_tip", "table"));
  EXPECT_TRUE(has_pair("left_tip", "right_tip"));
  EXPECT_TRUE(has_pair("right_tip", "mast_geom"));
  EXPECT_FALSE(output.evidence_loss);
  EXPECT_FALSE(builder_.build(model_.get(), data_.get(), false, state_).has_contact);
  ASSERT_TRUE(robot.configure(model_.get(), {"left", "right", "mast"}, 1));
  EXPECT_TRUE(robot.build(model_.get(), data_.get(), "session-a", 1, 1).truncated);
}

TEST_F(AtomicEvidenceTest, FullSceneStateTracksEveryDynamicBodyAndBindsCompiledModel)
{
  so101_mujoco_support::SceneStateBuilder scene;
  ASSERT_TRUE(scene.configure(model_.get()));
  const auto fingerprint = scene.model_sha256();
  ASSERT_EQ(fingerprint.size(), 64U);
  place_free_body("mast_joint", .8, .3, .4);
  data_->time = .25;
  const auto before = std::chrono::duration_cast<std::chrono::nanoseconds>(
    std::chrono::steady_clock::now().time_since_epoch()).count();
  const auto sample = scene.build(model_.get(), data_.get(), "session-a", 3, 17, false, before);
  const auto after = std::chrono::duration_cast<std::chrono::nanoseconds>(
    std::chrono::steady_clock::now().time_since_epoch()).count();
  EXPECT_EQ(sample.clock_interval_begin_monotonic_ns, before);
  EXPECT_LE(before, sample.clock_interval_end_monotonic_ns);
  EXPECT_LE(sample.clock_interval_end_monotonic_ns, after);
  EXPECT_EQ(sample.model_sha256, fingerprint);
  EXPECT_EQ(sample.qpos.size(), static_cast<std::size_t>(model_->nq));
  EXPECT_EQ(sample.simulation_session_id, "session-a");
  EXPECT_EQ(sample.reset_epoch, 3U);
  EXPECT_EQ(sample.simulation_step, 17U);
  EXPECT_FALSE(sample.paused);
  for (int i=0; i<model_->nq; ++i) {EXPECT_DOUBLE_EQ(sample.qpos[i], data_->qpos[i]);}
  const auto paused = scene.build(model_.get(), data_.get(), "session-a", 4, 0, true, before);
  EXPECT_TRUE(paused.paused);
  EXPECT_EQ(paused.reset_epoch, 4U);
  EXPECT_EQ(paused.simulation_step, 0U);
  EXPECT_EQ(paused.qpos, sample.qpos);
  model_->geom_size[0] += .001;
  so101_mujoco_support::SceneStateBuilder changed;
  ASSERT_TRUE(changed.configure(model_.get()));
  EXPECT_NE(changed.model_sha256(), fingerprint);
}
