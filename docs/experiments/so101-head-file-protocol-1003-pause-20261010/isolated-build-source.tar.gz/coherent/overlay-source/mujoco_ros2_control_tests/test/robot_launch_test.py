#!/usr/bin/env python3

# Copyright 2025 PAL Robotics S.L.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import os
import sys
import time
import unittest
from unittest import mock

from ament_index_python.packages import get_package_share_directory
import launch_testing
import launch_testing.asserts
from controller_manager.test_utils import check_if_js_published, check_node_running
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_testing.actions import ReadyToTest
from launch_testing.util import KeepAliveProc
from launch_testing_ros import WaitForTopics
import pytest
import rclpy
from rclpy.qos import QoSProfile, DurabilityPolicy
from rosgraph_msgs.msg import Clock
from mujoco_ros2_control_msgs.msg import FreeJointState
from mujoco_ros2_control_msgs.srv import ResetWorld, SetFreeJointState, SetPause, StepSimulation
from std_msgs.msg import Float64MultiArray, String
from sensor_msgs.msg import JointState, Image, CameraInfo
from geometry_msgs.msg import PoseStamped
from controller_manager_msgs.srv import ListControllers, ListHardwareInterfaces, SwitchController


def camera_integration_is_available(platform_name=None, environ=None):
    """Return the registered camera capability without consulting legacy ambient skips."""
    platform_name = sys.platform if platform_name is None else platform_name
    environ = os.environ if environ is None else environ
    capability = environ.get("MUJOCO_ROS2_CONTROL_TEST_CAMERA_CAPABLE", "true").lower()
    return platform_name != "darwin" and capability == "true"


def controller_service_timeout(platform_name=None):
    """Allow MJCF generation extra startup time on Darwin without weakening Linux."""
    platform_name = sys.platform if platform_name is None else platform_name
    return 90.0 if platform_name == "darwin" else 10.0


# This function specifies the processes to be run for our test
def generate_test_description_common(use_pid="false", use_mjcf_from_topic="false", test_transmissions="false"):
    # This is necessary to get unbuffered output from the process under test
    proc_env = os.environ.copy()
    proc_env["PYTHONUNBUFFERED"] = "1"
    os.environ["USE_PID"] = use_pid
    os.environ["USE_MJCF_FROM_TOPIC"] = use_mjcf_from_topic
    os.environ["TEST_TRANSMISSIONS"] = test_transmissions
    os.environ["USE_PIDS"] = use_pid

    if use_mjcf_from_topic == "true":
        # Setup the venv needed for the make_mjcf_from_robot_description node
        os.system(
            os.path.join(
                get_package_share_directory("mujoco_ros2_control"),
                "scripts/robot_description_to_mjcf.sh --install-only",
            )
        )

    launch_include = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(
                get_package_share_directory("mujoco_ros2_control_tests"),
                "launch/test_launch.py",
            )
        ),
        launch_arguments={
            "headless": "true",
            "use_pid": use_pid,
            "use_mjcf_from_topic": use_mjcf_from_topic,
            "test_transmissions": test_transmissions,
        }.items(),
    )

    return LaunchDescription([launch_include, KeepAliveProc(), ReadyToTest()])


@pytest.mark.rostest
def generate_test_description():
    return generate_test_description_common(use_pid="false")


class TestFixture(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        rclpy.init()

    @classmethod
    def tearDownClass(cls):
        rclpy.shutdown()

    def setUp(self):
        self.node = rclpy.create_node("test_node")
        self._latest_js = None
        self._latest_actuator_js = None
        self._latest_pose = None
        self._js_sub = self.node.create_subscription(JointState, "/joint_states", self.joint_state_cb, 10)
        self._actuator_sub = self.node.create_subscription(
            JointState, "/mujoco_actuators_states", self.actuator_joint_state_cb, 10
        )
        self._pose_sub = self.node.create_subscription(PoseStamped, "/pose_broadcaster/pose", self.pose_cb, 10)

    def tearDown(self):
        self.node.destroy_node()

    def joint_state_cb(self, msg):
        self._latest_js = msg

    def actuator_joint_state_cb(self, msg):
        self._latest_actuator_js = msg

    def pose_cb(self, msg):
        self._latest_pose = msg

    def spin_until(self, predicate, timeout=20.0, spin_period=0.05):
        """Spin the node until predicate() returns True or timeout is reached.

        Returns True if the predicate was satisfied, False on timeout.
        """
        end_time = time.time() + timeout
        while time.time() < end_time:
            rclpy.spin_once(self.node, timeout_sec=spin_period)
            if predicate():
                return True
        return False

    def _check_positions(self, msg, expected_positions, delta):
        """Return True if all expected joints are within delta in msg."""
        if msg is None:
            return False
        try:
            return all(abs(msg.position[msg.name.index(jn)] - ep) <= delta for jn, ep in expected_positions.items())
        except ValueError:
            return False

    def _check_pose(self, msg, expected_pose, delta):
        """Return True if all 7 pose interface elements are within delta in msg."""
        if msg is None:
            return False
        try:
            assert "ee_link" == msg.header.frame_id
            actual_pose = {
                "pose/orientation.w": msg.pose.orientation.w,
                "pose/orientation.x": msg.pose.orientation.x,
                "pose/orientation.y": msg.pose.orientation.y,
                "pose/orientation.z": msg.pose.orientation.z,
                "pose/position.x": msg.pose.position.x,
                "pose/position.y": msg.pose.position.y,
                "pose/position.z": msg.pose.position.z,
            }
            return all(abs(actual_pose[key] - value) <= delta for key, value in expected_pose.items())
        except AttributeError:
            return False

    def check_controllers_running_with_retry(self, controller_names, timeout=None):
        """Wait for authoritative controller-manager state, avoiding graph-discovery races."""
        timeout = controller_service_timeout() if timeout is None else timeout
        client = self.node.create_client(ListControllers, "/controller_manager/list_controllers")
        if not client.wait_for_service(timeout_sec=timeout):
            self.node.destroy_client(client)
            self.fail(f"list_controllers service not available after {timeout}s")

        deadline = time.time() + timeout
        last_states = {}
        while time.time() < deadline:
            future = client.call_async(ListControllers.Request())
            remaining = max(0.0, deadline - time.time())
            rclpy.spin_until_future_complete(self.node, future, timeout_sec=min(5.0, remaining))
            if future.done() and not future.cancelled():
                response = future.result()
                last_states = {controller.name: controller.state for controller in response.controller}
                if all(last_states.get(name) == "active" for name in controller_names):
                    self.node.destroy_client(client)
                    return
            else:
                future.cancel()
            time.sleep(0.1)

        self.node.destroy_client(client)
        self.fail(f"Controllers not active after {timeout}s: {controller_names}; last states: {last_states}")

    def wait_for_joint_positions(
        self, expected_positions, delta=0.05, timeout=15.0, verify_efforts=True, topic="joint_states"
    ):
        """Helper function to poll until the joint states reach the desired position."""

        # Get the relevant joint state message, which we do just by checking the topic name...
        if topic == "joint_states":
            get_msg = lambda: self._latest_js  # noqa: E731
        else:
            get_msg = lambda: self._latest_actuator_js  # noqa: E731

        ok = self.spin_until(
            lambda: self._check_positions(get_msg(), expected_positions, delta),
            timeout=timeout,
        )

        msg = get_msg()
        if not ok:
            # Try to get details about where exactly we failed, sometimes nothing has updated
            details = {}
            if msg is not None and msg.name:
                for jn in expected_positions:
                    if jn in msg.name:
                        details[jn] = msg.position[msg.name.index(jn)]
                    else:
                        details[jn] = "NOT FOUND"
            self.fail(
                f"joints did not reach the commanded position in {timeout}s. "
                f"expected: {expected_positions}, checked: {details}"
            )

        if verify_efforts and msg is not None:
            # make sure the efforts field is non-zero (indicating PID/ effort reporting is working)
            self.assertTrue(
                any(abs(effort) > 1e-6 for effort in msg.effort),
                "Effort field is zero, PID/Effort reporting may not be working",
            )

    def verify_arm_joint_states(self, expected_positions, delta=0.05, verify_efforts=True):
        self.wait_for_joint_positions(
            expected_positions, delta=delta, verify_efforts=verify_efforts, topic="joint_states"
        )

    def test_node_start(self, proc_output):
        check_node_running(self.node, "robot_state_publisher")

    def test_clock(self):
        topic_list = [("/clock", Clock)]
        with WaitForTopics(topic_list, timeout=10.0):
            print("/clock is receiving messages!")

    def test_check_if_msgs_published(self):
        check_if_js_published(
            "/joint_states",
            [
                "joint1",
                "joint2",
                "gripper_left_finger_joint",
                "gripper_right_finger_joint",
            ],
        )

    def test_check_if_mujoco_actuators_states_published(self):
        if os.environ.get("TEST_TRANSMISSIONS") != "true":
            check_if_js_published(
                "/mujoco_actuators_states",
                ["joint1", "joint2", "gripper_left_finger_joint", "gripper_right_finger_joint"],
            )
        else:
            check_if_js_published(
                "/mujoco_actuators_states",
                ["actuator1", "actuator2", "gripper_left_finger_joint", "gripper_right_finger_joint"],
            )

    def test_pose_interfaces_transform(self):
        # The pose_broadcaster is only spawned by the basic robot demo launch file.
        if any(os.environ.get(var) == "true" for var in ("USE_PID", "USE_MJCF_FROM_TOPIC", "TEST_TRANSMISSIONS")):
            self.skipTest("pose_broadcaster is only spawned in the basic robot configuration")

        # The settled contact pose differs between MuJoCo versions: the ROS binaries and pixi/conda environment
        # ships different versions of libmujoco. Both are deterministic, so keep one exact expected pose per
        # environment instead of a tolerance loose enough to span the gap between them.
        # See https://github.com/pal-robotics/mujoco_vendor/issues/11 for more details.
        if os.environ.get("PIXI_PROJECT_ROOT") or os.environ.get("CONDA_PREFIX"):
            expected_pose = {
                "pose/position.x": 1.8753,
                "pose/position.y": 0.0,
                "pose/position.z": -0.4885,
                "pose/orientation.w": 1.0,
                "pose/orientation.x": 0.0,
                "pose/orientation.y": 0.0024,
                "pose/orientation.z": 0.0,
            }
        else:
            expected_pose = {
                "pose/position.x": 1.8678,
                "pose/position.y": 0.0,
                "pose/position.z": -0.5162,
                "pose/orientation.w": 0.9999,
                "pose/orientation.x": 0.0,
                "pose/orientation.y": 0.0099,
                "pose/orientation.z": 0.0,
            }

        self.assertTrue(
            self.spin_until(
                lambda: self._check_pose(self._latest_pose, expected_pose, delta=1e-3),
                timeout=5.0,
            ),
            "Pose interfaces did not publish the expected transform on /pose_broadcaster/pose\n"
            f"Found {self._latest_pose}\nExpected {expected_pose}",
        )

    def test_arm(self):

        # Check if the controllers are running
        cnames = ["gripper_controller", "position_controller", "joint_state_broadcaster"]
        self.check_controllers_running_with_retry(cnames)

        # Create a publisher to send commands to the position controller
        pub = self.node.create_publisher(Float64MultiArray, "/position_controller/commands", 10)

        # Wait for subscriber to connect
        self.assertTrue(
            self.spin_until(lambda: pub.get_subscription_count() > 0, timeout=5.0),
            "Controller did not subscribe to commands",
        )

        msg = Float64MultiArray()
        msg.data = [0.5, -0.5]
        # This is needed to account for any missing message subscriptions
        end_time = time.time() + 2
        while time.time() < end_time:
            pub.publish(msg)
            rclpy.spin_once(self.node, timeout_sec=0.1)

        # Wait for joints to reach target positions
        self.wait_for_joint_positions({"joint1": 0.5, "joint2": -0.5}, delta=0.05, timeout=15.0)

        if os.environ.get("TEST_TRANSMISSIONS") != "true":
            expected_actuators = {"joint1": 0.5, "joint2": -0.5}
        else:
            # test_robot.urdf couples joint1/joint2 through a single DifferentialTransmission
            # (joint reductions 2.0/0.5, actuator reductions 1.0/1.0, no offsets), so each
            # actuator position is a sum/difference of both joint targets, not a 1:1 scaling.
            joint1, joint2, jr1, jr2 = 0.5, -0.5, 2.0, 0.5
            expected_actuators = {
                "actuator1": joint1 * jr1 + joint2 * jr2,
                "actuator2": joint1 * jr1 - joint2 * jr2,
            }

        self.wait_for_joint_positions(expected_actuators, delta=0.05, timeout=15.0, topic="actuator_states")

        # make sure the efforts field is non-zero (indicating PID/ effort reporting is working)
        self.assertTrue(
            self._latest_actuator_js is not None and any(abs(e) > 1e-6 for e in self._latest_actuator_js.effort),
            "Effort field is zero, PID/Effort reporting may not be working",
        )

    def test_gripper(self):

        # Check if the controllers are running
        cnames = ["gripper_controller", "position_controller", "joint_state_broadcaster"]
        self.check_controllers_running_with_retry(cnames)

        # Create a publisher to send commands to the gripper controller
        pub = self.node.create_publisher(Float64MultiArray, "/gripper_controller/commands", 10)

        # Wait for subscriber to connect
        self.assertTrue(
            self.spin_until(lambda: pub.get_subscription_count() > 0, timeout=5.0),
            "Controller did not subscribe to commands",
        )

        msg = Float64MultiArray()
        msg.data = [-0.04]  # Close gripper
        end_time = time.time() + 1.0
        while time.time() < end_time:
            pub.publish(msg)
            rclpy.spin_once(self.node, timeout_sec=0.1)

        # Wait for the gripper to get to the target pose
        self.wait_for_joint_positions(
            {"gripper_left_finger_joint": -0.04, "gripper_right_finger_joint": 0.04},
            delta=0.005,
            timeout=15.0,
        )

        # And confirm that the mujoco_actuators_states also gets there
        self.wait_for_joint_positions(
            {"gripper_left_finger_joint": -0.04, "gripper_right_finger_joint": 0.04},
            delta=0.005,
            timeout=15.0,
            topic="actuator_states",
        )

    def test_linux_legacy_camera_skip_environment_is_ignored(self):
        with mock.patch.dict(
            os.environ,
            {
                "SKIP_CAMERA_TESTS": "true",
                "MUJOCO_ROS2_CONTROL_TEST_CAMERA_CAPABLE": "true",
            },
        ):
            self.assertTrue(camera_integration_is_available(platform_name="linux"))

    def test_darwin_camera_capability_is_deterministic(self):
        with mock.patch.dict(os.environ, {"MUJOCO_ROS2_CONTROL_TEST_CAMERA_CAPABLE": "true"}):
            self.assertFalse(camera_integration_is_available(platform_name="darwin"))

    def test_controller_service_wait_is_extended_only_on_darwin(self):
        self.assertEqual(controller_service_timeout("darwin"), 90.0)
        self.assertEqual(controller_service_timeout("linux"), 10.0)

    @unittest.skipUnless(
        camera_integration_is_available(),
        "Camera integration is disabled by the registered platform capability.",
    )
    def test_camera_topics(self):
        topic_list = [
            ("/camera/color/image_raw", Image),
            ("/camera/color/camera_info", CameraInfo),
            ("/camera/aligned_depth_to_color/image_raw", Image),
        ]
        wait_for_topics = WaitForTopics(topic_list, timeout=5.0)
        assert wait_for_topics.wait(), "Not all camera topics were received in time!"
        assert wait_for_topics.topics_not_received() == set(), "Some topics were not received!"
        assert wait_for_topics.topics_received() == {t[0] for t in topic_list}, "Not all topics were received!"
        wait_for_topics.shutdown()

    def test_reset_world_service(self):
        """Test that reset_world resets joints and controllers remain functional."""
        cnames = ["gripper_controller", "position_controller", "joint_state_broadcaster"]
        self.check_controllers_running_with_retry(cnames)

        pub = self.node.create_publisher(Float64MultiArray, "/position_controller/commands", 10)
        self.assertTrue(
            self.spin_until(lambda: pub.get_subscription_count() > 0, timeout=10.0),
            "Controller did not subscribe to commands",
        )

        # Move joints to a non-zero position
        msg = Float64MultiArray()
        msg.data = [-0.5, 0.5]
        end_time = time.time() + 2
        while time.time() < end_time:
            pub.publish(msg)
            rclpy.spin_once(self.node, timeout_sec=0.1)
        self.wait_for_joint_positions({"joint1": -0.5, "joint2": 0.5}, delta=0.075, timeout=15.0)

        # Deactivate controller before reset
        switch_client = self.node.create_client(SwitchController, "/controller_manager/switch_controller")
        self.assertTrue(switch_client.wait_for_service(timeout_sec=10.0))
        switch_request = SwitchController.Request()
        switch_request.deactivate_controllers = ["position_controller"]
        switch_request.strictness = SwitchController.Request.BEST_EFFORT
        future = switch_client.call_async(switch_request)
        rclpy.spin_until_future_complete(self.node, future, timeout_sec=10.0)
        self.assertTrue(future.result().ok)

        # Controller switching needs the running control loop, while ResetWorld
        # is deliberately accepted only after that loop is paused.
        pause_client = self.node.create_client(SetPause, "/mujoco_ros2_control_node/set_pause")
        self.assertTrue(pause_client.wait_for_service(timeout_sec=10.0))
        pause_request = SetPause.Request()
        pause_request.paused = True
        future = pause_client.call_async(pause_request)
        rclpy.spin_until_future_complete(self.node, future, timeout_sec=10.0)
        self.assertTrue(future.result().success)

        # Reset world
        reset_client = self.node.create_client(ResetWorld, "/mujoco_ros2_control_node/reset_world")
        self.assertTrue(reset_client.wait_for_service(timeout_sec=10.0))
        future = reset_client.call_async(ResetWorld.Request())
        rclpy.spin_until_future_complete(self.node, future, timeout_sec=10.0)
        self.assertTrue(future.result().success)

        # Resume the physics loop before checking the externally published joint
        # state. ResetWorld updates the authoritative MuJoCo/control snapshot while
        # paused, but joint_state_broadcaster cannot publish that snapshot until the
        # controller-manager loop is running again. Keep position_controller inactive
        # so no pre-reset controller command can obscure the reset state.
        pause_request.paused = False
        future = pause_client.call_async(pause_request)
        rclpy.spin_until_future_complete(self.node, future, timeout_sec=10.0)
        self.assertTrue(future.result().success)
        self.wait_for_joint_positions({"joint1": 0.0, "joint2": 0.0}, delta=0.05, timeout=15.0, verify_efforts=False)

        # Reactivate controller and verify it still works
        switch_request = SwitchController.Request()
        switch_request.activate_controllers = ["position_controller"]
        switch_request.strictness = SwitchController.Request.BEST_EFFORT
        future = switch_client.call_async(switch_request)
        rclpy.spin_until_future_complete(self.node, future, timeout_sec=10.0)
        self.assertTrue(future.result().ok)

        end_time = time.time() + 2
        while time.time() < end_time:
            pub.publish(msg)
            rclpy.spin_once(self.node, timeout_sec=0.1)
        self.wait_for_joint_positions({"joint1": -0.5, "joint2": 0.5}, delta=0.075, timeout=15.0)

    def test_step_simulation_zero_steps_rejected(self):
        """step_simulation with steps=0 must be rejected even when the simulation is paused."""
        mujoco_sim_node = "/mujoco_ros2_control_node"

        pause_client = self.node.create_client(SetPause, f"{mujoco_sim_node}/set_pause")
        self.assertTrue(pause_client.wait_for_service(timeout_sec=10.0), "set_pause service not available")

        step_client = self.node.create_client(StepSimulation, f"{mujoco_sim_node}/step_simulation")
        self.assertTrue(step_client.wait_for_service(timeout_sec=10.0), "step_simulation service not available")

        # Pause so the steps=0 validation is reached
        pause_req = SetPause.Request()
        pause_req.paused = True
        future = pause_client.call_async(pause_req)
        rclpy.spin_until_future_complete(self.node, future, timeout_sec=10.0)
        self.assertTrue(future.result().success, "set_pause(paused=True) failed")

        step_req = StepSimulation.Request()
        step_req.steps = 0
        future = step_client.call_async(step_req)
        rclpy.spin_until_future_complete(self.node, future, timeout_sec=10.0)
        result = future.result()
        self.assertIsNotNone(result, "step_simulation returned None")
        self.assertFalse(result.success, "step_simulation with steps=0 should fail")

        # Leave the simulation running again
        pause_req.paused = False
        future = pause_client.call_async(pause_req)
        rclpy.spin_until_future_complete(self.node, future, timeout_sec=10.0)
        self.assertTrue(future.result().success, "set_pause(paused=False) failed after zero-steps test")

    def test_step_simulation_interrupted_by_resume(self):
        """Resuming the simulation while step_simulation is counting down must abort the call."""
        # Use enough steps that the physics loop cannot drain them all before we call resume.
        # 50 000 steps × 0.002 s = 100 s of sim time — far more than the ~0.2 s it takes
        # to spin, send the resume request, and have the physics loop react.

        mujoco_sim_node = "/mujoco_ros2_control_node"

        pause_client = self.node.create_client(SetPause, f"{mujoco_sim_node}/set_pause")
        self.assertTrue(pause_client.wait_for_service(timeout_sec=10.0), "set_pause service not available")

        step_client = self.node.create_client(StepSimulation, f"{mujoco_sim_node}/step_simulation")
        self.assertTrue(step_client.wait_for_service(timeout_sec=10.0), "step_simulation service not available")

        # Pause the simulation
        pause_req = SetPause.Request()
        pause_req.paused = True
        future = pause_client.call_async(pause_req)
        rclpy.spin_until_future_complete(self.node, future, timeout_sec=10.0)
        self.assertTrue(future.result().success, "set_pause(paused=True) failed")

        step_req = StepSimulation.Request()
        step_req.steps = 50000
        step_future = step_client.call_async(step_req)

        # Spin briefly so the service request is triggered
        self.spin_until(lambda: False, timeout=0.2)

        # Resume the simulation to trigger the physics loop to abort the pending steps
        pause_req.paused = False
        future = pause_client.call_async(pause_req)
        rclpy.spin_until_future_complete(self.node, future, timeout_sec=5.0)
        self.assertTrue(future.result().success, "set_pause(paused=False) failed")

        rclpy.spin_until_future_complete(self.node, step_future, timeout_sec=5.0)
        result = step_future.result()
        self.assertIsNotNone(result, "step_simulation returned None")
        self.assertFalse(result.success, "step_simulation should fail when simulation is resumed mid-countdown")

    def test_reset_free_body_poses(self):
        """set_free_joint_state must reposition free-body objects, reported via response.success.

        Both bodies are set in a single request to exercise the service's list/atomic behaviour.
        """
        if (
            os.environ.get("TEST_TRANSMISSIONS") == "true"
            or os.environ.get("USE_MJCF_FROM_TOPIC") == "true"
            or os.environ.get("USE_PIDS") == "true"
        ):
            self.skipTest("cube1/cube2 free bodies are only present in the default test_robot.xml scene")

        mujoco_sim_node = "/mujoco_ros2_control_node"

        client = self.node.create_client(SetFreeJointState, f"{mujoco_sim_node}/set_free_joint_state")
        self.assertTrue(client.wait_for_service(timeout_sec=10.0), "set_free_joint_state service not available")

        req = SetFreeJointState.Request()
        for body_name, target in (("cube1", (1.0, 1.0, 1.0)), ("cube2", (-1.0, 1.0, 1.0))):
            entry = FreeJointState()
            entry.name = body_name
            entry.pose.pose.position.x, entry.pose.pose.position.y, entry.pose.pose.position.z = target
            entry.pose.pose.orientation.w = 1.0
            req.free_joints.append(entry)

        future = client.call_async(req)
        rclpy.spin_until_future_complete(self.node, future, timeout_sec=10.0)
        result = future.result()
        self.assertIsNotNone(result, "set_free_joint_state returned None")
        self.assertTrue(result.success, f"set_free_joint_state failed: {result.message}")


class TestFixtureHardwareInterfacesCheck(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        rclpy.init()

    @classmethod
    def tearDownClass(cls):
        rclpy.shutdown()

    def setUp(self):
        self.node = rclpy.create_node("test_node")

    def tearDown(self):
        self.node.destroy_node()

    def test_available_hardware_interfaces(self):
        # Call /controller_manager/list_hardware_interfaces service and check the response
        client = self.node.create_client(ListHardwareInterfaces, "/controller_manager/list_hardware_interfaces")
        if not client.wait_for_service(timeout_sec=10.0):
            self.fail("Service /controller_manager/list_hardware_interfaces not available")

        request = ListHardwareInterfaces.Request()
        future = client.call_async(request)
        rclpy.spin_until_future_complete(self.node, future, timeout_sec=10.0)
        if future.result() is None:
            self.fail("Service call to /controller_manager/list_hardware_interfaces failed")
        response = future.result()

        # available state interfaces
        available_state_interfaces_names = [iface.name for iface in response.state_interfaces]
        expected_state_interfaces = [
            "gripper_left_finger_joint/position",
            "gripper_left_finger_joint/velocity",
            "gripper_left_finger_joint/effort",
            "gripper_left_finger_joint/force",
            "gripper_right_finger_joint/position",
            "gripper_right_finger_joint/velocity",
            "gripper_right_finger_joint/effort",
            "gripper_right_finger_joint/force",
            "joint1/position",
            "joint1/velocity",
            "joint1/effort",
            "joint1/torque",
            "joint2/position",
            "joint2/velocity",
            "joint2/effort",
            "joint2/torque",
            "pose/orientation.w",
            "pose/orientation.x",
            "pose/orientation.y",
            "pose/orientation.z",
            "pose/position.x",
            "pose/position.y",
            "pose/position.z",
            "magnetometer/magnetic_field.x",
            "magnetometer/magnetic_field.y",
            "magnetometer/magnetic_field.z",
        ]
        assert len(available_state_interfaces_names) == len(
            expected_state_interfaces
        ), f"Expected {len(expected_state_interfaces)} state interfaces, got {len(available_state_interfaces_names)}"
        assert set(available_state_interfaces_names) == set(
            expected_state_interfaces
        ), f"State interfaces do not match expected. Got: {available_state_interfaces_names}"

        # available command interfaces
        available_command_interfaces_names = [iface.name for iface in response.command_interfaces]
        expected_command_interfaces = ["joint1/position", "joint2/position", "gripper_left_finger_joint/position"]

        assert len(available_command_interfaces_names) == len(expected_command_interfaces), (
            f"Expected {len(expected_command_interfaces)} command interfaces, "
            f"got {len(available_command_interfaces_names)}"
        )
        assert set(available_command_interfaces_names) == set(
            expected_command_interfaces
        ), f"Command interfaces do not match expected. Got: {available_command_interfaces_names}"

        self.node.get_logger().info("Available hardware interfaces check passed.")


class TestMJCFGenerationFromURDF(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        if os.environ.get("USE_MJCF_FROM_TOPIC") != "true":
            raise unittest.SkipTest("Skipping MJCF generation tests because use_mjcf_from_topic is not true")
        rclpy.init()

    @classmethod
    def tearDownClass(cls):
        rclpy.shutdown()

    def setUp(self):
        self.node = rclpy.create_node("test_node")

    def tearDown(self):
        self.node.destroy_node()

    def test_check_for_mujoco_robot_description_topic(self):
        # Create a QoS profile for transient_local topics
        qos_profile = QoSProfile(depth=1, durability=DurabilityPolicy.TRANSIENT_LOCAL)

        received_msgs = []

        def callback(msg):
            received_msgs.append(msg)

        sub = self.node.create_subscription(String, "/mujoco_robot_description", callback, qos_profile)

        end_time = time.time() + 15.0
        while time.time() < end_time:
            rclpy.spin_once(self.node, timeout_sec=0.1)
            if received_msgs:
                break

        assert received_msgs, "The MuJoCo robot description topic is not published"
        msg = received_msgs[0]
        assert "<mujoco" in msg.data, "The MuJoCo robot description does not contain expected content"
        self.node.destroy_subscription(sub)


@launch_testing.post_shutdown_test()
class TestCleanShutdown(unittest.TestCase):

    def test_processes_exit_cleanly(self, proc_info):
        launch_testing.asserts.assertExitCodes(proc_info)

    def test_controller_introspection_publishers_stop_before_context_invalidation(
        self, proc_output
    ):
        output = "".join(event.text.decode(errors="replace") for event in proc_output)

        controller_shutdown = output.index(
            "Shutting down all controllers in the controller manager."
        )
        resource_shutdown = output.index("Successful 'shutdown' of hardware")
        publishers_stopped = output.index(
            "MUJOCO_ROS2_CONTROL_INTROSPECTION_PUBLISHERS_STOPPED"
        )

        self.assertLess(controller_shutdown, resource_shutdown)
        self.assertLess(resource_shutdown, publishers_stopped)
        self.assertNotIn("Exception in publisher thread", output)
        self.assertNotIn("context cannot be slept with because it's invalid", output)
