#pragma once

#include <cstddef>
#include <cstdint>
#include <memory>
#include <string>

namespace mujoco_ros2_control
{
enum class ClockTraceKind : uint64_t
{
  StepBegin = 1, StepCommit = 2, ClockBegin = 3, ClockEnd = 4,
  ResetBegin = 5, ResetEnd = 6, LoopStart = 10, Read = 11,
  Update = 12, Write = 13, SleepBegin = 14, SleepReturn = 15, SleepException = 16,
  ProbeWait = 17
};

// Diagnostic only. finish() requires every producer to have quiesced.
class ClockTrace
{
public:
  static constexpr size_t capacity = 1048576;
  static constexpr size_t record_bytes = 88;
  static constexpr size_t payload_bytes = capacity * record_bytes;
  ClockTrace(const std::string & directory, const std::string & manifest,
    const std::string & stream, size_t slots = capacity);
  ~ClockTrace();
  static std::unique_ptr<ClockTrace> from_environment(const std::string & stream);
  static uint64_t monotonic_ns() noexcept;
  static uint64_t reset_epoch() noexcept;
  static uint64_t complete_reset() noexcept;
  static uint64_t all_invalid_flags() noexcept;
  bool record(ClockTraceKind kind, uint64_t id, uint64_t epoch, int64_t sim_ns,
    int64_t auxiliary, uint64_t start, uint64_t end, uint64_t actor = 0,
    uint64_t flags = 0) noexcept;
  bool finish();
  uint64_t invalid_flags() const noexcept;
private:
  struct Impl;
  std::unique_ptr<Impl> impl_;
};
}
