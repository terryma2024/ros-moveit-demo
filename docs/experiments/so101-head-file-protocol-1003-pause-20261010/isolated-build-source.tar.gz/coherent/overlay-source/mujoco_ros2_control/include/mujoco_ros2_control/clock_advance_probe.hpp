#pragma once

#include <chrono>
#include <atomic>
#include <charconv>
#include <cstdlib>
#include <cstdint>
#include <cstring>
#include <limits>
#include <stdexcept>
#include <thread>
#include <rclcpp/clock.hpp>
#include <rclcpp/context.hpp>
#include <rclcpp/utilities.hpp>
#include "mujoco_ros2_control/clock_trace.hpp"

namespace mujoco_ros2_control
{
class ClockAdvanceProbe
{
public:
  struct Result
  {
    bool invoked = false;
    uint64_t flags = 0;
    int64_t before = 0, after = 0, target = 0;
    uint64_t start = 0, end = 0;
  };
  static ClockAdvanceProbe parse(const char * value, bool traced)
  {
    ClockAdvanceProbe probe;
    if (!value) {return probe;}
    const auto end = value + std::strlen(value);
    const auto parsed = std::from_chars(value, end, probe.selected_);
    if (!traced || parsed.ec != std::errc{} || parsed.ptr != end ||
      probe.selected_ == 0 || probe.selected_ > 50000)
    {
      throw std::invalid_argument("clock advance probe requires tracing and loop ID 1..50000");
    }
    return probe;
  }
  bool enabled() const noexcept {return selected_ != 0;}
  void validate(bool simulated, uint32_t rate) const
  {
    if (enabled() && (!simulated || rate != 500)) {
      throw std::invalid_argument("clock advance probe requires use_sim_time and 500 Hz");
    }
  }
  Result run(uint64_t loop, const rclcpp::Time & base, std::chrono::nanoseconds period,
    uint64_t epoch, rclcpp::Clock & clock, const rclcpp::Context & context) noexcept
  {
    Result result;
    if (!enabled() || fired_ || loop != selected_) {return result;}
    fired_ = true;
    result.invoked = true;
    result.start = ClockTrace::monotonic_ns();
    const auto deadline = std::chrono::steady_clock::now() + std::chrono::milliseconds(250);
    try {
      if (period.count() != 2000000 || base.get_clock_type() != RCL_ROS_TIME ||
        base.nanoseconds() > std::numeric_limits<int64_t>::max() - period.count())
      {
        result.flags = 16;
      } else {
        result.target = base.nanoseconds() + period.count();
        result.before = clock.now().nanoseconds();
        const bool initial_backwards = result.before < base.nanoseconds();
        auto previous = result.before;
        for (;;) {
          result.after = clock.now().nanoseconds();
          if (!context.is_valid()) {result.flags = 4;}
          else if (ClockTrace::reset_epoch() != epoch || initial_backwards ||
            result.after < previous) {
            result.flags = 8;
          }
          else if (clock.get_clock_type() != RCL_ROS_TIME || !clock.ros_time_is_active()) {
            result.flags = 16;
          }
          else if (std::chrono::steady_clock::now() >= deadline) {result.flags = 2;}
          else if (result.after >= result.target) {
            result.flags = result.before >= result.target ? 32 : 1;
          }
          if (result.flags) {break;}
          previous = result.after;
          std::this_thread::yield();
        }
      }
    } catch (...) {result.flags = 16;}
    result.end = ClockTrace::monotonic_ns();
    return result;
  }
private:
  uint64_t selected_ = 0;
  bool fired_ = false;
};

// Non-RT diagnostic lifecycle only. Persistent context shutdown cannot be lost at spin entry.
inline std::thread start_probe_shutdown_relay(bool enabled,
  const rclcpp::Context::SharedPtr & context, const std::atomic<bool> & failure,
  const std::atomic<bool> & quiesced)
{
  if (!enabled) {return {};}
  return std::thread([context, &failure, &quiesced]() {
    while (context->is_valid()) {
      if (failure.load(std::memory_order_acquire) && quiesced.load(std::memory_order_acquire)) {
        try {
          rclcpp::shutdown(context, "clock advance probe failed");
        } catch (...) {
          // An incomplete shutdown invalidates this diagnostic; never hang or claim clean close.
          std::_Exit(3);
        }
        return;
      }
      std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }
  });
}

struct ProbeControlQuiescence
{
  explicit ProbeControlQuiescence(std::atomic<bool> & quiesced) : quiesced_(quiesced) {}
  ~ProbeControlQuiescence() {quiesced_.store(true, std::memory_order_release);}
  ProbeControlQuiescence(const ProbeControlQuiescence &) = delete;
  ProbeControlQuiescence & operator=(const ProbeControlQuiescence &) = delete;
private:
  std::atomic<bool> & quiesced_;
};
}
