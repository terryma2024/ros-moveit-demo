// Copyright (C) 2026 zjumty@gmail.com
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef MUJOCO_ROS2_CONTROL__VIEWER_CAMERA_HPP_
#define MUJOCO_ROS2_CONTROL__VIEWER_CAMERA_HPP_

#include <string>

#include <mujoco/mujoco.h>
#include <mujoco_ros2_control_msgs/msg/viewer_camera.hpp>

namespace mujoco_ros2_control
{
struct ViewerCameraResult
{
  bool success{ false };
  std::string message;
  mujoco_ros2_control_msgs::msg::ViewerCamera camera;
};

double normalize_viewer_azimuth(double degrees);

ViewerCameraResult validate_and_apply_viewer_camera(
  const mujoco_ros2_control_msgs::msg::ViewerCamera & request,
  const mjModel * model,
  mjvCamera & camera,
  int & camera_selector);

ViewerCameraResult read_viewer_camera(
  const mjModel * model,
  const mjvCamera & camera,
  int camera_selector);
}  // namespace mujoco_ros2_control

#endif  // MUJOCO_ROS2_CONTROL__VIEWER_CAMERA_HPP_
