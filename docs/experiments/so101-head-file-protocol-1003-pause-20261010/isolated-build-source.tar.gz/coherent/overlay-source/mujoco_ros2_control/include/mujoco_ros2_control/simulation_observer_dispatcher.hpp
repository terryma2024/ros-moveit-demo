// Copyright 2026 PAL Robotics S.L.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef MUJOCO_ROS2_CONTROL__SIMULATION_OBSERVER_DISPATCHER_HPP_
#define MUJOCO_ROS2_CONTROL__SIMULATION_OBSERVER_DISPATCHER_HPP_

#include <functional>
#include <memory>
#include <vector>

#include <mujoco/mujoco.h>
#include <rclcpp/logger.hpp>

#include <mujoco_ros2_control_plugins/mujoco_ros2_control_plugin_capabilities.hpp>
#include <mujoco_ros2_control_plugins/mujoco_ros2_control_plugins_base.hpp>

namespace mujoco_ros2_control
{

class SimulationObserverDispatcher
{
public:
  explicit SimulationObserverDispatcher(rclcpp::Logger logger);
  void add(const std::shared_ptr<mujoco_ros2_control_plugins::MuJoCoROS2ControlPluginBase>& plugin);
  void on_physics_step(const mjModel* model, const mjData* data);
  void on_reset();
  void on_pause(bool paused);
  void on_state_snapshot(const mjModel* model, const mjData* data, bool paused);

private:
  using Observer = mujoco_ros2_control_plugins::MuJoCoROS2ControlSimulationObserver;

  struct ObserverEntry
  {
    std::shared_ptr<Observer> observer;
    bool disabled{ false };
  };

  void dispatch(const std::function<void(Observer&)>& callback);

  rclcpp::Logger logger_;
  std::vector<ObserverEntry> observers_;
};

}  // namespace mujoco_ros2_control

#endif  // MUJOCO_ROS2_CONTROL__SIMULATION_OBSERVER_DISPATCHER_HPP_
