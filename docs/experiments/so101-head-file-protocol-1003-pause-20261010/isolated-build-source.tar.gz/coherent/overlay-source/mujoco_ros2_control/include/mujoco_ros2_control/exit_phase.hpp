#pragma once
#include <cerrno>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <exception>
#include <utility>

extern "C" {
int exit_probe_init(const char *, const char *, unsigned, const char *, const char *, const char *);
uint64_t exit_probe_begin(unsigned, unsigned, int64_t, int64_t);
void exit_probe_end(uint64_t, int, int);
}
namespace mujoco_ros2_control {
// Diagnostic copied build only; initialize before ROS/control or recorder threads exist.
inline bool initialize_exit_phase() {
  const char *file=std::getenv("SO101_EXIT_PHASE_NODE_FILE");
  if (!file || !*file) {return true;}
  const char *meta=std::getenv("SO101_EXIT_PHASE_NODE_METADATA");
  const char *exe=std::getenv("SO101_EXIT_PHASE_NODE_EXE");
  const char *argument=std::getenv("SO101_EXIT_PHASE_NODE_ARGUMENT");
  const char *session=std::getenv("SO101_SIMULATION_SESSION_ID");
  if (!meta || !exe || !argument || !session || std::strlen(meta)>4032) {return false;}
  return exit_probe_init(file,meta,static_cast<unsigned>(std::strlen(meta)),exe,argument,session)==0;
}
class ExitPhaseScope {
  uint64_t slot_;
  int exceptions_;
public:
  ExitPhaseScope(unsigned phase,unsigned component=0) noexcept
  : slot_(exit_probe_begin(phase,component,0,0)),exceptions_(std::uncaught_exceptions()) {}
  ~ExitPhaseScope() noexcept {
    exit_probe_end(slot_,std::uncaught_exceptions()>exceptions_?1:0,errno);
  }
  ExitPhaseScope(const ExitPhaseScope&)=delete;
  ExitPhaseScope& operator=(const ExitPhaseScope&)=delete;
};
template<class Callable> decltype(auto) observe_exit(unsigned phase,unsigned component,Callable&& call) {
  ExitPhaseScope scope(phase,component);
  return std::forward<Callable>(call)();
}
}
