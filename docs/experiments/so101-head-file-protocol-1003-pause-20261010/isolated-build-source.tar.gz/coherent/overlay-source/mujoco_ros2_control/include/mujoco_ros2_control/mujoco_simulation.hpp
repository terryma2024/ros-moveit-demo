/**
 * Copyright (c) 2026, United States Government, as represented by the
 * Administrator of the National Aeronautics and Space Administration.
 *
 * All rights reserved.
 *
 * This software is licensed under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with the
 * License. You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations
 * under the License.
 */

#pragma once

#include <atomic>
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <functional>
#include <memory>
#include <mutex>
#include <string>
#include <thread>
#include "mujoco_ros2_control/clock_trace.hpp"
#include <utility>
#include <vector>

#include <rclcpp/rclcpp.hpp>
#include <realtime_tools/realtime_publisher.hpp>
#include <rosgraph_msgs/msg/clock.hpp>

#include "glfw_adapter.h"  // for mj::GlfwAdapter
#include "simulate.h"      // must be on your include path, handled by CMake

#include <mujoco/mujoco.h>

#include <geometry_msgs/msg/pose_stamped.hpp>
#include <geometry_msgs/msg/twist_stamped.hpp>
#include <mujoco_ros2_control_msgs/msg/free_joint_state.hpp>
#include <mujoco_ros2_control_msgs/msg/simulation_state.hpp>
#include <mujoco_ros2_control_msgs/srv/get_viewer_camera.hpp>
#include <mujoco_ros2_control_msgs/srv/reset_world.hpp>
#include <mujoco_ros2_control_msgs/srv/set_free_joint_state.hpp>
#include <mujoco_ros2_control_msgs/srv/set_pause.hpp>
#include <mujoco_ros2_control_msgs/srv/set_viewer_camera.hpp>
#include <mujoco_ros2_control_msgs/srv/step_simulation.hpp>
#include <mujoco_ros2_control_plugins/mujoco_ros2_control_plugin_capabilities.hpp>
#include <mujoco_ros2_control_plugins/mujoco_ros2_control_plugins_base.hpp>
#include <sensor_msgs/msg/joint_state.hpp>

#include <mujoco_ros2_control/simulation_observer_dispatcher.hpp>
#include <mujoco_ros2_control/macos_ui_dispatcher.hpp>

class MujocoSimulationTest;

namespace mujoco_ros2_control
{
/**
 * @brief ROS 2-based container for the mujoco Simulate application.
 *
 * This class wraps the MuJoCo simulation and Simulate application, while providing necessary
 * hooks to the ros2_control system interface to enable interaction with the sim using
 * "normal" ROS 2 constructs.
 *
 * This class is responsible for mujoco model and data, along with threads for the main physics
 * and rendering loops. It also provides several ROS interfaces for interacting with the
 * underlying simulation - including publishing simulated time to /clock, as well as services
 * for pausing, stepping, and resetting the simulation.
 *
 * Importantly, the physics loop is intended to run at whatever speed (relative realtime) is
 * requested by the user. It is important to not interrupt the loop with locking calls that
 * interact with either the physics sim data, `mj_data_`,  or the model, `mj_model_`.
 * Instead, consumers of this class are provided with functions to read all sim data and provide
 * control inputs from their own mjData containers.
 *
 * The functions relevant to interacting with the physics sim's mjData are:
 *
 * `copy_physics_data(...)` will lock the sim and do a full copy of the existing `mj_data_`
 * into the provided container, which can be used as the caller requires. Because the physics
 * loop can hold the sim mutex for a large fraction of a display refresh while it batches
 * steps, this can block the caller and should not be used from latency-sensitive threads.
 *
 * `acquire_data_snapshot()` instead borrows the most recent completed post-step snapshot of
 * `mj_data_`, produced by the physics loop into a separate buffer. Acquiring is a pointer
 * swap under a mutex that is never held for longer than a swap, so the caller performs no
 * scene-sized copy and never waits on physics stepping or refresh. The producer refreshes it
 * after every successful physics step. This is what the hardware interface uses in `write()`.
 *
 * `apply_control_data(...)` will copy control inputs from the provided mjData into staging
 * buffers that the physics loop applies to `mj_data_` immediately before each step.
 * Specifically, it stages `ctrl` and `qfrc_applied`. Both of these values should come from
 * the interfaces consuming this class. This  This only takes the control staging mutex
 * and never blocks on physics stepping.
 *
 * `overwrite_physics_data(...)` will completely replace the data for the sim. Should be used
 * with extreme caution.
 *
 * `set_pre_step_callback(...)` registers a callback which will be triggered in the Physics
 * Loop. It will be called immediately before `mj_step()`, providing direct access to
 * `mj_data_` immediately before progressing the simulation. This gives consumers direct
 * access to access and modify the data immediately before integration. Users should be
 * extremely careful with this callback, as it exposes "god like" powers to the simulation
 * environment and can break, slow down, or otherwise damage the simulation. This should also
 * be used with caution.
 *
 * Thread safety is still somewhat messy, as callers are provided with a simulation mutex that
 * locks the model and data while the actual mujoco engine moves the sim forward. Callers
 * need to be wary of locking that mutex external to this class, as it can have significant
 * consequences on the simulation's speed.
 *
 */
class MujocoSimulation
{
public:
  /**
   * @brief Callback invoked when the simulation's state must be reset.
   *
   * Triggered by the ~/reset_world service or by a any other reset detected in the physics
   * loop. The callback will be run with the sim mutex but after all data has been restored.
   *
   * @param fill_initial_state When true, the caller has not already populated
   *        mj_data_->qpos/qvel/ctrl from a keyframe and the callback should restore the captured
   *        initial state. When false, a keyframe has already been applied.
   */
  using ResetCallback = std::function<void(bool fill_initial_state)>;

  /**
   * @brief Callback function type the `set_pre_step_callback` hook.
   *
   * Called before `mjStep` in the physics loop, use with care.
   *
   * @param data The data from the physics simulation, under thread lock.
   */
  using PreStepCallback = std::function<void(mjData* data)>;

  /**
   * @brief Construct a new Mujoco Simulation object. This is a no-op until initialization.
   */
  MujocoSimulation() = default;

  ~MujocoSimulation();

  /**
   * @brief Move-only lease preventing interactive viewer destruction during a runtime call.
   */
  class RuntimeUse
  {
  public:
    RuntimeUse() = default;
    ~RuntimeUse();
    RuntimeUse(RuntimeUse&& other) noexcept;
    RuntimeUse& operator=(RuntimeUse&& other) noexcept;
    RuntimeUse(const RuntimeUse&) = delete;
    RuntimeUse& operator=(const RuntimeUse&) = delete;

    explicit operator bool() const
    {
      return owner_ != nullptr;
    }

  private:
    friend class MujocoSimulation;
    explicit RuntimeUse(MujocoSimulation* owner) : owner_(owner)
    {
    }
    MujocoSimulation* owner_{ nullptr };
  };

  /**
   * @brief Acquire a viewer-lifetime lease, or an empty lease once shutdown has begun.
   */
  RuntimeUse acquire_runtime_use();

  /**
   * @brief Construct the Simulate application and start the UI thread (if not headless).
   *
   * This initializes the Simulate app and starts the UI thread in the background (if not
   * running headless). It also sets up required publishers and services using the provided node.
   */
  bool initialize(rclcpp::Node::SharedPtr node, const std::string& model_path, const std::string& mujoco_model_topic,
                  double sim_speed_factor, bool headless, bool disable_rendering);

  /**
   * @brief Apply a keyframe to the simulation by name.
   *
   * This locks the simulation mutex and attempts to apply a keyframe by name by calling
   * `mj_resetDataKeyframe`.
   */
  bool apply_keyframe(const std::string& keyframe_name);

  /**
   * @brief Can be called by consumers of this class to store the current state as the "initial" state.
   *
   * In particular, this persises qpos, qvel, and ctrl vectors from the data and writes them into our
   * 'initial_*' vectors.
   */
  void capture_initial_state();

  /**
   * @brief Register a callback function to be called on `reset_world_state`.
   */
  void set_reset_callback(ResetCallback callback);

  /**
   * @brief Register the callback run before every `mj_step()`.
   *
   * See the class documentation for more information. Any function called here will hold
   * the simulation mutex and block the physics loop. Use with care.
   */
  void set_pre_step_callback(PreStepCallback callback);

  /**
   * @brief Hand platform rendering state to an optional rendering capability before init().
   *
   * Ordinary plugins which do not implement the capability are accepted unchanged.
   */
  bool prepare_rendering_plugin(
      const std::shared_ptr<mujoco_ros2_control_plugins::MuJoCoROS2ControlPluginBase>& plugin);

  /**
   * @brief Roll back lifecycle ownership after a rendering plugin fails init().
   *
   * If shutdown already owns the renderer, this waits for that shutdown pass instead of
   * attempting a second close.
   */
  void discard_rendering_plugin(
      const std::shared_ptr<mujoco_ros2_control_plugins::MuJoCoROS2ControlPluginBase>& plugin);

  /**
   * @brief Release the interactive-viewer teardown barrier after SystemInterface::on_init().
   *
   * Every success and failure path calls this before macOS UI resources may be destroyed.
   */
  void mark_external_initialization_complete();

  /**
   * @brief Register an initialized plugin for optional simulation lifecycle notifications.
   *
   * Plugins which do not implement the observer capability are ignored by the dispatcher.
   */
  void add_observer_plugin(
      const std::shared_ptr<mujoco_ros2_control_plugins::MuJoCoROS2ControlPluginBase>& plugin);

  /**
   * @brief Start the physics thread. Must be called after load_model().
   */
  void start_physics_thread();

  /**
   * @brief Stop the physics and UI threads if they are running.
   */
  void shutdown();

  /**
   * @brief Accessor for the mujoco model.
   */
  mjModel* model()
  {
    return mj_model_;
  }

  /**
   * @brief Accessor for the raw mujoco simulation data.
   *
   * Users should generally not interact with the physics sim data excepting during setup and
   * other special circumstances. For "normal" processing it is recommended to use
   * `control_data` or other containers populated by `copy_mj_data`.
   */
  mjData* data()
  {
    return mj_data_;
  }

  /**
   * @brief Reset simulation state (qpos/qvel/ctrl/sensors/forces) to the captured initial state.
   *
   * @note Caller must hold the sim mutex.
   */
  void reset_world_state(bool fill_initial_state);

  /**
   * @brief Sets the pose and velocity of one or more free-joint objects, identified by body name.
   *
   * Applied atomically: every entry is validated before anything is written, so a single invalid
   * entry leaves the sim state unchanged. Duplicate body names are applied in order, so the last
   * one wins. See `FreeJointState.msg` for per-entry fields.
   *
   * @param error_message Set to a human-readable description (identifying the offending entry)
   * if this returns false.
   * @return true if every entry was applied; false otherwise, with no data modified.
   */
  bool set_free_joint_states(const std::vector<mujoco_ros2_control_msgs::msg::FreeJointState>& free_joints,
                             std::string& error_message);

  /**
   * @brief Copies `mj_model_` into the provided container in a thread safe way.
   *
   * This locks the sim mutex and will pause the physics loop, so should be used sparingly.
   */
  void copy_physics_model(mjModel*& destination);

  /**
   * @brief Copies the provided mjData into mj_data_ in a thread safe way.
   *
   * @note This will completely overwrite the existing data, use with caution!
   */
  void overwrite_physics_data(mjData* source);

  /**
   * @brief Copies `mj_data_` into the provided container in a thread safe way.
   *
   * This locks the sim mutex and will pause the physics loop, so should be used sparingly.
   * Latency-sensitive callers should use `acquire_data_snapshot` or `copy_control_state` instead.
   * @note: If the destination is null it will be created.
   */
  void copy_physics_data(mjData*& destination);

  /**
   * @brief Borrows the latest completed post-step snapshot of `mj_data_` (producer-pays copying).
   *
   * The physics loop fills snapshot buffers on its own thread; this call only swaps pointers
   * to take ownership of the most recent completed one, so the caller never performs a scene-sized
   * copy and never waits for a stepping batch,or in-process refresh. If no new snapshot has
   * completed since the last call, the same buffer is returned again.
   * Also requests a refresh while paused, when no successful step is available to produce one.
   *
   * Ownership contract: there is a single borrower slot. The returned buffer remains valid and
   * is never touched by the physics loop until the next `acquire_data_snapshot()` call, at
   * which point the previous buffer is recycled back to the producer. The borrower may freely
   * write to the buffer (e.g., plugins composing control inputs); all such writes are discarded
   * when the buffer is recycled and refilled. Only one consumer may use this API — concurrent
   * callers would swap each other's buffer out from underneath them.
   * Cold-path consumers that need their own copy should use `copy_physics_data` instead.
   */
  mjData* acquire_data_snapshot();

  /**
   * @brief Small snapshot of the state the hardware interface needs every control cycle.
   *
   * This data structure is much smaller than a full mjData copy, so publishing and copying
   * it is also far cheaper, regardless of scene complexity. Refreshed by the physics loop
   * after every step, immediately before that step's /clock tick, so a consumer woken by a
   * clock tick sees state that is synchronous with (or newer than) that tick's sim time.
   */
  struct ControlState
  {
    mjtNum time{ 0.0 };
    std::vector<mjtNum> qpos;
    std::vector<mjtNum> qvel;
    std::vector<mjtNum> act;
    std::vector<mjtNum> qfrc_actuator;
    std::vector<mjtNum> sensordata;
    std::vector<mjtNum> ctrl;
  };

  /**
   * @brief Copies the latest per-step control state into the provided container.
   *
   * The copy is under a dedicated mutex and is significantly faster than
   * physics stepping or full-mjData copies.
   * This is what the hardware interface uses in `read()` and `write()`.
   */
  void copy_control_state(ControlState& destination);

  /**
   * @brief Stages control fields from `control_data` for the physics loop in a thread safe way.
   *
   * Specifically, copies `control_data->ctrl` and `control_data->qfrc_applied` into staging
   * buffers which the physics loop copies into `mj_data_` immediately before each step. These
   * are the only two fields staged here because both are "held" quantities that persist
   * correctly across a batch of steps. Anything else that requires direct access to simulation
   * data can access it through the `set_pre_step_callback` functions.
   */
  void apply_control_data(mjData* control_data);

  /**
   * @brief Accessor for the mutex which locks access to the data and model.
   */
  std::recursive_mutex& mutex() const
  {
    RCLCPP_WARN_EXPRESSION(logger_, sim_mutex_ == nullptr, "Sim recursive mutex is still nullptr");
    return *sim_mutex_;
  }

  /**
   * @brief Returns the number of steps takein by the physics simulation.
   *
   * Equivalent to the step counter that is shown in the simulate UI.
   */
  uint64_t step_count() const
  {
    return step_count_.load();
  }

private:
  friend class ::MujocoSimulationTest;

  /**
   * @brief Execute one authoritative physics transition.
   *
   * @return A MuJoCo divergence message on failure, otherwise nullptr.
   */
  const char* step_authoritative_physics();

  // Focused private seam used only by the lifecycle-order unit test.
  void set_transition_callback_for_testing(std::function<void(const char*)> callback)
  {
    transition_callback_for_testing_ = std::move(callback);
  }

  void record_transition_for_testing(const char* event)
  {
    if (transition_callback_for_testing_)
    {
      transition_callback_for_testing_(event);
    }
  }

  void set_rendering_transition_callback_for_testing(std::function<void(const char*)> callback)
  {
    rendering_transition_callback_for_testing_ = std::move(callback);
  }

  void request_stop();
  void stop_rendering_plugins();
  void close_runtime_uses();
  void release_runtime_use();
  void record_context_destroyed();
  void record_viewer_destroyed();

  /**
   * @brief Helper function to compose hw interface and simulation provided Cartesian forces.
   *
   * This should be called before stepping the simulation. Assumes the sim mutex is held.
   */
  void apply_staged_control_inputs();

  /**
   * @brief Publishes the per-step control state from `mj_data_`.
   *
   * Called after every mj_step (and forward/reset), before the corresponding /clock tick.
   * Assumes the sim mutex is held; takes the control state mutex.
   */
  void publish_control_state();

  /**
   * @brief Refreshes the consumer-facing snapshot from `mj_data_`.
   *
   * Reclaims the producer-side buffer (clearing snapshot_ready_ if a previous fill was never
   * consumed), fills it outside any shared lock (the sim mutex serializes writers), then
   * raises snapshot_ready_ for the consumer. Assumes the sim mutex is held.
   */
  void refresh_data_snapshot();

  /**
   * @brief Loops the physics simulation until asked to terminate.
   */
  void physics_loop();

  /**
   * @brief Publish the current sim time to /clock.
   */
  void publish_clock();

  /**
   * @brief Progresses the simulate windows display if not running headless.
   */
  void update_sim_display();

  /**
   * @brief Reset simulation state, applying joint state overrides on top of the restored state.
   *
   * Private because the overrides are assumed to have already been validated (see
   * `validate_joint_state_overrides` / `validate_free_joint_states`) -- a precondition only
   * in-class callers can satisfy, since the validators are private too. Applying unvalidated
   * overrides writes through unresolved (-1) addresses.
   *
   * @note Caller must hold the sim mutex.
   */
  void reset_world_state(bool fill_initial_state, const mujoco_ros2_control_msgs::msg::SimulationState& state_overrides);

  /**
   * @brief Receive the reset-only signal emitted by the UI adapter after Simulate::Sync.
   *
   * The adapter retains Simulate's recursive mutex after the exact upstream
   * reset operation. This callback aligns the editable viewer buffers and
   * publishes a durable generation before RenderLoop releases that mutex.
   */
  static void simulate_reset_callback(void* context, mjtNum previous_time);
  void on_simulate_reset(mjtNum previous_time);
  void align_viewer_edit_buffers();

  /**
   * @brief Resolves a `header.frame_id` to the body it names: -1 for the world frame (empty
   * string) or for an unknown body.
   *
   * This is the single definition of the frame_id convention; `validate_frame_id` wraps it to
   * turn the unknown-body case into an error message.
   */
  int frame_body_id(const std::string& frame_id) const;

  /**
   * @brief Checks that `frame_id` is empty (world frame) or names a known MuJoCo body.
   *
   * @param field_label Identifies which field ("pose"/"twist") in `error_message` on failure.
   * @return true if valid; false otherwise, with `error_message` set.
   */
  bool validate_frame_id(const std::string& frame_id, const std::string& field_label, std::string& error_message) const;

  /**
   * @brief Returns the id of the free joint driving `body_id`, or -1 if there is none.
   */
  int find_free_joint_id(int body_id) const;

  /**
   * @brief Validates a list of `FreeJointState` entries against the model, without touching
   * `mj_data_`: every entry must name a body driven by a free joint, and both `header.frame_id`s
   * must be empty (world frame) or name a known body.
   *
   * @note Caller must hold the sim mutex.
   * @return true if every entry is valid; false otherwise, with `error_message` set.
   */
  bool validate_free_joint_states(const std::vector<mujoco_ros2_control_msgs::msg::FreeJointState>& free_joints,
                                  std::string& error_message);

  /**
   * @brief Writes free-joint states into `mj_data_->qpos`/`qvel`, resolving each entry's `pose`
   * and `twist` against their own `header.frame_id` -- they may reference different bodies, or
   * vary between world vs. relative frame to another body.
   * Does not refresh snapshots or run forward dynamics; the caller is responsible for both.
   *
   * @note Caller must hold the sim mutex and have validated `free_joints` first.
   */
  void apply_free_joint_states(const std::vector<mujoco_ros2_control_msgs::msg::FreeJointState>& free_joints);

  /**
   * @brief Validates a `JointState` message against the model, without touching `mj_data_`.
   *
   * Every named joint must be a single-DOF (hinge or slide) MuJoCo joint, and `position` /
   * `velocity` must each be empty or the same length as `name`. `effort` is not supported and
   * must be empty.
   *
   * @note Caller must hold the sim mutex.
   * @return true if the message is valid; false otherwise, with `error_message` set.
   */
  bool validate_joint_state_overrides(const sensor_msgs::msg::JointState& joint_state, std::string& error_message);

  /**
   * @brief Writes single-DOF joint states into `mj_data_->qpos`/`qvel`.
   * Does not refresh snapshots or run forward dynamics; the caller is responsible for both.
   *
   * @note Caller must hold the sim mutex and have validated `joint_state` first.
   */
  void apply_joint_state_overrides(const sensor_msgs::msg::JointState& joint_state);

  // Service callbacks
  void reset_world_callback(const std::shared_ptr<mujoco_ros2_control_msgs::srv::ResetWorld::Request> request,
                            std::shared_ptr<mujoco_ros2_control_msgs::srv::ResetWorld::Response> response);
  void set_pause_callback(const std::shared_ptr<mujoco_ros2_control_msgs::srv::SetPause::Request> request,
                          std::shared_ptr<mujoco_ros2_control_msgs::srv::SetPause::Response> response);
  void step_simulation_callback(const std::shared_ptr<mujoco_ros2_control_msgs::srv::StepSimulation::Request> request,
                                std::shared_ptr<mujoco_ros2_control_msgs::srv::StepSimulation::Response> response);
  void
  set_free_joint_state_callback(const std::shared_ptr<mujoco_ros2_control_msgs::srv::SetFreeJointState::Request> request,
                                std::shared_ptr<mujoco_ros2_control_msgs::srv::SetFreeJointState::Response> response);
  void set_viewer_camera_callback(
      const std::shared_ptr<mujoco_ros2_control_msgs::srv::SetViewerCamera::Request> request,
      std::shared_ptr<mujoco_ros2_control_msgs::srv::SetViewerCamera::Response> response);
  void get_viewer_camera_callback(
      const std::shared_ptr<mujoco_ros2_control_msgs::srv::GetViewerCamera::Request> request,
      std::shared_ptr<mujoco_ros2_control_msgs::srv::GetViewerCamera::Response> response);

  rclcpp::Logger get_logger() const
  {
    return logger_;
  }

  // Logger
  rclcpp::Logger logger_ = rclcpp::get_logger("MujocoSimulation");

  // Optional lifecycle observers, preserving plugin registration order.
  SimulationObserverDispatcher observer_dispatcher_{ logger_ };

  // Rendering-aware plugins are kept separately so their producer/worker
  // lifecycle can end before any platform context or viewer is destroyed.
  std::vector<std::shared_ptr<mujoco_ros2_control_plugins::MuJoCoROS2ControlRenderingPlugin>> rendering_plugins_;
  std::mutex rendering_lifecycle_mutex_;
  std::condition_variable rendering_lifecycle_cv_;
  bool rendering_shutdown_started_{ false };
  bool rendering_shutdown_complete_{ false };

  // ROS node (owned by the HW interface, used here for services and clock publisher).
  rclcpp::Node::SharedPtr node_;

  // System information
  std::string model_path_;
  std::string mujoco_model_topic_;

  // MuJoCo data pointers, these are the primary containers used by the physics simulation.
  // It is generally not recommended to interact with them directly.
  mjModel* mj_model_{ nullptr };

  // Primary data container for the physics loop. We do not recommend interacting with this
  // directly unless you are sure of what you are doing.
  mjData* mj_data_{ nullptr };

  // Double-buffered snapshot of mj_data_: the physics loop pays for all scene-sized copies,
  // the consumer borrows the result via acquire_data_snapshot() and performs no copy at all.
  // The producer (any writer holding the sim mutex) fills snapshot_write_ outside any shared
  // lock and raises snapshot_ready_; the consumer, when the flag is up, swaps the two pointers
  // under data_exchange_mutex_ and reads snapshot_read_ in place.
  mjData* snapshot_write_{ nullptr };
  mjData* snapshot_read_{ nullptr };
  bool snapshot_ready_{ false };

  // Control inputs staged by apply_control_data, applied to mj_data_ before each step.
  std::vector<mjtNum> ctrl_staged_;
  std::vector<mjtNum> qfrc_applied_staged_;

  // False until apply_control_data is first called (and cleared on reset), so that initial /
  // reset ctrl values in mj_data_ are not clobbered by stale staging buffers.
  bool control_inputs_staged_{ false };

  // Guards only the snapshot pointer swap and snapshot_ready_ flag.
  // Lock order: sim_mutex_ (if needed) is always taken before this one.
  std::mutex data_exchange_mutex_;

  // Set by acquire_data_snapshot when a consumer takes the snapshot. Successful physics steps
  // always refresh authoritatively; this request additionally refreshes while paused so UI edits
  // and other non-step changes become visible. Starts true so the first paused refresh happens.
  std::atomic<bool> snapshot_refresh_requested_{ true };

  // Guards the staged control inputs (ctrl_staged_, qfrc_applied_staged_,
  // control_inputs_staged_). Separate from data_exchange_mutex_ so that staging commands in
  // write() and applying them before each physics step never queue behind a full mjData copy.
  // Critical sections are all small buffer copies.
  // Lock order: sim_mutex_ (if needed) before this one; never held with data_exchange_mutex_.
  std::mutex control_staging_mutex_;

  // Per-step control state served by copy_control_state. Guarded by its own mutex, separate
  // from data_exchange_mutex_, so the reduced control-state copies never queue behind a full
  // mjData snapshot copy.
  // Lock order: sim_mutex_ (if needed) before this one; never held with data_exchange_mutex_.
  ControlState control_state_;
  std::mutex control_state_mutex_;

  // For rendering
  mjvCamera cam_;
  mjvOption opt_;
  mjvPerturb pert_;

  // Speed scaling parameter. if set to >0 then we ignore the value set in the simulate app and instead
  // attempt to loop at whatever this is set to. If this is <0, then we use the value from the app.
  double sim_speed_factor_{ -1.0 };

  // True when running without a display (no GLFW window)
  bool headless_{ false };
  // Independent sensor-rendering policy; a headless simulation may still render with CGL/EGL.
  bool rendering_enabled_{ true };
  bool viewer_available_for_testing_{ false };

  // Primary simulate object
  std::unique_ptr<mujoco::Simulate> sim_;

  // Threads for rendering physics and the UI simulation
  std::thread physics_thread_;
  std::thread ui_thread_;
  std::mutex shutdown_mutex_;
  bool shutdown_complete_{ false };
  std::mutex runtime_use_mutex_;
  std::condition_variable runtime_use_cv_;
  std::size_t active_runtime_uses_{ 0 };
  bool accepting_runtime_uses_{ true };
  std::mutex viewer_service_mutex_;
#ifndef __APPLE__
  std::mutex viewer_destroy_mutex_;
  std::condition_variable viewer_destroy_cv_;
  bool viewer_destroy_requested_{ false };
#else
  GLFWwindow* macos_camera_window_{ nullptr };
  std::atomic<bool> macos_stop_requested_{ false };
  std::mutex macos_ui_state_mutex_;
  std::condition_variable macos_ui_state_cv_;
  bool macos_ui_finished_{ false };
  bool macos_ui_cleanup_finished_{ false };
  MacosUiTaskId macos_ui_task_id_{ 0 };
#endif
  std::mutex external_initialization_mutex_;
  std::condition_variable external_initialization_cv_;
  bool external_initialization_complete_{ false };
  bool context_destroy_recorded_{ false };
  bool viewer_destroy_recorded_{ false };

  // Primary clock publisher for the world
  std::shared_ptr<rclcpp::Publisher<rosgraph_msgs::msg::Clock>> clock_publisher_;
  realtime_tools::RealtimePublisher<rosgraph_msgs::msg::Clock>::SharedPtr clock_realtime_publisher_;

  // Mutex used inside simulate.h for protecting model/data, we keep a reference
  // here to protect access to shared data.
  // TODO: It would be far better to put all relevant data into a single container with accessors
  //       in a common location rather than passing around the raw pointer to the mutex, but it would
  //       require more work to pull it out of simulate.h.
  std::recursive_mutex* sim_mutex_{ nullptr };

  // Reset world service
  rclcpp::CallbackGroup::SharedPtr reset_world_cb_group_;
  rclcpp::Service<mujoco_ros2_control_msgs::srv::ResetWorld>::SharedPtr reset_world_service_;

  // Set pause service
  rclcpp::CallbackGroup::SharedPtr set_pause_cb_group_;
  rclcpp::Service<mujoco_ros2_control_msgs::srv::SetPause>::SharedPtr set_pause_service_;

  // Step simulation service
  rclcpp::CallbackGroup::SharedPtr step_simulation_cb_group_;
  rclcpp::Service<mujoco_ros2_control_msgs::srv::StepSimulation>::SharedPtr step_simulation_service_;

  // Set free joint state service (teleport/reset a free-joint object's pose)
  rclcpp::CallbackGroup::SharedPtr set_free_joint_state_cb_group_;
  rclcpp::Service<mujoco_ros2_control_msgs::srv::SetFreeJointState>::SharedPtr set_free_joint_state_service_;

  // Viewer camera services share a mutually-exclusive callback group and still
  // take the upstream Simulate/UI recursive mutex for atomicity.
  rclcpp::CallbackGroup::SharedPtr viewer_camera_cb_group_;
  rclcpp::Service<mujoco_ros2_control_msgs::srv::SetViewerCamera>::SharedPtr set_viewer_camera_service_;
  rclcpp::Service<mujoco_ros2_control_msgs::srv::GetViewerCamera>::SharedPtr get_viewer_camera_service_;

  // Pending steps to execute while paused, and synchronization for blocking callers
  std::atomic<uint32_t> pending_steps_{ 0 };
  std::atomic<bool> step_diverged_{ false };
  std::atomic<bool> steps_interrupted_{ false };
  std::atomic<bool> keyboard_step_requested_{ false };
  std::atomic<uint64_t> step_count_{ 0 };
  std::unique_ptr<ClockTrace> clock_trace_;
  uint64_t diagnostic_successful_step_ = 0;
  std::mutex steps_cv_mutex_;
  std::condition_variable steps_cv_;

  struct PendingUiReset
  {
    uint64_t generation{ 0 };
    mjtNum previous_time{ 0.0 };
  };

  // The UI adapter publishes these after a reset Sync while holding sim_mutex_. The atomic
  // generation makes the completed reset operation durable across the mutex
  // handoff; the queue retains the pre-reset clock value for each generation.
  std::deque<PendingUiReset> pending_ui_resets_;
  std::atomic<uint64_t> published_ui_reset_generation_{ 0 };
  uint64_t processed_ui_reset_generation_{ 0 };
  // Storage for initial state (used for reset_world)
  std::vector<mjtNum> initial_qpos_;
  std::vector<mjtNum> initial_qvel_;
  std::vector<mjtNum> initial_ctrl_;

  // Callback into the HW interface to perform component-side reset bookkeeping.
  ResetCallback reset_callback_;

  // Callback run immediately before every mj_step(), defaults to nothing.
  PreStepCallback pre_step_callback_{ [](mjData* /*data*/) {} };

  std::function<void(const char*)> transition_callback_for_testing_;
  std::function<void(const char*)> rendering_transition_callback_for_testing_;
};

}  // namespace mujoco_ros2_control
