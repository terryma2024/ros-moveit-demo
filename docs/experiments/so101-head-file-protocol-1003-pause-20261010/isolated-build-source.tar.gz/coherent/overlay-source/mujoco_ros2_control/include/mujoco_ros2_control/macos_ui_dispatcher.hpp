/**
 * Copyright (c) 2025, United States Government, as represented by the
 * Administrator of the National Aeronautics and Space Administration.
 *
 * All rights reserved.
 *
 * This software is licensed under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with the
 * License. You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations
 * under the License.
 */

#ifndef MUJOCO_ROS2_CONTROL__MACOS_UI_DISPATCHER_HPP_
#define MUJOCO_ROS2_CONTROL__MACOS_UI_DISPATCHER_HPP_

#ifdef __APPLE__

#include <cstdint>
#include <functional>

namespace mujoco_ros2_control
{
using MacosUiTaskId = std::uint64_t;

MacosUiTaskId submit_macos_ui_task(
  std::function<void()> task, std::function<void()> stop, std::function<void()> cleanup);
bool cancel_macos_ui_task(MacosUiTaskId task_id, std::function<void()> on_cancel = {});
void mark_current_macos_ui_task_ready();
void notify_macos_ui_not_required();
bool run_macos_ui_task_on_main_thread();
bool run_macos_ui_cleanup_on_main_thread();
void request_macos_ui_stop();
}  // namespace mujoco_ros2_control

#endif

#endif  // MUJOCO_ROS2_CONTROL__MACOS_UI_DISPATCHER_HPP_
