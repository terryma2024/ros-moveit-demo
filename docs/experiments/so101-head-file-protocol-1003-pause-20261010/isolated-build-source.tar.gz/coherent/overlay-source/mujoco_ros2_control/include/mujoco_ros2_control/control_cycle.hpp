// Copyright 2026 ROS2-Control Development Team
// Licensed under the Apache License, Version 2.0.
#pragma once

#include <rclcpp/duration.hpp>
#include <rclcpp/time.hpp>

namespace mujoco_ros2_control
{

enum class CycleOperation {Read, Update, Write};

// A sim-time cycle keeps the caller's sampled timestamp across all operations.
// Other clock domains retain the original per-operation sampling policy.
template<class Manager, class ClockReader, class Begin, class End, class AfterRead>
bool execute_control_cycle(
  Manager & manager, const rclcpp::Time & cycle_time,
  const rclcpp::Duration & period, bool use_sim_time, ClockReader get_time,
  Begin begin, End end, AfterRead after_read)
{
  const auto invoke = [&](CycleOperation operation, auto call) {
      const auto start = begin(operation);
      const auto argument = use_sim_time ? cycle_time : get_time();
      call(argument, period);
      end(operation, argument, start);
    };

  invoke(CycleOperation::Read,
    [&](const auto & time, const auto & dt) {manager.read(time, dt);});
  if (!after_read()) {
    return false;
  }
  invoke(CycleOperation::Update,
    [&](const auto & time, const auto & dt) {manager.update(time, dt);});
  invoke(CycleOperation::Write,
    [&](const auto & time, const auto & dt) {manager.write(time, dt);});
  return true;
}

}  // namespace mujoco_ros2_control

