#include "mujoco_ros2_control/clock_trace.hpp"
#include "mujoco_ros2_control/exit_phase.hpp"

#include <atomic>
#include <chrono>
#include <cstdlib>
#include <fstream>
#include <iterator>
#include <stdexcept>
#include <thread>
#include <array>
#include <cerrno>
#include <fcntl.h>
#include <time.h>
#include <unistd.h>

namespace mujoco_ros2_control
{
namespace
{
constexpr uint64_t overflow = 1, io_failure = 2, incomplete = 4, late_producer = 8;
std::atomic<uint64_t> epoch{0};
std::atomic<uint64_t> all_invalid{0};
struct Slot
{
  std::atomic<uint64_t> fields[11]{};
};
static_assert(sizeof(Slot) == ClockTrace::record_bytes);
static_assert(std::atomic<uint64_t>::is_always_lock_free);
static_assert(ClockTrace::payload_bytes * 2 == 184549376);
static_assert(ClockTrace::payload_bytes * 2 + 1048576 < 201326592);
}
struct ClockTrace::Impl
{
  std::unique_ptr<Slot[]> slots;
  size_t limit;
  std::atomic<uint64_t> reserved{0}, committed{0}, invalid{0};
  std::atomic<bool> closing{false}, stop{false};
  uint64_t written = 0;
  int fd = -1;
  std::string directory, stream;
  std::thread drainer;
  bool finished = false;
  void fail(uint64_t flags) noexcept
  {
    invalid.fetch_or(flags);
    all_invalid.fetch_or(flags);
  }

  bool write_all(int handle, const void * raw, size_t count) noexcept
  {
    auto * data = static_cast<const char *>(raw);
    while (count) {
      const auto n = ::write(handle, data, count);
      if (n < 0 && errno == EINTR) {continue;}
      if (n <= 0) {fail(io_failure); return false;}
      data += n; count -= static_cast<size_t>(n);
    }
    return true;
  }
  bool checked_close(int handle) noexcept
  {
    if (::close(handle) != 0) {fail(io_failure); return false;}
    return true;
  }
  void drain() noexcept
  {
    const auto count = std::min<uint64_t>(reserved.load(std::memory_order_acquire), limit);
    // Batch complete immutable slots outside the producers; never reuse or clear a slot.
    std::array<uint64_t, 11 * 256> batch{};
    while (written < count && !(invalid.load() & io_failure)) {
      size_t ready = 0;
      while (ready < 256 && written + ready < count) {
        const auto & slot = slots[written + ready];
        if (slot.fields[10].load(std::memory_order_acquire) != 1) {break;}
        for (size_t i = 0; i < 11; ++i) {
          batch[ready * 11 + i] = slot.fields[i].load(std::memory_order_relaxed);
        }
        ++ready;
      }
      if (!ready) {break;}
      if (!write_all(fd, batch.data(), ready * ClockTrace::record_bytes)) {break;}
      written += ready;
    }
  }
  void status(bool final)
  {
    const std::string destination = directory + "/" + stream + ".status.json";
    const std::string temporary = destination + ".tmp";
    const std::string text = "{\"schema\":\"SOCLK001\",\"stream\":\"" + stream +
      "\",\"heartbeat_ns\":" + std::to_string(ClockTrace::monotonic_ns()) +
      ",\"reserved\":" + std::to_string(reserved.load()) +
      ",\"committed\":" + std::to_string(committed.load()) +
      ",\"written\":" + std::to_string(written) +
      ",\"invalid_flags\":" + std::to_string(invalid.load()) +
      ",\"final\":" + (final ? "true" : "false") + "}\n";
    int handle = ::open(temporary.c_str(), O_WRONLY | O_CREAT | O_TRUNC | O_NOFOLLOW, 0600);
    if (handle < 0) {fail(io_failure); return;}
    bool ok = write_all(handle, text.data(), text.size());
    if (::fsync(handle) != 0) {fail(io_failure); ok = false;}
    if (!checked_close(handle)) {ok = false;}
    if (ok && ::rename(temporary.c_str(), destination.c_str()) != 0) {
      fail(io_failure);
    }
  }
  Impl(const std::string & dir, const std::string & manifest, const std::string & name, size_t count)
  : limit(count), directory(dir), stream(name)
  {
    if (!count || count > ClockTrace::capacity || (name != "physics" && name != "loop") ||
      manifest.empty() || manifest.size() > 65536) {throw std::invalid_argument("CLOCK_TRACE_CONFIG");}
    slots = std::make_unique<Slot[]>(count);
    if (sizeof(Slot) * count > ClockTrace::payload_bytes) {
      throw std::runtime_error("CLOCK_TRACE_MEMORY_BUDGET");
    }
    fd = ::open((dir + "/" + name + ".bin").c_str(),
      O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW, 0600);
    if (fd < 0) {throw std::runtime_error("CLOCK_TRACE_OPEN");}
    const std::string header = "{\"schema\":\"SOCLK001\",\"record_bytes\":88,\"stream\":\"" +
      name + "\",\"manifest\":" + manifest + "}";
    const uint64_t length = header.size();
    const bool ok = write_all(fd, "SOCLK001", 8) && write_all(fd, &length, 8) &&
      write_all(fd, header.data(), header.size());
    if (!ok || ::fsync(fd) != 0) {
      checked_close(fd); fd = -1; throw std::runtime_error("CLOCK_TRACE_HEADER");
    }
    status(false);
    if (invalid.load()) {
      checked_close(fd); fd = -1; throw std::runtime_error("CLOCK_TRACE_INITIAL_STATUS");
    }
    try {
      drainer = std::thread([this]() {
        while (!stop.load(std::memory_order_acquire)) {
          drain(); status(false);
          std::this_thread::sleep_for(std::chrono::milliseconds(100));
        }
      });
    } catch (...) {checked_close(fd); fd = -1; throw;}
  }
};
ClockTrace::ClockTrace(const std::string & directory, const std::string & manifest,
  const std::string & stream, size_t slots)
: impl_(std::make_unique<Impl>(directory, manifest, stream, slots)) {}
ClockTrace::~ClockTrace() {finish();}
std::unique_ptr<ClockTrace> ClockTrace::from_environment(const std::string & stream)
{
  const auto * dir = std::getenv("SO101_CLOCK_TRACE_DIR");
  if (!dir || !*dir) {return nullptr;}
  const auto * path = std::getenv("SO101_CLOCK_TRACE_MANIFEST");
  if (!path || !*path) {throw std::runtime_error("CLOCK_TRACE_MANIFEST_MISSING");}
  std::ifstream input(path, std::ios::binary);
  if (!input) {throw std::runtime_error("CLOCK_TRACE_MANIFEST_OPEN");}
  // Configure before RT; cap file consumption as well as the stored header.
  std::string manifest;
  char buffer[4096];
  while (input.read(buffer, sizeof(buffer)) || input.gcount()) {
    manifest.append(buffer, static_cast<size_t>(input.gcount()));
    if (manifest.size() > 65536) {throw std::runtime_error("CLOCK_TRACE_MANIFEST_SIZE");}
  }
  if (!input.eof()) {throw std::runtime_error("CLOCK_TRACE_MANIFEST_READ");}
  return std::make_unique<ClockTrace>(dir, manifest, stream);
}
uint64_t ClockTrace::monotonic_ns() noexcept
{
  timespec now{};
  if (::clock_gettime(CLOCK_MONOTONIC, &now) != 0) {return 0;}
  return static_cast<uint64_t>(now.tv_sec) * 1000000000 + static_cast<uint64_t>(now.tv_nsec);
}
bool ClockTrace::record(ClockTraceKind kind, uint64_t id, uint64_t epoch, int64_t sim_ns,
  int64_t auxiliary, uint64_t start, uint64_t end, uint64_t actor, uint64_t flags) noexcept
{
  if (impl_->closing.load(std::memory_order_acquire)) {
    impl_->fail(late_producer); return false;
  }
  const auto index = impl_->reserved.fetch_add(1, std::memory_order_relaxed);
  if (index >= impl_->limit) {impl_->fail(overflow); return false;}
  const std::array<uint64_t, 10> values{{static_cast<uint64_t>(kind), index, id, epoch,
    static_cast<uint64_t>(sim_ns), static_cast<uint64_t>(auxiliary), start, end, actor, flags}};
  auto & slot = impl_->slots[index];
  for (size_t i = 0; i < values.size(); ++i) {slot.fields[i].store(values[i], std::memory_order_relaxed);}
  slot.fields[10].store(1, std::memory_order_release);
  impl_->committed.fetch_add(1, std::memory_order_release);
  return true;
}
bool ClockTrace::finish()
{
  const unsigned component=impl_->stream=="physics"?1:2;
  ExitPhaseScope finish_phase(100,component);
  if (impl_->finished) {return impl_->invalid.load() == 0;}
  impl_->closing.store(true, std::memory_order_release);
  impl_->stop.store(true, std::memory_order_release);
  if (impl_->drainer.joinable()) {
    observe_exit(101,component,[&] {impl_->drainer.join();});
  }
  observe_exit(102,component,[&] {impl_->drain();});
  if (impl_->reserved.load() != impl_->committed.load() ||
    impl_->committed.load() != impl_->written) {impl_->fail(incomplete);}
  if (observe_exit(103,component,[&] {return ::fsync(impl_->fd);}) != 0) {impl_->fail(io_failure);}
  observe_exit(104,component,[&] {return impl_->checked_close(impl_->fd);}); impl_->fd = -1;
  const int directory = ::open(impl_->directory.c_str(), O_RDONLY | O_DIRECTORY);
  if (directory < 0) {impl_->fail(io_failure);}
  else {
    if (observe_exit(105,component,[&] {return ::fsync(directory);}) != 0) {impl_->fail(io_failure);}
    observe_exit(106,component,[&] {return impl_->checked_close(directory);});
  }
  // Publish every binary and directory finalization failure before the final status.
  observe_exit(107,component,[&] {impl_->status(true);});
  const int final_directory = ::open(impl_->directory.c_str(), O_RDONLY | O_DIRECTORY);
  const auto before_final_sync = impl_->invalid.load();
  if (final_directory < 0) {impl_->fail(io_failure);}
  else {
    if (observe_exit(108,component,[&] {return ::fsync(final_directory);}) != 0) {impl_->fail(io_failure);}
    observe_exit(109,component,[&] {return impl_->checked_close(final_directory);});
  }
  if (impl_->invalid.load() != before_final_sync) {
    observe_exit(110,component,[&] {impl_->status(true);});
  }
  impl_->finished = true;
  return impl_->invalid.load() == 0;
}
uint64_t ClockTrace::invalid_flags() const noexcept {return impl_->invalid.load();}
uint64_t ClockTrace::reset_epoch() noexcept {return epoch.load(std::memory_order_acquire);}
uint64_t ClockTrace::complete_reset() noexcept {return epoch.fetch_add(1, std::memory_order_acq_rel) + 1;}
uint64_t ClockTrace::all_invalid_flags() noexcept {return all_invalid.load();}
}
