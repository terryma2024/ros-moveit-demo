/**
 * Copyright (c) 2025, United States Government, as represented by the
 * Administrator of the National Aeronautics and Space Administration.
 *
 * All rights reserved.
 *
 * This software is licensed under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with the
 * License. You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations
 * under the License.
 */

#include "mujoco_ros2_control/macos_ui_dispatcher.hpp"

#ifdef __APPLE__

#include <condition_variable>
#include <functional>
#include <mutex>
#include <utility>

#include <rclcpp/rclcpp.hpp>

namespace mujoco_ros2_control
{
namespace
{
std::mutex macos_ui_mutex;
std::condition_variable macos_ui_cv;
std::function<void()> macos_ui_task;
std::function<void()> macos_ui_stop;
std::function<void()> macos_ui_cleanup;
MacosUiTaskId macos_ui_next_task_id = 1;
MacosUiTaskId macos_ui_pending_task_id = 0;
MacosUiTaskId macos_ui_running_task_id = 0;
MacosUiTaskId macos_ui_cleanup_task_id = 0;
MacosUiTaskId macos_ui_cancel_requested_id = 0;
MacosUiTaskId macos_ui_ready_task_id = 0;
bool macos_ui_decided = false;
bool macos_ui_shutdown_requested = false;
}  // namespace

MacosUiTaskId submit_macos_ui_task(
  std::function<void()> task, std::function<void()> stop, std::function<void()> cleanup)
{
  RCLCPP_INFO(
    rclcpp::get_logger("mujoco_macos_ui"),
    "Submitting MuJoCo UI task to the process main thread.");
  MacosUiTaskId task_id;
  {
    const std::lock_guard<std::mutex> lock(macos_ui_mutex);
    task_id = macos_ui_next_task_id++;
    macos_ui_task = std::move(task);
    macos_ui_stop = std::move(stop);
    macos_ui_cleanup = std::move(cleanup);
    macos_ui_pending_task_id = task_id;
    macos_ui_cleanup_task_id = task_id;
    macos_ui_cancel_requested_id = 0;
    macos_ui_ready_task_id = 0;
    macos_ui_shutdown_requested = false;
    macos_ui_decided = true;
  }
  macos_ui_cv.notify_all();
  return task_id;
}

bool cancel_macos_ui_task(MacosUiTaskId task_id, std::function<void()> on_cancel)
{
  std::function<void()> stop;
  {
    std::unique_lock<std::mutex> lock(macos_ui_mutex);
    if (macos_ui_ready_task_id == task_id)
    {
      // The UI task published sim_ready before the timeout raced with it. Let initialize()
      // consume that ready future and keep the normal deferred cleanup path.
      return false;
    }
    if (macos_ui_pending_task_id == task_id && macos_ui_running_task_id != task_id)
    {
      if (on_cancel)
      {
        on_cancel();
      }
      macos_ui_task = {};
      macos_ui_stop = {};
      macos_ui_cleanup = {};
      macos_ui_pending_task_id = 0;
      macos_ui_cleanup_task_id = 0;
      macos_ui_decided = true;
      lock.unlock();
      macos_ui_cv.notify_all();
      return true;
    }
    if (macos_ui_running_task_id != task_id)
    {
      return false;
    }
    macos_ui_cancel_requested_id = task_id;
    if (on_cancel)
    {
      on_cancel();
    }
    stop = macos_ui_stop;
  }

  if (stop)
  {
    stop();
  }

  std::unique_lock<std::mutex> lock(macos_ui_mutex);
  macos_ui_cv.wait(lock, [task_id]() {
    return macos_ui_running_task_id != task_id && macos_ui_cleanup_task_id != task_id;
  });
  return true;
}

void mark_current_macos_ui_task_ready()
{
  const std::lock_guard<std::mutex> lock(macos_ui_mutex);
  macos_ui_ready_task_id = macos_ui_running_task_id;
}

void notify_macos_ui_not_required()
{
  {
    const std::lock_guard<std::mutex> lock(macos_ui_mutex);
    macos_ui_task = {};
    macos_ui_stop = {};
    macos_ui_cleanup = {};
    macos_ui_pending_task_id = 0;
    macos_ui_cleanup_task_id = 0;
    macos_ui_ready_task_id = 0;
    macos_ui_decided = true;
  }
  macos_ui_cv.notify_all();
}

bool run_macos_ui_task_on_main_thread()
{
  RCLCPP_INFO(
    rclcpp::get_logger("mujoco_macos_ui"),
    "Waiting for a MuJoCo UI task on the process main thread.");
  std::function<void()> task;
  MacosUiTaskId task_id = 0;
  {
    std::unique_lock<std::mutex> lock(macos_ui_mutex);
    macos_ui_cv.wait(lock, []() { return macos_ui_decided || macos_ui_shutdown_requested; });
    task = std::move(macos_ui_task);
    task_id = macos_ui_pending_task_id;
    macos_ui_pending_task_id = 0;
    macos_ui_running_task_id = task_id;
    macos_ui_decided = false;
  }
  if (!task)
  {
    RCLCPP_INFO(rclcpp::get_logger("mujoco_macos_ui"), "No MuJoCo UI task was required.");
    return false;
  }
  RCLCPP_INFO(
    rclcpp::get_logger("mujoco_macos_ui"),
    "Running MuJoCo UI task on the process main thread.");
  task();

  std::function<void()> cancelled_cleanup;
  {
    std::lock_guard<std::mutex> lock(macos_ui_mutex);
    if (macos_ui_cancel_requested_id == task_id && macos_ui_cleanup_task_id == task_id)
    {
      cancelled_cleanup = std::move(macos_ui_cleanup);
    }
    else
    {
      // This is one atomic task-return transition. A later timeout cancellation observes
      // ready_task_id and cannot revoke a cleanup after the main thread chose deferral.
      macos_ui_stop = {};
      macos_ui_running_task_id = 0;
    }
  }
  // A timeout may revoke a task while it is already executing. Finish its Cocoa teardown on
  // this same main thread before allowing initialize() to return and destroy the owner.
  if (cancelled_cleanup)
  {
    cancelled_cleanup();
    const std::lock_guard<std::mutex> lock(macos_ui_mutex);
    macos_ui_stop = {};
    macos_ui_cleanup = {};
    macos_ui_running_task_id = 0;
    macos_ui_cleanup_task_id = 0;
    macos_ui_cancel_requested_id = 0;
    macos_ui_ready_task_id = 0;
  }
  macos_ui_cv.notify_all();
  return true;
}

bool run_macos_ui_cleanup_on_main_thread()
{
  std::function<void()> cleanup;
  {
    const std::lock_guard<std::mutex> lock(macos_ui_mutex);
    cleanup = std::move(macos_ui_cleanup);
  }
  if (!cleanup)
  {
    return false;
  }
  RCLCPP_INFO(
    rclcpp::get_logger("mujoco_macos_ui"),
    "Cleaning up MuJoCo UI resources on the process main thread.");
  cleanup();
  {
    const std::lock_guard<std::mutex> lock(macos_ui_mutex);
    macos_ui_cleanup = {};
    macos_ui_cleanup_task_id = 0;
    macos_ui_ready_task_id = 0;
  }
  macos_ui_cv.notify_all();
  return true;
}

void request_macos_ui_stop()
{
  std::function<void()> stop;
  {
    const std::lock_guard<std::mutex> lock(macos_ui_mutex);
    macos_ui_shutdown_requested = true;
    stop = macos_ui_stop;
  }
  if (stop)
  {
    stop();
  }
  macos_ui_cv.notify_all();
}
}  // namespace mujoco_ros2_control

#endif
