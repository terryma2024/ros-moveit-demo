// Copyright 2026 PAL Robotics S.L.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include <mujoco_ros2_control/simulation_observer_dispatcher.hpp>

#include <exception>
#include <utility>

#include <rclcpp/logging.hpp>

namespace mujoco_ros2_control
{

SimulationObserverDispatcher::SimulationObserverDispatcher(rclcpp::Logger logger) : logger_(std::move(logger))
{
}

void SimulationObserverDispatcher::add(
    const std::shared_ptr<mujoco_ros2_control_plugins::MuJoCoROS2ControlPluginBase>& plugin)
{
  auto observer = std::dynamic_pointer_cast<Observer>(plugin);
  if (observer)
  {
    observers_.push_back({ std::move(observer), false });
  }
}

void SimulationObserverDispatcher::on_physics_step(const mjModel* model, const mjData* data)
{
  dispatch([model, data](Observer& observer) { observer.on_physics_step(model, data); });
}

void SimulationObserverDispatcher::on_reset()
{
  dispatch([](Observer& observer) { observer.on_reset(); });
}

void SimulationObserverDispatcher::on_pause(bool paused)
{
  dispatch([paused](Observer& observer) { observer.on_pause(paused); });
}

void SimulationObserverDispatcher::on_state_snapshot(const mjModel* model, const mjData* data, bool paused)
{
  dispatch([model, data, paused](Observer& observer) { observer.on_state_snapshot(model, data, paused); });
}

void SimulationObserverDispatcher::dispatch(const std::function<void(Observer&)>& callback)
{
  for (std::size_t index = 0; index < observers_.size(); ++index)
  {
    auto& entry = observers_[index];
    if (entry.disabled)
    {
      continue;
    }

    try
    {
      callback(*entry.observer);
    }
    catch (const std::exception& error)
    {
      entry.disabled = true;
      RCLCPP_ERROR(logger_, "Disabling simulation observer at index %zu after exception: %s", index, error.what());
    }
    catch (...)
    {
      entry.disabled = true;
      RCLCPP_ERROR(logger_, "Disabling simulation observer at index %zu after unknown exception", index);
    }
  }
}

}  // namespace mujoco_ros2_control
