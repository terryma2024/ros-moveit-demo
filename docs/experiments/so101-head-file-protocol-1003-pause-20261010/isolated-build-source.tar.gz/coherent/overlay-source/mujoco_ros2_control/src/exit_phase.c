#define _GNU_SOURCE
#include <stdint.h>
#include <stdatomic.h>
#include <stddef.h>
#include <errno.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

/* Explicit late-phase markers. No constructors, libc interposition or destructor IO. */
enum { CAPACITY=4096, HEADER_BYTES=4096, SLOT_BYTES=128, FILE_BYTES=528384 };
typedef struct {
 char magic[8]; uint32_t version,endian,header_bytes,slot_bytes,capacity,metadata_bytes;
 _Atomic uint32_t pid; uint32_t uid; uint64_t start;
 _Atomic uint32_t flags,claim; _Atomic uint64_t count;
} Header;
typedef struct {
 uint64_t sequence; uint32_t phase,component,tid; _Atomic uint32_t state;
 uint64_t begin,end; int64_t arg0,arg1; int32_t outcome,error; char padding[64];
} Slot;
_Static_assert(sizeof(Header)==64 && sizeof(Slot)==128,"layout");
_Static_assert(offsetof(Header,count)==56 && offsetof(Slot,state)==20,"offsets");
_Static_assert(__atomic_always_lock_free(8,0) && __atomic_always_lock_free(4,0),"lock_free");
#if __BYTE_ORDER__ != __ORDER_LITTLE_ENDIAN__
#error SOEXIT01_requires_little_endian
#endif
static Header *header;
static Slot *slots;
static pid_t creator;
static uint64_t monotonic_ns(void) {
 struct timespec t;
 if(clock_gettime(CLOCK_MONOTONIC,&t))return 0;
 return (uint64_t)t.tv_sec*1000000000ULL+(uint64_t)t.tv_nsec;
}
static int read_small(const char *name,char *out,size_t capacity) {
 int fd=open(name,O_RDONLY|O_CLOEXEC);if(fd<0)return -1;
 ssize_t n=read(fd,out,capacity);int saved=errno;close(fd);errno=saved;
 if(n<=0 || (size_t)n==capacity)return -1;
 return (int)n;
}
static uint64_t start_ticks(void) {
 char data[8192];int n=read_small("/proc/self/stat",data,sizeof(data)-1);
 if(n<0)return 0;
 data[n]=0;char *tail=strrchr(data,')');if(!tail)return 0;
 char *save=NULL,*word=strtok_r(tail+1," ", &save);
 for(int field=3;word && field<22;field++)word=strtok_r(NULL," ",&save);
 if(!word)return 0;
 char *end=NULL;errno=0;unsigned long long value=strtoull(word,&end,10);
 return errno || end==word || *end ? 0 : (uint64_t)value;
}
static int valid_process(const char *exe,const char *argument,const char *session) {
 char actual[4096],cmdline[16384];ssize_t n=readlink("/proc/self/exe",actual,sizeof(actual)-1);
 if(n<=0 || n==(ssize_t)sizeof(actual)-1)return 0;
 actual[n]=0;
 if(strcmp(actual,exe))return 0;
 const char *live_session=getenv("SO101_SIMULATION_SESSION_ID");
 if(!live_session || strcmp(live_session,session))return 0;
 int bytes=read_small("/proc/self/cmdline",cmdline,sizeof(cmdline));if(bytes<0 || cmdline[bytes-1])return 0;
 int found=0;
 for(int at=0;at<bytes;){size_t len=strnlen(cmdline+at,(size_t)(bytes-at));
  if(len==(size_t)(bytes-at))return 0;
  if(!strcmp(cmdline+at,argument))found++;
  at+=(int)len+1;
 }
 return found==1;
}
int exit_probe_init(const char *path,const char *metadata,unsigned metadata_bytes,
 const char *exe,const char *argument,const char *session) {
 int saved=errno,rc=1,fd=-1;void *mapping=MAP_FAILED;
 if(header || !path || !metadata || !exe || !argument || !session || !*path ||
  !metadata_bytes || metadata_bytes>4032 || !valid_process(exe,argument,session))goto done;
 uint64_t start=start_ticks();if(!start)goto done;
 fd=open(path,O_RDWR|O_NOFOLLOW|O_CLOEXEC);if(fd<0)goto done;
 struct stat s;if(fstat(fd,&s) || !S_ISREG(s.st_mode) || s.st_uid!=getuid() ||
  (s.st_mode&0777)!=0600 || s.st_nlink!=1 || s.st_size!=FILE_BYTES)goto done;
 mapping=mmap(NULL,FILE_BYTES,PROT_READ|PROT_WRITE,MAP_SHARED,fd,0);if(mapping==MAP_FAILED)goto done;
 Header *h=mapping;
 if(memcmp(h->magic,"SOEXIT01",8) || h->version!=1 || h->endian!=0x01020304 ||
  h->header_bytes!=HEADER_BYTES || h->slot_bytes!=SLOT_BYTES || h->capacity!=CAPACITY ||
  h->metadata_bytes!=metadata_bytes || memcmp((char*)mapping+64,metadata,metadata_bytes) ||
  atomic_load(&h->claim) || atomic_load(&h->flags) || atomic_load(&h->count) || h->uid || h->start)goto done;
 /* Fresh reserved header/slot bytes must be zero before creator binding. */
 for(size_t k=64+metadata_bytes;k<FILE_BYTES;k++)if(((unsigned char*)mapping)[k])goto done;
 uint32_t empty=0;
 if(!atomic_compare_exchange_strong(&h->pid,&empty,(uint32_t)getpid()))goto done;
 atomic_store_explicit(&h->claim,1,memory_order_release);
 h->uid=(uint32_t)getuid();h->start=start;
 creator=getpid();header=h;slots=(Slot*)((char*)mapping+HEADER_BYTES);
 atomic_store_explicit(&h->claim,2,memory_order_release);rc=0;
done:
 if(fd>=0)close(fd);
 if(rc && mapping!=MAP_FAILED)munmap(mapping,FILE_BYTES);
 errno=saved;return rc;
}
uint64_t exit_probe_begin(unsigned phase,unsigned component,int64_t arg0,int64_t arg1) {
 int saved=errno;uint64_t result=UINT64_MAX;
 if(!header || getpid()!=creator)goto done;
 if(atomic_load_explicit(&header->claim,memory_order_acquire)!=2 || atomic_load(&header->flags))goto done;
 if(!phase || component>2){atomic_fetch_or(&header->flags,2);goto done;}
 uint64_t i=atomic_fetch_add_explicit(&header->count,1,memory_order_relaxed);
 if(i>=CAPACITY){atomic_fetch_or(&header->flags,1);goto done;}
 Slot *s=&slots[i];s->sequence=i;s->phase=phase;s->component=component;s->tid=(uint32_t)gettid();
 s->arg0=arg0;s->arg1=arg1;s->begin=monotonic_ns();
 if(!s->begin){atomic_fetch_or(&header->flags,4);goto done;}
 atomic_store_explicit(&s->state,1,memory_order_release);result=i;
done:errno=saved;return result;
}
void exit_probe_end(uint64_t i,int result,int error) {
 int saved=errno;
 if(!header || getpid()!=creator || i==UINT64_MAX)goto done;
 if(i>=CAPACITY || i>=atomic_load(&header->count)){atomic_fetch_or(&header->flags,2);goto done;}
 Slot *s=&slots[i];
 if(atomic_load_explicit(&s->state,memory_order_acquire)!=1 || s->tid!=(uint32_t)gettid()){
  atomic_fetch_or(&header->flags,2);goto done;
 }
 s->end=monotonic_ns();s->outcome=result;s->error=error;
 if(s->end<s->begin){atomic_fetch_or(&header->flags,4);goto done;}
 atomic_store_explicit(&s->state,2,memory_order_release);
done:errno=saved;
}
