/**
 * Copyright (c) 2025, United States Government, as represented by the
 * Administrator of the National Aeronautics and Space Administration.
 *
 * All rights reserved.
 *
 * This software is licensed under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with the
 * License. You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations
 * under the License.
 */

#include "mujoco_ros2_control/mujoco_simulation.hpp"
#include "array_safety.h"
#include "mujoco_ros2_control/sim_display_text.hpp"
#include "mujoco_ros2_control/viewer_camera.hpp"

#include <unistd.h>
#include <cerrno>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <future>
#include <iostream>
#include <limits>
#include <memory>
#include <new>
#include <stdexcept>
#include <string>
#include <thread>

#include <std_msgs/msg/string.hpp>

#include <hardware_interface/version.h>
#include <rclcpp/version.h>
#include "ament_index_cpp/version.h"
#if AMENT_INDEX_CPP_VERSION_GTE(1, 13, 2)
#include <ament_index_cpp/get_package_share_path.hpp>
#else
#include <ament_index_cpp/get_package_share_directory.hpp>
#endif
#include <ament_index_cpp/get_resource.hpp>
#include <ament_index_cpp/get_resources.hpp>

#include <rclcpp/rclcpp.hpp>
#include "lodepng.h"

#define ROS_DISTRO_HUMBLE (HARDWARE_INTERFACE_VERSION_MAJOR < 3)

#define MUJOCO_PLUGIN_DIR "mujoco_plugin"

using namespace std::chrono_literals;

// constants
const double kSyncMisalign = 0.1;        // maximum misalignment before re-sync (simulation seconds)
const double kSimRefreshFraction = 0.7;  // fraction of refresh available for simulation
const int kErrorLength = 1024;           // load error string length

using Seconds = std::chrono::duration<double>;

namespace mujoco_ros2_control
{
namespace mj = ::mujoco;
namespace mju = ::mujoco::sample_util;

using SimulateResetCallback = void (*)(void* context, mjtNum previous_time);

/**
 * Consumes only the viewer's explicit pending reset at the RenderLoop adapter
 * seam. PollEvents runs while RenderLoop owns Simulate::mtx; taking the
 * recursive mutex here also makes direct headless/test polling safe.
 *
 * Calling the real Sync preserves upstream's complete reset bookkeeping. The
 * callback runs after that Sync completes, while the mutex is still owned, so
 * the editable buffers and durable reset generation can be published before
 * RenderLoop's immediately following outer Sync.
 */
class PendingViewerResetHandler
{
public:
  PendingViewerResetHandler(SimulateResetCallback callback, void* context) : callback_(callback), context_(context)
  {
  }

  void bind(mj::Simulate* sim)
  {
    sim_ = sim;
  }

  void process()
  {
    if (sim_ == nullptr)
    {
      return;
    }

    const std::unique_lock<std::recursive_mutex> lock(sim_->mtx);
    if (sim_->m_ == nullptr || sim_->d_ == nullptr || !sim_->pending_.reset)
    {
      return;
    }

    mjData* const reset_data = sim_->d_;
    const mjtNum previous_time = reset_data->time;
    // Upstream Sync applies history, keyframe, and zero-control requests after
    // reset. In a coalesced batch those later mutations are the winning viewer
    // transaction, so publishing common-reset recovery would overwrite them in
    // RenderLoop's immediately following outer Sync.
    const bool reset_is_final =
      !sim_->pending_.load_from_history && !sim_->pending_.load_key && !sim_->pending_.zero_ctrl;
    sim_->Sync();

    if (reset_is_final && callback_ != nullptr && sim_->d_ == reset_data && !sim_->pending_.reset)
    {
      callback_(context_, previous_time);
    }
  }

private:
  mj::Simulate* sim_{ nullptr };
  SimulateResetCallback callback_{ nullptr };
  void* context_{ nullptr };
};

/**
 * Minimal UI adapter to support running the drivers in a headless environment.
 *
 * Window-system event methods remain no-ops, while PollEvents preserves the exact
 * viewer-reset handoff shared with the interactive adapter.
 */
class HeadlessAdapter : public mj::PlatformUIAdapter
{
public:
  HeadlessAdapter(SimulateResetCallback callback, void* context) : reset_handler_(callback, context)
  {
  }
  ~HeadlessAdapter() override = default;

  void bind(mj::Simulate* sim)
  {
    reset_handler_.bind(sim);
  }

  std::pair<double, double> GetCursorPosition() const override
  {
    return { 0.0, 0.0 };
  }
  double GetDisplayPixelsPerInch() const override
  {
    return 96.0;
  }
  std::pair<int, int> GetFramebufferSize() const override
  {
    return { 800, 600 };
  }
  std::pair<int, int> GetWindowSize() const override
  {
    return { 800, 600 };
  }
  bool IsGPUAccelerated() const override
  {
    return false;
  }
  void PollEvents() override
  {
    reset_handler_.process();
  }
  void SetClipboardString(const char* /*text*/) override
  {
  }
  void SetVSync(bool /*enabled*/) override
  {
  }
  void SetWindowTitle(const char* /*title*/) override
  {
  }
  bool ShouldCloseWindow() const override
  {
    return false;
  }
  void SwapBuffers() override
  {
  }
  void ToggleFullscreen() override
  {
  }

  bool IsLeftMouseButtonPressed() const override
  {
    return false;
  }
  bool IsMiddleMouseButtonPressed() const override
  {
    return false;
  }
  bool IsRightMouseButtonPressed() const override
  {
    return false;
  }

  bool IsAltKeyPressed() const override
  {
    return false;
  }
  bool IsCtrlKeyPressed() const override
  {
    return false;
  }
  bool IsShiftKeyPressed() const override
  {
    return false;
  }

  bool IsMouseButtonDownEvent(int /*act*/) const override
  {
    return false;
  }
  bool IsKeyDownEvent(int /*act*/) const override
  {
    return false;
  }

  int TranslateKeyCode(int /*key*/) const override
  {
    return 0;
  }
  mjtButton TranslateMouseButton(int /*button*/) const override
  {
    return mjBUTTON_NONE;
  }

  bool RefreshMjrContext(const mjModel* /*m*/, int /*fontscale*/) override
  {
    return false;
  }

private:
  PendingViewerResetHandler reset_handler_;
};

/**
 * GlfwAdapter subclass that overrides right-arrow-key handling so that a single
 * simulation step is driven exclusively by the ROS control loop rather than by
 * MuJoCo's built-in viewer.
 *
 * When the simulation is paused, MuJoCo's default GlfwAdapter advances the
 * physics by one step (mj_step) on each right-arrow press or key-repeat event.
 * This class suppresses that native behaviour and instead sets step_requested_,
 * which the ROS control loop polls to advance the simulation.  This ensures
 * that ros2_controller read/update/write cycles are executed for every step and
 * that controller state remains consistent with the physics.
 *
 * All other keys are forwarded to the parent class unchanged so that the rest
 * of the MuJoCo viewer UI (play/pause, reset, rendering options, etc.) works
 * as normal.
 */
class ROS2ControlGlfwAdapter : public mj::GlfwAdapter
{
public:
  ROS2ControlGlfwAdapter(std::atomic<bool>& step_requested, SimulateResetCallback callback, void* context)
    : step_requested_(step_requested), reset_handler_(callback, context)
  {
  }

  void bind(mj::Simulate* sim)
  {
    reset_handler_.bind(sim);
  }

  void PollEvents() override
  {
    mj::GlfwAdapter::PollEvents();
    reset_handler_.process();
  }

protected:
  void OnKey(int key, int scancode, int act) override
  {
    // Intercept the right arrow key so only the ROS loop advances the physics,
    // preventing double-stepping (MuJoCo's native handler would also call mj_step).
    if (key == GLFW_KEY_RIGHT)
    {
      if (act == GLFW_PRESS || act == GLFW_REPEAT)
      {
        step_requested_.store(true);
      }
      return;
    }

    // Forward all other keys so normal UI behaviour is preserved.
    mj::GlfwAdapter::OnKey(key, scancode, act);
  }

private:
  std::atomic<bool>& step_requested_;
  PendingViewerResetHandler reset_handler_;
};

// return the path to the directory containing the current executable
// used to determine the location of auto-loaded plugin libraries
static std::string getExecutableDir()
{
  constexpr char kPathSep = '/';

  // Determine the executable location while respecting symlinks, as the plugins are installed
  // next to the ros2 control node's executable
  std::string real_path = [&]() -> std::string {
    std::ifstream f("/proc/self/cmdline");
    std::string argv0;
    std::getline(f, argv0, '\0');
    return argv0;
  }();

  if (real_path.empty())
  {
    return "";
  }

  for (std::size_t i = real_path.size() - 1; i > 0; --i)
  {
    if (real_path.c_str()[i] == kPathSep)
    {
      return real_path.substr(0, i);
    }
  }

  // don't scan through the entire file system's root
  return "";
}

// Load all .so plugins from a directory, following symlinks, this is different from the upstream
static void loadPluginsFromDirectory(const std::string& plugin_dir)
{
  std::error_code ec;
  if (!std::filesystem::is_directory(plugin_dir, ec))
  {
    return;
  }

  for (const auto& entry : std::filesystem::directory_iterator(plugin_dir, ec))
  {
    if (!entry.is_regular_file(ec))
    {
      continue;
    }

    const auto& path = entry.path();
    if (path.extension() != ".so")
    {
      continue;
    }

    int before = mjp_pluginCount();
    mj_loadPluginLibrary(path.c_str());
    int after = mjp_pluginCount();
    if (after > before)
    {
      std::printf("Plugins registered by library '%s':\n", path.filename().c_str());
      for (int i = before; i < after; ++i)
      {
        std::printf("    %s\n", mjp_getPluginAtSlot(i)->name);
      }
    }
    else
    {
      std::printf("No plugins loaded from: '%s':\n", path.filename().c_str());
    }
  }
}

// scan for libraries in the plugin directory to load additional plugins
static void scanPluginLibraries()
{
  // check and print plugins that are linked directly into the executable
  int nplugin = mjp_pluginCount();
  if (nplugin)
  {
    std::printf("Built-in plugins:\n");
    for (int i = 0; i < nplugin; ++i)
    {
      std::printf("    %s\n", mjp_getPluginAtSlot(i)->name);
    }
  }

  // try to open the ${EXECDIR}/MUJOCO_PLUGIN_DIR directory
  // ${EXECDIR} is the directory containing the simulate binary itself
  // MUJOCO_PLUGIN_DIR is the MUJOCO_PLUGIN_DIR preprocessor macro
  const std::string executable_dir = getExecutableDir();
  if (!executable_dir.empty())
  {
    const std::string plugin_dir = executable_dir + "/" + MUJOCO_PLUGIN_DIR;
    loadPluginsFromDirectory(plugin_dir);
  }

  // Then try to find all packages that registered mujoco plugins via the ament resource index
  // get_resources/get_resource were deprecated in https://github.com/ament/ament_index/pull/120
#if AMENT_INDEX_CPP_VERSION_GTE(1, 13, 2)
  auto plugins = ament_index_cpp::get_resources_by_name("mujoco_plugins");
  for (const auto& [package_name, _] : plugins)
  {
    auto resource = ament_index_cpp::get_resource("mujoco_plugins", package_name);
    if (resource.resourcePath.has_value())
    {
      const std::string plugin_dir = (resource.resourcePath.value() / resource.contents).string();
#else
  auto plugins = ament_index_cpp::get_resources("mujoco_plugins");
  for (const auto& [package_name, _] : plugins)
  {
    std::string content;
    std::string prefix;
    if (ament_index_cpp::get_resource("mujoco_plugins", package_name, content, &prefix))
    {
      const std::string plugin_dir = prefix + "/" + content;
#endif
      std::printf("Loading MuJoCo plugins from package '%s': %s\n", package_name.c_str(), plugin_dir.c_str());
      loadPluginsFromDirectory(plugin_dir);
    }
  }
}

//------------------------------------------- simulation
//-------------------------------------------

static const char* Diverged(int disableflags, const mjData* d)
{
  if (disableflags & mjDSBL_AUTORESET)
  {
    for (mjtWarning w : { mjWARN_BADQACC, mjWARN_BADQVEL, mjWARN_BADQPOS })
    {
      if (d->warning[w].number > 0)
      {
        return mju_warningText(w, static_cast<std::size_t>(d->warning[w].lastinfo));
      }
    }
  }
  return nullptr;
}

static mjModel* loadModelFromFile(const char* file, mj::Simulate& sim)
{
  mjModel* mnew = 0;

  // this copy is needed so that the mju::strlen call below compiles
  char filename[mj::Simulate::kMaxFilenameLength];
  mju::strcpy_arr(filename, file);

  // load and compile
  char loadError[kErrorLength] = "";
  auto load_start = mj::Simulate::Clock::now();
  if (mju::strlen_arr(filename) > 4 && !std::strncmp(filename + mju::strlen_arr(filename) - 4, ".mjb",
                                                     mju::sizeof_arr(filename) - mju::strlen_arr(filename) + 4))
  {
    mnew = mj_loadModel(filename, nullptr);
    if (!mnew)
    {
      mju::strcpy_arr(loadError, "could not load binary model");
    }
  }
  else
  {
    mnew = mj_loadXML(filename, nullptr, loadError, kErrorLength);

    // remove trailing newline character from loadError
    if (loadError[0])
    {
      auto error_length = mju::strlen_arr(loadError);
      if (loadError[error_length - 1] == '\n')
      {
        loadError[error_length - 1] = '\0';
      }
    }
  }
  auto load_interval = mj::Simulate::Clock::now() - load_start;
  double load_seconds = Seconds(load_interval).count();

  if (!mnew)
  {
    std::printf("%s\n", loadError);
    mju::strcpy_arr(sim.load_error, loadError);
    return nullptr;
  }

  // compiler warning: print and pause
  if (loadError[0])
  {
    // mj_forward() below will print the warning message
    std::printf("Model compiled, but simulation warning (paused):\n  %s\n", loadError);
    sim.run = 0;
  }

  // if no error and load took more than 1/4 seconds, report load time
  else if (load_seconds > 0.25)
  {
    mju::sprintf_arr(loadError, "Model loaded in %.2g seconds", load_seconds);
  }

  mju::strcpy_arr(sim.load_error, loadError);
  return mnew;
}

static mjModel* loadModelFromTopic(rclcpp::Node::SharedPtr node, const std::string& topic_name)
{
  mjModel* mnew = 0;
  std::string robot_description;

  rclcpp::QoS qos_profile(rclcpp::QoSInitialization::from_rmw(rmw_qos_profile_default));
  qos_profile.reliable().transient_local().keep_last(1);
  RCLCPP_INFO(node->get_logger(), "Trying to get the MuJoCo model from topic '%s'", topic_name.c_str());

  // Try to get mujoco_model via topic
  auto mujoco_model_sub = node->create_subscription<std_msgs::msg::String>(
      topic_name, qos_profile, [&](const std_msgs::msg::String::SharedPtr msg) {
        if (!msg->data.empty() && robot_description.empty())
          robot_description = msg->data;
      });

  auto start = std::chrono::steady_clock::now();
  auto timeout = std::chrono::seconds(120);

  while (robot_description.empty() && rclcpp::ok())
  {
    auto now = std::chrono::steady_clock::now();

    RCLCPP_INFO_THROTTLE(node->get_logger(), *node->get_clock(), 1000, "Waiting for '%s'...", topic_name.c_str());

    if (now - start > timeout)
    {
      RCLCPP_WARN(node->get_logger(), "Timeout waiting for '%s' topic.", topic_name.c_str());
      return nullptr;
    }

    rclcpp::sleep_for(std::chrono::milliseconds(200));
  }

  if (!robot_description.empty())
  {
    // Load MuJoCo model
    char error[1000] = "Could not load XML model";

    mjSpec* spec = nullptr;
    spec = mj_parseXMLString(robot_description.c_str(), nullptr, error, 1000);
    if (!spec)
    {
      RCLCPP_FATAL(node->get_logger(), "Failed to parse spec from XML topic string: %s", error);
      mj_deleteSpec(spec);
      return nullptr;
    }

    mnew = mj_compile(spec, nullptr);
    if (!mnew)
    {
      const char* myerr = mjs_getError(spec);
      RCLCPP_INFO(node->get_logger(), "Error %s", myerr);
      RCLCPP_FATAL(node->get_logger(), "Failed to compile MuJoCo model: %s", error);
      mj_deleteSpec(spec);
      return nullptr;
    }
    mj_deleteSpec(spec);
    RCLCPP_INFO(node->get_logger(), "Model body count: %ld", static_cast<long>(mnew->nbody));
    RCLCPP_INFO(node->get_logger(), "Model geom count: %ld", static_cast<long>(mnew->ngeom));
  }
  return mnew;
}

static mjModel* LoadModel(const char* file, const std::string& topic, mj::Simulate& sim, rclcpp::Node::SharedPtr node)
{
  // Try to get the MuJoCo model from URDF.
  // If it is not available, create a subscription and listen for the model on a topic.

  // this copy is needed so that the mju::strlen call below compiles
  char filename[mj::Simulate::kMaxFilenameLength];
  mju::strcpy_arr(filename, file);

  // load model from path if the filename is not empty
  if (filename[0])
  {
    return loadModelFromFile(file, sim);
  }
  // Try to get the MuJoCo model from topic
  return loadModelFromTopic(node, topic);
}

MujocoSimulation::RuntimeUse::~RuntimeUse()
{
  if (owner_ != nullptr)
  {
    owner_->release_runtime_use();
  }
}

MujocoSimulation::RuntimeUse::RuntimeUse(RuntimeUse&& other) noexcept : owner_(other.owner_)
{
  other.owner_ = nullptr;
}

MujocoSimulation::RuntimeUse& MujocoSimulation::RuntimeUse::operator=(RuntimeUse&& other) noexcept
{
  if (this != &other)
  {
    if (owner_ != nullptr)
    {
      owner_->release_runtime_use();
    }
    owner_ = other.owner_;
    other.owner_ = nullptr;
  }
  return *this;
}

MujocoSimulation::RuntimeUse MujocoSimulation::acquire_runtime_use()
{
  const std::lock_guard<std::mutex> lock(runtime_use_mutex_);
  if (!accepting_runtime_uses_)
  {
    return {};
  }
  ++active_runtime_uses_;
  return RuntimeUse(this);
}

void MujocoSimulation::release_runtime_use()
{
  {
    const std::lock_guard<std::mutex> lock(runtime_use_mutex_);
    --active_runtime_uses_;
  }
  runtime_use_cv_.notify_all();
}

void MujocoSimulation::close_runtime_uses()
{
  {
    const std::lock_guard<std::mutex> lock(runtime_use_mutex_);
    accepting_runtime_uses_ = false;
  }
  // A step_simulation callback retains its lease while waiting for queued physics. Publish
  // the permanent stop and wake that wait before draining leases, otherwise early viewer close
  // can wait for a physics thread which on_init has not even started yet.
  request_stop();
  std::unique_lock<std::mutex> lock(runtime_use_mutex_);
  runtime_use_cv_.wait(lock, [this]() { return active_runtime_uses_ == 0; });
}

MujocoSimulation::~MujocoSimulation()
{
  shutdown();

  // Cleanup data and the model, if they haven't been
  if (mj_data_)
  {
    mj_deleteData(mj_data_);
  }
  for (mjData* snapshot : { snapshot_write_, snapshot_read_ })
  {
    if (snapshot)
    {
      mj_deleteData(snapshot);
    }
  }
  if (mj_model_)
  {
    mj_deleteModel(mj_model_);
  }
}

bool MujocoSimulation::initialize(rclcpp::Node::SharedPtr node, const std::string& model_path,
                                  const std::string& mujoco_model_topic, double sim_speed_factor, bool headless,
                                  bool disable_rendering)
{
  node_ = node;
  clock_trace_ = ClockTrace::from_environment("physics");
  model_path_ = model_path;
  mujoco_model_topic_ = mujoco_model_topic;
  sim_speed_factor_ = sim_speed_factor;
  headless_ = headless;
  rendering_enabled_ = !disable_rendering;
  {
    const std::lock_guard<std::mutex> lock(external_initialization_mutex_);
    external_initialization_complete_ = false;
  }
  {
    const std::lock_guard<std::mutex> lock(runtime_use_mutex_);
    accepting_runtime_uses_ = true;
    active_runtime_uses_ = 0;
  }

  if (sim_speed_factor_ > 0)
  {
    RCLCPP_INFO(get_logger(), "Running the simulation at %.2f percent speed", sim_speed_factor_ * 100.0);
  }
  else
  {
    RCLCPP_INFO(get_logger(), "No sim_speed set, using the setting from the UI");
  }

  RCLCPP_INFO_EXPRESSION(get_logger(), headless_, "Running in HEADLESS mode.");
  RCLCPP_INFO(get_logger(), "Sensor rendering is %s.", rendering_enabled_ ? "enabled" : "disabled");

  // We essentially reconstruct the 'simulate.cc::main()' function here, and
  // launch a Simulate object with all necessary rendering process/options
  // attached.

  // scan for libraries in the plugin directory to load additional plugins
  RCLCPP_INFO(get_logger(), "Scanning plugin libraries...");
  scanPluginLibraries();

  // Retain scope
  mjv_defaultCamera(&cam_);
  mjv_defaultOption(&opt_);
  mjv_defaultPerturb(&pert_);

  // There is a timing issue here as the rendering context must be attached to
  // the executing thread, but we require the simulation to be available on
  // init. So we spawn the sim in the rendering thread prior to proceeding with
  // initialization.
  RCLCPP_INFO(get_logger(), "Initializing simulation...");
  auto sim_ready = std::make_shared<std::promise<void>>();
  std::future<void> sim_ready_future = sim_ready->get_future();

  if (headless_)
  {
#ifdef __APPLE__
    notify_macos_ui_not_required();
#endif
    auto adapter = std::make_unique<HeadlessAdapter>(&MujocoSimulation::simulate_reset_callback, this);
    HeadlessAdapter* const adapter_ptr = adapter.get();
    sim_ = std::make_unique<mj::Simulate>(std::move(adapter), &cam_, &opt_, &pert_, /* is_passive = */ false);
    adapter_ptr->bind(sim_.get());

    // Notify sim that we are ready
    sim_ready->set_value();
  }
  else
  {
    auto run_ui = [this, sim_ready]() {
      auto adapter = std::make_unique<ROS2ControlGlfwAdapter>(
          keyboard_step_requested_, &MujocoSimulation::simulate_reset_callback, this);
      ROS2ControlGlfwAdapter* const adapter_ptr = adapter.get();
      sim_ = std::make_unique<mj::Simulate>(std::move(adapter), &cam_, &opt_, &pert_, /* is_passive = */ false);
      adapter_ptr->bind(sim_.get());

      // Add ros2 control icon for the taskbar
#if AMENT_INDEX_CPP_VERSION_GTE(1, 13, 2)
      std::string icon_location =
          (ament_index_cpp::get_package_share_path("mujoco_ros2_control") / "resources/mujoco_logo.png").string();
#else
      std::string icon_location =
          ament_index_cpp::get_package_share_directory("mujoco_ros2_control") + "/resources/mujoco_logo.png";
#endif
      std::vector<unsigned char> image;
      unsigned width, height;
      unsigned error = lodepng::decode(image, width, height, icon_location);

      // Only process the icon if we successfully loaded it. Otherwise, just proceed without
      if (error)
      {
        RCLCPP_WARN(get_logger(), "LodePNG error %u: %s. Icon file not loaded: %s", error, lodepng_error_text(error),
                    icon_location.c_str());
      }
      else if (width <= static_cast<unsigned>(std::numeric_limits<int>::max()) &&
               height <= static_cast<unsigned>(std::numeric_limits<int>::max()))
      {
        GLFWimage icon;
        icon.width = static_cast<int>(width);
        icon.height = static_cast<int>(height);
        icon.pixels = image.data();
        glfwSetWindowIcon(glfwGetCurrentContext(), 1, &icon);
      }
      else
      {
        RCLCPP_WARN(
            get_logger(),
            "MuJoCo icon dimensions exceed GLFW's supported integer range; icon not loaded");
      }

      // Set glfw window size to max size of the primary monitor
#ifndef __APPLE__
      GLFWmonitor* primary_monitor = glfwGetPrimaryMonitor();
      if (primary_monitor != nullptr)
      {
        const GLFWvidmode* mode = glfwGetVideoMode(primary_monitor);
        if (mode != nullptr)
        {
          glfwSetWindowSize(glfwGetCurrentContext(), mode->width, mode->height);
        }
        else
        {
          RCLCPP_WARN(get_logger(), "GLFW primary video mode is unavailable; retaining the default viewer size");
        }
      }
      else
      {
        RCLCPP_WARN(get_logger(), "GLFW primary monitor is unavailable; retaining the default viewer size");
      }
#endif  // __APPLE__

      // Hide UI panels programmatically
      sim_->ui0_enable = false;  // Hide left panel
      sim_->ui1_enable = false;  // Hide right panel

#ifdef __APPLE__
      // Cocoa window creation and destruction must stay on the process main
      // thread. The worker later borrows this context only while rendering.
      glfwWindowHint(GLFW_VISIBLE, GLFW_FALSE);
      macos_camera_window_ = glfwCreateWindow(1, 1, "mujoco_ros2_control_camera", nullptr, nullptr);
      if (macos_camera_window_ == nullptr)
      {
        RCLCPP_ERROR(get_logger(), "Failed to create the macOS main-thread camera GLFW window.");
      }
      else
      {
        RCLCPP_INFO(get_logger(), "Prepared the macOS main-thread GLFW context for camera rendering.");
      }
#endif

      // Notify sim that we are ready
#ifdef __APPLE__
      mark_current_macos_ui_task_ready();
#endif
      sim_ready->set_value();

#ifdef __APPLE__
      if (macos_stop_requested_.load())
      {
        request_stop();
      }
#endif

      // Blocks until terminated
      RCLCPP_INFO(get_logger(), "Starting the MuJoCo rendering thread...");
      sim_->RenderLoop();

      // A user-closing viewer follows the same producer -> worker boundary as
      // an externally requested shutdown.
      stop_rendering_plugins();
      close_runtime_uses();

#ifdef __APPLE__
      request_stop();

      {
        const std::lock_guard<std::mutex> lock(macos_ui_state_mutex_);
        macos_ui_finished_ = true;
      }
      macos_ui_state_cv_.notify_all();
#else
      record_context_destroyed();
      {
        std::unique_lock<std::mutex> lock(viewer_destroy_mutex_);
        viewer_destroy_cv_.wait(lock, [this]() { return viewer_destroy_requested_; });
      }
      {
        const std::lock_guard<std::mutex> service_lock(viewer_service_mutex_);
        sim_mutex_ = nullptr;
        sim_.reset();
        record_viewer_destroyed();
      }
      glfwTerminate();
#endif
    };
#ifdef __APPLE__
    {
      const std::lock_guard<std::mutex> lock(macos_ui_state_mutex_);
      macos_ui_finished_ = false;
      macos_ui_cleanup_finished_ = false;
    }
    auto cleanup_ui = [this]() {
      // SystemInterface::on_init() must finish before its Simulate pointers can be invalidated.
      // The control thread is joined before this main-thread phase; close_runtime_uses() below
      // rejects and drains executor callbacks. The outer executor joins after cleanup to avoid
      // a failed-on_init resource-destruction cycle.
      {
        std::unique_lock<std::mutex> lock(external_initialization_mutex_);
        external_initialization_cv_.wait(lock, [this]() {
          return external_initialization_complete_;
        });
      }
      stop_rendering_plugins();
      close_runtime_uses();
      // The viewer may close before on_init starts physics. Only this post-initialization
      // main-thread phase consumes the physics thread, so thread creation and join cannot race.
      request_stop();
      if (physics_thread_.joinable())
      {
        physics_thread_.join();
      }
      {
        const std::lock_guard<std::mutex> service_lock(viewer_service_mutex_);
        const std::lock_guard<std::mutex> rendering_lock(rendering_lifecycle_mutex_);
        if (macos_camera_window_ != nullptr)
        {
          glfwDestroyWindow(macos_camera_window_);
          macos_camera_window_ = nullptr;
        }
        record_context_destroyed();
        sim_mutex_ = nullptr;
        sim_.reset();
        record_viewer_destroyed();
      }
      glfwTerminate();
      {
        const std::lock_guard<std::mutex> lock(macos_ui_state_mutex_);
        macos_ui_cleanup_finished_ = true;
      }
      macos_ui_state_cv_.notify_all();
    };
    macos_ui_task_id_ = submit_macos_ui_task(
        std::move(run_ui), [this]() {
          macos_stop_requested_.store(true);
          request_stop();
        }, std::move(cleanup_ui));
#else
    // GLFW is permitted on a worker thread on non-Cocoa platforms.
    ui_thread_ = std::thread(std::move(run_ui));
#endif
  }

  if (sim_ready_future.wait_for(10s) == std::future_status::timeout)
  {
#ifdef __APPLE__
    const bool cancelled = cancel_macos_ui_task(macos_ui_task_id_, [this]() {
      mark_external_initialization_complete();
    });
    if (!cancelled)
    {
      // sim_ready won the boundary race while cancellation held the dispatcher mutex.
      sim_ready_future.wait();
    }
    else
    {
      RCLCPP_FATAL(get_logger(), "Timed out waiting to start simulation rendering!");
      return false;
    }
#else
    RCLCPP_FATAL(get_logger(), "Timed out waiting to start simulation rendering!");
    return false;
#endif
  }
  RCLCPP_INFO(get_logger(), "Sim ready, continuing initialization...");

  // We maintain a pointer to the mutex so that we can lock from here, too.
  // Is this a terrible idea? Maybe, but it lets us use their libraries as is...
  sim_mutex_ = &sim_->mtx;

  // Load the model and data prior to hw registration and starting the physics thread
  sim_->LoadMessage(model_path_.c_str());

  // Time publisher will be pushed from the physics_thread_
  RCLCPP_INFO(get_logger(), "Constructing clock publisher.");
  clock_publisher_ = node_->create_publisher<rosgraph_msgs::msg::Clock>("/clock", 1);
  clock_realtime_publisher_ =
      std::make_shared<realtime_tools::RealtimePublisher<rosgraph_msgs::msg::Clock>>(clock_publisher_);

  // Initialize services
  // For humble compatibility.
#if RCLCPP_VERSION_MAJOR >= 17
  rclcpp::QoS qos_services =
      rclcpp::QoS(rclcpp::QoSInitialization(RMW_QOS_POLICY_HISTORY_KEEP_ALL, 1)).reliable().durability_volatile();
#else
  const rmw_qos_profile_t qos_services = { RMW_QOS_POLICY_HISTORY_KEEP_ALL,
                                           1,  // message queue depth
                                           RMW_QOS_POLICY_RELIABILITY_RELIABLE,
                                           RMW_QOS_POLICY_DURABILITY_VOLATILE,
                                           RMW_QOS_DEADLINE_DEFAULT,
                                           RMW_QOS_LIFESPAN_DEFAULT,
                                           RMW_QOS_POLICY_LIVELINESS_SYSTEM_DEFAULT,
                                           RMW_QOS_LIVELINESS_LEASE_DURATION_DEFAULT,
                                           false };
#endif
  reset_world_cb_group_ = node_->create_callback_group(rclcpp::CallbackGroupType::MutuallyExclusive);
  set_pause_cb_group_ = node_->create_callback_group(rclcpp::CallbackGroupType::MutuallyExclusive);
  step_simulation_cb_group_ = node_->create_callback_group(rclcpp::CallbackGroupType::MutuallyExclusive);
  set_free_joint_state_cb_group_ = node_->create_callback_group(rclcpp::CallbackGroupType::MutuallyExclusive);
  viewer_camera_cb_group_ = node_->create_callback_group(rclcpp::CallbackGroupType::MutuallyExclusive);

  reset_world_service_ = node_->create_service<mujoco_ros2_control_msgs::srv::ResetWorld>(
      "~/reset_world",
      std::bind(&MujocoSimulation::reset_world_callback, this, std::placeholders::_1, std::placeholders::_2),
      qos_services, reset_world_cb_group_);
  RCLCPP_INFO(get_logger(), "Created reset_world service at: %s/reset_world", node_->get_fully_qualified_name());

  set_pause_service_ = node_->create_service<mujoco_ros2_control_msgs::srv::SetPause>(
      "~/set_pause",
      std::bind(&MujocoSimulation::set_pause_callback, this, std::placeholders::_1, std::placeholders::_2),
      qos_services, set_pause_cb_group_);
  RCLCPP_INFO(get_logger(), "Created set_pause service at: %s/set_pause", node_->get_fully_qualified_name());

  step_simulation_service_ = node_->create_service<mujoco_ros2_control_msgs::srv::StepSimulation>(
      "~/step_simulation",
      std::bind(&MujocoSimulation::step_simulation_callback, this, std::placeholders::_1, std::placeholders::_2),
      qos_services, step_simulation_cb_group_);
  RCLCPP_INFO(get_logger(), "Created step_simulation service at: %s/step_simulation", node_->get_fully_qualified_name());

  set_free_joint_state_service_ = node_->create_service<mujoco_ros2_control_msgs::srv::SetFreeJointState>(
      "~/set_free_joint_state",
      std::bind(&MujocoSimulation::set_free_joint_state_callback, this, std::placeholders::_1, std::placeholders::_2),
      qos_services, set_free_joint_state_cb_group_);
  RCLCPP_INFO(get_logger(), "Created set_free_joint_state service at: %s/set_free_joint_state",
              node_->get_fully_qualified_name());

  set_viewer_camera_service_ = node_->create_service<mujoco_ros2_control_msgs::srv::SetViewerCamera>(
      "~/set_viewer_camera",
      std::bind(&MujocoSimulation::set_viewer_camera_callback, this, std::placeholders::_1, std::placeholders::_2),
      qos_services, viewer_camera_cb_group_);
  get_viewer_camera_service_ = node_->create_service<mujoco_ros2_control_msgs::srv::GetViewerCamera>(
      "~/get_viewer_camera",
      std::bind(&MujocoSimulation::get_viewer_camera_callback, this, std::placeholders::_1, std::placeholders::_2),
      qos_services, viewer_camera_cb_group_);
  RCLCPP_INFO(get_logger(), "Created viewer camera services at: %s/{set,get}_viewer_camera",
              node_->get_fully_qualified_name());

  // Finish initialization by loading the model and initializing the model and control data containers.
  RCLCPP_INFO(get_logger(), "Loading model...");
  mj_model_ = LoadModel(model_path_.c_str(), mujoco_model_topic_, *sim_, node_);
  if (!mj_model_)
  {
    RCLCPP_FATAL(get_logger(), "MuJoCo failed to load the model");
    return false;
  }

  {
    std::unique_lock<std::recursive_mutex> lock(*sim_mutex_);
    mj_data_ = mj_makeData(mj_model_);
    snapshot_write_ = mj_makeData(mj_model_);
    snapshot_read_ = mj_makeData(mj_model_);
    snapshot_ready_ = false;

    // Initialize containers for data sharing
    ctrl_staged_.assign(static_cast<std::size_t>(mj_model_->nu), 0.0);
    qfrc_applied_staged_.assign(static_cast<std::size_t>(mj_model_->nv), 0.0);
    control_inputs_staged_ = false;

    if (mj_data_ && snapshot_write_ && snapshot_read_)
    {
      // Seed both snapshot buffers so a consumer that arrives before the first physics-loop
      // refresh still sees valid initial data.
      mj_copyData(snapshot_read_, mj_model_, mj_data_);
      refresh_data_snapshot();
      publish_control_state();
    }
  }
  if (!mj_data_ || !snapshot_write_ || !snapshot_read_)
  {
    RCLCPP_FATAL(get_logger(), "Could not allocate mjData for '%s'", model_path_.c_str());
    return false;
  }

  return true;
}

bool MujocoSimulation::apply_keyframe(const std::string& keyframe_name)
{
  int keyframe_id = mj_name2id(mj_model_, mjOBJ_KEY, keyframe_name.c_str());
  if (keyframe_id == -1)
  {
    RCLCPP_ERROR(get_logger(), "Failed to find keyframe : '%s' in the MuJoCo model!", keyframe_name.c_str());
    return false;
  }

  const std::unique_lock<std::recursive_mutex> lock(*sim_mutex_);

  const auto prev_sim_time = mj_data_->time;
  mj_resetDataKeyframe(mj_model_, mj_data_, keyframe_id);
  mj_data_->time = prev_sim_time;

  return true;
}

void MujocoSimulation::capture_initial_state()
{
  const std::unique_lock<std::recursive_mutex> lock(*sim_mutex_);
  initial_qpos_.assign(mj_data_->qpos, mj_data_->qpos + mj_model_->nq);
  initial_qvel_.assign(mj_data_->qvel, mj_data_->qvel + mj_model_->nv);
  initial_ctrl_.assign(mj_data_->ctrl, mj_data_->ctrl + mj_model_->nu);
}

void MujocoSimulation::set_reset_callback(ResetCallback callback)
{
  reset_callback_ = std::move(callback);
}

void MujocoSimulation::simulate_reset_callback(void* context, mjtNum previous_time)
{
  static_cast<MujocoSimulation*>(context)->on_simulate_reset(previous_time);
}

void MujocoSimulation::on_simulate_reset(mjtNum previous_time)
{
  // The adapter still owns sim_mutex_ after the reset Sync. Align the edit
  // buffers before RenderLoop can enter its outer Sync and publish the
  // generation only after all associated state is ready for the physics thread.
  align_viewer_edit_buffers();

  const uint64_t generation = published_ui_reset_generation_.load(std::memory_order_relaxed) + 1;
  const mjtNum preserved_time = pending_ui_resets_.empty() ? previous_time : pending_ui_resets_.front().previous_time;
  pending_ui_resets_.push_back(PendingUiReset{ generation, preserved_time });
  published_ui_reset_generation_.store(generation, std::memory_order_release);
}

void MujocoSimulation::set_pre_step_callback(PreStepCallback callback)
{
  // Don't drop in a nullptr if requested, just pass an empty function.
  PreStepCallback next = callback ? std::move(callback) : PreStepCallback([](mjData* /*data*/) {});

  // Plugins may be registered after the physics thread is already running, so the loop
  // could otherwise be reading pre_step_callback_ while we assign to it.
  if (sim_mutex_ != nullptr)
  {
    const std::unique_lock<std::recursive_mutex> lock(*sim_mutex_);
    pre_step_callback_ = std::move(next);
  }
  else
  {
    pre_step_callback_ = std::move(next);
  }
}

bool MujocoSimulation::prepare_rendering_plugin(
    const std::shared_ptr<mujoco_ros2_control_plugins::MuJoCoROS2ControlPluginBase>& plugin)
{
  auto renderer =
      std::dynamic_pointer_cast<mujoco_ros2_control_plugins::MuJoCoROS2ControlRenderingPlugin>(plugin);
  if (!renderer)
  {
    return true;
  }

  try
  {
    const std::lock_guard<std::mutex> lock(rendering_lifecycle_mutex_);
    if (rendering_shutdown_started_)
    {
      return false;
    }
#ifdef __APPLE__
    renderer->set_platform_render_context(macos_camera_window_);
    renderer->set_rendering_enabled(rendering_enabled_);
#else
    renderer->set_platform_render_context(nullptr);
    renderer->set_rendering_enabled(rendering_enabled_);
#endif
    const auto existing = std::find(rendering_plugins_.begin(), rendering_plugins_.end(), renderer);
    if (existing == rendering_plugins_.end())
    {
      // Ownership must be visible before init() is allowed to launch a worker. A concurrent
      // shutdown can now disable and join the renderer before destroying its platform context.
      rendering_plugins_.push_back(renderer);
    }
  }
  catch (const std::exception& error)
  {
    RCLCPP_ERROR(get_logger(), "Rendering plugin preparation failed: %s", error.what());
    return false;
  }
  catch (...)
  {
    RCLCPP_ERROR(get_logger(), "Rendering plugin preparation failed with an unknown exception");
    return false;
  }
  return true;
}

void MujocoSimulation::discard_rendering_plugin(
    const std::shared_ptr<mujoco_ros2_control_plugins::MuJoCoROS2ControlPluginBase>& plugin)
{
  auto renderer =
      std::dynamic_pointer_cast<mujoco_ros2_control_plugins::MuJoCoROS2ControlRenderingPlugin>(plugin);
  if (!renderer)
  {
    return;
  }

  {
    std::unique_lock<std::mutex> lock(rendering_lifecycle_mutex_);
    if (rendering_shutdown_started_)
    {
      rendering_lifecycle_cv_.wait(lock, [this]() { return rendering_shutdown_complete_; });
      return;
    }
    rendering_plugins_.erase(
        std::remove(rendering_plugins_.begin(), rendering_plugins_.end(), renderer), rendering_plugins_.end());
  }

  try
  {
    renderer->set_rendering_enabled(false);
    renderer->close_rendering();
  }
  catch (const std::exception& error)
  {
    RCLCPP_ERROR(get_logger(), "Failed to close a rendering plugin after init failure: %s", error.what());
  }
  catch (...)
  {
    RCLCPP_ERROR(get_logger(), "Failed to close a rendering plugin after init failure");
  }
}

void MujocoSimulation::mark_external_initialization_complete()
{
  {
    const std::lock_guard<std::mutex> lock(external_initialization_mutex_);
    external_initialization_complete_ = true;
  }
  external_initialization_cv_.notify_all();
}

void MujocoSimulation::add_observer_plugin(
    const std::shared_ptr<mujoco_ros2_control_plugins::MuJoCoROS2ControlPluginBase>& plugin)
{
  const std::unique_lock<std::recursive_mutex> lock(*sim_mutex_);
  observer_dispatcher_.add(plugin);
}

void MujocoSimulation::start_physics_thread()
{
  // Disable the rangefinder flag at startup so that we don't get the yellow lines.
  // We can still turn this on manually if desired.
  sim_->opt.flags[mjVIS_RANGEFINDER] = false;
  // Turn off site rendering so that the visualization is more realistic.
  // These can still be turned on in the visualizer.
  for (int i = 0; i < mjNGROUP; i++)
  {
    sim_->opt.sitegroup[i] = 0;
  }

  // When the interface is activated, we start the physics engine.
  physics_thread_ = std::thread([this]() {
    // Load the simulation and do an initial forward pass
    RCLCPP_INFO(get_logger(), "Starting the MuJoCo physics thread...");
    if (this->headless_)
    {
      const std::unique_lock<std::recursive_mutex> lock(*sim_mutex_);
      sim_->m_ = mj_model_;
      sim_->d_ = mj_data_;
      mju::strcpy_arr(sim_->filename, model_path_.c_str());
    }
    else
    {
      sim_->Load(mj_model_, mj_data_, model_path_.c_str());
    }
    // lock the sim mutex
    {
      const std::unique_lock<std::recursive_mutex> lock(*sim_mutex_);
      mj_forward(mj_model_, mj_data_);
    }
    // Blocks until terminated
    physics_loop();
  });
}

void MujocoSimulation::request_stop()
{
  const std::lock_guard<std::mutex> service_lock(viewer_service_mutex_);
  if (!sim_)
  {
    return;
  }

  sim_->exitrequest.store(true);
  uint32_t interrupted_steps = 0;
  if (sim_mutex_)
  {
    const std::unique_lock<std::recursive_mutex> lock(*sim_mutex_);
    sim_->run = false;
    interrupted_steps = pending_steps_.exchange(0);
  }
  else
  {
    sim_->run = false;
    interrupted_steps = pending_steps_.exchange(0);
  }
  if (interrupted_steps > 0)
  {
    steps_interrupted_.store(true);
  }
  steps_cv_.notify_all();
}

void MujocoSimulation::stop_rendering_plugins()
{
  std::vector<std::shared_ptr<mujoco_ros2_control_plugins::MuJoCoROS2ControlRenderingPlugin>> renderers;
  {
    std::unique_lock<std::mutex> lock(rendering_lifecycle_mutex_);
    if (rendering_shutdown_started_)
    {
      rendering_lifecycle_cv_.wait(lock, [this]() { return rendering_shutdown_complete_; });
      return;
    }
    rendering_shutdown_started_ = true;
    renderers = rendering_plugins_;
  }

  for (const auto& renderer : renderers)
  {
    try
    {
      renderer->set_rendering_enabled(false);
    }
    catch (const std::exception& error)
    {
      RCLCPP_ERROR(get_logger(), "Failed to disable a rendering plugin during shutdown: %s", error.what());
    }
    catch (...)
    {
      RCLCPP_ERROR(get_logger(), "Failed to disable a rendering plugin during shutdown");
    }
  }
  for (const auto& renderer : renderers)
  {
    try
    {
      renderer->close_rendering();
    }
    catch (const std::exception& error)
    {
      RCLCPP_ERROR(get_logger(), "Failed to close a rendering plugin during shutdown: %s", error.what());
    }
    catch (...)
    {
      RCLCPP_ERROR(get_logger(), "Failed to close a rendering plugin during shutdown");
    }
  }

  {
    const std::lock_guard<std::mutex> lock(rendering_lifecycle_mutex_);
    rendering_shutdown_complete_ = true;
  }
  rendering_lifecycle_cv_.notify_all();
}

void MujocoSimulation::record_context_destroyed()
{
  if (!context_destroy_recorded_)
  {
    context_destroy_recorded_ = true;
    if (rendering_transition_callback_for_testing_)
    {
      rendering_transition_callback_for_testing_("destroy_context");
    }
  }
}

void MujocoSimulation::record_viewer_destroyed()
{
  if (!viewer_destroy_recorded_)
  {
    viewer_destroy_recorded_ = true;
    if (rendering_transition_callback_for_testing_)
    {
      rendering_transition_callback_for_testing_("destroy_viewer");
    }
  }
}

void MujocoSimulation::shutdown()
{
  const std::lock_guard<std::mutex> shutdown_lock(shutdown_mutex_);
  if (shutdown_complete_)
  {
    return;
  }

  stop_rendering_plugins();
  close_runtime_uses();
  if (!sim_)
  {
    if (clock_trace_) {clock_trace_->finish();}
    shutdown_complete_ = true;
    return;
  }

  request_stop();

#ifdef __APPLE__
  if (!headless_)
  {
    request_macos_ui_stop();
    std::unique_lock<std::mutex> lock(macos_ui_state_mutex_);
    macos_ui_state_cv_.wait(lock, [this]() { return macos_ui_finished_; });
    macos_ui_state_cv_.wait(lock, [this]() { return macos_ui_cleanup_finished_; });
  }
  else
  {
    if (physics_thread_.joinable())
    {
      physics_thread_.join();
    }
    record_context_destroyed();
    record_viewer_destroyed();
  }
#else
  if (physics_thread_.joinable())
  {
    physics_thread_.join();
  }
  if (ui_thread_.joinable())
  {
    {
      const std::lock_guard<std::mutex> lock(viewer_destroy_mutex_);
      viewer_destroy_requested_ = true;
    }
    viewer_destroy_cv_.notify_all();
    ui_thread_.join();
  }
  else
  {
    record_context_destroyed();
    record_viewer_destroyed();
  }
#endif
  if (clock_trace_) {clock_trace_->finish();}
  shutdown_complete_ = true;
}

void MujocoSimulation::reset_world_state(bool fill_initial_state)
{
  reset_world_state(fill_initial_state, mujoco_ros2_control_msgs::msg::SimulationState{});
}

void MujocoSimulation::reset_world_state(bool fill_initial_state,
                                         const mujoco_ros2_control_msgs::msg::SimulationState& state_overrides)
{
  /// @note This method assumes sim_mutex_ is already held by the caller
  const auto diagnostic_reset_start = clock_trace_ ? ClockTrace::monotonic_ns() : 0;
  if (clock_trace_) {
    clock_trace_->record(ClockTraceKind::ResetBegin, diagnostic_successful_step_, ClockTrace::reset_epoch(),
      std::llround(mj_data_->time * 1e9), ClockTrace::reset_epoch(), diagnostic_reset_start, diagnostic_reset_start);
  }

  // Save the simulation time to preserve ROS clock continuity
  const mjtNum saved_time = mj_data_->time;

  if (fill_initial_state)
  {
    // Reset all positions, velocities and controls to initial state
    std::copy(initial_qpos_.begin(), initial_qpos_.end(), mj_data_->qpos);
    std::copy(initial_qvel_.begin(), initial_qvel_.end(), mj_data_->qvel);
    std::copy(initial_ctrl_.begin(), initial_ctrl_.end(), mj_data_->ctrl);
  }

  // Reset actuator activations (for muscles and similar)
  std::fill(mj_data_->act, mj_data_->act + mj_model_->na, 0.0);

  // Reset warmstart accelerations
  std::fill(mj_data_->qacc_warmstart, mj_data_->qacc_warmstart + mj_model_->nv, 0.0);

  // Clear cumulative divergence diagnostics so a successful reset does not re-latch
  // a warning from the failed pre-reset integration on the next physics step.
  std::fill(mj_data_->warning, mj_data_->warning + mjNWARNING, mjWarningStat{});

  // Reset sensor data
  std::fill(mj_data_->sensordata, mj_data_->sensordata + mj_model_->nsensordata, 0.0);

  // Reset actuator forces
  std::fill(mj_data_->actuator_force, mj_data_->actuator_force + mj_model_->nu, 0.0);

  // Reset applied forces
  std::fill(mj_data_->qfrc_applied, mj_data_->qfrc_applied + mj_model_->nv, 0.0);
  std::fill(mj_data_->xfrc_applied, mj_data_->xfrc_applied + 6 * mj_model_->nbody, 0.0);

  {
    // Clear staged control inputs so stale commands from before the reset are not re-applied
    // on the next step.
    const std::lock_guard<std::mutex> staging_lock(control_staging_mutex_);
    control_inputs_staged_ = false;
    std::fill(ctrl_staged_.begin(), ctrl_staged_.end(), 0.0);
    std::fill(qfrc_applied_staged_.begin(), qfrc_applied_staged_.end(), 0.0);
  }

  // Restore simulation time to preserve ROS clock continuity
  mj_data_->time = saved_time;

  // Apply single-DOF joint overrides on top of the restored state.
  apply_joint_state_overrides(state_overrides.joint_states);

  // Apply free-joint overrides. Their frame_ids resolve against post-reset body poses
  // (including the single-DOF overrides above), so refresh kinematics before applying.
  if (!state_overrides.free_joints.empty())
  {
    mj_kinematics(mj_model_, mj_data_);
    apply_free_joint_states(state_overrides.free_joints);
  }

  // Run forward dynamics to update derived quantities
  mj_forward(mj_model_, mj_data_);

  // Delegate HW-side bookkeeping (PID resets, command/state interface sync, etc.)
  if (reset_callback_)
  {
    reset_callback_(fill_initial_state);
  }

  align_viewer_edit_buffers();

  // Publish the final authoritative reset state after HW-side bookkeeping is complete.
  step_diverged_.store(false);
  publish_control_state();
  refresh_data_snapshot();
  observer_dispatcher_.on_reset();
  observer_dispatcher_.on_state_snapshot(mj_model_, mj_data_, !sim_->run);
  if (clock_trace_) {
    const auto reset_epoch = ClockTrace::complete_reset();
    clock_trace_->record(ClockTraceKind::ResetEnd, diagnostic_successful_step_, reset_epoch,
      std::llround(mj_data_->time * 1e9), reset_epoch, diagnostic_reset_start, ClockTrace::monotonic_ns());
  }
}

void MujocoSimulation::align_viewer_edit_buffers()
{
  // Keep the viewer's double-buffered editable state aligned only at true
  // reset boundaries. In particular, a UI reset after divergence can leave
  // NaNs in both qpos_ buffers before Sync calls mj_resetData; since NaN !=
  // NaN, another Sync would otherwise write that stale state back into data.
  if (sim_->qpos_.size() == static_cast<std::size_t>(mj_model_->nq))
  {
    std::copy(mj_data_->qpos, mj_data_->qpos + mj_model_->nq, sim_->qpos_.begin());
    sim_->qpos_prev_ = sim_->qpos_;
  }
  if (sim_->ctrl_.size() == static_cast<std::size_t>(mj_model_->nu))
  {
    std::copy(mj_data_->ctrl, mj_data_->ctrl + mj_model_->nu, sim_->ctrl_.begin());
    sim_->ctrl_prev_ = sim_->ctrl_;
  }
  if (sim_->eq_active_.size() == static_cast<std::size_t>(mj_model_->neq))
  {
    std::copy(mj_data_->eq_active, mj_data_->eq_active + mj_model_->neq, sim_->eq_active_.begin());
    sim_->eq_active_prev_ = sim_->eq_active_;
  }
}

void MujocoSimulation::reset_world_callback(
    const std::shared_ptr<mujoco_ros2_control_msgs::srv::ResetWorld::Request> request,
    std::shared_ptr<mujoco_ros2_control_msgs::srv::ResetWorld::Response> response)
{
  auto runtime_use = acquire_runtime_use();
  if (!runtime_use)
  {
    response->success = false;
    response->message = "Simulation is shutting down.";
    return;
  }
  RCLCPP_INFO_EXPRESSION(get_logger(), !request->keyframe.empty(), "Reset world service called with keyframe: '%s'",
                         request->keyframe.c_str());
  RCLCPP_INFO_EXPRESSION(get_logger(), request->keyframe.empty(),
                         "Reset world service called. Resetting to initial keyframe...");
  const std::unique_lock<std::recursive_mutex> lock(*sim_mutex_);

  if (sim_->run)
  {
    response->message = "Simulation must be paused before resetting the world.";
    RCLCPP_ERROR(get_logger(), "%s", response->message.c_str());
    response->success = false;
    return;
  }

  // Validate every override before touching any state, so an invalid entry leaves the world
  // un-reset. Validation only checks names and shapes against the model; free-joint frame_ids
  // resolve against post-reset body poses when reset_world_state applies the overrides.
  std::string error_message;
  if (!validate_joint_state_overrides(request->state_overrides.joint_states, error_message) ||
      !validate_free_joint_states(request->state_overrides.free_joints, error_message))
  {
    response->message = error_message + " Not resetting world.";
    RCLCPP_ERROR(get_logger(), "%s", response->message.c_str());
    response->success = false;
    return;
  }

  bool fill_initial_state = request->keyframe.empty();
  if (!fill_initial_state)
  {
    if (!apply_keyframe(request->keyframe))
    {
      response->message = "Failed to apply keyframe: '" + request->keyframe + "'. Not resetting world.";
      RCLCPP_ERROR(get_logger(), "%s", response->message.c_str());
      response->success = false;
      return;
    }
  }

  reset_world_state(fill_initial_state, request->state_overrides);
  response->success = true;
  const std::string keyframe_str = fill_initial_state ? "initial" : ("'" + request->keyframe + "'");
  response->message = "Successfully reset the MuJoCo world to the " + keyframe_str + " state.";
  // Reported separately: the two fields are keyed differently (joint name vs. body name).
  const size_t num_joint_overrides = request->state_overrides.joint_states.name.size();
  const size_t num_free_joint_overrides = request->state_overrides.free_joints.size();
  if (num_joint_overrides > 0 || num_free_joint_overrides > 0)
  {
    response->message += " Applied " + std::to_string(num_joint_overrides) + " joint and " +
                         std::to_string(num_free_joint_overrides) + " free-joint override(s).";
  }

  RCLCPP_INFO(get_logger(), "%s", response->message.c_str());
}

void MujocoSimulation::set_pause_callback(const std::shared_ptr<mujoco_ros2_control_msgs::srv::SetPause::Request> request,
                                          std::shared_ptr<mujoco_ros2_control_msgs::srv::SetPause::Response> response)
{
  auto runtime_use = acquire_runtime_use();
  if (!runtime_use)
  {
    response->success = false;
    response->message = "Simulation is shutting down.";
    return;
  }
  const std::unique_lock<std::recursive_mutex> lock(*sim_mutex_);
  const bool currently_paused = !sim_->run;
  if (currently_paused == request->paused)
  {
    if (request->paused)
    {
      publish_control_state();
      refresh_data_snapshot();
      observer_dispatcher_.on_state_snapshot(mj_model_, mj_data_, true);
    }
    response->success = true;
    response->message = std::string("Simulation is already ") + (request->paused ? "paused." : "running.");
    RCLCPP_DEBUG(get_logger(), "%s", response->message.c_str());
    return;
  }

  if (!request->paused && step_diverged_.load())
  {
    response->success = false;
    response->message = "Cannot resume simulation: reset is required after divergence.";
    RCLCPP_WARN(get_logger(), "%s", response->message.c_str());
    return;
  }

  sim_->run = !request->paused;

  if (!request->paused)
  {
    // Force timing re-sync so the physics loop doesn't try to catch up on
    // accumulated wall-clock time that elapsed while paused.
    sim_->speed_changed = true;

    // If step_simulation is currently blocking with pending steps, abort those steps
    // immediately rather than waiting for the physics loop to detect the transition.
    // This ensures step_simulation_callback unblocks and frees its executor thread
    // without any additional latency.
    const uint32_t pending = pending_steps_.load();
    if (pending > 0)
    {
      RCLCPP_WARN(get_logger(), "Resuming simulation while %u step(s) were pending; aborting.", pending);
      pending_steps_.store(0);
      steps_interrupted_.store(true);
      steps_cv_.notify_all();
    }
  }

  observer_dispatcher_.on_pause(request->paused);
  if (request->paused)
  {
    publish_control_state();
    refresh_data_snapshot();
    observer_dispatcher_.on_state_snapshot(mj_model_, mj_data_, true);
  }

  response->success = true;
  response->message = std::string("Simulation ") + (request->paused ? "paused." : "resumed.");
  RCLCPP_INFO(get_logger(), "%s", response->message.c_str());
}

void MujocoSimulation::step_simulation_callback(
    const std::shared_ptr<mujoco_ros2_control_msgs::srv::StepSimulation::Request> request,
    std::shared_ptr<mujoco_ros2_control_msgs::srv::StepSimulation::Response> response)
{
  auto runtime_use = acquire_runtime_use();
  if (!runtime_use)
  {
    response->success = false;
    response->message = "Cannot step simulation: simulation is shutting down.";
    return;
  }
  {
    // The pause check and queue mutation are one transaction with SetPause and the
    // physics loop. Release this lock before the condition-variable wait below.
    const std::unique_lock<std::recursive_mutex> lock(*sim_mutex_);
    if (sim_->exitrequest.load())
    {
      response->success = false;
      response->message = "Cannot step simulation: simulation is shutting down.";
      RCLCPP_WARN(get_logger(), "%s", response->message.c_str());
      return;
    }
    if (sim_->run)
    {
      response->success = false;
      response->message = "Cannot step simulation: simulation is not paused.";
      RCLCPP_WARN(get_logger(), "%s", response->message.c_str());
      return;
    }

    if (request->steps == 0)
    {
      response->success = false;
      response->message = "Number of steps must be positive, got: 0";
      RCLCPP_WARN(get_logger(), "%s", response->message.c_str());
      return;
    }
    if (step_diverged_.load())
    {
      response->success = false;
      response->message = "Cannot step simulation: reset is required after divergence.";
      RCLCPP_WARN(get_logger(), "%s", response->message.c_str());
      return;
    }

    // Reset the interrupt flag and queue steps while resume is excluded by sim_mutex_.
    record_transition_for_testing("step_queue_setup");
    steps_interrupted_.store(false);
    pending_steps_.fetch_add(request->steps);
  }

  // Block until all steps are executed or the timeout expires.
  // Timeout: at least 30 s, or 10 ms per step (whichever is larger).
  const auto timeout =
      std::chrono::milliseconds(std::max(static_cast<uint64_t>(30000), static_cast<uint64_t>(request->steps) * 10));

  std::unique_lock<std::mutex> lock(steps_cv_mutex_);
  const bool completed = steps_cv_.wait_for(lock, timeout, [this] { return pending_steps_.load() == 0; });

  if (!completed)
  {
    response->success = false;
    response->message = "Timeout waiting for " + std::to_string(request->steps) + " simulation step(s).";
    RCLCPP_WARN(get_logger(), "%s", response->message.c_str());
  }
  else if (steps_interrupted_.load())
  {
    response->success = false;
    response->message = "Steps aborted: simulation was resumed while steps were pending.";
    RCLCPP_WARN(get_logger(), "%s", response->message.c_str());
  }
  else if (step_diverged_.load())
  {
    response->success = false;
    response->message = "Steps aborted: simulation diverged.";
    RCLCPP_WARN(get_logger(), "%s", response->message.c_str());
  }
  else
  {
    response->success = true;
    response->message = "Completed " + std::to_string(request->steps) + " simulation step(s).";
    RCLCPP_DEBUG(get_logger(), "%s", response->message.c_str());
  }
}

int MujocoSimulation::frame_body_id(const std::string& frame_id) const
{
  if (frame_id.empty())
  {
    return -1;
  }
  return mj_name2id(mj_model_, mjOBJ_BODY, frame_id.c_str());
}

bool MujocoSimulation::validate_frame_id(const std::string& frame_id, const std::string& field_label,
                                         std::string& error_message) const
{
  if (!frame_id.empty() && frame_body_id(frame_id) == -1)
  {
    error_message = "Unknown " + field_label + " frame_id body name: '" + frame_id + "'.";
    return false;
  }
  return true;
}

int MujocoSimulation::find_free_joint_id(int body_id) const
{
  // A body's joints are contiguous from body_jntadr, and a free joint is the only joint its body
  // can carry, so this inspects one entry rather than scanning all njnt joints.
  const int first_joint = mj_model_->body_jntadr[body_id];
  const int num_joints = mj_model_->body_jntnum[body_id];
  for (int j = first_joint; j >= 0 && j < first_joint + num_joints; ++j)
  {
    if (mj_model_->jnt_type[j] == mjJNT_FREE)
    {
      return j;
    }
  }
  return -1;
}

bool MujocoSimulation::validate_free_joint_states(
    const std::vector<mujoco_ros2_control_msgs::msg::FreeJointState>& free_joints, std::string& error_message)
{
  for (size_t i = 0; i < free_joints.size(); ++i)
  {
    const mujoco_ros2_control_msgs::msg::FreeJointState& state = free_joints[i];
    // Only built when an entry is rejected, which is why this is a lambda and not a string.
    const auto fail = [&](const std::string& reason) {
      error_message = "Entry " + std::to_string(i) + " ('" + state.name + "'): " + reason;
      return false;
    };

    const int body_id = mj_name2id(mj_model_, mjOBJ_BODY, state.name.c_str());
    if (body_id == -1)
    {
      return fail("Unknown body name.");
    }

    if (find_free_joint_id(body_id) == -1)
    {
      return fail("Body is not driven by a free joint.");
    }

    std::string frame_error;
    if (!validate_frame_id(state.pose.header.frame_id, "pose", frame_error) ||
        !validate_frame_id(state.twist.header.frame_id, "twist", frame_error))
    {
      return fail(frame_error);
    }
  }
  return true;
}

void MujocoSimulation::apply_free_joint_states(
    const std::vector<mujoco_ros2_control_msgs::msg::FreeJointState>& free_joints)
{
  for (const mujoco_ros2_control_msgs::msg::FreeJointState& state : free_joints)
  {
    const int body_id = mj_name2id(mj_model_, mjOBJ_BODY, state.name.c_str());
    const int joint_id = find_free_joint_id(body_id);
    // qpos layout is position then orientation in (w, x, y, z), MuJoCo's convention; qvel is
    // linear then angular velocity.
    mjtNum* qpos = mj_data_->qpos + mj_model_->jnt_qposadr[joint_id];
    mjtNum* qvel = mj_data_->qvel + mj_model_->jnt_dofadr[joint_id];

    const mjtNum rel_pos[3] = { state.pose.pose.position.x, state.pose.pose.position.y, state.pose.pose.position.z };
    const mjtNum rel_quat[4] = { state.pose.pose.orientation.w, state.pose.pose.orientation.x,
                                 state.pose.pose.orientation.y, state.pose.pose.orientation.z };
    const mjtNum rel_linvel[3] = { state.twist.twist.linear.x, state.twist.twist.linear.y, state.twist.twist.linear.z };
    const mjtNum rel_angvel[3] = { state.twist.twist.angular.x, state.twist.twist.angular.y,
                                   state.twist.twist.angular.z };

    // Frame poses come from xpos/xquat, which only change when kinematics runs, so earlier
    // entries' qpos/qvel writes cannot affect later entries' frame resolution.
    const int pose_frame_body_id = frame_body_id(state.pose.header.frame_id);
    if (pose_frame_body_id == -1)
    {
      mju_copy3(qpos, rel_pos);
      mju_copy4(qpos + 3, rel_quat);
    }
    else
    {
      mju_mulPose(qpos, qpos + 3, mj_data_->xpos + 3 * pose_frame_body_id, mj_data_->xquat + 4 * pose_frame_body_id,
                  rel_pos, rel_quat);
    }

    const int twist_frame_body_id = frame_body_id(state.twist.header.frame_id);
    if (twist_frame_body_id == -1)
    {
      mju_copy3(qvel, rel_linvel);
      mju_copy3(qvel + 3, rel_angvel);
    }
    else
    {
      // The reference body's own velocity is not added, only its orientation.
      const mjtNum* twist_frame_quat = mj_data_->xquat + 4 * twist_frame_body_id;
      mju_rotVecQuat(qvel, rel_linvel, twist_frame_quat);
      mju_rotVecQuat(qvel + 3, rel_angvel, twist_frame_quat);
    }
  }
}

bool MujocoSimulation::validate_joint_state_overrides(const sensor_msgs::msg::JointState& joint_state,
                                                      std::string& error_message)
{
  const size_t num_joints = joint_state.name.size();
  if (!joint_state.effort.empty())
  {
    error_message = "Joint state effort is not supported; leave 'effort' empty.";
    return false;
  }
  // Both value arrays are optional, but a non-empty one must line up with 'name'.
  const auto check_length = [&](const char* field, size_t size) {
    if (size == 0 || size == num_joints)
    {
      return true;
    }
    error_message = std::string("Joint state '") + field + "' has " + std::to_string(size) +
                    " entries but 'name' has " + std::to_string(num_joints) + "; it must be empty or the same length.";
    return false;
  };
  if (!check_length("position", joint_state.position.size()) || !check_length("velocity", joint_state.velocity.size()))
  {
    return false;
  }

  for (size_t i = 0; i < num_joints; ++i)
  {
    const std::string& name = joint_state.name[i];
    // Only built when an entry is rejected, which is why this is a lambda and not a string.
    const auto fail = [&](const std::string& reason) {
      error_message = "Entry " + std::to_string(i) + " ('" + name + "'): " + reason;
      return false;
    };

    const int joint_id = mj_name2id(mj_model_, mjOBJ_JOINT, name.c_str());
    if (joint_id == -1)
    {
      return fail("Unknown joint name.");
    }
    const int joint_type = mj_model_->jnt_type[joint_id];
    if (joint_type != mjJNT_HINGE && joint_type != mjJNT_SLIDE)
    {
      // Ball and other multi-DOF joints have no home in either field: one scalar per name cannot
      // express them, and they are not free-joint bodies either.
      fail("Not a single-DOF (hinge or slide) joint.");
      if (joint_type == mjJNT_FREE)
      {
        error_message += " Free joints are set through 'state_overrides.free_joints' by body name.";
      }
      return false;
    }
  }
  return true;
}

void MujocoSimulation::apply_joint_state_overrides(const sensor_msgs::msg::JointState& joint_state)
{
  for (size_t i = 0; i < joint_state.name.size(); ++i)
  {
    const int joint_id = mj_name2id(mj_model_, mjOBJ_JOINT, joint_state.name[i].c_str());
    if (!joint_state.position.empty())
    {
      mj_data_->qpos[mj_model_->jnt_qposadr[joint_id]] = joint_state.position[i];
    }
    if (!joint_state.velocity.empty())
    {
      mj_data_->qvel[mj_model_->jnt_dofadr[joint_id]] = joint_state.velocity[i];
    }
  }
}

bool MujocoSimulation::set_free_joint_states(
    const std::vector<mujoco_ros2_control_msgs::msg::FreeJointState>& free_joints, std::string& error_message)
{
  const std::unique_lock<std::recursive_mutex> lock(*sim_mutex_);

  // Nothing to write, and nothing worth republishing a snapshot for.
  if (free_joints.empty())
  {
    return true;
  }

  // Validate everything before writing anything, so a single invalid entry leaves mj_data_
  // untouched.
  if (!validate_free_joint_states(free_joints, error_message))
  {
    RCLCPP_WARN(get_logger(), "%s", error_message.c_str());
    return false;
  }

  apply_free_joint_states(free_joints);

  refresh_data_snapshot();
  publish_control_state();
  mj_forward(mj_model_, mj_data_);
  return true;
}

void MujocoSimulation::set_free_joint_state_callback(
    const std::shared_ptr<mujoco_ros2_control_msgs::srv::SetFreeJointState::Request> request,
    std::shared_ptr<mujoco_ros2_control_msgs::srv::SetFreeJointState::Response> response)
{
  auto runtime_use = acquire_runtime_use();
  if (!runtime_use)
  {
    response->success = false;
    response->message = "Simulation is shutting down.";
    return;
  }
  std::string error_message;
  response->success = set_free_joint_states(request->free_joints, error_message);
  if (response->success)
  {
    response->message = "Successfully set free joint state for " + std::to_string(request->free_joints.size()) +
                        " bod" + (request->free_joints.size() == 1 ? "y" : "ies") + ".";
    RCLCPP_INFO(get_logger(), "%s", response->message.c_str());
  }
  else
  {
    response->message = error_message;
    RCLCPP_WARN(get_logger(), "%s", response->message.c_str());
  }
}

void MujocoSimulation::set_viewer_camera_callback(
    const std::shared_ptr<mujoco_ros2_control_msgs::srv::SetViewerCamera::Request> request,
    std::shared_ptr<mujoco_ros2_control_msgs::srv::SetViewerCamera::Response> response)
{
  auto runtime_use = acquire_runtime_use();
  if (!runtime_use)
  {
    response->success = false;
    response->message = "viewer unavailable";
    return;
  }
  const std::lock_guard<std::mutex> service_lock(viewer_service_mutex_);
  if ((headless_ && !viewer_available_for_testing_) || sim_ == nullptr || sim_mutex_ == nullptr || mj_model_ == nullptr)
  {
    response->success = false;
    response->message = "viewer unavailable";
    return;
  }

  const std::unique_lock<std::recursive_mutex> lock(*sim_mutex_);
  const ViewerCameraResult result =
      validate_and_apply_viewer_camera(request->camera, mj_model_, cam_, sim_->camera);
  response->success = result.success;
  response->message = result.message;
  response->applied_camera = result.camera;
}

void MujocoSimulation::get_viewer_camera_callback(
    const std::shared_ptr<mujoco_ros2_control_msgs::srv::GetViewerCamera::Request> /*request*/,
    std::shared_ptr<mujoco_ros2_control_msgs::srv::GetViewerCamera::Response> response)
{
  auto runtime_use = acquire_runtime_use();
  if (!runtime_use)
  {
    response->success = false;
    response->message = "viewer unavailable";
    return;
  }
  const std::lock_guard<std::mutex> service_lock(viewer_service_mutex_);
  if ((headless_ && !viewer_available_for_testing_) || sim_ == nullptr || sim_mutex_ == nullptr || mj_model_ == nullptr)
  {
    response->success = false;
    response->message = "viewer unavailable";
    return;
  }

  const std::unique_lock<std::recursive_mutex> lock(*sim_mutex_);
  const ViewerCameraResult result = read_viewer_camera(mj_model_, cam_, sim_->camera);
  response->success = result.success;
  response->message = result.message;
  response->camera = result.camera;
}

void MujocoSimulation::copy_physics_model(mjModel*& destination)
{
  const std::unique_lock<std::recursive_mutex> lock(*sim_mutex_);
  destination = mj_copyModel(destination, mj_model_);
}

void MujocoSimulation::overwrite_physics_data(mjData* source)
{
  const std::unique_lock<std::recursive_mutex> lock(*sim_mutex_);
  mj_copyData(mj_data_, mj_model_, source);
  refresh_data_snapshot();
  publish_control_state();
}

void MujocoSimulation::copy_physics_data(mjData*& destination)
{
  if (destination == nullptr)
  {
    destination = mj_makeData(mj_model_);
  }

  const std::unique_lock<std::recursive_mutex> lock(*sim_mutex_);
  // Authoritative copies also refresh the snapshots, so that snapshot readers immediately see
  // any direct mj_data_ manipulation the caller performed before this call (e.g. during setup).
  refresh_data_snapshot();
  publish_control_state();
  mj_copyData(destination, mj_model_, mj_data_);
}

mjData* MujocoSimulation::acquire_data_snapshot()
{
  {
    const std::lock_guard<std::mutex> lock(data_exchange_mutex_);
    if (snapshot_ready_)
    {
      // Take ownership of the completed snapshot and recycle the previous one back to the
      // producer. O(1): the consumer never copies and never waits on a fill.
      std::swap(snapshot_write_, snapshot_read_);
      snapshot_ready_ = false;
    }
  }

  // Ask the physics loop for a refresh if it is paused. Running steps refresh every
  // successful transition independently of this request.
  snapshot_refresh_requested_.store(true, std::memory_order_release);
  return snapshot_read_;
}

void MujocoSimulation::apply_control_data(mjData* control_data)
{
  const std::lock_guard<std::mutex> lock(control_staging_mutex_);
  mju_copy(ctrl_staged_.data(), control_data->ctrl, static_cast<int>(mj_model_->nu));
  mju_copy(qfrc_applied_staged_.data(), control_data->qfrc_applied, static_cast<int>(mj_model_->nv));
  control_inputs_staged_ = true;
}

void MujocoSimulation::refresh_data_snapshot()
{
  {
    // Reclaim the producer-side buffer. Once snapshot_ready_ is lowered the consumer can no
    // longer swap it away mid-fill, so the copy below can safely run outside the lock.
    const std::lock_guard<std::mutex> lock(data_exchange_mutex_);
    snapshot_ready_ = false;
  }

  // Scene-sized copy, paid by the producer, outside any shared lock.
  // Writers are serialized by the sim mutex and the consumer never touches snapshot_write_.
  mj_copyData(snapshot_write_, mj_model_, mj_data_);

  {
    const std::lock_guard<std::mutex> lock(data_exchange_mutex_);
    snapshot_ready_ = true;
  }
  record_transition_for_testing("data_snapshot");
}

void MujocoSimulation::publish_control_state()
{
  {
    const std::lock_guard<std::mutex> lock(control_state_mutex_);
    control_state_.time = mj_data_->time;
    control_state_.qpos.assign(mj_data_->qpos, mj_data_->qpos + mj_model_->nq);
    control_state_.qvel.assign(mj_data_->qvel, mj_data_->qvel + mj_model_->nv);
    control_state_.act.assign(mj_data_->act, mj_data_->act + mj_model_->na);
    control_state_.qfrc_actuator.assign(
      mj_data_->qfrc_actuator, mj_data_->qfrc_actuator + mj_model_->nv);
    control_state_.sensordata.assign(
      mj_data_->sensordata, mj_data_->sensordata + mj_model_->nsensordata);
    control_state_.ctrl.assign(mj_data_->ctrl, mj_data_->ctrl + mj_model_->nu);
  }
  record_transition_for_testing("control_state");
}

void MujocoSimulation::copy_control_state(ControlState& destination)
{
  const std::lock_guard<std::mutex> lock(control_state_mutex_);
  destination = control_state_;
}

void MujocoSimulation::apply_staged_control_inputs()
{
  const std::lock_guard<std::mutex> lock(control_staging_mutex_);

  // Only apply ctrl / qfrc_applied once the hw interface has staged control inputs,
  // so that initial or reset values in mj_data_ are not overwritten with zeros.
  if (control_inputs_staged_)
  {
    mju_copy(mj_data_->ctrl, ctrl_staged_.data(), static_cast<int>(mj_model_->nu));
    mju_copy(mj_data_->qfrc_applied, qfrc_applied_staged_.data(), static_cast<int>(mj_model_->nv));
  }
}

const char* MujocoSimulation::step_authoritative_physics()
{
  const auto diagnostic_step_start = clock_trace_ ? ClockTrace::monotonic_ns() : 0;
  if (clock_trace_) {
    const auto original_time = std::llround(mj_data_->time * 1e9);
    // Begin names the previous successful step; only a successful commit assigns the next ID.
    clock_trace_->record(ClockTraceKind::StepBegin, diagnostic_successful_step_, ClockTrace::reset_epoch(),
      original_time, original_time, diagnostic_step_start, diagnostic_step_start);
  }
  apply_staged_control_inputs();
  record_transition_for_testing("apply_staged_control");

  // Keep the established plugin pre_step fan-out on the physics thread.
  pre_step_callback_(mj_data_);
  mj_step(mj_model_, mj_data_);

  // A divergent step is not authoritative: do not wake observers or publish snapshots/clock.
  const char* message = Diverged(mj_model_->opt.disableflags, mj_data_);
  if (message)
  {
    step_diverged_.store(true);
    return message;
  }

  if (clock_trace_) {
    ++diagnostic_successful_step_;
    clock_trace_->record(ClockTraceKind::StepCommit, diagnostic_successful_step_, ClockTrace::reset_epoch(),
      std::llround(mj_data_->time * 1e9), 1, diagnostic_step_start, ClockTrace::monotonic_ns());
  }

  record_transition_for_testing("mj_step");
  observer_dispatcher_.on_physics_step(mj_model_, mj_data_);

  publish_control_state();
  refresh_data_snapshot();
  snapshot_refresh_requested_.store(false, std::memory_order_release);
  publish_clock();
  return nullptr;
}

// simulate in background thread (while rendering in main thread)
void MujocoSimulation::physics_loop()
{
  // cpu-sim synchronization point
  std::chrono::time_point<mj::Simulate::Clock> syncCPU;
  mjtNum syncSim = 0;

  // run until asked to exit
  while (!sim_->exitrequest.load())
  {
    // sleep for 1 ms or yield, to let main thread run
    //  yield results in busy wait - which has better timing but kills battery life
    if (sim_->run && sim_->busywait)
    {
      std::this_thread::yield();
    }
    else
    {
      std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }

    {
      // lock the sim mutex during the update
      const std::unique_lock<std::recursive_mutex> lock(*sim_mutex_);

      // Consume only reset generations published by the adapter after it ran
      // the actual pending_.reset branch in Simulate::Sync. History scrubs and
      // keyframe loads can also move time backward, but they never publish it.
      const uint64_t published_generation = published_ui_reset_generation_.load(std::memory_order_acquire);
      while (processed_ui_reset_generation_ < published_generation)
      {
        if (pending_ui_resets_.empty())
        {
          RCLCPP_ERROR(get_logger(), "Lost Simulate UI reset generation %llu",
                       static_cast<unsigned long long>(processed_ui_reset_generation_ + 1));
          processed_ui_reset_generation_ = published_generation;
          break;
        }

        const PendingUiReset reset = pending_ui_resets_.front();
        pending_ui_resets_.pop_front();
        mj_data_->time = reset.previous_time;

        reset_world_state(true);
        sim_->speed_changed = true;
        processed_ui_reset_generation_ = reset.generation;

        RCLCPP_INFO(get_logger(), "Applied UI reset generation %llu through the common reset transaction.",
                    static_cast<unsigned long long>(reset.generation));
      }

      // run only if model is present
      if (mj_model_)
      {
        // running (ie, not paused)
        if (sim_->run)
        {
          // If the sim was unpaused while a StepSimulation call was in progress,
          // abort the remaining pending steps so the service call unblocks cleanly.
          if (pending_steps_.load() > 0)
          {
            RCLCPP_WARN(get_logger(), "Simulation resumed while %u step(s) were still pending; aborting.",
                        pending_steps_.load());
            pending_steps_.store(0);
            steps_interrupted_.store(true);
            steps_cv_.notify_all();
          }

          bool stepped = false;

          // record cpu time at start of iteration
          const auto startCPU = mj::Simulate::Clock::now();

          // elapsed CPU and simulation time since last sync
          const auto elapsedCPU = startCPU - syncCPU;
          auto elapsedSim = mj_data_->time - syncSim;

          // Ordinarily the speed factor for the simulation is pulled from the sim UI. However, this is
          // overridable by setting the "sim_speed_factor" parameter in the hardware info.
          // If that parameter is set, then we ignore whatever slowdown has been requested from the UI.
          double speedFactor = sim_speed_factor_ < 0 ? (100.0 / sim_->percentRealTime[sim_->real_time_index]) :
                                                       (1.0 / sim_speed_factor_);

          // misalignment condition: distance from target sim time is bigger
          // than syncmisalign
          bool misaligned = std::abs(Seconds(elapsedCPU).count() / speedFactor - elapsedSim) > kSyncMisalign;

          // out-of-sync (for any reason): reset sync times, step
          if (elapsedSim < 0 || elapsedCPU.count() < 0 || syncCPU.time_since_epoch().count() == 0 || misaligned ||
              sim_->speed_changed)
          {
            // re-sync
            syncCPU = startCPU;
            syncSim = mj_data_->time;
            sim_->speed_changed = false;

            // Run one authoritative step, then let the next iteration deal with timing.
            const char* message = step_authoritative_physics();
            if (message)
            {
              sim_->run = 0;
              mju::strcpy_arr(sim_->load_error, message);
            }
            else
            {
              stepped = true;
              step_count_.fetch_add(1);
            }
          }

          // in-sync: step until ahead of cpu
          else
          {
            bool measured = false;
            mjtNum prevSim = mj_data_->time;

            double refreshTime = kSimRefreshFraction / sim_->refresh_rate;

            // step while sim lags behind cpu and within refreshTime.
            auto currentCPU = mj::Simulate::Clock::now();
            while (Seconds((mj_data_->time - syncSim) * speedFactor) < currentCPU - syncCPU &&
                   currentCPU - startCPU < Seconds(refreshTime))
            {
              // measure slowdown before first step
              if (!measured && elapsedSim != 0.0)
              {
                sim_->measured_slowdown =
                    static_cast<float>(std::chrono::duration<double>(elapsedCPU).count() / elapsedSim);
                measured = true;
              }
// inject noise
// Use mjVERSION_HEADER and if it is greater than 337 then do one thing or another
// Needed due to
// https://github.com/google-deepmind/mujoco/commit/401bf431b8b0fe6e0a619412a607b5135dc4ded4#diff-3dc22ceeebd71304c41d349c6d273bda172ea88ff49c772dbdcf51b9b19bbd33R2943
#if mjVERSION_HEADER < 337
              sim_->InjectNoise();
#else
              sim_->InjectNoise(-1);
#endif
              const char* message = step_authoritative_physics();
              if (message)
              {
                sim_->run = 0;
                mju::strcpy_arr(sim_->load_error, message);
                // The failed integration mutated mj_data_ and must not be stored in history.
                // Stop this catch-up batch immediately; earlier successful steps already
                // published their own authoritative snapshots and clock ticks.
                stepped = false;
                break;
              }
              else
              {
                stepped = true;
                step_count_.fetch_add(1);
              }

              // break if reset
              if (mj_data_->time < prevSim)
              {
                break;
              }

              // Update current CPU time for next iteration
              currentCPU = mj::Simulate::Clock::now();
            }
          }

          // save current state to history buffer
          if (stepped)
          {
            sim_->AddToHistory();
            update_sim_display();
          }
        }

        // paused
        else
        {
          // Translate keyboard 'S' presses into single pending steps.
          if (keyboard_step_requested_.exchange(false))
          {
            if (!step_diverged_.load())
            {
              pending_steps_.fetch_add(1);
            }
          }

          // Execute one pending step per physics loop iteration so the clock publisher
          // (try_publish) has time to flush between steps, matching play mode behavior.
          if (pending_steps_.load() > 0)
          {
            const char* message = step_authoritative_physics();
            if (message)
            {
              pending_steps_.store(0);
              step_diverged_.store(true);
              mju::strcpy_arr(sim_->load_error, message);
              steps_cv_.notify_all();
            }
            else
            {
              sim_->AddToHistory();
              pending_steps_.fetch_sub(1);
              step_count_.fetch_add(1);
              steps_cv_.notify_all();
              update_sim_display();
            }

            if (pending_steps_.load() == 0)
            {
              sim_->speed_changed = true;
            }
          }
          else
          {
            // A divergent step mutated mj_data_ but is not authoritative. Retain the last good
            // snapshots until reset instead of publishing failed integration state.
            if (!step_diverged_.load())
            {
              // Merge staged actuator commands while paused so the viewer reflects the latest
              // commands without manufacturing a physics transition or observer notification.
              apply_staged_control_inputs();
              mj_forward(mj_model_, mj_data_);
              sim_->speed_changed = true;
              update_sim_display();

              // Keep snapshots in sync with non-step UI/control edits while paused.
              if (snapshot_refresh_requested_.exchange(false, std::memory_order_acq_rel))
              {
                refresh_data_snapshot();
              }
              publish_control_state();
            }
          }
        }

      }
    }  // release std::lock_guard<std::mutex>
  }
}

void MujocoSimulation::publish_clock()
{
  // Quantize the original physics time once at ROS nanosecond resolution.
  // Fractional-second truncation can create a 1ns short timestep from floating
  // point roundoff, deferring a controller's update to the next physics step.
  const rclcpp::Time sim_time_ros(std::llround(mj_data_->time * 1e9), RCL_ROS_TIME);

  rosgraph_msgs::msg::Clock sim_time_msg;
  sim_time_msg.clock = sim_time_ros;
  const auto diagnostic_publish_start = clock_trace_ ? ClockTrace::monotonic_ns() : 0;
  if (clock_trace_) {
    clock_trace_->record(ClockTraceKind::ClockBegin, diagnostic_successful_step_, ClockTrace::reset_epoch(),
      sim_time_ros.nanoseconds(), sim_time_ros.nanoseconds(), diagnostic_publish_start, diagnostic_publish_start);
  }
// fixing for different naming convention on humble vs everything else
#if ROS_DISTRO_HUMBLE
  const bool admitted = clock_realtime_publisher_->tryPublish(sim_time_msg);
#else
  const bool admitted = clock_realtime_publisher_->try_publish(sim_time_msg);
#endif
  if (clock_trace_) {
    clock_trace_->record(ClockTraceKind::ClockEnd, diagnostic_successful_step_, ClockTrace::reset_epoch(),
      sim_time_ros.nanoseconds(), admitted, diagnostic_publish_start, ClockTrace::monotonic_ns());
  }
  record_transition_for_testing("clock");
}

void MujocoSimulation::update_sim_display()
{
  if (headless_)
  {
    return;
  }

  // Lock-free handoff to the render thread, which swaps user_texts_new_ without
  // holding sim_->mtx (Simulate::Render runs outside the lock). newtextrequest is
  // the single-producer/single-consumer flag: 0 = physics may write, 1 = render
  // may consume. Skip if the last update hasn't been consumed yet.
  if (sim_->newtextrequest.load(std::memory_order_acquire) != 0)
  {
    return;
  }

  // Desired speed: from parameter override when set, otherwise from the UI slider.
  const double desired_pct = sim_speed_factor_ < 0 ? static_cast<double>(sim_->percentRealTime[sim_->real_time_index]) :
                                                     sim_speed_factor_ * 100.0;

  // Actual speed: measured_slowdown = CPU_time / sim_time, so speed = 100 / slowdown.
  // Falls back to 0 while paused (slowdown stays at its last measured value but we
  // suppress the display when there is no forward progress).
  const double actual_pct = sim_->run ? (100.0 / sim_->measured_slowdown) : 0.0;

  // mj_data_ is owned by this (the physics) thread, so reading time/ncon needs no extra locking.
  // Contacts surface why the sim slows down: a spike here usually explains a drop in actual speed.
  const auto [title, content] =
      compose_sim_display_text(sim_->run, step_count_.load(), mj_data_->time, desired_pct, actual_pct, mj_data_->ncon);

  sim_->user_texts_new_.clear();
  sim_->user_texts_new_.emplace_back(mjFONT_NORMAL, mjGRID_TOPRIGHT, title, content);

  // Publish only after the vector is fully written; the release store pairs with
  // the render thread's load.
  sim_->newtextrequest.store(1, std::memory_order_release);
}

}  // namespace mujoco_ros2_control
