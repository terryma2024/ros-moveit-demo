// Copyright (C) 2026 zjumty@gmail.com
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include <mujoco_ros2_control/viewer_camera.hpp>

#include <cmath>
#include <string>

namespace mujoco_ros2_control
{
namespace
{
using mujoco_ros2_control_msgs::msg::ViewerCamera;

ViewerCameraResult failure(std::string message)
{
  return { false, std::move(message), ViewerCamera{} };
}

bool free_camera_values_are_valid(const ViewerCamera & request)
{
  for (const double coordinate : request.lookat)
  {
    if (!std::isfinite(coordinate))
    {
      return false;
    }
  }
  return std::isfinite(request.distance) && request.distance > 0.0 &&
         std::isfinite(request.azimuth_deg) && std::isfinite(request.elevation_deg) &&
         request.elevation_deg > -90.0 && request.elevation_deg < 90.0;
}
}  // namespace

double normalize_viewer_azimuth(double degrees)
{
  if (!std::isfinite(degrees))
  {
    return degrees;
  }
  double normalized = std::fmod(degrees, 360.0);
  if (normalized < -180.0)
  {
    normalized += 360.0;
  }
  else if (normalized >= 180.0)
  {
    normalized -= 360.0;
  }
  return normalized == 0.0 ? 0.0 : normalized;
}

ViewerCameraResult read_viewer_camera(
  const mjModel * model,
  const mjvCamera & camera,
  int camera_selector)
{
  ViewerCamera state;
  if (camera.type == mjCAMERA_FREE && camera_selector == 0)
  {
    state.mode = ViewerCamera::FREE;
    state.lookat = {{ camera.lookat[0], camera.lookat[1], camera.lookat[2] }};
    state.distance = camera.distance;
    state.azimuth_deg = normalize_viewer_azimuth(camera.azimuth);
    state.elevation_deg = camera.elevation;
    state.orthographic = camera.orthographic != 0;
    state.fixed_camera_name = "";
    return { true, "viewer camera read", state };
  }

  if (camera.type == mjCAMERA_FIXED && model != nullptr && camera.fixedcamid >= 0 &&
      camera.fixedcamid < model->ncam && camera_selector == camera.fixedcamid + 2)
  {
    const char * name = mj_id2name(model, mjOBJ_CAMERA, camera.fixedcamid);
    if (name == nullptr)
    {
      return failure("fixed camera has no name");
    }
    state.mode = ViewerCamera::FIXED;
    state.fixed_camera_name = name;
    return { true, "viewer camera read", state };
  }

  return failure("unsupported viewer camera state");
}

ViewerCameraResult validate_and_apply_viewer_camera(
  const ViewerCamera & request,
  const mjModel * model,
  mjvCamera & camera,
  int & camera_selector)
{
  mjvCamera candidate = camera;
  int candidate_selector = camera_selector;

  if (request.mode == ViewerCamera::FREE)
  {
    if (!request.fixed_camera_name.empty())
    {
      return failure("free camera must not name a fixed camera");
    }
    if (!free_camera_values_are_valid(request))
    {
      return failure("invalid free camera values");
    }
    candidate.type = mjCAMERA_FREE;
    candidate.fixedcamid = -1;
    candidate.trackbodyid = -1;
    for (std::size_t index = 0; index < request.lookat.size(); ++index)
    {
      candidate.lookat[index] = request.lookat[index];
    }
    candidate.distance = request.distance;
    candidate.azimuth = normalize_viewer_azimuth(request.azimuth_deg);
    candidate.elevation = request.elevation_deg;
    candidate.orthographic = request.orthographic ? 1 : 0;
    candidate_selector = 0;
  }
  else if (request.mode == ViewerCamera::FIXED)
  {
    if (request.fixed_camera_name.empty())
    {
      return failure("fixed camera name is required");
    }
    if (model == nullptr)
    {
      return failure("MuJoCo model is unavailable");
    }
    const int camera_id = mj_name2id(model, mjOBJ_CAMERA, request.fixed_camera_name.c_str());
    if (camera_id < 0)
    {
      return failure("unknown fixed camera: " + request.fixed_camera_name);
    }
    candidate.type = mjCAMERA_FIXED;
    candidate.fixedcamid = camera_id;
    candidate.trackbodyid = -1;
    candidate_selector = camera_id + 2;
  }
  else
  {
    return failure("unknown viewer camera mode");
  }

  const ViewerCameraResult applied = read_viewer_camera(model, candidate, candidate_selector);
  if (!applied.success)
  {
    return applied;
  }
  camera = candidate;
  camera_selector = candidate_selector;
  return { true, "viewer camera applied", applied.camera };
}
}  // namespace mujoco_ros2_control
