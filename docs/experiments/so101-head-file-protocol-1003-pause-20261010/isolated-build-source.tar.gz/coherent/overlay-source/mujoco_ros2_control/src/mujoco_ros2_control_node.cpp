// Copyright 2020 ROS2-Control Development Team
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include <errno.h>
#include <atomic>
#include <chrono>
#include <memory>
#include <string>
#include <thread>
#include "mujoco_ros2_control/clock_trace.hpp"
#include "mujoco_ros2_control/clock_advance_probe.hpp"
#include "mujoco_ros2_control/exit_phase.hpp"
#include "mujoco_ros2_control/control_cycle.hpp"

#include <hardware_interface/version.h>
#include <hardware_interface/introspection.hpp>
#include <controller_manager/controller_manager.hpp>
#include <rclcpp/executors.hpp>
#include <realtime_tools/realtime_helpers.hpp>
#ifdef __APPLE__
#include "mujoco_ros2_control/macos_ui_dispatcher.hpp"
#endif

using namespace std::chrono_literals;

namespace
{
// Reference: https://man7.org/linux/man-pages/man2/sched_setparam.2.html
// This value is used when configuring the main loop to use SCHED_FIFO scheduling
// We use a midpoint RT priority to allow maximum flexibility to users
int const kSchedPriority = 50;

void spin_controller_executor(
  const std::shared_ptr<rclcpp::Executor> & executor, const rclcpp::Logger & logger)
{
  while (rclcpp::ok())
  {
    try
    {
      executor->spin();
    }
    catch (const rclcpp::exceptions::RCLError & error)
    {
      const std::string message(error.what());
      if (message.find("failed to send response: cannot publish data") == std::string::npos)
      {
        throw;
      }
      RCLCPP_WARN(
        logger, "MUJOCO_ROS2_CONTROL_DROPPED_SERVICE_RESPONSE: %s", error.what());
    }
  }
}

}  // namespace

int main(int argc, char ** argv)
{
  if (!mujoco_ros2_control::initialize_exit_phase()) {return 3;}
  rclcpp::init(argc, argv);

  std::shared_ptr<rclcpp::Executor> executor =
    std::make_shared<rclcpp::executors::MultiThreadedExecutor>();
  std::string manager_node_name = "controller_manager";

  rclcpp::NodeOptions cm_node_options = controller_manager::get_cm_node_options();
  std::vector<std::string> node_arguments = cm_node_options.arguments();
  for (int i = 1; i < argc; ++i)
  {
    if (node_arguments.empty() && std::string(argv[i]) != "--ros-args")
    {
      // A simple way to reject non ros args
      continue;
    }
    node_arguments.push_back(argv[i]);
  }
  cm_node_options.arguments(node_arguments);
  const auto loop_trace = mujoco_ros2_control::ClockTrace::from_environment("loop");
  mujoco_ros2_control::ClockAdvanceProbe clock_probe;
  try {
    clock_probe = mujoco_ros2_control::ClockAdvanceProbe::parse(
      std::getenv("SO101_DIAGNOSTIC_CLOCK_ADVANCE_LOOP"), bool(loop_trace));
  } catch (const std::invalid_argument & error) {
    RCLCPP_ERROR(rclcpp::get_logger("controller_manager"), "%s", error.what());
    if (loop_trace) {loop_trace->finish();}
    rclcpp::shutdown();
    return 3;
  }

  auto cm = std::make_shared<controller_manager::ControllerManager>(
    executor, manager_node_name, "", cm_node_options);

  // ControllerManager registers its controller/resource teardown callback in its constructor.
  // rclcpp runs pre-shutdown callbacks FIFO, so registering this callback afterwards keeps the
  // PAL publisher threads alive through teardown but stops them before the ROS context is invalid.
  // The registries remain present until ControllerManager destruction because the control thread
  // can still call publishAsync() while the context shutdown is being completed.
  const auto introspection_shutdown_once = std::make_shared<std::atomic_bool>(false);
  [[maybe_unused]] const auto introspection_shutdown_callback =
    cm->get_node_base_interface()->get_context()->add_pre_shutdown_callback(
    [logger = cm->get_logger(), introspection_shutdown_once]()
    {
      mujoco_ros2_control::ExitPhaseScope callback_phase(7);
      if (!introspection_shutdown_once->exchange(true))
      {
        const auto default_registry =
          pal_statistics::getRegistry(hardware_interface::DEFAULT_REGISTRY_KEY);
        if (default_registry)
        {
          mujoco_ros2_control::observe_exit(8,0,[&] {default_registry->stopPublisherThread();});
        }
        const auto cm_statistics_registry =
          pal_statistics::getRegistry(hardware_interface::CM_STATISTICS_KEY);
        if (cm_statistics_registry)
        {
          mujoco_ros2_control::observe_exit(9,0,[&] {cm_statistics_registry->stopPublisherThread();});
        }
        if (default_registry && cm_statistics_registry)
        {
          RCLCPP_INFO(logger, "MUJOCO_ROS2_CONTROL_INTROSPECTION_PUBLISHERS_STOPPED");
        }
        else
        {
          RCLCPP_ERROR(logger, "Failed to stop all controller introspection publishers");
        }
      }
    });

  const bool use_sim_time = cm->get_parameter_or("use_sim_time", false);
  try {
    clock_probe.validate(use_sim_time, cm->get_update_rate());
  } catch (const std::invalid_argument & error) {
    RCLCPP_ERROR(cm->get_logger(), "%s", error.what());
    rclcpp::shutdown();
    cm.reset();
    if (loop_trace) {loop_trace->finish();}
    return 3;
  }

  const bool has_realtime = realtime_tools::has_realtime_kernel();
  const bool lock_memory = cm->get_parameter_or<bool>("lock_memory", has_realtime);
  if (lock_memory)
  {
    const auto lock_result = realtime_tools::lock_memory();
    if (!lock_result.first)
    {
      RCLCPP_WARN(cm->get_logger(), "Unable to lock the memory: '%s'", lock_result.second.c_str());
    }
  }

  RCLCPP_INFO(cm->get_logger(), "update rate is %d Hz", cm->get_update_rate());
  const bool manage_overruns = cm->get_parameter_or<bool>("overruns.manage", true);
  RCLCPP_INFO(
    cm->get_logger(), "Overruns handling is : %s", manage_overruns ? "enabled" : "disabled");
  const int thread_priority = cm->get_parameter_or<int>("thread_priority", kSchedPriority);
  RCLCPP_INFO(
    cm->get_logger(), "Spawning %s RT thread with scheduler priority: %d", cm->get_name(),
    thread_priority);

  std::atomic<bool> probe_failure{false}, control_quiesced{false};
  std::thread cm_thread(
    [cm, thread_priority, use_sim_time, manage_overruns, trace = loop_trace.get(),
      clock_probe, &probe_failure, &control_quiesced]() mutable
    {
      mujoco_ros2_control::ProbeControlQuiescence on_exit(control_quiesced);
      // portable function that gets now from the cm on humble or later appropriately
      auto get_cm_now = [](const auto& ctrl_mgr) -> rclcpp::Time {
#if HARDWARE_INTERFACE_VERSION_MAJOR < 3
        return ctrl_mgr->now();
#else
        return ctrl_mgr->get_trigger_clock()->now();
#endif
      };

      rclcpp::Parameter cpu_affinity_param;
      if (cm->get_parameter("cpu_affinity", cpu_affinity_param))
      {
        std::vector<int> cpus = {};
        if (cpu_affinity_param.get_type() == rclcpp::ParameterType::PARAMETER_INTEGER)
        {
          cpus = {static_cast<int>(cpu_affinity_param.as_int())};
        }
        else if (cpu_affinity_param.get_type() == rclcpp::ParameterType::PARAMETER_INTEGER_ARRAY)
        {
          const auto cpu_affinity_param_array = cpu_affinity_param.as_integer_array();
          std::for_each(
            cpu_affinity_param_array.begin(), cpu_affinity_param_array.end(),
            [&cpus](int cpu) { cpus.push_back(static_cast<int>(cpu)); });
        }
        const auto affinity_result = realtime_tools::set_current_thread_affinity(cpus);
        if (!affinity_result.first)
        {
          RCLCPP_WARN(
            cm->get_logger(), "Unable to set the CPU affinity : '%s'",
            affinity_result.second.c_str());
        }
      }

      if (!realtime_tools::configure_sched_fifo(thread_priority))
      {
        RCLCPP_WARN(
          cm->get_logger(),
          "Could not enable FIFO RT scheduling policy: with error number <%i>(%s). See "
          "[https://control.ros.org/master/doc/ros2_control/controller_manager/doc/userdoc.html] "
          "for details on how to enable realtime scheduling.",
          errno, strerror(errno));
      }
      else
      {
        RCLCPP_INFO(
          cm->get_logger(), "Successful set up FIFO RT scheduling policy with priority %i.",
          thread_priority);
      }

      // CHANGED FROM UPSTREAM
      // We must wait for the clock to be running, which requires the simulation to have started so that the
      // physics loop will publish to the clock topic. To account for that, we must spin the executor
      // and the controller manager node to ensure the MuJoCo hardware interface is constructed and launched.
      // So instead, we just wait in the control loop so that the hardware interface can still start and run.
      //
      // TODO: Potentially remove this node depending on what comes out of the upstream PR:
      // https://github.com/ros-controls/ros2_control/pull/2654
      try
      {
        if (!cm->get_clock()->wait_until_started() || !rclcpp::ok())
        {
          return;
        }
        if (!cm->get_clock()->sleep_for(
            rclcpp::Duration::from_seconds(1.0 / cm->get_update_rate())) ||
          !rclcpp::ok())
        {
          return;
        }
      }
      catch (const std::runtime_error & e)
      {
        RCLCPP_ERROR(
          cm->get_logger(),
          "Initial sleep_for failed with error: %s. Exiting control loop.", e.what());
        return;
      }

      // for calculating sleep time
      auto const period = std::chrono::nanoseconds(1'000'000'000 / cm->get_update_rate());

      // for calculating the measured period of the loop
      rclcpp::Time previous_time = get_cm_now(cm);
      std::this_thread::sleep_for(period);

      std::chrono::steady_clock::time_point next_iteration_time{std::chrono::steady_clock::now()};
      uint64_t diagnostic_loop = 0;
      using mujoco_ros2_control::ClockTrace;
      using mujoco_ros2_control::ClockTraceKind;

      while (rclcpp::ok())
      {
        // calculate measured period
        const auto diagnostic_epoch = trace ? ClockTrace::reset_epoch() : 0;
        const auto diagnostic_clock_start = trace ? ClockTrace::monotonic_ns() : 0;
        auto const current_time = get_cm_now(cm);
        const auto diagnostic_clock_end = trace ? ClockTrace::monotonic_ns() : 0;
        auto const measured_period = current_time - previous_time;
        previous_time = current_time;
        if (trace) {
          ++diagnostic_loop;
          trace->record(ClockTraceKind::LoopStart, diagnostic_loop, diagnostic_epoch,
            current_time.nanoseconds(), measured_period.nanoseconds(), diagnostic_clock_start, diagnostic_clock_end);
        }

        // execute update loop
        using mujoco_ros2_control::CycleOperation;
        const bool cycle_complete = mujoco_ros2_control::execute_control_cycle(
          *cm, current_time, measured_period, use_sim_time,
          [&] {return get_cm_now(cm);},
          [&](CycleOperation) {return trace ? ClockTrace::monotonic_ns() : 0;},
          [&](CycleOperation operation, const rclcpp::Time & argument, uint64_t start) {
            if (trace) {
              const auto kind = operation == CycleOperation::Read ? ClockTraceKind::Read :
                operation == CycleOperation::Update ? ClockTraceKind::Update : ClockTraceKind::Write;
              trace->record(kind, diagnostic_loop, ClockTrace::reset_epoch(),
                argument.nanoseconds(), measured_period.nanoseconds(), start,
                ClockTrace::monotonic_ns());
            }
          },
          [&] {
            if (trace && clock_probe.enabled()) {
              const auto probe = clock_probe.run(diagnostic_loop, current_time, period,
                diagnostic_epoch, *cm->get_clock(), *cm->get_node_base_interface()->get_context());
              if (probe.invoked) {
                trace->record(ClockTraceKind::ProbeWait, diagnostic_loop, diagnostic_epoch,
                  probe.after, probe.target, probe.start, probe.end,
                  static_cast<uint64_t>(probe.before), probe.flags);
                if (probe.flags != 1 && probe.flags != 32) {
                  probe_failure.store(true, std::memory_order_release);
                  return false;
                }
              }
            }
            return true;
          });
        if (!cycle_complete) {
          break;
        }

        // wait until we hit the end of the period
        if (use_sim_time)
        {
          try
          {
            // `sleep_until` may throw if sim time stops (e.g., simulation shutdown).
            if (trace) {
              const auto target = current_time + period;
              const auto start = ClockTrace::monotonic_ns();
              trace->record(ClockTraceKind::SleepBegin, diagnostic_loop, ClockTrace::reset_epoch(),
                current_time.nanoseconds(), target.nanoseconds(), start, start);
              const bool slept = cm->get_clock()->sleep_until(target);
              trace->record(ClockTraceKind::SleepReturn, diagnostic_loop, ClockTrace::reset_epoch(),
                current_time.nanoseconds(), slept, start, ClockTrace::monotonic_ns());
            } else {
              cm->get_clock()->sleep_until(current_time + period);
            }
          }
          catch (const std::runtime_error & e)
          {
            if (trace) {
              const auto stamp = ClockTrace::monotonic_ns();
              trace->record(ClockTraceKind::SleepException, diagnostic_loop, ClockTrace::reset_epoch(),
                current_time.nanoseconds(), 1, stamp, stamp);
            }
            RCLCPP_ERROR(cm->get_logger(),
            "Sleep_until failed with error: %s. Exiting control loop and aborting....", e.what());
            break;
          }
        }
        else
        {
          next_iteration_time += period;
          const auto time_now = std::chrono::steady_clock::now();
          if (manage_overruns && next_iteration_time < time_now)
          {
            const double time_diff =
              static_cast<double>(
                std::chrono::duration_cast<std::chrono::nanoseconds>(time_now - next_iteration_time)
                  .count()) /
              1.e6;
            const double cm_period = 1.e3 / static_cast<double>(cm->get_update_rate());
            const int overrun_count = static_cast<int>(std::ceil(time_diff / cm_period));
            RCLCPP_WARN_THROTTLE(
              cm->get_logger(), *cm->get_clock(), 1000,
              "Overrun detected! The controller manager missed its desired rate of %d Hz. The loop "
              "took %f ms (missed cycles : %d).",
              cm->get_update_rate(), time_diff + cm_period, overrun_count + 1);
            next_iteration_time += (overrun_count * period);
          }
          std::this_thread::sleep_until(next_iteration_time);
        }
      }
    });

  auto probe_relay = mujoco_ros2_control::start_probe_shutdown_relay(
    clock_probe.enabled(), cm->get_node_base_interface()->get_context(),
    probe_failure, control_quiesced);

  executor->add_node(cm);
#ifdef __APPLE__
  std::thread executor_thread([executor, logger = cm->get_logger()]() {
    spin_controller_executor(executor, logger);
    mujoco_ros2_control::request_macos_ui_stop();
  });
  const bool ran_ui = mujoco_ros2_control::run_macos_ui_task_on_main_thread();
  if (ran_ui && rclcpp::ok())
  {
    rclcpp::shutdown();
  }
  if (ran_ui)
  {
    // The UI phase has closed and drained the simulation runtime-use gate. The control loop
    // cannot depend on main-thread cleanup, so join it first. Then clean Cocoa resources before
    // joining the outer executor: failed on_init destruction can wait in that executor for this
    // main-thread cleanup without forming a cycle.
    cm_thread.join();
    mujoco_ros2_control::run_macos_ui_cleanup_on_main_thread();
  }
  executor_thread.join();
  if (!ran_ui)
  {
    cm_thread.join();
  }
#else
  mujoco_ros2_control::observe_exit(1,0,[&] {spin_controller_executor(executor, cm->get_logger());});
  mujoco_ros2_control::observe_exit(2,0,[&] {cm_thread.join();});
#endif
  if (probe_relay.joinable()) {
    mujoco_ros2_control::observe_exit(3,0,[&] {probe_relay.join();});
  }
  // ControllerManager owns the final registry clear. Destroy it only after the control and
  // executor threads have joined so no reader can race the global registry-map erase.
  mujoco_ros2_control::observe_exit(4,0,[&] {cm.reset();});
  if (loop_trace) {
    const bool trace_complete = mujoco_ros2_control::observe_exit(5,0,[&] {return loop_trace->finish();});
    if (!trace_complete || mujoco_ros2_control::ClockTrace::all_invalid_flags()) {return 2;}
  }
  mujoco_ros2_control::observe_exit(6,0,[] {rclcpp::shutdown();});
  return probe_failure.load(std::memory_order_acquire) ? 3 : 0;
}
