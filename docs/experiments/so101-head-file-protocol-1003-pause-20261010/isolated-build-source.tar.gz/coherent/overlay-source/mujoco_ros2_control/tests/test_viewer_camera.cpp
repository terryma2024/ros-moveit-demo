// Copyright (C) 2026 zjumty@gmail.com
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include <gtest/gtest.h>

#include <cmath>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <limits>
#include <string>

#include <mujoco/mujoco.h>
#include <mujoco_ros2_control/viewer_camera.hpp>
#include <mujoco_ros2_control_msgs/msg/viewer_camera.hpp>

namespace
{
using mujoco_ros2_control_msgs::msg::ViewerCamera;

class ViewerCameraTest : public ::testing::Test
{
protected:
  void SetUp() override
  {
    model_path_ = "/tmp/test_viewer_camera_model.xml";
    std::ofstream file(model_path_);
    file << R"(<mujoco model="viewer_camera_test">
  <worldbody>
    <camera name="fixed_test" pos="1 -1 1" xyaxes="1 1 0 -0.5 0.5 1"/>
    <geom type="plane" size="1 1 0.1"/>
  </worldbody>
</mujoco>)";
    file.close();

    char error[1024] = {};
    model_ = mj_loadXML(model_path_.c_str(), nullptr, error, sizeof(error));
    ASSERT_NE(model_, nullptr) << error;
  }

  void TearDown() override
  {
    if (model_ != nullptr)
    {
      mj_deleteModel(model_);
    }
    std::filesystem::remove(model_path_);
  }

  static mjvCamera initial_camera()
  {
    mjvCamera camera;
    mjv_defaultCamera(&camera);
    camera.lookat[0] = 0.1;
    camera.lookat[1] = 0.2;
    camera.lookat[2] = 0.3;
    camera.distance = 2.0;
    camera.azimuth = 15.0;
    camera.elevation = -25.0;
    camera.orthographic = 0;
    return camera;
  }

  static ViewerCamera valid_free_request()
  {
    ViewerCamera request;
    request.mode = ViewerCamera::FREE;
    request.lookat = {{ 0.4, -0.2, 0.7 }};
    request.distance = 1.25;
    request.azimuth_deg = 225.0;
    request.elevation_deg = -20.0;
    request.orthographic = true;
    request.fixed_camera_name = "";
    return request;
  }

  static void expect_unchanged(
    const mjvCamera & expected_camera,
    int expected_selector,
    const mjvCamera & actual_camera,
    int actual_selector)
  {
    EXPECT_EQ(std::memcmp(&expected_camera, &actual_camera, sizeof(mjvCamera)), 0);
    EXPECT_EQ(actual_selector, expected_selector);
  }

  std::string model_path_;
  mjModel * model_{ nullptr };
};

TEST_F(ViewerCameraTest, NormalizesAzimuthIntoHalfOpenRange)
{
  EXPECT_DOUBLE_EQ(mujoco_ros2_control::normalize_viewer_azimuth(225.0), -135.0);
  EXPECT_DOUBLE_EQ(mujoco_ros2_control::normalize_viewer_azimuth(-225.0), 135.0);
  EXPECT_DOUBLE_EQ(mujoco_ros2_control::normalize_viewer_azimuth(180.0), -180.0);
}

TEST_F(ViewerCameraTest, AppliesEveryFreeCameraFieldAndReturnsNormalizedState)
{
  mjvCamera camera = initial_camera();
  int selector = 7;

  const auto result = mujoco_ros2_control::validate_and_apply_viewer_camera(
    valid_free_request(), model_, camera, selector);

  ASSERT_TRUE(result.success) << result.message;
  EXPECT_EQ(camera.type, mjCAMERA_FREE);
  EXPECT_EQ(camera.fixedcamid, -1);
  EXPECT_EQ(camera.trackbodyid, -1);
  EXPECT_EQ(selector, 0);
  EXPECT_DOUBLE_EQ(camera.lookat[0], 0.4);
  EXPECT_DOUBLE_EQ(camera.lookat[1], -0.2);
  EXPECT_DOUBLE_EQ(camera.lookat[2], 0.7);
  EXPECT_DOUBLE_EQ(camera.distance, 1.25);
  EXPECT_DOUBLE_EQ(camera.azimuth, -135.0);
  EXPECT_DOUBLE_EQ(camera.elevation, -20.0);
  EXPECT_EQ(camera.orthographic, 1);
  EXPECT_EQ(result.camera.mode, ViewerCamera::FREE);
  EXPECT_DOUBLE_EQ(result.camera.azimuth_deg, -135.0);
}

TEST_F(ViewerCameraTest, RejectsInvalidFreeCameraRequestsWithoutMutation)
{
  const double nan = std::numeric_limits<double>::quiet_NaN();
  const double infinity = std::numeric_limits<double>::infinity();
  const auto baseline_camera = initial_camera();
  constexpr int baseline_selector = 4;

  for (int invalid_case = 0; invalid_case < 8; ++invalid_case)
  {
    auto request = valid_free_request();
    switch (invalid_case)
    {
      case 0: request.lookat[1] = nan; break;
      case 1: request.azimuth_deg = infinity; break;
      case 2: request.distance = 0.0; break;
      case 3: request.distance = -1.0; break;
      case 4: request.elevation_deg = -90.0; break;
      case 5: request.elevation_deg = 90.0; break;
      case 6: request.fixed_camera_name = "fixed_test"; break;
      case 7: request.mode = 255; break;
    }
    mjvCamera camera = baseline_camera;
    int selector = baseline_selector;

    const auto result = mujoco_ros2_control::validate_and_apply_viewer_camera(
      request, model_, camera, selector);

    EXPECT_FALSE(result.success) << "invalid case " << invalid_case;
    expect_unchanged(baseline_camera, baseline_selector, camera, selector);
  }
}

TEST_F(ViewerCameraTest, ResolvesFixedCameraNameAndReturnsActualState)
{
  ViewerCamera request;
  request.mode = ViewerCamera::FIXED;
  request.fixed_camera_name = "fixed_test";
  mjvCamera camera = initial_camera();
  int selector = 0;

  const auto result = mujoco_ros2_control::validate_and_apply_viewer_camera(
    request, model_, camera, selector);

  const int fixed_id = mj_name2id(model_, mjOBJ_CAMERA, "fixed_test");
  ASSERT_GE(fixed_id, 0);
  ASSERT_TRUE(result.success) << result.message;
  EXPECT_EQ(camera.type, mjCAMERA_FIXED);
  EXPECT_EQ(camera.fixedcamid, fixed_id);
  EXPECT_EQ(camera.trackbodyid, -1);
  EXPECT_EQ(selector, fixed_id + 2);
  EXPECT_EQ(result.camera.mode, ViewerCamera::FIXED);
  EXPECT_EQ(result.camera.fixed_camera_name, "fixed_test");
}

TEST_F(ViewerCameraTest, RejectsUnknownFixedCameraWithoutMutation)
{
  ViewerCamera request;
  request.mode = ViewerCamera::FIXED;
  request.fixed_camera_name = "missing_camera";
  const auto baseline_camera = initial_camera();
  mjvCamera camera = baseline_camera;
  constexpr int baseline_selector = 3;
  int selector = baseline_selector;

  const auto result = mujoco_ros2_control::validate_and_apply_viewer_camera(
    request, model_, camera, selector);

  EXPECT_FALSE(result.success);
  expect_unchanged(baseline_camera, baseline_selector, camera, selector);
}

TEST_F(ViewerCameraTest, ReadsFreeAndFixedCameraState)
{
  mjvCamera camera = initial_camera();
  camera.type = mjCAMERA_FREE;
  camera.azimuth = 225.0;
  auto result = mujoco_ros2_control::read_viewer_camera(model_, camera, 0);
  ASSERT_TRUE(result.success) << result.message;
  EXPECT_EQ(result.camera.mode, ViewerCamera::FREE);
  EXPECT_DOUBLE_EQ(result.camera.azimuth_deg, -135.0);

  camera.type = mjCAMERA_FIXED;
  camera.fixedcamid = mj_name2id(model_, mjOBJ_CAMERA, "fixed_test");
  result = mujoco_ros2_control::read_viewer_camera(model_, camera, camera.fixedcamid + 2);
  ASSERT_TRUE(result.success) << result.message;
  EXPECT_EQ(result.camera.mode, ViewerCamera::FIXED);
  EXPECT_EQ(result.camera.fixed_camera_name, "fixed_test");
}

TEST_F(ViewerCameraTest, RejectsUnsupportedTrackingAndUserCameraState)
{
  mjvCamera camera = initial_camera();
  camera.type = mjCAMERA_TRACKING;
  EXPECT_FALSE(mujoco_ros2_control::read_viewer_camera(model_, camera, 1).success);

  camera.type = mjCAMERA_USER;
  EXPECT_FALSE(mujoco_ros2_control::read_viewer_camera(model_, camera, -1).success);
}
}  // namespace
