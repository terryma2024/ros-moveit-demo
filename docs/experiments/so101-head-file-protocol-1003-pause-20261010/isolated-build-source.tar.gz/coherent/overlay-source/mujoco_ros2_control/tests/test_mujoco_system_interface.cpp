/**
 * Copyright (c) 2026, United States Government, as represented by the
 * Administrator of the National Aeronautics and Space Administration.
 *
 * All rights reserved.
 *
 * This software is licensed under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with the
 * License. You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations
 * under the License.
 */

#include <gtest/gtest.h>

#include <atomic>
#include <chrono>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <functional>
#include <mutex>
#include <string>
#include <thread>
#include <utility>
#include <vector>

#include <hardware_interface/version.h>
#include <mujoco/mujoco.h>
#include <hardware_interface/hardware_info.hpp>
#include <rclcpp/rclcpp.hpp>

#include <mujoco_ros2_control/mujoco_system_interface.hpp>
#include <mujoco_ros2_control_plugins/mujoco_ros2_control_plugin_capabilities.hpp>
#include <mujoco_ros2_control_plugins/mujoco_ros2_control_plugins_base.hpp>

#define ROS_DISTRO_HUMBLE (HARDWARE_INTERFACE_VERSION_MAJOR < 3)

namespace
{

// Pendulum model with framepos/framequat and magnetometer sensors on a site at the pendulum body origin.
constexpr const char* kTestModel = R"(<?xml version="1.0"?>
<mujoco model="test_system_interface">
  <option timestep="0.002" magnetic="0.1 0.2 0.3"/>

  <worldbody>
    <body name="pendulum" pos="0 0 1">
      <joint name="hinge" type="hinge" axis="0 1 0"/>
      <geom type="capsule" size="0.02" fromto="0 0 0 0.3 0 0" mass="1"/>
      <site name="pendulum_site"/>
    </body>
  </worldbody>

  <sensor>
    <framepos name="pose_sensor_pos" objtype="site" objname="pendulum_site"/>
    <framequat name="pose_sensor_quat" objtype="site" objname="pendulum_site"/>
    <magnetometer name="magnetometer_sensor" site="pendulum_site"/>
  </sensor>
</mujoco>
)";

constexpr const char* kIntVelocityTestModel = R"(<?xml version="1.0"?>
<mujoco model="intvelocity_system_interface">
  <option timestep="0.002"/>

  <worldbody>
    <body name="wheel" pos="0 0 0">
      <joint name="wheel_joint" type="hinge" axis="0 1 0"/>
      <geom type="cylinder" size="0.1 0.02" mass="1"/>
    </body>
  </worldbody>

  <actuator>
    <intvelocity name="wheel_joint" joint="wheel_joint" kp="10" kv="1" ctrlrange="-5 5"
                 actrange="-100 100"/>
  </actuator>
</mujoco>
)";

// Write to disk for testing
const std::string kTestModelPath = "/tmp/test_mujoco_system_interface_model.xml";
const std::string kIntVelocityTestModelPath = "/tmp/test_mujoco_system_interface_intvelocity_model.xml";
void write_test_model()
{
  std::ofstream file(kTestModelPath);
  file << kTestModel;
  file.close();
}

void write_intvelocity_test_model()
{
  std::ofstream file(kIntVelocityTestModelPath);
  file << kIntVelocityTestModel;
  file.close();
}

}  // namespace

class StepCountingObserverPlugin
  : public mujoco_ros2_control_plugins::MuJoCoROS2ControlPluginBase,
    public mujoco_ros2_control_plugins::MuJoCoROS2ControlSimulationObserver
{
public:
  bool init(rclcpp::Node::SharedPtr, const mjModel*, mjData*) override
  {
    return true;
  }

  void cleanup() override
  {
  }

  void on_physics_step(const mjModel*, const mjData*) override
  {
    step_notifications.fetch_add(1);
  }

  std::atomic<uint64_t> step_notifications{ 0 };
};

class CleanupAwareObserverPlugin
  : public mujoco_ros2_control_plugins::MuJoCoROS2ControlPluginBase,
    public mujoco_ros2_control_plugins::MuJoCoROS2ControlSimulationObserver
{
public:
  bool init(rclcpp::Node::SharedPtr, const mjModel*, mjData*) override
  {
    return true;
  }

  void cleanup() override
  {
    cleanup_started.store(true);
    cleanup_calls.fetch_add(1);

    // Give an incorrectly still-running physics loop a deterministic opportunity to dispatch.
    const auto deadline = std::chrono::steady_clock::now() + std::chrono::milliseconds(250);
    while (callbacks_after_cleanup.load() == 0 && std::chrono::steady_clock::now() < deadline)
    {
      std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }
  }

  void on_physics_step(const mjModel*, const mjData*) override
  {
    step_notifications.fetch_add(1);
    if (cleanup_started.load())
    {
      callbacks_after_cleanup.fetch_add(1);
    }
  }

  std::atomic<bool> cleanup_started{ false };
  std::atomic<uint64_t> cleanup_calls{ 0 };
  std::atomic<uint64_t> step_notifications{ 0 };
  std::atomic<uint64_t> callbacks_after_cleanup{ 0 };
};

class PluginLifecycleLog
{
public:
  void add(std::string event)
  {
    const std::lock_guard<std::mutex> lock(mutex_);
    events_.push_back(std::move(event));
  }

  std::vector<std::string> copy() const
  {
    const std::lock_guard<std::mutex> lock(mutex_);
    return events_;
  }

private:
  mutable std::mutex mutex_;
  std::vector<std::string> events_;
};

class InitializationTrackingObserverPlugin
  : public mujoco_ros2_control_plugins::MuJoCoROS2ControlPluginBase,
    public mujoco_ros2_control_plugins::MuJoCoROS2ControlSimulationObserver
{
public:
  InitializationTrackingObserverPlugin(std::string name, bool init_result, PluginLifecycleLog& lifecycle)
    : name_(std::move(name)), init_result_(init_result), lifecycle_(lifecycle)
  {
  }

  bool init(rclcpp::Node::SharedPtr, const mjModel*, mjData*) override
  {
    lifecycle_.add("init:" + name_);
    return init_result_;
  }

  void cleanup() override
  {
    cleanup_calls.fetch_add(1);
    lifecycle_.add("cleanup:" + name_);
  }

  void on_physics_step(const mjModel*, const mjData*) override
  {
    step_notifications.fetch_add(1);
  }

  std::atomic<uint64_t> cleanup_calls{ 0 };
  std::atomic<uint64_t> step_notifications{ 0 };

private:
  std::string name_;
  bool init_result_;
  PluginLifecycleLog& lifecycle_;
};

class MujocoSystemInterfaceTest : public ::testing::Test
{
protected:
  static void SetUpTestSuite()
  {
    if (!rclcpp::ok())
    {
      rclcpp::init(0, nullptr);
    }
  }

  static void TearDownTestSuite()
  {
    if (rclcpp::ok())
    {
      rclcpp::shutdown();
    }
  }

  void SetUp() override
  {
    write_test_model();
    interface_ = std::make_shared<mujoco_ros2_control::MujocoSystemInterface>();
  }

  void TearDown() override
  {
    // Deactivate interface before destroying to stop threads cleanly
    if (interface_)
    {
      rclcpp_lifecycle::State inactive_state(0, "inactive");
      interface_->on_deactivate(inactive_state);
      interface_.reset();
    }

    // Clean up test files if present
    if (std::filesystem::exists(kTestModelPath))
    {
      std::filesystem::remove(kTestModelPath);
    }
    if (std::filesystem::exists(kIntVelocityTestModelPath))
    {
      std::filesystem::remove(kIntVelocityTestModelPath);
    }
  }

  // Create the hardware info to initialize the interface with, in headless mode.
  hardware_interface::HardwareInfo create_hardware_info()
  {
    hardware_interface::HardwareInfo info;
    info.name = "test_mujoco_system_interface";
    info.type = "system";
    info.hardware_parameters["mujoco_model"] = kTestModelPath;
    info.hardware_parameters["meshdir"] = "";
    info.hardware_parameters["headless"] = "true";
    info.hardware_parameters["disable_rendering"] = "true";
    return info;
  }

  // Initialize the interface with the given hardware info.
  hardware_interface::CallbackReturn initialize_interface(const hardware_interface::HardwareInfo& hardware_info)
  {
#if ROS_DISTRO_HUMBLE
    return interface_->on_init(hardware_info);
#else
    hardware_interface::HardwareComponentInterfaceParams params;
    params.hardware_info = hardware_info;
    return interface_->on_init(params);
#endif
  }

  // Helper function to poll a condition until it returns true or the timeout expires.
  bool wait_until(std::function<bool()> condition, std::chrono::milliseconds timeout = std::chrono::seconds(5),
                  std::chrono::milliseconds poll_interval = std::chrono::milliseconds(10))
  {
    const auto deadline = std::chrono::steady_clock::now() + timeout;
    while (std::chrono::steady_clock::now() < deadline)
    {
      if (condition())
        return true;
      std::this_thread::sleep_for(poll_interval);
    }
    return condition();
  }

  bool initialize_and_register_plugin(
      const std::shared_ptr<mujoco_ros2_control_plugins::MuJoCoROS2ControlPluginBase>& plugin,
      const std::string& plugin_namespace)
  {
    return interface_->initialize_and_register_plugin(
        plugin, interface_->get_node()->create_sub_node(plugin_namespace));
  }

  std::shared_ptr<mujoco_ros2_control::MujocoSystemInterface> interface_;
};

TEST_F(MujocoSystemInterfaceTest, InitializedPluginsRegisterSimulationObserverCapability)
{
  ASSERT_EQ(initialize_interface(create_hardware_info()), hardware_interface::CallbackReturn::SUCCESS);

  auto observer = std::make_shared<StepCountingObserverPlugin>();
  ASSERT_TRUE(initialize_and_register_plugin(observer, "explicit_observer"));

  EXPECT_TRUE(wait_until([&]() { return observer->step_notifications.load() > 0; }))
      << "Registered plugin did not receive authoritative physics-step notifications";
}

TEST_F(MujocoSystemInterfaceTest, TeardownStopsObserverDispatchBeforePluginCleanup)
{
  ASSERT_EQ(initialize_interface(create_hardware_info()), hardware_interface::CallbackReturn::SUCCESS);

  auto observer = std::make_shared<CleanupAwareObserverPlugin>();
  ASSERT_TRUE(initialize_and_register_plugin(observer, "cleanup_observer"));
  ASSERT_TRUE(wait_until([&]() { return observer->step_notifications.load() > 0; }));

  interface_.reset();

  EXPECT_EQ(observer->cleanup_calls.load(), 1u);
  EXPECT_EQ(observer->callbacks_after_cleanup.load(), 0u)
      << "Physics observer callback executed after plugin cleanup began";
}

TEST_F(MujocoSystemInterfaceTest, ExplicitAndAutomaticInitializationRetainOnlySuccessesInLoadOrder)
{
  ASSERT_EQ(initialize_interface(create_hardware_info()), hardware_interface::CallbackReturn::SUCCESS);

  PluginLifecycleLog lifecycle;
  auto explicit_plugin = std::make_shared<InitializationTrackingObserverPlugin>("explicit", true, lifecycle);
  auto failed_plugin = std::make_shared<InitializationTrackingObserverPlugin>("failed", false, lifecycle);
  auto automatic_plugin = std::make_shared<InitializationTrackingObserverPlugin>("automatic", true, lifecycle);

  EXPECT_TRUE(initialize_and_register_plugin(explicit_plugin, "explicit"));
  EXPECT_FALSE(initialize_and_register_plugin(failed_plugin, "failed"));
  EXPECT_TRUE(initialize_and_register_plugin(automatic_plugin, "automatic"));

  ASSERT_TRUE(wait_until([&]() {
    return explicit_plugin->step_notifications.load() > 0 && automatic_plugin->step_notifications.load() > 0;
  }));
  EXPECT_EQ(failed_plugin->step_notifications.load(), 0u);
  EXPECT_EQ(lifecycle.copy(),
            (std::vector<std::string>{ "init:explicit", "init:failed", "init:automatic" }));

  interface_.reset();

  EXPECT_EQ(explicit_plugin->cleanup_calls.load(), 1u);
  EXPECT_EQ(failed_plugin->cleanup_calls.load(), 0u);
  EXPECT_EQ(automatic_plugin->cleanup_calls.load(), 1u);
  EXPECT_EQ(lifecycle.copy(), (std::vector<std::string>{ "init:explicit", "init:failed", "init:automatic",
                                                        "cleanup:explicit", "cleanup:automatic" }));
}

TEST_F(MujocoSystemInterfaceTest, IntVelocityActuatorSupportsVelocityCommandInterface)
{
  write_intvelocity_test_model();
  auto hardware_info = create_hardware_info();
  hardware_info.hardware_parameters["mujoco_model"] = kIntVelocityTestModelPath;

  hardware_interface::ComponentInfo joint_info;
  joint_info.name = "wheel_joint";

  hardware_interface::InterfaceInfo command_interface;
  command_interface.name = hardware_interface::HW_IF_VELOCITY;
  joint_info.command_interfaces.push_back(command_interface);

  for (const auto* interface_name :
       { hardware_interface::HW_IF_POSITION, hardware_interface::HW_IF_VELOCITY, hardware_interface::HW_IF_EFFORT })
  {
    hardware_interface::InterfaceInfo state_interface;
    state_interface.name = interface_name;
    joint_info.state_interfaces.push_back(state_interface);
  }
  hardware_info.joints.push_back(joint_info);

  ASSERT_EQ(initialize_interface(hardware_info), hardware_interface::CallbackReturn::SUCCESS);

  mjModel* model = nullptr;
  interface_->get_model(model);
  ASSERT_NE(model, nullptr);
  const int actuator_id = mj_name2id(model, mjOBJ_ACTUATOR, "wheel_joint");
  ASSERT_NE(actuator_id, -1);
  EXPECT_EQ(model->actuator_dyntype[actuator_id], mjDYN_INTEGRATOR);

  auto command_interfaces = interface_->export_command_interfaces();
  ASSERT_EQ(command_interfaces.size(), 1u);
  EXPECT_EQ(command_interfaces.front().get_name(), "wheel_joint/velocity");

  constexpr double velocity_command = 2.0;
  command_interfaces.front().set_value(velocity_command);
  ASSERT_EQ(interface_->write(rclcpp::Time(0), rclcpp::Duration::from_seconds(0.002)),
            hardware_interface::return_type::OK);

  mjData* data = nullptr;
  ASSERT_TRUE(wait_until([&]() {
    interface_->get_data(data);
    return data != nullptr && std::abs(data->ctrl[actuator_id] - velocity_command) < 1e-9;
  })) << "Velocity command was not written to the intvelocity actuator ctrl input";

  mj_deleteData(data);
  mj_deleteModel(model);
}

TEST_F(MujocoSystemInterfaceTest, PoseSensorStateInterfacesRead)
{
  // Register a pose sensor mapped to the framepos/framequat sensors in the MJCF model.
  auto hardware_info = create_hardware_info();
  hardware_interface::ComponentInfo sensor_info;
  sensor_info.name = "pose_sensor";
  sensor_info.parameters[mujoco_ros2_control::MUJOCO_TYPE_PARAM] = mujoco_ros2_control::MUJOCO_TYPE_POSE;
  for (const auto* interface_name :
       { "position.x", "position.y", "position.z", "orientation.x", "orientation.y", "orientation.z", "orientation.w" })
  {
    hardware_interface::InterfaceInfo interface_info;
    interface_info.name = interface_name;
    sensor_info.state_interfaces.push_back(interface_info);
  }
  hardware_info.sensors.push_back(sensor_info);

  ASSERT_EQ(initialize_interface(hardware_info), hardware_interface::CallbackReturn::SUCCESS);

  // Wait for the model to load and for the physics loop to advance, so that the
  // simulation has computed and published sensor data at least once.
  mjModel* model = nullptr;
  mjData* data = nullptr;
  ASSERT_TRUE(wait_until([&]() {
    interface_->get_model(model);
    interface_->get_data(data);
    return model != nullptr && data != nullptr && data->time > 0.0;
  })) << "Simulation did not start stepping";

  // read() should pull the latest sensor values into the exported state interfaces.
  interface_->read(rclcpp::Time(0), rclcpp::Duration::from_seconds(0.002));

  // The pose sensor is the only component registered, so its interfaces are exported
  // in registration order: position.x/y/z, orientation.x/y/z/w.
  const auto state_interfaces = interface_->export_state_interfaces();
  ASSERT_EQ(state_interfaces.size(), 7u);
  ASSERT_EQ(state_interfaces[0].get_name(), "pose_sensor/position.x");
  ASSERT_EQ(state_interfaces[1].get_name(), "pose_sensor/position.y");
  ASSERT_EQ(state_interfaces[2].get_name(), "pose_sensor/position.z");
  ASSERT_EQ(state_interfaces[3].get_name(), "pose_sensor/orientation.x");
  ASSERT_EQ(state_interfaces[4].get_name(), "pose_sensor/orientation.y");
  ASSERT_EQ(state_interfaces[5].get_name(), "pose_sensor/orientation.z");
  ASSERT_EQ(state_interfaces[6].get_name(), "pose_sensor/orientation.w");

#if ROS_DISTRO_HUMBLE
  const double position_z = state_interfaces[2].get_value();
  const double qx = state_interfaces[3].get_value();
  const double qy = state_interfaces[4].get_value();
  const double qz = state_interfaces[5].get_value();
  const double qw = state_interfaces[6].get_value();
#else
  const double position_z = state_interfaces[2].get_optional().value();
  const double qx = state_interfaces[3].get_optional().value();
  const double qy = state_interfaces[4].get_optional().value();
  const double qz = state_interfaces[5].get_optional().value();
  const double qw = state_interfaces[6].get_optional().value();
#endif

  // The site sits at the pendulum body origin at height 1.0, so the pose should be
  // a valid unit quaternion and a position fixed at the hinge point.
  const double tol = 1e-3;
  const double quat_norm = std::sqrt(qw * qw + qx * qx + qy * qy + qz * qz);
  EXPECT_NEAR(quat_norm, 1.0, tol);
  EXPECT_NEAR(position_z, 1.0, tol);
}

TEST_F(MujocoSystemInterfaceTest, MagnetometerSensorStateInterfacesRead)
{
  auto hardware_info = create_hardware_info();
  hardware_interface::ComponentInfo sensor_info;
  sensor_info.name = "magnetometer_sensor";
  sensor_info.parameters[mujoco_ros2_control::MUJOCO_TYPE_PARAM] = mujoco_ros2_control::MUJOCO_TYPE_MAGNETOMETER;
  for (const auto* interface_name : { "magnetic_field.x", "magnetic_field.y", "magnetic_field.z" })
  {
    hardware_interface::InterfaceInfo interface_info;
    interface_info.name = interface_name;
    sensor_info.state_interfaces.push_back(interface_info);
  }
  hardware_info.sensors.push_back(sensor_info);

  ASSERT_EQ(initialize_interface(hardware_info), hardware_interface::CallbackReturn::SUCCESS);

  mjModel* model = nullptr;
  mjData* data = nullptr;
  ASSERT_TRUE(wait_until([&]() {
    interface_->get_model(model);
    interface_->get_data(data);
    return model != nullptr && data != nullptr && data->time > 0.0;
  })) << "Simulation did not start stepping";

  interface_->read(rclcpp::Time(0), rclcpp::Duration::from_seconds(0.002));

  const auto state_interfaces = interface_->export_state_interfaces();
  ASSERT_EQ(state_interfaces.size(), 3u);
  ASSERT_EQ(state_interfaces[0].get_name(), "magnetometer_sensor/magnetic_field.x");
  ASSERT_EQ(state_interfaces[1].get_name(), "magnetometer_sensor/magnetic_field.y");
  ASSERT_EQ(state_interfaces[2].get_name(), "magnetometer_sensor/magnetic_field.z");

  const int magnetometer_id = mj_name2id(model, mjOBJ_SENSOR, "magnetometer_sensor");
  ASSERT_NE(magnetometer_id, -1);
  const int magnetometer_data_index = model->sensor_adr[magnetometer_id];

#if ROS_DISTRO_HUMBLE
  const double magnetic_field_x = state_interfaces[0].get_value();
  const double magnetic_field_y = state_interfaces[1].get_value();
  const double magnetic_field_z = state_interfaces[2].get_value();
#else
  const double magnetic_field_x = state_interfaces[0].get_optional().value();
  const double magnetic_field_y = state_interfaces[1].get_optional().value();
  const double magnetic_field_z = state_interfaces[2].get_optional().value();
#endif

  const double tol = 1e-9;
  EXPECT_NEAR(magnetic_field_x, data->sensordata[magnetometer_data_index], tol);
  EXPECT_NEAR(magnetic_field_y, data->sensordata[magnetometer_data_index + 1], tol);
  EXPECT_NEAR(magnetic_field_z, data->sensordata[magnetometer_data_index + 2], tol);
}

int main(int argc, char** argv)
{
  ::testing::InitGoogleTest(&argc, argv);
  int result = RUN_ALL_TESTS();
  return result;
}
