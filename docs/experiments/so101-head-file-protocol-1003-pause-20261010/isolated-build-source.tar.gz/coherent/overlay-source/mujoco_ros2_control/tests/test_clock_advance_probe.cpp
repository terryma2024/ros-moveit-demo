#include <gtest/gtest.h>
#include <rcl/time.h>
#include <rclcpp/executors.hpp>
#include <future>
#include <mutex>
#include "mujoco_ros2_control/clock_advance_probe.hpp"

using namespace std::chrono_literals;
using mujoco_ros2_control::ClockAdvanceProbe;
using mujoco_ros2_control::ClockTrace;

// Test-only scheduling hook: read the real clock, then change its actual ROS override
// before the next sample. Production code and clock.now() retain their original paths.
class ClockReadBoundary
{
public:
  ClockReadBoundary(rclcpp::Clock & clock, int64_t next, std::promise<void> * entered = nullptr)
  : handle_(clock.get_clock_handle()), original_(handle_->get_now), next_(next), entered_(entered)
  {
    current_ = this;
    handle_->get_now = [](void * data, rcl_time_point_value_t * value) {
      auto & state = *current_;
      const auto rc = state.original_(data, value);
      if (rc != RCL_RET_OK || state.changed_) {return rc;}
      state.changed_ = true;
      const auto changed = rcl_set_ros_time_override(state.handle_, state.next_);
      if (state.entered_) {state.entered_->set_value();}
      return changed;
    };
  }
  ~ClockReadBoundary() {handle_->get_now = original_; current_ = nullptr;}
private:
  rcl_clock_t * handle_;
  rcl_ret_t (* original_)(void *, rcl_time_point_value_t *);
  int64_t next_;
  std::promise<void> * entered_;
  bool changed_ = false;
  inline static thread_local ClockReadBoundary * current_ = nullptr;
};

class ClockProbeTest : public ::testing::Test
{
protected:
  rclcpp::Clock clock{RCL_ROS_TIME};
  rclcpp::Context::SharedPtr context = std::make_shared<rclcpp::Context>();
  rclcpp::Time base{int64_t{100000000}, RCL_ROS_TIME};
  void SetUp() override
  {
    context->init(0, nullptr, rclcpp::InitOptions().auto_initialize_logging(false));
    ASSERT_EQ(rcl_enable_ros_time_override(clock.get_clock_handle()), RCL_RET_OK);
    set_time(base.nanoseconds());
  }
  void TearDown() override {context->shutdown("test complete");}
  void set_time(int64_t ns)
  {
    std::lock_guard<std::mutex> lock(clock.get_clock_mutex());
    ASSERT_EQ(rcl_set_ros_time_override(clock.get_clock_handle(), ns), RCL_RET_OK);
  }
  ClockAdvanceProbe::Result run(ClockAdvanceProbe & probe, uint64_t loop = 5)
  {
    return probe.run(loop, base, 2ms, ClockTrace::reset_epoch(), clock, *context);
  }
  std::future<ClockAdvanceProbe::Result> entered_probe(ClockAdvanceProbe & probe)
  {
    auto entered = std::make_shared<std::promise<void>>();
    auto boundary = entered->get_future();
    auto pending = std::async(std::launch::async, [&, entered]() {
      ClockReadBoundary read(clock, base.nanoseconds(), entered.get());
      return run(probe);
    });
    EXPECT_EQ(boundary.wait_for(1s), std::future_status::ready);
    return pending;
  }
};

TEST_F(ClockProbeTest, AbsentConfigurationDoesNotWait)
{
  auto probe = ClockAdvanceProbe::parse(nullptr, false);
  probe.validate(false, 1);
  EXPECT_FALSE(run(probe).invoked);
}

TEST_F(ClockProbeTest, InvalidAndUntracedConfigurationIsRejected)
{
  for (const char * value : {"", "0", "50001", "-1", "+1", " 5", "5x",
      "18446744073709551616"})
  {
    EXPECT_THROW(ClockAdvanceProbe::parse(value, true), std::invalid_argument) << value;
  }
  EXPECT_THROW(ClockAdvanceProbe::parse("5", false), std::invalid_argument);
}

TEST_F(ClockProbeTest, IncompatibleRuntimeIsRejected)
{
  auto probe = ClockAdvanceProbe::parse("5", true);
  EXPECT_THROW(probe.validate(false, 500), std::invalid_argument);
  EXPECT_THROW(probe.validate(true, 499), std::invalid_argument);
  EXPECT_NO_THROW(probe.validate(true, 500));
}

TEST_F(ClockProbeTest, ActualClockAdvanceIsConsumedOnceAtSelectedLoop)
{
  auto probe = ClockAdvanceProbe::parse("5", true);
  EXPECT_FALSE(run(probe, 4).invoked);
  auto pending = entered_probe(probe);
  EXPECT_EQ(pending.wait_for(0ms), std::future_status::timeout);
  set_time(base.nanoseconds() + 2000000);
  const auto result = pending.get();
  EXPECT_TRUE(result.invoked);
  EXPECT_EQ(result.flags, 1u);
  EXPECT_EQ(result.before, base.nanoseconds());
  EXPECT_EQ(result.after, clock.now().nanoseconds());
  EXPECT_EQ(result.target, base.nanoseconds() + 2000000);
  EXPECT_GT(result.end, result.start);
  EXPECT_FALSE(run(probe).invoked);
  EXPECT_FALSE(run(probe, 6).invoked);
}

TEST_F(ClockProbeTest, AlreadyReachedTargetIsNotInducedAdvance)
{
  auto probe = ClockAdvanceProbe::parse("5", true);
  set_time(base.nanoseconds() + 2000000);
  const auto result = run(probe);
  EXPECT_TRUE(result.invoked);
  EXPECT_EQ(result.flags, 32u);
  EXPECT_EQ(result.before, result.after);
}

TEST_F(ClockProbeTest, CancelledContextWinsOverReachedTarget)
{
  auto probe = ClockAdvanceProbe::parse("5", true);
  set_time(base.nanoseconds() + 2000000);
  context->shutdown("cancel before success");
  EXPECT_EQ(run(probe).flags, 4u);
}

TEST_F(ClockProbeTest, ShutdownWakesWaitWithoutClockDelivery)
{
  auto probe = ClockAdvanceProbe::parse("5", true);
  auto pending = entered_probe(probe);
  context->shutdown("cancel wait");
  EXPECT_EQ(pending.get().flags, 4u);
}

TEST_F(ClockProbeTest, LoopStartResetEpochWinsOverReachedTarget)
{
  auto probe = ClockAdvanceProbe::parse("5", true);
  const auto epoch = ClockTrace::reset_epoch();
  ClockTrace::complete_reset();
  set_time(base.nanoseconds() + 2000000);
  EXPECT_EQ(probe.run(5, base, 2ms, epoch, clock, *context).flags, 8u);
}

TEST_F(ClockProbeTest, ResetDuringWaitFails)
{
  auto probe = ClockAdvanceProbe::parse("5", true);
  auto pending = entered_probe(probe);
  ClockTrace::complete_reset();
  EXPECT_EQ(pending.get().flags, 8u);
}

TEST_F(ClockProbeTest, BackwardsClockDuringWaitFails)
{
  auto probe = ClockAdvanceProbe::parse("5", true);
  auto pending = entered_probe(probe);
  set_time(base.nanoseconds() - 2000000);
  EXPECT_EQ(pending.get().flags, 8u);
}

TEST_F(ClockProbeTest, MissingClockDeliveryHasSteadyDeadline)
{
  auto probe = ClockAdvanceProbe::parse("5", true);
  const auto start = std::chrono::steady_clock::now();
  const auto result = run(probe);
  const auto elapsed = std::chrono::steady_clock::now() - start;
  EXPECT_TRUE(result.invoked);
  EXPECT_EQ(result.flags, 2u);
  EXPECT_GE(elapsed, 250ms);
  EXPECT_LT(elapsed, 1s);
}

TEST_F(ClockProbeTest, RelayShutdownWaitsForControlQuiescenceAndWakesActualSpin)
{
  std::atomic<bool> failure{false}, quiesced{false};
  bool owner_alive = true, callback_order_ok = false;
  context->add_pre_shutdown_callback([&]() {
    callback_order_ok = owner_alive && quiesced.load(std::memory_order_acquire);
  });
  rclcpp::ExecutorOptions options;
  options.context = context;
  rclcpp::executors::MultiThreadedExecutor executor(options, 2);
  auto relay = mujoco_ros2_control::start_probe_shutdown_relay(
    true, context, failure, quiesced);
  EXPECT_TRUE(relay.joinable());
  auto spin = std::async(std::launch::async, [&]() {executor.spin();});
  const auto spin_deadline = std::chrono::steady_clock::now() + 1s;
  while (!executor.is_spinning() && std::chrono::steady_clock::now() < spin_deadline) {
    std::this_thread::yield();
  }
  EXPECT_TRUE(executor.is_spinning());
  failure.store(true, std::memory_order_release);
  EXPECT_EQ(spin.wait_for(10ms), std::future_status::timeout);
  EXPECT_TRUE(context->is_valid());
  quiesced.store(true, std::memory_order_release);
  const auto retired = spin.wait_for(500ms);
  EXPECT_EQ(retired, std::future_status::ready);
  if (retired != std::future_status::ready) {context->shutdown("RED cleanup");}
  spin.get();
  if (relay.joinable()) {relay.join();}
  EXPECT_TRUE(callback_order_ok);
  EXPECT_FALSE(context->is_valid());
  owner_alive = false;
}

TEST_F(ClockProbeTest, RelayShutdownBeforeSpinCannotBeLost)
{
  std::atomic<bool> failure{true}, quiesced{true};
  rclcpp::ExecutorOptions options;
  options.context = context;
  rclcpp::executors::MultiThreadedExecutor executor(options, 2);
  auto relay = mujoco_ros2_control::start_probe_shutdown_relay(
    true, context, failure, quiesced);
  EXPECT_TRUE(relay.joinable());
  if (relay.joinable()) {relay.join();}
  EXPECT_FALSE(context->is_valid());
  if (context->is_valid()) {context->shutdown("RED cleanup before spin");}
  EXPECT_NO_THROW(executor.spin());
}

TEST_F(ClockProbeTest, DisabledRelayDoesNotCreateThread)
{
  std::atomic<bool> failure{true}, quiesced{true};
  auto relay = mujoco_ros2_control::start_probe_shutdown_relay(
    false, context, failure, quiesced);
  EXPECT_FALSE(relay.joinable());
  EXPECT_TRUE(context->is_valid());
}

TEST_F(ClockProbeTest, RelayRetiresOnExternalShutdown)
{
  std::atomic<bool> failure{false}, quiesced{false};
  auto relay = mujoco_ros2_control::start_probe_shutdown_relay(
    true, context, failure, quiesced);
  EXPECT_TRUE(relay.joinable());
  context->shutdown("external context shutdown");
  if (relay.joinable()) {relay.join();}
  EXPECT_FALSE(context->is_valid());
}

TEST_F(ClockProbeTest, InactiveRosClockFailsBeforeApparentTargetSuccess)
{
  auto probe = ClockAdvanceProbe::parse("5", true);
  ASSERT_EQ(rcl_disable_ros_time_override(clock.get_clock_handle()), RCL_RET_OK);
  EXPECT_EQ(run(probe).flags, 16u);
}

TEST_F(ClockProbeTest, ControlExitPublishesQuiescenceOnException)
{
  std::atomic<bool> quiesced{false};
  try {
    mujoco_ros2_control::ProbeControlQuiescence on_exit(quiesced);
    EXPECT_FALSE(quiesced.load(std::memory_order_acquire));
    throw std::runtime_error("control exit");
  } catch (const std::runtime_error &) {}
  EXPECT_TRUE(quiesced.load(std::memory_order_acquire));
}

TEST_F(ClockProbeTest, RelayCallbackExceptionFailsClosedWithNonzeroExit)
{
  ::testing::GTEST_FLAG(death_test_style) = "threadsafe";
  ASSERT_EXIT({
    std::atomic<bool> failure{true};
    std::atomic<bool> quiesced{true};
    context->add_pre_shutdown_callback([]() {throw std::runtime_error("teardown fault");});
    auto relay = mujoco_ros2_control::start_probe_shutdown_relay(
      true, context, failure, quiesced);
    if (relay.joinable()) {relay.join();}
    std::_Exit(0);
  }, ::testing::ExitedWithCode(3), "");
}

TEST_F(ClockProbeTest, BackwardsBetweenFirstTwoActualReadsWinsOverAlreadyTarget)
{
  auto probe = ClockAdvanceProbe::parse("5", true);
  set_time(base.nanoseconds() + 3000000);
  ClockReadBoundary interleave(clock, base.nanoseconds() + 2000000);
  const auto result = run(probe);
  EXPECT_EQ(result.before, base.nanoseconds() + 3000000);
  EXPECT_EQ(result.after, base.nanoseconds() + 2000000);
  EXPECT_EQ(result.flags, 8u);
}

TEST_F(ClockProbeTest, FirstReadBelowLoopStartFailsEvenIfNextReadRecovers)
{
  auto probe = ClockAdvanceProbe::parse("5", true);
  set_time(base.nanoseconds() - 2000000);
  ClockReadBoundary interleave(clock, base.nanoseconds() + 2000000);
  const auto result = run(probe);
  EXPECT_EQ(result.before, base.nanoseconds() - 2000000);
  EXPECT_EQ(result.flags, 8u);
}
