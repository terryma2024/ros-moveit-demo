// Copyright 2026 PAL Robotics S.L.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include <gtest/gtest.h>

#include <memory>
#include <stdexcept>
#include <string>
#include <type_traits>
#include <utility>
#include <vector>

#include <mujoco_ros2_control/simulation_observer_dispatcher.hpp>
#include <mujoco_ros2_control_plugins/mujoco_ros2_control_plugin_capabilities.hpp>
#include <mujoco_ros2_control_plugins/mujoco_ros2_control_plugins_base.hpp>

namespace
{

using Base = mujoco_ros2_control_plugins::MuJoCoROS2ControlPluginBase;
using Observer = mujoco_ros2_control_plugins::MuJoCoROS2ControlSimulationObserver;

static_assert(std::is_same_v<decltype(&Base::init), bool (Base::*)(rclcpp::Node::SharedPtr, const mjModel*, mjData*)>);
static_assert(std::is_same_v<decltype(&Base::update), void (Base::*)(const mjModel*, mjData*)>);
static_assert(std::is_same_v<decltype(&Base::pre_step), void (Base::*)(mjData*)>);
static_assert(std::is_same_v<decltype(&Base::cleanup), void (Base::*)()>);

static_assert(std::is_same_v<decltype(&Observer::on_physics_step), void (Observer::*)(const mjModel*, const mjData*)>);
static_assert(std::is_same_v<decltype(&Observer::on_reset), void (Observer::*)()>);
static_assert(std::is_same_v<decltype(&Observer::on_pause), void (Observer::*)(bool)>);
static_assert(
    std::is_same_v<decltype(&Observer::on_state_snapshot), void (Observer::*)(const mjModel*, const mjData*, bool)>);

enum class ThrowOn
{
  nothing,
  physics_step,
  reset,
  pause,
  state_snapshot,
};

class RecordingPlugin : public Base, public Observer
{
public:
  RecordingPlugin(std::vector<std::string>& events, std::string name, ThrowOn throw_on = ThrowOn::nothing,
                  bool throw_unknown = false)
    : events_(events), name_(std::move(name)), throw_on_(throw_on), throw_unknown_(throw_unknown)
  {
  }

  bool init(rclcpp::Node::SharedPtr, const mjModel*, mjData*) override
  { return true; }

  void cleanup() override
  {
  }

  void on_physics_step(const mjModel* model, const mjData* data) override
  {
    last_model_ = model;
    last_data_ = data;
    record("step", ThrowOn::physics_step);
  }

  void on_reset() override
  { record("reset", ThrowOn::reset); }

  void on_pause(bool paused) override
  {
    last_paused_ = paused;
    record("pause", ThrowOn::pause);
  }

  void on_state_snapshot(const mjModel* model, const mjData* data, bool paused) override
  {
    last_model_ = model;
    last_data_ = data;
    last_paused_ = paused;
    record("snapshot", ThrowOn::state_snapshot);
  }

  const mjModel* last_model_{ nullptr };
  const mjData* last_data_{ nullptr };
  bool last_paused_{ false };

private:
  void record(const std::string& event, ThrowOn callback)
  {
    events_.push_back(name_ + ":" + event);
    if (throw_on_ != callback)
    {
      return;
    }
    if (throw_unknown_)
    {
      throw 7;
    }
    throw std::runtime_error("observer failure");
  }

  std::vector<std::string>& events_;
  std::string name_;
  ThrowOn throw_on_;
  bool throw_unknown_;
};

class OrdinaryPlugin : public Base
{
public:
  bool init(rclcpp::Node::SharedPtr, const mjModel*, mjData*) override
  { return true; }

  void cleanup() override
  {
  }
};

TEST(SimulationObserverDispatcherTest, DiscoversCapabilitiesInLoadOrderAndForwardsArguments)
{
  std::vector<std::string> events;
  auto first = std::make_shared<RecordingPlugin>(events, "first");
  auto ordinary = std::make_shared<OrdinaryPlugin>();
  auto last = std::make_shared<RecordingPlugin>(events, "last");
  mujoco_ros2_control::SimulationObserverDispatcher dispatcher(rclcpp::get_logger("observer_dispatcher_test"));
  auto* model = reinterpret_cast<const mjModel*>(0x1);
  auto* data = reinterpret_cast<const mjData*>(0x2);

  dispatcher.add(first);
  dispatcher.add(ordinary);
  dispatcher.add(last);
  dispatcher.on_physics_step(model, data);
  dispatcher.on_reset();
  dispatcher.on_pause(true);
  dispatcher.on_state_snapshot(model, data, true);

  EXPECT_EQ(events, (std::vector<std::string>{ "first:step", "last:step", "first:reset", "last:reset", "first:pause",
                                               "last:pause", "first:snapshot", "last:snapshot" }));
  EXPECT_EQ(first->last_model_, model);
  EXPECT_EQ(first->last_data_, data);
  EXPECT_TRUE(first->last_paused_);
  EXPECT_EQ(last->last_model_, model);
  EXPECT_EQ(last->last_data_, data);
  EXPECT_TRUE(last->last_paused_);
}

TEST(SimulationObserverDispatcherTest, DisablesOnlyObserverThatThrowsAndPreservesOrder)
{
  std::vector<std::string> events;
  auto first = std::make_shared<RecordingPlugin>(events, "first");
  auto ordinary = std::make_shared<OrdinaryPlugin>();
  auto throwing = std::make_shared<RecordingPlugin>(events, "throwing", ThrowOn::physics_step);
  auto last = std::make_shared<RecordingPlugin>(events, "last");
  mujoco_ros2_control::SimulationObserverDispatcher dispatcher(rclcpp::get_logger("observer_dispatcher_test"));
  const mjModel* model = nullptr;
  const mjData* data = nullptr;

  dispatcher.add(first);
  dispatcher.add(ordinary);
  dispatcher.add(throwing);
  dispatcher.add(last);
  dispatcher.on_physics_step(model, data);
  EXPECT_EQ(events, (std::vector<std::string>{ "first:step", "throwing:step", "last:step" }));

  dispatcher.on_physics_step(model, data);
  EXPECT_EQ(events, (std::vector<std::string>{ "first:step", "throwing:step", "last:step", "first:step", "last:step" }));
}

TEST(SimulationObserverDispatcherTest, ContainsUnknownExceptionsAndDisablesTheThrowingObserver)
{
  std::vector<std::string> events;
  auto throwing = std::make_shared<RecordingPlugin>(events, "throwing", ThrowOn::reset, true);
  auto last = std::make_shared<RecordingPlugin>(events, "last");
  mujoco_ros2_control::SimulationObserverDispatcher dispatcher(rclcpp::get_logger("observer_dispatcher_test"));

  dispatcher.add(throwing);
  dispatcher.add(last);
  dispatcher.on_reset();
  dispatcher.on_pause(true);

  EXPECT_EQ(events, (std::vector<std::string>{ "throwing:reset", "last:reset", "last:pause" }));
}

}  // namespace
