#include "mujoco_ros2_control/clock_trace.hpp"
#include <gtest/gtest.h>
#include <array>
#include <chrono>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <thread>
#include <vector>
#include <atomic>
#include <dlfcn.h>
#include <sys/stat.h>
#include <unistd.h>

using mujoco_ros2_control::ClockTrace;
using mujoco_ros2_control::ClockTraceKind;
namespace fs = std::filesystem;
namespace
{
std::atomic<bool> fail_directory_fsync{false};
}
// Test-only injection at the actual POSIX IO boundary; regular-file IO remains real.
extern "C" int fsync(int fd)
{
  struct stat info{};
  if (fail_directory_fsync.load() && fstat(fd, &info) == 0 && S_ISDIR(info.st_mode)) {
    errno = EIO; return -1;
  }
  static auto real_fsync = reinterpret_cast<int (*)(int)>(dlsym(RTLD_NEXT, "fsync"));
  return real_fsync(fd);
}
namespace
{
struct Scratch
{
  fs::path root;
  Scratch()
  {
    std::string name = (fs::temp_directory_path() / "clock-trace-XXXXXX").string();
    auto * path = mkdtemp(name.data());
    if (!path) {throw std::runtime_error("mkdtemp");}
    root = path;
  }
  ~Scratch() {chmod(root.c_str(), 0700);}
};
std::vector<std::array<uint64_t, 11>> read_rows(const fs::path & path)
{
  std::ifstream f(path, std::ios::binary);
  char magic[8]; f.read(magic, 8);
  if (std::string(magic, 8) != "SOCLK001") {throw std::runtime_error("magic");}
  uint64_t header_size = 0; f.read(reinterpret_cast<char *>(&header_size), 8);
  f.seekg(static_cast<std::streamoff>(header_size), std::ios::cur);
  std::vector<std::array<uint64_t, 11>> result;
  std::array<uint64_t, 11> row{};
  while (f.read(reinterpret_cast<char *>(row.data()), 88)) {result.push_back(row);}
  return result;
}
}

TEST(ClockTrace, DisabledDoesNotCreateFiles)
{
  unsetenv("SO101_CLOCK_TRACE_DIR");
  EXPECT_EQ(ClockTrace::from_environment("loop"), nullptr);
}
TEST(ClockTrace, WritesOriginalValuesAndImmutableSequence)
{
  Scratch s;
  ClockTrace trace(s.root.string(), "{\"run_id\":\"test\"}", "loop", 8);
  ASSERT_TRUE(trace.record(ClockTraceKind::Update, 23, 4, 47384000000, 2000000, 101, 102, 9, 7));
  ASSERT_TRUE(trace.finish());
  auto rows = read_rows(s.root / "loop.bin");
  ASSERT_EQ(rows.size(), 1u);
  EXPECT_EQ(rows[0], (std::array<uint64_t, 11>{{12, 0, 23, 4, 47384000000, 2000000, 101, 102, 9, 7, 1}}));
  EXPECT_TRUE(trace.finish());
  EXPECT_EQ(read_rows(s.root / "loop.bin").size(), 1u);
}
TEST(ClockTrace, OverflowIsStickyAndNeverReusesSlots)
{
  Scratch s; ClockTrace trace(s.root.string(), "{}", "physics", 2);
  ASSERT_TRUE(trace.record(ClockTraceKind::StepCommit, 1, 0, 2, 1, 3, 4));
  ASSERT_TRUE(trace.record(ClockTraceKind::StepCommit, 2, 0, 4, 1, 5, 6));
  EXPECT_FALSE(trace.record(ClockTraceKind::StepCommit, 3, 0, 6, 1, 7, 8));
  EXPECT_NE(trace.invalid_flags(), 0u);
  EXPECT_FALSE(trace.finish());
  auto rows = read_rows(s.root / "physics.bin");
  ASSERT_EQ(rows.size(), 2u); EXPECT_EQ(rows[0][2], 1u); EXPECT_EQ(rows[1][2], 2u);
}
TEST(ClockTrace, ConcurrentProducersRetainEveryCompletePayload)
{
  Scratch s; ClockTrace trace(s.root.string(), "{}", "physics", 100001);
  std::vector<std::thread> producers;
  for (uint64_t actor = 0; actor < 4; ++actor) {
    producers.emplace_back([&trace, actor]() {
      for (uint64_t id = 0; id < 25000; ++id) {
        EXPECT_TRUE(trace.record(ClockTraceKind::ResetEnd, id, actor, id * 2, id * 3, id * 4, id * 5, actor));
      }
    });
  }
  for (auto & p : producers) {p.join();}
  ASSERT_TRUE(trace.finish()); auto rows = read_rows(s.root / "physics.bin");
  ASSERT_EQ(rows.size(), 100000u);
  std::vector<bool> seen(100000, false);
  for (size_t i = 0; i < rows.size(); ++i) {
    const auto & v = rows[i]; EXPECT_EQ(v[1], i); EXPECT_EQ(v[10], 1u);
    EXPECT_EQ(v[4], v[2] * 2); EXPECT_EQ(v[5], v[2] * 3);
    EXPECT_EQ(v[6], v[2] * 4); EXPECT_EQ(v[7], v[2] * 5); EXPECT_EQ(v[3], v[8]);
    ASSERT_LT(v[8] * 25000 + v[2], seen.size());
    EXPECT_FALSE(seen[v[8] * 25000 + v[2]]); seen[v[8] * 25000 + v[2]] = true;
  }
}
TEST(ClockTrace, StatusIoFailureCannotReportSuccess)
{
  ASSERT_NE(getuid(), 0u);
  Scratch s; ClockTrace trace(s.root.string(), "{}", "loop", 8);
  chmod(s.root.c_str(), 0500);
  std::this_thread::sleep_for(std::chrono::milliseconds(300));
  EXPECT_NE(trace.invalid_flags(), 0u);
  chmod(s.root.c_str(), 0700);
  EXPECT_FALSE(trace.finish());
}
TEST(ClockTrace, MonotonicBracketIsNonzeroAndOrdered)
{
  auto before = ClockTrace::monotonic_ns(); auto after = ClockTrace::monotonic_ns();
  EXPECT_NE(before, 0u); EXPECT_GE(after, before);
  EXPECT_EQ(ClockTrace::payload_bytes * 2, 184549376u);
}

TEST(ClockTrace, LateDirectoryFsyncFailureAppearsInFinalStatus)
{
  Scratch s; ClockTrace trace(s.root.string(), "{}", "physics", 8);
  fail_directory_fsync.store(true);
  EXPECT_FALSE(trace.finish());
  fail_directory_fsync.store(false);
  std::ifstream status(s.root / "physics.status.json");
  std::string text((std::istreambuf_iterator<char>(status)), {});
  EXPECT_NE(text.find("\"invalid_flags\":2"), std::string::npos);
}
