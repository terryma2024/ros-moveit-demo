from pathlib import Path


PACKAGE = Path(__file__).resolve().parents[1]
CMAKE = PACKAGE / "CMakeLists.txt"
SOURCE = PACKAGE / "src" / "mujoco_simulation.cpp"


def test_source_less_interactive_build_has_no_reset_signal_gate() -> None:
    cmake = CMAKE.read_text(encoding="utf-8")
    source = SOURCE.read_text(encoding="utf-8")

    assert "MUJOCO_SIMULATE_RESET_SIGNAL_AVAILABLE" not in cmake
    assert "Interactive MuJoCo requires Simulate source" not in source


def test_source_built_simulate_archive_has_no_project_reset_dependency() -> None:
    cmake = CMAKE.read_text(encoding="utf-8")

    assert "src/simulate_with_reset_signal.cpp" not in cmake
    assert "src/simulate_reset_signal.cpp" not in cmake
    assert "PRIVATE ${MUJOCO_SIMULATE_DIR}/simulate.cc" in cmake
