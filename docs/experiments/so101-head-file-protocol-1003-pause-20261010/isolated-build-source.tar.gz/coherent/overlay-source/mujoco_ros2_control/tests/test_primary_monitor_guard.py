import importlib.util
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
from types import SimpleNamespace

import pytest


SOURCE = Path(__file__).resolve().parents[1] / "src" / "mujoco_simulation.cpp"
NODE_SOURCE = Path(__file__).resolve().parents[1] / "src" / "mujoco_ros2_control_node.cpp"
SYSTEM_SOURCE = Path(__file__).resolve().parents[1] / "src" / "mujoco_system_interface.cpp"
CMAKE_SOURCE = Path(__file__).resolve().parents[1] / "CMakeLists.txt"
DISPATCHER_SOURCE = Path(__file__).resolve().parents[1] / "src" / "macos_ui_dispatcher.cpp"
LAUNCH_TEST_SOURCE = (
    Path(__file__).resolve().parents[2]
    / "mujoco_ros2_control_tests"
    / "test"
    / "robot_launch_test.py"
)


def _load_launch_test_module():
    spec = importlib.util.spec_from_file_location(
        "mujoco_ros2_control_robot_launch_test", LAUNCH_TEST_SOURCE
    )
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _shutdown_output(extra_line: str) -> list[SimpleNamespace]:
    output = "\n".join(
        [
            "Shutting down all controllers in the controller manager.",
            "Successful 'shutdown' of hardware 'MujocoSystem'",
            "MUJOCO_ROS2_CONTROL_INTROSPECTION_PUBLISHERS_STOPPED",
            extra_line,
        ]
    )
    return [SimpleNamespace(text=output.encode())]


def _required_environment_path(name: str) -> Path:
    value = os.environ.get(name)
    assert value, f"registered test did not provide {name}"
    return Path(value)


def _rewrite_overlay_path(path: Path, original_root: Path, relocated_root: Path) -> Path:
    try:
        return relocated_root / path.relative_to(original_root)
    except ValueError:
        return path


def _new_artifact_directory(prefix: str) -> Path:
    artifact_root = _required_environment_path("MUJOCO_TEST_ARTIFACT_ROOT")
    artifact_root.mkdir(parents=True, exist_ok=True)
    return Path(tempfile.mkdtemp(prefix=f"{prefix}-", dir=artifact_root))


@pytest.mark.skipif(
    sys.platform != "darwin", reason="sentinel verifies the AppleClang warning policy"
)
def test_unrelated_conversion_remains_fatal_under_actual_target_options() -> None:
    options_file = _required_environment_path("MUJOCO_TEST_COMPILE_OPTIONS")
    compiler = _required_environment_path("MUJOCO_TEST_CXX_COMPILER")
    options = [line for line in options_file.read_text(encoding="utf-8").splitlines() if line]

    assert "-Werror=conversion" in options
    assert "-Wno-error=sign-conversion" not in options
    assert "-Wno-error=float-conversion" not in options

    artifact_directory = _new_artifact_directory("warning-policy")
    source = artifact_directory / "unrelated_sign_conversion.cpp"
    source.write_text(
        "#include <vector>\n"
        "int unrelated_conversion(const std::vector<int>& values, int index) {\n"
        "  return values[index];\n"
        "}\n",
        encoding="utf-8",
    )
    warning_options = [option for option in options if option.startswith("-W")]
    completed = subprocess.run(
        [
            str(compiler),
            *warning_options,
            "-c",
            str(source),
            "-o",
            str(artifact_directory / "sentinel.o"),
        ],
        capture_output=True,
        check=False,
        text=True,
    )

    assert completed.returncode != 0
    assert "sign-conversion" in completed.stderr
    assert "error:" in completed.stderr


@pytest.mark.skipif(sys.platform != "darwin", reason="LC_RPATH is a Mach-O property")
def test_installed_core_uses_only_loader_relative_rpath() -> None:
    install_prefix = _required_environment_path("MUJOCO_TEST_INSTALL_PREFIX")
    library = install_prefix / "lib" / "libmujoco_ros2_control.dylib"
    assert library.is_file()

    completed = subprocess.run(
        ["otool", "-l", str(library)], capture_output=True, check=True, text=True
    )
    rpaths = re.findall(r"cmd LC_RPATH\s+cmdsize \d+\s+path (.*?) \(offset", completed.stdout)
    assert rpaths == ["@loader_path"]


@pytest.mark.skipif(
    sys.platform != "darwin", reason="relocation smoke exercises the Mach-O loader"
)
def test_installed_core_loads_after_overlay_relocation() -> None:
    install_prefix = _required_environment_path("MUJOCO_TEST_INSTALL_PREFIX").resolve()
    original_root = (
        install_prefix.parent if install_prefix.name == "mujoco_ros2_control" else install_prefix
    )
    relocated_root = _new_artifact_directory("relocation-smoke") / "relocated-install"
    shutil.copytree(original_root, relocated_root, symlinks=False)

    relative_package_prefix = install_prefix.relative_to(original_root)
    relocated_prefix = relocated_root / relative_package_prefix
    relocated_library = relocated_prefix / "lib" / "libmujoco_ros2_control.dylib"
    assert relocated_library.is_file()

    environment = os.environ.copy()
    original_ament_prefixes = [
        Path(value)
        for value in environment.get("AMENT_PREFIX_PATH", "").split(os.pathsep)
        if value
    ]
    relocated_ament_prefixes = [
        _rewrite_overlay_path(prefix.resolve(), original_root, relocated_root)
        for prefix in original_ament_prefixes
    ]

    library_dirs = [relocated_prefix / "lib"]
    for prefix in relocated_ament_prefixes:
        library_dirs.extend((prefix / "lib", prefix / "opt" / "mujoco_vendor" / "lib"))
    for value in environment.get("DYLD_LIBRARY_PATH", "").split(os.pathsep):
        if value:
            library_dirs.append(
                _rewrite_overlay_path(Path(value).resolve(), original_root, relocated_root)
            )

    unique_library_dirs = []
    for library_dir in library_dirs:
        if library_dir.is_dir() and library_dir not in unique_library_dirs:
            unique_library_dirs.append(library_dir)

    environment["AMENT_PREFIX_PATH"] = os.pathsep.join(
        str(path) for path in relocated_ament_prefixes
    )
    environment["DYLD_LIBRARY_PATH"] = os.pathsep.join(str(path) for path in unique_library_dirs)
    environment.pop("DYLD_FALLBACK_LIBRARY_PATH", None)
    loader_environment = environment["AMENT_PREFIX_PATH"] + environment["DYLD_LIBRARY_PATH"]
    assert str(original_root) not in loader_environment

    completed = subprocess.run(
        [
            sys.executable,
            "-c",
            "import ctypes, sys; ctypes.CDLL(sys.argv[1])",
            str(relocated_library),
        ],
        capture_output=True,
        check=False,
        env=environment,
        text=True,
    )
    assert completed.returncode == 0, completed.stderr


def test_viewer_window_size_checks_monitor_and_video_mode_before_use() -> None:
    source = SOURCE.read_text(encoding="utf-8")
    start = source.index("// Set glfw window size to max size of the primary monitor")
    end = source.index("// Hide UI panels programmatically", start)
    block = source[start:end]

    assert "GLFWmonitor* primary_monitor = glfwGetPrimaryMonitor();" in block
    assert "if (primary_monitor != nullptr)" in block
    assert "const GLFWvidmode* mode = glfwGetVideoMode(primary_monitor);" in block
    assert "if (mode != nullptr)" in block
    assert "glfwGetVideoMode(glfwGetPrimaryMonitor())" not in block
    assert "GLFW primary monitor is unavailable; retaining the default viewer size" in block
    assert "GLFW primary video mode is unavailable; retaining the default viewer size" in block


def test_macos_viewer_does_not_resize_a_cocoa_window_from_its_startup_callback() -> None:
    source = SOURCE.read_text(encoding="utf-8")
    start = source.index("// Set glfw window size to max size of the primary monitor")
    end = source.index("// Hide UI panels programmatically", start)
    block = source[start:end]

    guard_start = block.index("#ifndef __APPLE__")
    resize = block.index("glfwSetWindowSize")
    guard_end = block.index("#endif  // __APPLE__")

    assert guard_start < resize < guard_end
    assert block.count("glfwSetWindowSize") == 1


def test_macos_viewer_and_camera_windows_are_dispatched_to_the_process_main_thread() -> None:
    source = SOURCE.read_text(encoding="utf-8")
    node = NODE_SOURCE.read_text(encoding="utf-8")

    assert "submit_macos_ui_task(" in source
    assert 'glfwCreateWindow(1, 1, "mujoco_ros2_control_camera"' in source
    assert "ui_thread_ = std::thread(std::move(run_ui));" in source
    assert "run_macos_ui_task_on_main_thread()" in node
    assert "std::thread executor_thread" in node


def test_macos_cleanup_waits_for_runtime_users_then_preserves_resource_order() -> None:
    source = SOURCE.read_text(encoding="utf-8")
    node = NODE_SOURCE.read_text(encoding="utf-8")
    system = SYSTEM_SOURCE.read_text(encoding="utf-8")

    render_loop = source.index("sim_->RenderLoop();")
    stop_renderers = source.index("stop_rendering_plugins();", render_loop)
    cleanup_function = source.index("auto cleanup_ui = [this]()")
    destroy_context = source.index("glfwDestroyWindow(macos_camera_window_)", cleanup_function)
    destroy_viewer = source.index("sim_.reset();", destroy_context)
    terminate_glfw = source.index("glfwTerminate();", destroy_viewer)

    assert render_loop < stop_renderers < cleanup_function
    assert destroy_context < destroy_viewer < terminate_glfw

    shutdown_ros = node.index("rclcpp::shutdown();", node.index("const bool ran_ui"))
    join_control = node.index("cm_thread.join();", shutdown_ros)
    cleanup_on_main = node.index("run_macos_ui_cleanup_on_main_thread();", join_control)
    join_executor = node.index("executor_thread.join();", cleanup_on_main)
    assert shutdown_ros < join_control < cleanup_on_main < join_executor

    assert "auto runtime_use = simulation_->acquire_runtime_use();" in system
    assert "close_runtime_uses();" in source
    assert "external_initialization_complete_" in source


def test_control_loop_exits_if_shutdown_precedes_the_first_sim_clock_tick() -> None:
    node = NODE_SOURCE.read_text(encoding="utf-8")
    start = node.index("if (!cm->get_clock()->wait_until_started")
    end = node.index("// for calculating sleep time", start)
    block = node[start:end]

    assert "if (!cm->get_clock()->wait_until_started() || !rclcpp::ok())" in block
    assert "if (!cm->get_clock()->sleep_for" in block
    assert "catch (const std::runtime_error & e)" in block
    assert "return;" in block
    wait = node.index("cm->get_clock()->wait_until_started")
    initial_try = node.rindex("try", 0, wait)
    initial_catch = node.index("catch (const std::runtime_error & e)", wait)
    assert initial_try < wait < initial_catch


def test_controller_introspection_stops_after_resource_shutdown_and_before_context() -> None:
    node = NODE_SOURCE.read_text(encoding="utf-8")

    controller_manager = node.index(
        "auto cm = std::make_shared<controller_manager::ControllerManager>"
    )
    callback = node.index("add_pre_shutdown_callback", controller_manager)
    idempotence = node.index("exchange(true)", callback)
    default_registry = node.index(
        "pal_statistics::getRegistry(hardware_interface::DEFAULT_REGISTRY_KEY)", idempotence
    )
    stop_default = node.index("default_registry->stopPublisherThread();", default_registry)
    cm_statistics_registry = node.index(
        "pal_statistics::getRegistry(hardware_interface::CM_STATISTICS_KEY)", stop_default
    )
    stop_cm_statistics = node.index(
        "cm_statistics_registry->stopPublisherThread();", cm_statistics_registry
    )
    marker = node.index(
        "MUJOCO_ROS2_CONTROL_INTROSPECTION_PUBLISHERS_STOPPED", stop_cm_statistics
    )
    final_context_shutdown = node.rindex("rclcpp::shutdown();")
    callback_block = node[callback:marker]

    assert controller_manager < callback < idempotence < default_registry
    assert default_registry < stop_default < cm_statistics_registry < stop_cm_statistics
    assert stop_cm_statistics < marker < final_context_shutdown
    assert "CLEAR_ALL_ROS2_CONTROL_INTROSPECTION_REGISTRIES" not in callback_block


def test_controller_executor_contains_disconnected_service_response_errors() -> None:
    node = NODE_SOURCE.read_text(encoding="utf-8")

    helper = node[node.index("void spin_controller_executor") : node.index("int main(")]
    assert "while (rclcpp::ok())" in helper
    assert "executor->spin();" in helper
    assert "catch (const rclcpp::exceptions::RCLError & error)" in helper
    assert "failed to send response: cannot publish data" in helper
    assert "MUJOCO_ROS2_CONTROL_DROPPED_SERVICE_RESPONSE" in helper
    assert "throw;" in helper

    linux_spin = node[node.index("#else", node.index("int main(")) :]
    assert "spin_controller_executor(executor, cm->get_logger());" in linux_spin


def test_clean_shutdown_allows_runtime_publish_lock_contention() -> None:
    launch_test = _load_launch_test_module()
    test_case = launch_test.TestCleanShutdown()

    test_case.test_controller_introspection_publishers_stop_before_context_invalidation(
        _shutdown_output("publish_async_failures_ 1")
    )


@pytest.mark.parametrize(
    "pal_error",
    [
        "Exception in publisher thread: unrelated PAL failure.",
        "context cannot be slept with because it's invalid",
    ],
)
def test_clean_shutdown_rejects_pal_publisher_context_errors(pal_error: str) -> None:
    launch_test = _load_launch_test_module()
    test_case = launch_test.TestCleanShutdown()

    with pytest.raises(AssertionError):
        test_case.test_controller_introspection_publishers_stop_before_context_invalidation(
            _shutdown_output(pal_error)
        )


def test_controller_manager_destruction_clears_registries_only_after_worker_joins() -> None:
    node = NODE_SOURCE.read_text(encoding="utf-8")

    last_control_join = node.rindex("cm_thread.join();")
    executor_join = node.index("executor_thread.join();")
    destroy_controller_manager = node.index("cm.reset();", max(last_control_join, executor_join))
    final_context_shutdown = node.rindex("rclcpp::shutdown();")

    assert last_control_join < destroy_controller_manager
    assert executor_join < destroy_controller_manager
    assert destroy_controller_manager < final_context_shutdown


def test_macos_node_does_not_preload_the_hardware_plugin_dso() -> None:
    cmake = CMAKE_SOURCE.read_text(encoding="utf-8")
    node_target = cmake[cmake.index("add_executable(ros2_control_node") :]
    node_links = node_target[: node_target.index("install(\n  TARGETS ros2_control_node")]

    assert "add_library(mujoco_ros2_control_macos_ui_dispatcher SHARED" in cmake
    assert "target_link_libraries(mujoco_ros2_control PRIVATE\n    mujoco_ros2_control_macos_ui_dispatcher" in cmake
    assert "mujoco_ros2_control_macos_ui_dispatcher" in node_links
    assert "PUBLIC mujoco_ros2_control)" not in node_links
    assert DISPATCHER_SOURCE.is_file()
