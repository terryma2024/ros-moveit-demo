from pathlib import Path


REPOSITORY = Path(__file__).resolve().parents[2]
CAPABILITIES = (
    REPOSITORY
    / "mujoco_ros2_control_plugins"
    / "include"
    / "mujoco_ros2_control_plugins"
    / "mujoco_ros2_control_plugin_capabilities.hpp"
)
CAMERA_HEADER = REPOSITORY / "mujoco_ros2_control_plugins" / "src" / "camera_plugin.hpp"
CAMERA_SOURCE = REPOSITORY / "mujoco_ros2_control_plugins" / "src" / "camera_plugin.cpp"
SIMULATION_SOURCE = REPOSITORY / "mujoco_ros2_control" / "src" / "mujoco_simulation.cpp"
PRODUCTION_SOURCES = (
    REPOSITORY / "mujoco_ros2_control" / "include",
    REPOSITORY / "mujoco_ros2_control" / "src",
    REPOSITORY / "mujoco_ros2_control_plugins" / "include",
    REPOSITORY / "mujoco_ros2_control_plugins" / "src",
)


def test_rendering_capability_uses_platform_neutral_context_contract() -> None:
    """Reject an Apple-specific ABI name while retaining the opaque context handoff."""
    expected_declaration = "virtual void set_platform_render_context(void* context) = 0;"
    expected_camera_override = "void set_platform_render_context(void* context) override;"

    assert expected_declaration in CAPABILITIES.read_text(encoding="utf-8")
    assert expected_camera_override in CAMERA_HEADER.read_text(encoding="utf-8")
    assert "void CameraPlugin::set_platform_render_context(void* context)" in CAMERA_SOURCE.read_text(
        encoding="utf-8"
    )

    simulation = SIMULATION_SOURCE.read_text(encoding="utf-8")
    assert "renderer->set_platform_render_context(macos_camera_window_);" in simulation
    assert "renderer->set_platform_render_context(nullptr);" in simulation

    production_text = "\n".join(
        path.read_text(encoding="utf-8")
        for root in PRODUCTION_SOURCES
        for path in root.rglob("*")
        if path.suffix in {".cpp", ".hpp", ".h", ".mm"}
    )
    assert "set_macos_render_context" not in production_text
