/**
 * Copyright (c) 2026, United States Government, as represented by the
 * Administrator of the National Aeronautics and Space Administration.
 *
 * All rights reserved.
 *
 * This software is licensed under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with the
 * License. You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations
 * under the License.
 */

#include <gtest/gtest.h>

#include <chrono>
#include <cmath>
#include <condition_variable>
#include <filesystem>
#include <fstream>
#include <future>
#include <limits>
#include <mutex>
#include <thread>
#include <utility>
#include <vector>

#include <mujoco/mujoco.h>
#include <rclcpp/rclcpp.hpp>

#include <mujoco_ros2_control/mujoco_simulation.hpp>
#include <mujoco_ros2_control_msgs/msg/free_joint_state.hpp>
#include <mujoco_ros2_control_msgs/srv/reset_world.hpp>
#include <mujoco_ros2_control_msgs/srv/get_viewer_camera.hpp>
#include <mujoco_ros2_control_msgs/srv/set_free_joint_state.hpp>
#include <mujoco_ros2_control_msgs/srv/set_pause.hpp>
#include <mujoco_ros2_control_msgs/srv/set_viewer_camera.hpp>
#include <mujoco_ros2_control_msgs/srv/step_simulation.hpp>
#include <mujoco_ros2_control_plugins/mujoco_ros2_control_plugin_capabilities.hpp>
#include <mujoco_ros2_control_plugins/mujoco_ros2_control_plugins_base.hpp>

namespace
{

// Basic model for executing unit tests: a hinge joint with an actuator, plus two free-floating
// bodies ("free_object", "free_object_2") for exercising the free-joint state service.
//    nu=1, nq=15 (1 hinge + 7 + 7 free joint), nv=13 (1 hinge + 6 + 6 free joint), nbody=4
//    (world + pendulum + free_object + free_object_2)
constexpr const char* kTestModel = R"(<?xml version="1.0"?>
<mujoco model="test_simulation">
  <option timestep="0.002"/>

  <worldbody>
    <body name="pendulum" pos="0 0 1">
      <joint name="hinge" type="hinge" axis="0 1 0"/>
      <geom type="capsule" size="0.02" fromto="0 0 0 0.3 0 0" mass="1"/>
    </body>
    <body name="free_object" pos="1 0 1">
      <freejoint name="free_object_joint"/>
      <geom type="box" size="0.05 0.05 0.05" mass="1"/>
    </body>
    <body name="free_object_2" pos="2 0 1">
      <freejoint name="free_object_2_joint"/>
      <geom type="box" size="0.05 0.05 0.05" mass="1"/>
    </body>
  </worldbody>

  <equality>
    <weld name="test_weld" body1="free_object" body2="free_object_2" active="false"/>
  </equality>

  <actuator>
    <position name="hinge_pos" joint="hinge" kp="10"/>
  </actuator>

  <keyframe>
    <key name="home" qpos="0.5 1 0 1 1 0 0 0 2 0 1 1 0 0 0"/>
  </keyframe>
</mujoco>
)";

// Write to disk for testing
const std::string kTestModelPath = "/tmp/test_mujoco_simulation_model.xml";
void write_test_model()
{
  std::ofstream file(kTestModelPath);
  file << kTestModel;
  file.close();
}

constexpr double TEST_TOLERANCE = 1e-9;

class EventCollector
{
public:
  void add(std::string event)
  {
    const std::lock_guard<std::mutex> lock(mutex_);
    events_.push_back(std::move(event));
  }

  void clear()
  {
    const std::lock_guard<std::mutex> lock(mutex_);
    events_.clear();
  }

  std::vector<std::string> copy() const
  {
    const std::lock_guard<std::mutex> lock(mutex_);
    return events_;
  }

private:
  mutable std::mutex mutex_;
  std::vector<std::string> events_;
};

class RecordingObserverPlugin
  : public mujoco_ros2_control_plugins::MuJoCoROS2ControlPluginBase,
    public mujoco_ros2_control_plugins::MuJoCoROS2ControlSimulationObserver
{
public:
  explicit RecordingObserverPlugin(EventCollector& events) : events_(events)
  {
  }

  bool init(rclcpp::Node::SharedPtr, const mjModel*, mjData*) override
  {
    return true;
  }

  void cleanup() override
  {
  }

  void on_physics_step(const mjModel*, const mjData*) override
  {
    events_.add("observer_post_step");
  }

  void on_reset() override
  {
    events_.add("reset");
  }

  void on_pause(bool paused) override
  {
    events_.add(paused ? "pause:true" : "pause:false");
  }

  void on_state_snapshot(const mjModel*, const mjData* data, bool paused) override
  {
    snapshot_qpos_ = data->qpos[0];
    snapshot_paused_ = paused;
    events_.add("state_snapshot");
  }

  double snapshot_qpos() const
  {
    return snapshot_qpos_;
  }

  bool snapshot_paused() const
  {
    return snapshot_paused_;
  }

private:
  EventCollector& events_;
  double snapshot_qpos_{ 0.0 };
  bool snapshot_paused_{ false };
};

class SimulationShutdownGuard
{
public:
  explicit SimulationShutdownGuard(mujoco_ros2_control::MujocoSimulation& simulation)
    : simulation_(simulation)
  {
  }

  ~SimulationShutdownGuard()
  {
    simulation_.shutdown();
  }

  SimulationShutdownGuard(const SimulationShutdownGuard&) = delete;
  SimulationShutdownGuard& operator=(const SimulationShutdownGuard&) = delete;

private:
  mujoco_ros2_control::MujocoSimulation& simulation_;
};

class RecordingRenderingPlugin
  : public mujoco_ros2_control_plugins::MuJoCoROS2ControlPluginBase,
    public mujoco_ros2_control_plugins::MuJoCoROS2ControlRenderingPlugin
{
public:
  explicit RecordingRenderingPlugin(EventCollector& events) : events_(events)
  {
  }

  bool init(rclcpp::Node::SharedPtr, const mjModel*, mjData*) override
  {
    return true;
  }

  void cleanup() override
  {
  }

  void set_platform_render_context(void*) override
  {
  }

  void set_rendering_enabled(bool enabled) override
  {
    events_.add(enabled ? "enable_rendering" : "disable_rendering");
  }

  void close_rendering() override
  {
    events_.add("close_rendering");
  }

private:
  EventCollector& events_;
};

class BlockingRenderingPlugin : public RecordingRenderingPlugin
{
public:
  BlockingRenderingPlugin(
      EventCollector& events, std::promise<void>& close_entered, std::shared_future<void> release_close)
    : RecordingRenderingPlugin(events), close_entered_(close_entered), release_close_(std::move(release_close)),
      events_(events)
  {
  }

  void close_rendering() override
  {
    close_entered_.set_value();
    release_close_.wait();
    events_.add("close_rendering");
  }

private:
  std::promise<void>& close_entered_;
  std::shared_future<void> release_close_;
  EventCollector& events_;
};
}  // namespace

class MujocoSimulationTest : public ::testing::Test
{
protected:
  struct ViewerSyncObservation
  {
    bool reset_pending_after_poll{ false };
    bool history_pending_after_poll{ false };
    bool key_pending_after_poll{ false };
    bool zero_ctrl_pending_after_poll{ false };
    double data_time{ 0.0 };
    double data_qpos{ 0.0 };
    double data_ctrl{ 0.0 };
    int data_eq_active{ 0 };
    double viewer_qpos{ 0.0 };
    double viewer_qpos_prev{ 0.0 };
    double viewer_ctrl{ 0.0 };
    double viewer_ctrl_prev{ 0.0 };
    int viewer_eq_active{ 0 };
    int viewer_eq_active_prev{ 0 };
    double followup_data_time{ 0.0 };
    double followup_data_qpos{ 0.0 };
    double followup_data_ctrl{ 0.0 };
    int followup_data_eq_active{ 0 };
  };

  static void SetUpTestSuite()
  {
    if (!rclcpp::ok())
    {
      rclcpp::init(0, nullptr);
    }
  }

  static void TearDownTestSuite()
  {
    if (rclcpp::ok())
    {
      rclcpp::shutdown();
    }
  }

  void SetUp() override
  {
    write_test_model();
    const auto* test_info = ::testing::UnitTest::GetInstance()->current_test_info();
    const std::string node_name = std::string("test_sim_") + test_info->name();
    node_ = std::make_shared<rclcpp::Node>(node_name);
    executor_ = std::make_unique<rclcpp::executors::MultiThreadedExecutor>();
    executor_->add_node(node_);
    spin_thread_ = std::thread([this]() { executor_->spin(); });

    sim_ = std::make_unique<mujoco_ros2_control::MujocoSimulation>();
  }

  void TearDown() override
  {
    // Clean up the executor to kill callbacks
    if (executor_)
    {
      executor_->cancel();
    }
    if (spin_thread_.joinable())
    {
      spin_thread_.join();
    }
    // Then tear down the sim
    if (sim_)
    {
      sim_->shutdown();
      if (sync_scene_initialized_)
      {
        mjv_freeScene(&sim_->sim_->scn);
        sync_scene_initialized_ = false;
      }
      sim_.reset();
    }
    node_.reset();
    executor_.reset();

    // Clean up test files if present
    if (std::filesystem::exists(kTestModelPath))
    {
      std::filesystem::remove(kTestModelPath);
    }
  }

  // initialize the simulation in headless mode with default settings.
  bool initialize_sim()
  {
    return sim_->initialize(node_, kTestModelPath, "/mujoco_robot_description", -1.0, true, true);
  }

  void publish_original_time_for_testing(double physics_time)
  {
    const std::unique_lock<std::recursive_mutex> lock(sim_->mutex());
    sim_->data()->time = physics_time;
    sim_->publish_clock();
  }

  std::shared_ptr<mujoco_ros2_control_msgs::srv::SetPause::Response> request_pause(bool paused)
  {
    const std::string ns = std::string(node_->get_fully_qualified_name());
    auto client = node_->create_client<mujoco_ros2_control_msgs::srv::SetPause>(ns + "/set_pause");
    if (!client->wait_for_service(std::chrono::seconds(5)))
    {
      return nullptr;
    }
    auto request = std::make_shared<mujoco_ros2_control_msgs::srv::SetPause::Request>();
    request->paused = paused;
    auto future = client->async_send_request(request);
    if (future.wait_for(std::chrono::seconds(5)) != std::future_status::ready)
    {
      return nullptr;
    }
    return future.get();
  }

  bool set_paused(bool paused)
  {
    const auto response = request_pause(paused);
    return response && response->success;
  }

  void expose_viewer_for_testing()
  {
    const std::unique_lock<std::recursive_mutex> lock(sim_->mutex());
    sim_->viewer_available_for_testing_ = true;
    sim_->sim_->camera = 0;
  }

  bool is_paused()
  {
    const std::unique_lock<std::recursive_mutex> lock(sim_->mutex());
    return !sim_->sim_->run;
  }

  void set_transition_callback(std::function<void(const char*)> callback)
  {
    sim_->set_transition_callback_for_testing(std::move(callback));
  }

  void set_rendering_transition_callback(std::function<void(const char*)> callback)
  {
    sim_->set_rendering_transition_callback_for_testing(std::move(callback));
  }

  void stop_rendering_plugins()
  {
    sim_->stop_rendering_plugins();
  }

  void close_runtime_uses()
  {
    sim_->close_runtime_uses();
  }

  uint32_t pending_steps() const
  {
    return sim_->pending_steps_.load();
  }

  void force_paused()
  {
    const std::unique_lock<std::recursive_mutex> lock(sim_->mutex());
    sim_->sim_->run = false;
  }

  void request_physics_exit()
  {
    sim_->sim_->exitrequest.store(true);
  }

  bool prepare_actual_viewer_sync()
  {
    const std::unique_lock<std::recursive_mutex> lock(sim_->mutex());
    if (sim_->sim_->m_ != sim_->model() || sim_->sim_->d_ != sim_->data())
    {
      return false;
    }

    auto& viewer = *sim_->sim_;
    viewer.jnt_range_.clear();
    viewer.jnt_range_.reserve(static_cast<std::size_t>(sim_->model()->njnt));
    for (int i = 0; i < sim_->model()->njnt; ++i)
    {
      if (sim_->model()->jnt_limited[i])
      {
        viewer.jnt_range_.emplace_back(
          std::make_pair(sim_->model()->jnt_range[2 * i], sim_->model()->jnt_range[2 * i + 1]));
      }
      else
      {
        viewer.jnt_range_.emplace_back(std::nullopt);
      }
    }

    viewer.actuator_ctrlrange_.clear();
    viewer.actuator_ctrlrange_.reserve(static_cast<std::size_t>(sim_->model()->nu));
    for (int i = 0; i < sim_->model()->nu; ++i)
    {
      if (sim_->model()->actuator_ctrllimited[i])
      {
        viewer.actuator_ctrlrange_.emplace_back(
          std::make_pair(sim_->model()->actuator_ctrlrange[2 * i], sim_->model()->actuator_ctrlrange[2 * i + 1]));
      }
      else
      {
        viewer.actuator_ctrlrange_.emplace_back(std::nullopt);
      }
    }

    viewer.qpos_.assign(sim_->data()->qpos, sim_->data()->qpos + sim_->model()->nq);
    viewer.qpos_prev_ = viewer.qpos_;
    viewer.ctrl_.assign(sim_->data()->ctrl, sim_->data()->ctrl + sim_->model()->nu);
    viewer.ctrl_prev_ = viewer.ctrl_;
    viewer.eq_active_.assign(sim_->data()->eq_active, sim_->data()->eq_active + sim_->model()->neq);
    viewer.eq_active_prev_ = viewer.eq_active_;

    viewer.state_size_ = mj_stateSize(sim_->model(), mjSTATE_INTEGRATION);
    viewer.nhistory_ = 2;
    viewer.history_cursor_ = 1;
    viewer.scrub_index = 0;
    viewer.history_.resize(static_cast<std::size_t>(viewer.nhistory_ * viewer.state_size_));
    mj_getState(sim_->model(), sim_->data(), viewer.history_.data(), mjSTATE_INTEGRATION);
    mju_copy(viewer.history_.data() + viewer.state_size_, viewer.history_.data(), viewer.state_size_);

    mjv_makeScene(sim_->model(), &viewer.scn, 1000);
    sync_scene_initialized_ = true;
    return true;
  }

  void store_history_state(double time, double qpos, double ctrl, int eq_active, int scrub_index = -1)
  {
    const std::unique_lock<std::recursive_mutex> lock(sim_->mutex());
    mjData* history_data = mj_copyData(nullptr, sim_->model(), sim_->data());
    history_data->time = time;
    history_data->qpos[0] = qpos;
    history_data->ctrl[0] = ctrl;
    history_data->eq_active[0] = static_cast<mjtByte>(eq_active);
    mj_forward(sim_->model(), history_data);

    auto& viewer = *sim_->sim_;
    viewer.history_cursor_ = 1;
    viewer.scrub_index = scrub_index;
    int history_index = (viewer.scrub_index + viewer.history_cursor_) % viewer.nhistory_;
    history_index = (history_index + viewer.nhistory_) % viewer.nhistory_;
    mj_getState(
      sim_->model(), history_data, viewer.history_.data() + history_index * viewer.state_size_,
      mjSTATE_INTEGRATION);
    mj_deleteData(history_data);
  }

  void select_viewer_keyframe(int key)
  {
    const std::unique_lock<std::recursive_mutex> lock(sim_->mutex());
    sim_->sim_->key = key;
  }

  ViewerSyncObservation process_actual_ui_reset()
  {
    const std::unique_lock<std::recursive_mutex> lock(sim_->mutex());
    auto& viewer = *sim_->sim_;
    viewer.pending_.reset = true;
    viewer.platform_ui->PollEvents();

    ViewerSyncObservation observation;
    observation.reset_pending_after_poll = viewer.pending_.reset;
    observation.data_qpos = sim_->data()->qpos[0];
    observation.data_ctrl = sim_->data()->ctrl[0];
    observation.data_eq_active = sim_->data()->eq_active[0];
    observation.viewer_qpos = viewer.qpos_[0];
    observation.viewer_qpos_prev = viewer.qpos_prev_[0];
    observation.viewer_ctrl = viewer.ctrl_[0];
    observation.viewer_ctrl_prev = viewer.ctrl_prev_[0];
    observation.viewer_eq_active = viewer.eq_active_[0];
    observation.viewer_eq_active_prev = viewer.eq_active_prev_[0];

    // This is the outer Sync that RenderLoop calls immediately after PollEvents.
    // The adapter must already have consumed reset and aligned the edit buffers.
    viewer.Sync();
    observation.followup_data_qpos = sim_->data()->qpos[0];
    observation.followup_data_ctrl = sim_->data()->ctrl[0];
    observation.followup_data_eq_active = sim_->data()->eq_active[0];
    return observation;
  }

  ViewerSyncObservation process_actual_history_scrub()
  {
    const std::unique_lock<std::recursive_mutex> lock(sim_->mutex());
    auto& viewer = *sim_->sim_;
    viewer.pending_.load_from_history = true;
    viewer.platform_ui->PollEvents();

    ViewerSyncObservation observation;
    observation.history_pending_after_poll = viewer.pending_.load_from_history;
    viewer.Sync();

    observation.data_qpos = sim_->data()->qpos[0];
    observation.data_ctrl = sim_->data()->ctrl[0];
    observation.data_eq_active = sim_->data()->eq_active[0];

    viewer.Sync();
    observation.followup_data_qpos = sim_->data()->qpos[0];
    observation.followup_data_ctrl = sim_->data()->ctrl[0];
    observation.followup_data_eq_active = sim_->data()->eq_active[0];
    return observation;
  }

  ViewerSyncObservation process_actual_ui_reset_with_later_operation(
    bool load_from_history, bool load_key, bool zero_ctrl)
  {
    const std::unique_lock<std::recursive_mutex> lock(sim_->mutex());
    auto& viewer = *sim_->sim_;
    viewer.pending_.reset = true;
    viewer.pending_.load_from_history = load_from_history;
    viewer.pending_.load_key = load_key;
    viewer.pending_.zero_ctrl = zero_ctrl;
    viewer.platform_ui->PollEvents();

    ViewerSyncObservation observation;
    observation.reset_pending_after_poll = viewer.pending_.reset;
    observation.history_pending_after_poll = viewer.pending_.load_from_history;
    observation.key_pending_after_poll = viewer.pending_.load_key;
    observation.zero_ctrl_pending_after_poll = viewer.pending_.zero_ctrl;
    observation.data_time = sim_->data()->time;
    observation.data_qpos = sim_->data()->qpos[0];
    observation.data_ctrl = sim_->data()->ctrl[0];
    observation.data_eq_active = sim_->data()->eq_active[0];

    // RenderLoop invokes this outer Sync immediately after PollEvents. The
    // winning later transaction must survive it and the subsequent physics
    // mutex handoff.
    viewer.Sync();
    observation.followup_data_time = sim_->data()->time;
    observation.followup_data_qpos = sim_->data()->qpos[0];
    observation.followup_data_ctrl = sim_->data()->ctrl[0];
    observation.followup_data_eq_active = sim_->data()->eq_active[0];
    return observation;
  }

  void latch_divergence_for_viewer_transaction()
  {
    {
      const std::unique_lock<std::recursive_mutex> lock(sim_->mutex());
      sim_->model()->opt.disableflags |= mjDSBL_AUTORESET;
    }
    divergence_pre_step_calls_.store(0);
    sim_->set_pre_step_callback([this](mjData* data) {
      if (divergence_pre_step_calls_.fetch_add(1) == 0)
      {
        data->warning[mjWARN_BADQPOS].lastinfo = 0;
        data->warning[mjWARN_BADQPOS].number = 1;
      }
    });

    const std::string ns = std::string(node_->get_fully_qualified_name());
    auto client = node_->create_client<mujoco_ros2_control_msgs::srv::StepSimulation>(ns + "/step_simulation");
    ASSERT_TRUE(client->wait_for_service(std::chrono::seconds(5)));
    auto request = std::make_shared<mujoco_ros2_control_msgs::srv::StepSimulation::Request>();
    request->steps = 1;
    auto future = client->async_send_request(request);
    ASSERT_EQ(future.wait_for(std::chrono::seconds(5)), std::future_status::ready);
    ASSERT_FALSE(future.get()->success);
    ASSERT_EQ(divergence_pre_step_calls_.load(), 1u);
    ASSERT_TRUE(is_paused());
  }

  // Helper function to poll a condition until it returns true or the timeout expires.
  bool wait_until(std::function<bool()> condition, std::chrono::milliseconds timeout = std::chrono::seconds(5),
                  std::chrono::milliseconds poll_interval = std::chrono::milliseconds(10))
  {
    const auto deadline = std::chrono::steady_clock::now() + timeout;
    while (std::chrono::steady_clock::now() < deadline)
    {
      if (condition())
        return true;
      std::this_thread::sleep_for(poll_interval);
    }
    return condition();
  }

  // Helper function to confirm physics loop has stopped by verifying the time has "settled".
  // Verifies that the sim is continuing to step, but the time remains constant for 10 iterations.
  bool wait_for_pause()
  {
    uint64_t prev = sim_->step_count();
    int settled_count = 0;
    return wait_until([&]() {
      uint64_t now = sim_->step_count();
      if (now == prev)
      {
        settled_count++;
      }
      else
      {
        settled_count = 0;
      }
      prev = now;
      return settled_count >= 10;
    });
  };

  rclcpp::Node::SharedPtr node_;
  std::unique_ptr<rclcpp::executors::MultiThreadedExecutor> executor_;
  std::thread spin_thread_;
  std::unique_ptr<mujoco_ros2_control::MujocoSimulation> sim_;
  std::atomic<uint64_t> divergence_pre_step_calls_{ 0 };
  bool sync_scene_initialized_{ false };
};

#ifdef __APPLE__
TEST(MacosUiDispatcherTest, CancelledPendingTaskCannotOutliveItsOwner)
{
  int task_calls = 0;
  int cleanup_calls = 0;
  const auto task_id = mujoco_ros2_control::submit_macos_ui_task(
      [&task_calls]() { ++task_calls; }, []() {}, [&cleanup_calls]() { ++cleanup_calls; });

  EXPECT_TRUE(mujoco_ros2_control::cancel_macos_ui_task(task_id));
  EXPECT_FALSE(mujoco_ros2_control::run_macos_ui_task_on_main_thread());
  EXPECT_FALSE(mujoco_ros2_control::run_macos_ui_cleanup_on_main_thread());
  EXPECT_EQ(task_calls, 0);
  EXPECT_EQ(cleanup_calls, 0);
}

TEST(MacosUiDispatcherTest, CleanupIsASeparateMainThreadPhase)
{
  std::vector<std::string> events;
  mujoco_ros2_control::submit_macos_ui_task(
      [&events]() { events.push_back("render_loop_finished"); }, []() {},
      [&events]() { events.push_back("resources_destroyed"); });

  ASSERT_TRUE(mujoco_ros2_control::run_macos_ui_task_on_main_thread());
  EXPECT_EQ(events, (std::vector<std::string>{ "render_loop_finished" }));
  ASSERT_TRUE(mujoco_ros2_control::run_macos_ui_cleanup_on_main_thread());
  EXPECT_EQ(events, (std::vector<std::string>{ "render_loop_finished", "resources_destroyed" }));
}

TEST(MacosUiDispatcherTest, RunningTaskCancellationCleansBeforeOwnerCanUnwind)
{
  std::promise<void> task_entered;
  auto task_entered_future = task_entered.get_future();
  std::promise<void> release_task;
  auto release_task_future = release_task.get_future().share();
  int cleanup_calls = 0;
  const auto task_id = mujoco_ros2_control::submit_macos_ui_task(
      [&task_entered, release_task_future]() {
        task_entered.set_value();
        release_task_future.wait();
      },
      [&release_task]() { release_task.set_value(); },
      [&cleanup_calls]() { ++cleanup_calls; });

  std::thread dispatcher([]() {
    EXPECT_TRUE(mujoco_ros2_control::run_macos_ui_task_on_main_thread());
  });
  ASSERT_EQ(task_entered_future.wait_for(std::chrono::seconds(5)), std::future_status::ready);
  EXPECT_TRUE(mujoco_ros2_control::cancel_macos_ui_task(task_id));
  dispatcher.join();

  EXPECT_EQ(cleanup_calls, 1);
  EXPECT_FALSE(mujoco_ros2_control::run_macos_ui_cleanup_on_main_thread());
}
#endif

TEST_F(MujocoSimulationTest, TestInitialization)
{
  ASSERT_TRUE(initialize_sim());
  EXPECT_NE(sim_->model(), nullptr);
  EXPECT_NE(sim_->data(), nullptr);

  // nq/nv account for the "hinge" joint (1 each) plus the "free_object" and "free_object_2"
  // free joints (7 qpos each: xyz + wxyz quat; 6 qvel each: linear + angular).
  EXPECT_EQ(sim_->model()->nq, 15);
  EXPECT_EQ(sim_->model()->nv, 13);
  EXPECT_EQ(sim_->model()->nu, 1);
  EXPECT_EQ(sim_->model()->nbody, 4);
}

TEST_F(MujocoSimulationTest, ViewerCameraServicesRejectHeadlessAndRoundTripAtomically)
{
  ASSERT_TRUE(initialize_sim());

  const std::string ns = std::string(node_->get_fully_qualified_name());
  auto set_client =
    node_->create_client<mujoco_ros2_control_msgs::srv::SetViewerCamera>(ns + "/set_viewer_camera");
  auto get_client =
    node_->create_client<mujoco_ros2_control_msgs::srv::GetViewerCamera>(ns + "/get_viewer_camera");
  ASSERT_TRUE(set_client->wait_for_service(std::chrono::seconds(5)));
  ASSERT_TRUE(get_client->wait_for_service(std::chrono::seconds(5)));

  auto set_request = std::make_shared<mujoco_ros2_control_msgs::srv::SetViewerCamera::Request>();
  set_request->camera.mode = mujoco_ros2_control_msgs::msg::ViewerCamera::FREE;
  set_request->camera.lookat = {{ 0.4, -0.2, 0.7 }};
  set_request->camera.distance = 1.25;
  set_request->camera.azimuth_deg = 225.0;
  set_request->camera.elevation_deg = -20.0;
  set_request->camera.orthographic = true;

  auto set_future = set_client->async_send_request(set_request);
  ASSERT_EQ(set_future.wait_for(std::chrono::seconds(5)), std::future_status::ready);
  auto set_response = set_future.get();
  EXPECT_FALSE(set_response->success);
  EXPECT_EQ(set_response->message, "viewer unavailable");

  auto get_request = std::make_shared<mujoco_ros2_control_msgs::srv::GetViewerCamera::Request>();
  auto get_future = get_client->async_send_request(get_request);
  ASSERT_EQ(get_future.wait_for(std::chrono::seconds(5)), std::future_status::ready);
  auto get_response = get_future.get();
  EXPECT_FALSE(get_response->success);
  EXPECT_EQ(get_response->message, "viewer unavailable");

  const std::vector<mjtNum> qpos_before(sim_->data()->qpos, sim_->data()->qpos + sim_->model()->nq);
  expose_viewer_for_testing();

  set_future = set_client->async_send_request(set_request);
  ASSERT_EQ(set_future.wait_for(std::chrono::seconds(5)), std::future_status::ready);
  set_response = set_future.get();
  ASSERT_TRUE(set_response->success) << set_response->message;
  EXPECT_NEAR(set_response->applied_camera.lookat[0], set_request->camera.lookat[0], 1e-9);
  EXPECT_NEAR(set_response->applied_camera.distance, set_request->camera.distance, 1e-9);

  get_future = get_client->async_send_request(get_request);
  ASSERT_EQ(get_future.wait_for(std::chrono::seconds(5)), std::future_status::ready);
  get_response = get_future.get();
  ASSERT_TRUE(get_response->success) << get_response->message;
  EXPECT_NEAR(get_response->camera.lookat[0], set_request->camera.lookat[0], 1e-9);
  EXPECT_NEAR(get_response->camera.lookat[1], set_request->camera.lookat[1], 1e-9);
  EXPECT_NEAR(get_response->camera.lookat[2], set_request->camera.lookat[2], 1e-9);
  EXPECT_NEAR(get_response->camera.distance, set_request->camera.distance, 1e-9);
  EXPECT_NEAR(get_response->camera.azimuth_deg, -135.0, 1e-9);

  auto invalid_request =
    std::make_shared<mujoco_ros2_control_msgs::srv::SetViewerCamera::Request>(*set_request);
  invalid_request->camera.distance = 0.0;
  set_future = set_client->async_send_request(invalid_request);
  ASSERT_EQ(set_future.wait_for(std::chrono::seconds(5)), std::future_status::ready);
  set_response = set_future.get();
  EXPECT_FALSE(set_response->success);

  get_future = get_client->async_send_request(get_request);
  ASSERT_EQ(get_future.wait_for(std::chrono::seconds(5)), std::future_status::ready);
  get_response = get_future.get();
  ASSERT_TRUE(get_response->success);
  EXPECT_NEAR(get_response->camera.distance, set_request->camera.distance, 1e-9)
    << "invalid viewer request partially mutated the camera";
  EXPECT_EQ(
    std::vector<mjtNum>(sim_->data()->qpos, sim_->data()->qpos + sim_->model()->nq), qpos_before)
    << "viewer camera services modified physics state";
}

TEST_F(MujocoSimulationTest, RenderingShutdownClosesWorkersBeforeContextsAndViewer)
{
  ASSERT_TRUE(initialize_sim());
  EventCollector events;
  auto renderer = std::make_shared<RecordingRenderingPlugin>(events);
  ASSERT_TRUE(sim_->prepare_rendering_plugin(renderer));
  sim_->add_observer_plugin(renderer);
  events.clear();
  set_rendering_transition_callback([&](const char* event) { events.add(event); });

  sim_->shutdown();

  EXPECT_EQ(events.copy(), (std::vector<std::string>{
    "disable_rendering", "close_rendering", "destroy_context", "destroy_viewer" }));
}

TEST_F(MujocoSimulationTest, HeadlessSimulationCanEnableRenderingWithoutViewerContext)
{
  ASSERT_TRUE(sim_->initialize(
      node_, kTestModelPath, "/mujoco_robot_description", -1.0, true, false));
  EventCollector events;
  auto renderer = std::make_shared<RecordingRenderingPlugin>(events);

  ASSERT_TRUE(sim_->prepare_rendering_plugin(renderer));

  EXPECT_EQ(events.copy(), (std::vector<std::string>{ "enable_rendering" }));
  sim_->shutdown();
}

TEST_F(MujocoSimulationTest, PreparedRenderingPluginIsOwnedBeforeInitCanStartWorker)
{
  ASSERT_TRUE(initialize_sim());
  EventCollector events;
  auto renderer = std::make_shared<RecordingRenderingPlugin>(events);
  ASSERT_TRUE(sim_->prepare_rendering_plugin(renderer));
  events.clear();
  set_rendering_transition_callback([&](const char* event) { events.add(event); });

  // A concurrent shutdown may begin as soon as init() is entered. Lifecycle ownership must
  // therefore be established by prepare_rendering_plugin(), before observer registration.
  sim_->shutdown();

  EXPECT_EQ(events.copy(), (std::vector<std::string>{
    "disable_rendering", "close_rendering", "destroy_context", "destroy_viewer" }));
}

TEST_F(MujocoSimulationTest, ConcurrentRendererStopsWaitForWorkerCloseCompletion)
{
  ASSERT_TRUE(initialize_sim());
  EventCollector events;
  std::promise<void> close_entered;
  auto close_entered_future = close_entered.get_future();
  std::promise<void> release_close;
  auto renderer = std::make_shared<BlockingRenderingPlugin>(
      events, close_entered, release_close.get_future().share());
  ASSERT_TRUE(sim_->prepare_rendering_plugin(renderer));
  events.clear();

  std::thread owner([this]() { stop_rendering_plugins(); });
  ASSERT_EQ(close_entered_future.wait_for(std::chrono::seconds(5)), std::future_status::ready);

  std::promise<void> waiter_returned;
  auto waiter_returned_future = waiter_returned.get_future();
  std::thread waiter([this, &waiter_returned]() {
    stop_rendering_plugins();
    waiter_returned.set_value();
  });
  EXPECT_EQ(waiter_returned_future.wait_for(std::chrono::milliseconds(100)), std::future_status::timeout)
    << "a second shutdown caller returned before the renderer worker was joined";

  release_close.set_value();
  owner.join();
  ASSERT_EQ(waiter_returned_future.wait_for(std::chrono::seconds(5)), std::future_status::ready);
  waiter.join();

  EXPECT_EQ(events.copy(), (std::vector<std::string>{ "disable_rendering", "close_rendering" }));
}

TEST_F(MujocoSimulationTest, ViewerCleanupRejectsNewRuntimeUsersAndDrainsInFlightCallback)
{
  ASSERT_TRUE(initialize_sim());
  auto in_flight = sim_->acquire_runtime_use();
  ASSERT_TRUE(in_flight);

  std::promise<void> cleanup_returned;
  auto cleanup_returned_future = cleanup_returned.get_future();
  std::thread cleanup([this, &cleanup_returned]() {
    close_runtime_uses();
    cleanup_returned.set_value();
  });

  ASSERT_TRUE(wait_until([this]() { return !sim_->acquire_runtime_use(); }));
  EXPECT_EQ(cleanup_returned_future.wait_for(std::chrono::milliseconds(100)), std::future_status::timeout)
    << "viewer cleanup did not wait for an in-flight runtime callback";

  in_flight = {};
  ASSERT_EQ(cleanup_returned_future.wait_for(std::chrono::seconds(5)), std::future_status::ready);
  cleanup.join();
  EXPECT_FALSE(sim_->acquire_runtime_use()) << "shutdown admitted a new runtime callback";
}

TEST_F(MujocoSimulationTest, ViewerCleanupWakesInFlightStepBeforeDrainingRuntimeUsers)
{
  ASSERT_TRUE(initialize_sim());
  force_paused();

  const std::string ns = std::string(node_->get_fully_qualified_name());
  auto client = node_->create_client<mujoco_ros2_control_msgs::srv::StepSimulation>(ns + "/step_simulation");
  ASSERT_TRUE(client->wait_for_service(std::chrono::seconds(5)));
  auto request = std::make_shared<mujoco_ros2_control_msgs::srv::StepSimulation::Request>();
  request->steps = 100;
  auto future = client->async_send_request(request);
  ASSERT_TRUE(wait_until([this]() { return pending_steps() == 100; }));

  const auto started = std::chrono::steady_clock::now();
  close_runtime_uses();
  const auto elapsed = std::chrono::steady_clock::now() - started;

  ASSERT_EQ(future.wait_for(std::chrono::seconds(1)), std::future_status::ready);
  EXPECT_FALSE(future.get()->success);
  EXPECT_LT(elapsed, std::chrono::seconds(1))
    << "runtime drain waited for the 30-second step timeout instead of waking it";
}

TEST_F(MujocoSimulationTest, ControlUpdateTests)
{
  ASSERT_TRUE(initialize_sim());

  // Simulate the read/write cycle in the ros2_control loop, making sure data
  // is updated where expected
  mjData* control = nullptr;
  sim_->copy_physics_data(control);
  ASSERT_NE(control, nullptr);

  // Update control inputs
  control->ctrl[0] = 0.75;
  control->qfrc_applied[0] = 1.5;

  // Apply to sim. Inputs are staged and copied into the sim data by the physics loop
  // immediately before each step, so they must not appear until stepping occurs.
  sim_->apply_control_data(control);
  EXPECT_DOUBLE_EQ(sim_->data()->ctrl[0], 0.0);
  EXPECT_DOUBLE_EQ(sim_->data()->qfrc_applied[0], 0.0);

  // Once the physics loop starts stepping, the staged inputs should land in the sim data
  sim_->start_physics_thread();
  EXPECT_TRUE(wait_until([this]() { return sim_->data()->ctrl[0] == 0.75 && sim_->data()->qfrc_applied[0] == 1.5; }))
      << "Staged control inputs were not applied by the physics loop";

  mj_deleteData(control);
}

TEST_F(MujocoSimulationTest, PreStepCallbackAppliesXfrcApplied)
{
  ASSERT_TRUE(initialize_sim());

  // xfrc_applied is not staged through apply_control_data, instead we register a pre-step callback that
  // writes directly into the live mjData immediately before every mj_step.
  const size_t body_id = 1;
  sim_->set_pre_step_callback([body_id](mjData* data) {
    data->xfrc_applied[body_id * 6 + 0] = 1.0;
    data->xfrc_applied[body_id * 6 + 1] = 2.0;
    data->xfrc_applied[body_id * 6 + 2] = 3.0;
  });

  // The callback has not run yet as it is only invoked from the physics loop.
  EXPECT_DOUBLE_EQ(sim_->data()->xfrc_applied[body_id * 6 + 0], 0.0);

  sim_->start_physics_thread();
  EXPECT_TRUE(wait_until([this, body_id]() { return sim_->data()->xfrc_applied[body_id * 6 + 0] == 1.0; }))
      << "pre_step callback's xfrc_applied write was not applied by the physics loop";
  EXPECT_DOUBLE_EQ(sim_->data()->xfrc_applied[body_id * 6 + 1], 2.0);
  EXPECT_DOUBLE_EQ(sim_->data()->xfrc_applied[body_id * 6 + 2], 3.0);
}

TEST_F(MujocoSimulationTest, PauseStepUnpause)
{
  ASSERT_TRUE(initialize_sim());
  sim_->start_physics_thread();

  // Confirm the sim has started
  ASSERT_TRUE(wait_until([this]() { return sim_->data()->time > 0.0; })) << "Simulation did not start stepping";

  // Setup service clients
  const std::string ns = std::string(node_->get_fully_qualified_name());
  auto pause_client = node_->create_client<mujoco_ros2_control_msgs::srv::SetPause>(ns + "/set_pause");
  auto step_client = node_->create_client<mujoco_ros2_control_msgs::srv::StepSimulation>(ns + "/step_simulation");
  ASSERT_TRUE(pause_client->wait_for_service(std::chrono::seconds(5))) << "set_pause service not found";
  ASSERT_TRUE(step_client->wait_for_service(std::chrono::seconds(5))) << "step_simulation service not found";

  // Pause the simulation and wait for the service to return
  auto pause_req = std::make_shared<mujoco_ros2_control_msgs::srv::SetPause::Request>();
  pause_req->paused = true;
  auto pause_future = pause_client->async_send_request(pause_req);
  ASSERT_EQ(pause_future.wait_for(std::chrono::seconds(5)), std::future_status::ready);
  ASSERT_TRUE(pause_future.get()->success);

  // Once paused, time should not advance
  ASSERT_TRUE(wait_for_pause()) << "Simulation did not pause";
  const double time_after_pause = sim_->data()->time;
  ASSERT_TRUE(wait_until([&]() { return sim_->data()->time != time_after_pause; }, std::chrono::milliseconds(200)) ==
              false)
      << "Time should not advance while paused";

  // Next step the simulation by 10 steps
  const uint32_t num_steps = 10;
  auto step_req = std::make_shared<mujoco_ros2_control_msgs::srv::StepSimulation::Request>();
  step_req->steps = num_steps;
  auto step_future = step_client->async_send_request(step_req);
  ASSERT_EQ(step_future.wait_for(std::chrono::seconds(5)), std::future_status::ready);
  ASSERT_TRUE(step_future.get()->success);

  const double expected_time = time_after_pause + num_steps * sim_->model()->opt.timestep;
  EXPECT_NEAR(sim_->data()->time, expected_time, TEST_TOLERANCE)
      << "Time should advance by exactly " << num_steps << " steps";

  // Verify still paused after stepping
  const double time_after_step = sim_->data()->time;
  ASSERT_TRUE(wait_until([&]() { return sim_->data()->time != time_after_step; }, std::chrono::milliseconds(200)) ==
              false)
      << "Time should not advance after steps complete";

  // The simulation, confirm the sim restarts
  pause_req->paused = false;
  pause_future = pause_client->async_send_request(pause_req);
  ASSERT_EQ(pause_future.wait_for(std::chrono::seconds(5)), std::future_status::ready);
  ASSERT_TRUE(pause_future.get()->success);
  ASSERT_TRUE(wait_until([&]() { return sim_->data()->time > time_after_step; }))
      << "Time should advance after unpausing";
}

TEST_F(MujocoSimulationTest, PublishedClockDoesNotTurnPhysicsRoundoffIntoAControllerPhaseSlip)
{
  ASSERT_TRUE(initialize_sim());
  std::atomic<int64_t> stamp_ns{ -1 };
  std::atomic<unsigned int> received{ 0 };
  auto subscription = node_->create_subscription<rosgraph_msgs::msg::Clock>(
      "/clock", rclcpp::QoS(10), [&](const rosgraph_msgs::msg::Clock& message) {
        stamp_ns.store(rclcpp::Time(message.clock, RCL_ROS_TIME).nanoseconds());
        received.fetch_add(1);
      });
  ASSERT_TRUE(wait_until([&]() { return subscription->get_publisher_count() == 1; }));

  // Adjacent doubles straddle a decimal timestep boundary by much less than
  // one nanosecond. Truncation creates a short ROS clock tick and can defer
  // the controller's 10ms update to the following 2ms physics step.
  for (const auto& sample : std::vector<std::pair<double, int64_t>>{
           { 19.628, 19'628'000'000 },
           { std::nextafter(19.630, 0.0), 19'630'000'000 },
           { std::nextafter(19.632, 0.0), 19'632'000'000 },
           { std::nextafter(20.0, 0.0), 20'000'000'000 } })
  {
    const auto previous_count = received.load();
    publish_original_time_for_testing(sample.first);
    ASSERT_TRUE(wait_until([&]() { return received.load() > previous_count; }));
    EXPECT_EQ(stamp_ns.load(), sample.second);
    EXPECT_DOUBLE_EQ(sim_->data()->time, sample.first);
  }
}

TEST_F(MujocoSimulationTest, AuthoritativePausedStepUsesExactTransitionOrder)
{
  ASSERT_TRUE(initialize_sim());

  EventCollector events;
  auto observer = std::make_shared<RecordingObserverPlugin>(events);
  sim_->add_observer_plugin(observer);
  sim_->start_physics_thread();
  ASSERT_TRUE(set_paused(true));
  ASSERT_TRUE(wait_for_pause());
  events.clear();

  mjData* control = nullptr;
  sim_->copy_physics_data(control);
  ASSERT_NE(control, nullptr);
  control->ctrl[0] = 0.75;
  sim_->apply_control_data(control);

  bool pre_step_saw_staged_control = false;
  sim_->set_pre_step_callback([&](mjData* data) {
    pre_step_saw_staged_control = data->ctrl[0] == 0.75;
    events.add("pre_step");
  });
  set_transition_callback([&](const char* event) {
    if (std::string(event) == "step_queue_setup")
    {
      events.clear();
      return;
    }
    events.add(event);
    if (std::string(event) == "clock")
    {
      // Freeze after this whole physics-loop iteration so later paused refreshes cannot
      // obscure whether the pending-step iteration itself published more than once.
      request_physics_exit();
    }
  });

  const std::string ns = std::string(node_->get_fully_qualified_name());
  auto client = node_->create_client<mujoco_ros2_control_msgs::srv::StepSimulation>(ns + "/step_simulation");
  ASSERT_TRUE(client->wait_for_service(std::chrono::seconds(5)));
  auto request = std::make_shared<mujoco_ros2_control_msgs::srv::StepSimulation::Request>();
  request->steps = 1;
  auto future = client->async_send_request(request);
  ASSERT_EQ(future.wait_for(std::chrono::seconds(5)), std::future_status::ready);
  ASSERT_TRUE(future.get()->success);

  EXPECT_TRUE(pre_step_saw_staged_control);
  EXPECT_EQ(events.copy(), (std::vector<std::string>{ "apply_staged_control", "pre_step", "mj_step",
                                                     "observer_post_step", "control_state", "data_snapshot", "clock" }));

  mj_deleteData(control);
}

TEST_F(MujocoSimulationTest, StepQueueSetupSerializesAgainstConcurrentResume)
{
  ASSERT_TRUE(initialize_sim());
  sim_->start_physics_thread();
  ASSERT_TRUE(set_paused(true));
  ASSERT_TRUE(wait_for_pause());

  std::mutex hook_mutex;
  std::condition_variable hook_cv;
  bool queue_setup_reached = false;
  bool release_queue_setup = false;
  set_transition_callback([&](const char* event) {
    if (std::string(event) != "step_queue_setup")
    {
      return;
    }
    std::unique_lock<std::mutex> lock(hook_mutex);
    queue_setup_reached = true;
    hook_cv.notify_all();
    hook_cv.wait(lock, [&]() { return release_queue_setup; });
  });

  const std::string ns = std::string(node_->get_fully_qualified_name());
  auto step_client = node_->create_client<mujoco_ros2_control_msgs::srv::StepSimulation>(ns + "/step_simulation");
  auto pause_client = node_->create_client<mujoco_ros2_control_msgs::srv::SetPause>(ns + "/set_pause");
  ASSERT_TRUE(step_client->wait_for_service(std::chrono::seconds(5)));
  ASSERT_TRUE(pause_client->wait_for_service(std::chrono::seconds(5)));

  auto step_request = std::make_shared<mujoco_ros2_control_msgs::srv::StepSimulation::Request>();
  step_request->steps = 10;
  auto step_future = step_client->async_send_request(step_request);
  {
    std::unique_lock<std::mutex> lock(hook_mutex);
    ASSERT_TRUE(hook_cv.wait_for(lock, std::chrono::seconds(5), [&]() { return queue_setup_reached; }));
  }

  auto resume_request = std::make_shared<mujoco_ros2_control_msgs::srv::SetPause::Request>();
  resume_request->paused = false;
  auto resume_future = pause_client->async_send_request(resume_request);
  EXPECT_EQ(resume_future.wait_for(std::chrono::milliseconds(100)), std::future_status::timeout)
      << "Resume completed between StepSimulation's paused check and pending-step queue setup";

  {
    const std::lock_guard<std::mutex> lock(hook_mutex);
    release_queue_setup = true;
  }
  hook_cv.notify_all();

  ASSERT_EQ(resume_future.wait_for(std::chrono::seconds(5)), std::future_status::ready);
  EXPECT_TRUE(resume_future.get()->success);
  ASSERT_EQ(step_future.wait_for(std::chrono::seconds(5)), std::future_status::ready);
  EXPECT_FALSE(step_future.get()->success) << "Concurrent resume must interrupt the atomically queued steps";
}

TEST_F(MujocoSimulationTest, DivergentPausedStepRetainsLastAuthoritativeSnapshots)
{
  ASSERT_TRUE(initialize_sim());

  EventCollector events;
  auto observer = std::make_shared<RecordingObserverPlugin>(events);
  sim_->add_observer_plugin(observer);
  sim_->start_physics_thread();
  ASSERT_TRUE(set_paused(true));
  ASSERT_TRUE(wait_for_pause());

  // Consume the pause snapshot, then request one more paused refresh so the pre-failure
  // snapshot is known-good and a post-failure refresh would be observable.
  sim_->acquire_data_snapshot();
  std::this_thread::sleep_for(std::chrono::milliseconds(20));
  const mjData* good_snapshot = sim_->acquire_data_snapshot();
  const double good_snapshot_time = good_snapshot->time;
  const double good_snapshot_qpos = good_snapshot->qpos[0];
  mujoco_ros2_control::MujocoSimulation::ControlState good_control_state;
  sim_->copy_control_state(good_control_state);

  {
    const std::unique_lock<std::recursive_mutex> lock(sim_->mutex());
    sim_->model()->opt.disableflags |= mjDSBL_AUTORESET;
  }
  sim_->set_pre_step_callback([&](mjData* data) {
    events.add("pre_step");
    data->qpos[0] = std::numeric_limits<mjtNum>::quiet_NaN();
  });
  set_transition_callback([&](const char* event) {
    if (std::string(event) == "step_queue_setup")
    {
      events.clear();
      return;
    }
    events.add(event);
  });
  events.clear();

  const std::string ns = std::string(node_->get_fully_qualified_name());
  auto client = node_->create_client<mujoco_ros2_control_msgs::srv::StepSimulation>(ns + "/step_simulation");
  ASSERT_TRUE(client->wait_for_service(std::chrono::seconds(5)));
  auto request = std::make_shared<mujoco_ros2_control_msgs::srv::StepSimulation::Request>();
  request->steps = 1;
  auto future = client->async_send_request(request);
  ASSERT_EQ(future.wait_for(std::chrono::seconds(5)), std::future_status::ready);
  EXPECT_FALSE(future.get()->success);

  std::this_thread::sleep_for(std::chrono::milliseconds(50));
  mujoco_ros2_control::MujocoSimulation::ControlState after_control_state;
  sim_->copy_control_state(after_control_state);
  const mjData* after_snapshot = sim_->acquire_data_snapshot();

  EXPECT_DOUBLE_EQ(after_control_state.time, good_control_state.time);
  ASSERT_FALSE(after_control_state.qpos.empty());
  ASSERT_FALSE(good_control_state.qpos.empty());
  EXPECT_DOUBLE_EQ(after_control_state.qpos[0], good_control_state.qpos[0]);
  EXPECT_DOUBLE_EQ(after_snapshot->time, good_snapshot_time);
  EXPECT_DOUBLE_EQ(after_snapshot->qpos[0], good_snapshot_qpos);
  EXPECT_EQ(events.copy(), (std::vector<std::string>{ "apply_staged_control", "pre_step" }))
      << "A failed paused step must not dispatch observers or publish state";
}

TEST_F(MujocoSimulationTest, CatchUpDivergenceStopsTheCurrentBatchAndRetainsLastGoodState)
{
  ASSERT_TRUE(initialize_sim());

  {
    const std::unique_lock<std::recursive_mutex> lock(sim_->mutex());
    sim_->model()->opt.disableflags |= mjDSBL_AUTORESET;
  }

  std::atomic<uint64_t> pre_step_calls{ 0 };
  sim_->set_pre_step_callback([&](mjData* data) {
    const uint64_t call = pre_step_calls.fetch_add(1) + 1;
    if (call == 1)
    {
      // Leave the next physics-loop iteration behind wall time, forcing the catch-up branch.
      std::this_thread::sleep_for(std::chrono::milliseconds(50));
    }
    else if (call == 3)
    {
      data->qpos[0] = std::numeric_limits<mjtNum>::quiet_NaN();
    }
  });

  sim_->start_physics_thread();
  ASSERT_TRUE(wait_until([&]() { return pre_step_calls.load() >= 3; }));
  std::this_thread::sleep_for(std::chrono::milliseconds(100));

  EXPECT_EQ(pre_step_calls.load(), 3u) << "Catch-up integration continued after the first divergent step";
  EXPECT_EQ(sim_->step_count(), 2u) << "Only the two pre-divergence steps are authoritative";

  mujoco_ros2_control::MujocoSimulation::ControlState state;
  sim_->copy_control_state(state);
  EXPECT_DOUBLE_EQ(state.time, 2.0 * sim_->model()->opt.timestep)
      << "Paused-state publication replaced the last good control snapshot after divergence";
}

TEST_F(MujocoSimulationTest, PausedDivergenceRejectsResumeUntilReset)
{
  ASSERT_TRUE(initialize_sim());
  sim_->capture_initial_state();

  EventCollector events;
  auto observer = std::make_shared<RecordingObserverPlugin>(events);
  std::atomic<uint64_t> pre_step_calls{ 0 };
  // Stop and join the physics thread before observer and callback state captured from
  // this test body leave scope, including every fatal-assertion early-return path.
  SimulationShutdownGuard shutdown_before_captured_state(*sim_);

  sim_->add_observer_plugin(observer);
  {
    const std::unique_lock<std::recursive_mutex> lock(sim_->mutex());
    sim_->model()->opt.disableflags |= mjDSBL_AUTORESET;
  }
  sim_->set_pre_step_callback([&](mjData* data) {
    if (pre_step_calls.fetch_add(1) == 0)
    {
      data->qpos[0] = std::numeric_limits<mjtNum>::quiet_NaN();
    }
  });
  sim_->start_physics_thread();
  ASSERT_TRUE(set_paused(true));
  ASSERT_TRUE(wait_for_pause());
  events.clear();

  const std::string ns = std::string(node_->get_fully_qualified_name());
  auto step_client = node_->create_client<mujoco_ros2_control_msgs::srv::StepSimulation>(ns + "/step_simulation");
  auto reset_client = node_->create_client<mujoco_ros2_control_msgs::srv::ResetWorld>(ns + "/reset_world");
  ASSERT_TRUE(step_client->wait_for_service(std::chrono::seconds(5)));
  ASSERT_TRUE(reset_client->wait_for_service(std::chrono::seconds(5)));

  auto step_request = std::make_shared<mujoco_ros2_control_msgs::srv::StepSimulation::Request>();
  step_request->steps = 1;
  auto step_future = step_client->async_send_request(step_request);
  ASSERT_EQ(step_future.wait_for(std::chrono::seconds(5)), std::future_status::ready);
  ASSERT_FALSE(step_future.get()->success);
  ASSERT_EQ(pre_step_calls.load(), 1u);

  events.clear();
  const auto rejected_resume = request_pause(false);
  ASSERT_NE(rejected_resume, nullptr);
  EXPECT_FALSE(rejected_resume->success);
  EXPECT_NE(rejected_resume->message.find("reset"), std::string::npos);
  EXPECT_TRUE(is_paused());
  std::this_thread::sleep_for(std::chrono::milliseconds(100));
  EXPECT_EQ(pre_step_calls.load(), 1u) << "Rejected resume attempted another physics integration";
  EXPECT_TRUE(events.copy().empty()) << "Rejected resume emitted a pause or physics notification";

  auto reset_request = std::make_shared<mujoco_ros2_control_msgs::srv::ResetWorld::Request>();
  auto reset_future = reset_client->async_send_request(reset_request);
  ASSERT_EQ(reset_future.wait_for(std::chrono::seconds(5)), std::future_status::ready);
  ASSERT_TRUE(reset_future.get()->success);
  EXPECT_TRUE(is_paused());
  EXPECT_EQ(events.copy(), (std::vector<std::string>{ "reset", "state_snapshot" }));

  events.clear();
  const auto successful_resume = request_pause(false);
  ASSERT_NE(successful_resume, nullptr);
  ASSERT_TRUE(successful_resume->success) << successful_resume->message;
  EXPECT_FALSE(is_paused());
  const auto after_resume_events = events.copy();
  ASSERT_FALSE(after_resume_events.empty());
  EXPECT_EQ(after_resume_events.front(), "pause:false");
  EXPECT_TRUE(wait_until([&]() { return pre_step_calls.load() > 1; }))
      << "Reset did not clear the divergence latch and restore normal resume";
  EXPECT_TRUE(wait_until([&]() { return sim_->step_count() > 0; }))
      << "Reset-then-resume did not complete a successful authoritative physics step";
}

TEST_F(MujocoSimulationTest, CatchUpDivergenceRejectsResumeWithoutAnotherIntegration)
{
  ASSERT_TRUE(initialize_sim());

  EventCollector events;
  auto observer = std::make_shared<RecordingObserverPlugin>(events);
  sim_->add_observer_plugin(observer);
  {
    const std::unique_lock<std::recursive_mutex> lock(sim_->mutex());
    sim_->model()->opt.disableflags |= mjDSBL_AUTORESET;
  }

  std::atomic<uint64_t> pre_step_calls{ 0 };
  sim_->set_pre_step_callback([&](mjData* data) {
    const uint64_t call = pre_step_calls.fetch_add(1) + 1;
    if (call == 1)
    {
      std::this_thread::sleep_for(std::chrono::milliseconds(50));
    }
    else if (call == 3)
    {
      data->qpos[0] = std::numeric_limits<mjtNum>::quiet_NaN();
    }
  });

  sim_->start_physics_thread();
  ASSERT_TRUE(wait_until([&]() { return pre_step_calls.load() >= 3; }));
  ASSERT_TRUE(wait_for_pause());
  ASSERT_EQ(pre_step_calls.load(), 3u);

  events.clear();
  const auto rejected_resume = request_pause(false);
  ASSERT_NE(rejected_resume, nullptr);
  EXPECT_FALSE(rejected_resume->success);
  EXPECT_NE(rejected_resume->message.find("reset"), std::string::npos);
  EXPECT_TRUE(is_paused());
  std::this_thread::sleep_for(std::chrono::milliseconds(100));
  EXPECT_EQ(pre_step_calls.load(), 3u) << "Rejected resume attempted another catch-up integration";
  EXPECT_TRUE(events.copy().empty()) << "Rejected resume emitted pause:false or a physics notification";
}

TEST_F(MujocoSimulationTest, EarlyDivergenceActualUiResetRestoresRecoveryAndAllowsResume)
{
  ASSERT_TRUE(initialize_sim());

  {
    const std::unique_lock<std::recursive_mutex> lock(sim_->mutex());
    sim_->data()->qpos[0] = 0.25;
    sim_->data()->ctrl[0] = 0.35;
    sim_->data()->eq_active[0] = 1;
    mj_forward(sim_->model(), sim_->data());
  }
  sim_->capture_initial_state();

  EventCollector events;
  auto observer = std::make_shared<RecordingObserverPlugin>(events);
  sim_->add_observer_plugin(observer);
  ASSERT_TRUE(set_paused(true));
  events.clear();

  sim_->start_physics_thread();
  ASSERT_TRUE(wait_for_pause());
  ASSERT_TRUE(wait_until([&]() { return prepare_actual_viewer_sync(); }))
      << "Headless fixture did not initialize the actual Simulate::Sync state";
  std::this_thread::sleep_for(std::chrono::milliseconds(25));
  EXPECT_TRUE(events.copy().empty()) << "Initial near-zero simulation state emitted a reset";

  {
    const std::unique_lock<std::recursive_mutex> lock(sim_->mutex());
    sim_->model()->opt.disableflags |= mjDSBL_AUTORESET;
  }
  std::atomic<uint64_t> pre_step_calls{ 0 };
  sim_->set_pre_step_callback([&](mjData* data) {
    const uint64_t call = pre_step_calls.fetch_add(1) + 1;
    if (call == 1)
    {
      data->qpos[0] = std::numeric_limits<mjtNum>::quiet_NaN();
    }
    else if (call == 2)
    {
      request_physics_exit();
    }
  });

  const std::string ns = std::string(node_->get_fully_qualified_name());
  auto step_client = node_->create_client<mujoco_ros2_control_msgs::srv::StepSimulation>(ns + "/step_simulation");
  ASSERT_TRUE(step_client->wait_for_service(std::chrono::seconds(5)));
  auto step_request = std::make_shared<mujoco_ros2_control_msgs::srv::StepSimulation::Request>();
  step_request->steps = 1;
  auto step_future = step_client->async_send_request(step_request);
  ASSERT_EQ(step_future.wait_for(std::chrono::seconds(5)), std::future_status::ready);
  ASSERT_FALSE(step_future.get()->success);
  ASSERT_EQ(pre_step_calls.load(), 1u);

  double divergence_time = 0.0;
  {
    const std::unique_lock<std::recursive_mutex> lock(sim_->mutex());
    divergence_time = sim_->data()->time;
  }
  ASSERT_GT(divergence_time, 0.0);
  ASSERT_LT(divergence_time, 0.1) << "Regression setup did not exercise an early UI reset";

  {
    const std::unique_lock<std::recursive_mutex> lock(sim_->mutex());
    sim_->data()->ctrl[0] = 0.91;
    sim_->data()->eq_active[0] = 1;
  }

  events.clear();
  const ViewerSyncObservation reset_sync = process_actual_ui_reset();
  EXPECT_FALSE(reset_sync.reset_pending_after_poll)
      << "The project UI adapter did not consume reset through the real Simulate::Sync operation";
  EXPECT_DOUBLE_EQ(reset_sync.data_qpos, 0.0);
  EXPECT_DOUBLE_EQ(reset_sync.data_ctrl, 0.0);
  EXPECT_EQ(reset_sync.data_eq_active, 0);
  EXPECT_DOUBLE_EQ(reset_sync.viewer_qpos, reset_sync.data_qpos);
  EXPECT_DOUBLE_EQ(reset_sync.viewer_qpos_prev, reset_sync.data_qpos);
  EXPECT_DOUBLE_EQ(reset_sync.viewer_ctrl, reset_sync.data_ctrl);
  EXPECT_DOUBLE_EQ(reset_sync.viewer_ctrl_prev, reset_sync.data_ctrl);
  EXPECT_EQ(reset_sync.viewer_eq_active, reset_sync.data_eq_active);
  EXPECT_EQ(reset_sync.viewer_eq_active_prev, reset_sync.data_eq_active);
  EXPECT_DOUBLE_EQ(reset_sync.followup_data_qpos, reset_sync.data_qpos);
  EXPECT_DOUBLE_EQ(reset_sync.followup_data_ctrl, reset_sync.data_ctrl);
  EXPECT_EQ(reset_sync.followup_data_eq_active, reset_sync.data_eq_active);

  ASSERT_TRUE(wait_until([&]() { return events.copy().size() >= 2; }, std::chrono::milliseconds(500)))
      << "The physics loop did not route the early UI reset through the common reset transaction";
  EXPECT_EQ(events.copy(), (std::vector<std::string>{ "reset", "state_snapshot" }));
  {
    const std::unique_lock<std::recursive_mutex> lock(sim_->mutex());
    EXPECT_DOUBLE_EQ(sim_->data()->time, divergence_time) << "UI reset broke ROS clock continuity";
    EXPECT_DOUBLE_EQ(sim_->data()->qpos[0], 0.25) << "UI reset did not restore the captured initial position";
    EXPECT_DOUBLE_EQ(sim_->data()->ctrl[0], 0.35) << "UI reset did not restore the captured initial control";
    EXPECT_EQ(sim_->data()->eq_active[0], 0) << "UI reset did not retain the model's reset equality state";
    for (int warning = 0; warning < mjNWARNING; ++warning)
    {
      EXPECT_EQ(sim_->data()->warning[warning].number, 0)
          << "UI reset retained cumulative warning " << warning;
    }
  }

  events.clear();
  const auto resumed = request_pause(false);
  ASSERT_NE(resumed, nullptr);
  ASSERT_TRUE(resumed->success) << resumed->message;
  EXPECT_FALSE(is_paused());
  const auto resume_events = events.copy();
  ASSERT_FALSE(resume_events.empty());
  EXPECT_EQ(resume_events.front(), "pause:false");
  ASSERT_TRUE(wait_until([&]() { return sim_->step_count() == 1; }))
      << "UI reset did not clear recovery state for one authoritative post-reset step";
  EXPECT_EQ(pre_step_calls.load(), 2u);
  for (const auto& event : events.copy())
  {
    EXPECT_NE(event, "reset") << "Normal early forward simulation time was misclassified as another UI reset";
  }
  {
    const std::unique_lock<std::recursive_mutex> lock(sim_->mutex());
    EXPECT_GT(sim_->data()->time, divergence_time);
    EXPECT_LT(sim_->data()->time, 0.1);
  }
}

TEST_F(MujocoSimulationTest, ActualHistoryScrubPreservesSelectedStateWithoutResetRecovery)
{
  ASSERT_TRUE(initialize_sim());
  sim_->capture_initial_state();

  EventCollector events;
  auto observer = std::make_shared<RecordingObserverPlugin>(events);
  sim_->add_observer_plugin(observer);
  ASSERT_TRUE(set_paused(true));
  events.clear();

  sim_->start_physics_thread();
  ASSERT_TRUE(wait_for_pause());
  ASSERT_TRUE(wait_until([&]() { return prepare_actual_viewer_sync(); }))
      << "Headless fixture did not initialize the actual Simulate::Sync state";

  constexpr double selected_time = 0.0;
  constexpr double selected_qpos = 0.63;
  constexpr double selected_ctrl = 0.47;
  constexpr int selected_eq_active = 1;
  store_history_state(selected_time, selected_qpos, selected_ctrl, selected_eq_active);

  {
    const std::unique_lock<std::recursive_mutex> lock(sim_->mutex());
    sim_->model()->opt.disableflags |= mjDSBL_AUTORESET;
  }
  std::atomic<uint64_t> pre_step_calls{ 0 };
  sim_->set_pre_step_callback([&](mjData* data) {
    if (pre_step_calls.fetch_add(1) == 0)
    {
      data->warning[mjWARN_BADQPOS].lastinfo = 0;
      data->warning[mjWARN_BADQPOS].number = 1;
    }
  });

  const std::string ns = std::string(node_->get_fully_qualified_name());
  auto step_client = node_->create_client<mujoco_ros2_control_msgs::srv::StepSimulation>(ns + "/step_simulation");
  ASSERT_TRUE(step_client->wait_for_service(std::chrono::seconds(5)));
  auto step_request = std::make_shared<mujoco_ros2_control_msgs::srv::StepSimulation::Request>();
  step_request->steps = 1;
  auto step_future = step_client->async_send_request(step_request);
  ASSERT_EQ(step_future.wait_for(std::chrono::seconds(5)), std::future_status::ready);
  ASSERT_FALSE(step_future.get()->success);
  ASSERT_EQ(pre_step_calls.load(), 1u);

  double divergence_time = 0.0;
  {
    const std::unique_lock<std::recursive_mutex> lock(sim_->mutex());
    divergence_time = sim_->data()->time;
  }
  ASSERT_GT(divergence_time, selected_time);

  events.clear();
  const ViewerSyncObservation history_sync = process_actual_history_scrub();
  EXPECT_TRUE(history_sync.history_pending_after_poll)
      << "The project UI adapter incorrectly consumed a history restore as reset";
  EXPECT_DOUBLE_EQ(history_sync.data_qpos, selected_qpos);
  EXPECT_DOUBLE_EQ(history_sync.data_ctrl, selected_ctrl);
  EXPECT_EQ(history_sync.data_eq_active, selected_eq_active);
  EXPECT_DOUBLE_EQ(history_sync.followup_data_qpos, selected_qpos);
  EXPECT_DOUBLE_EQ(history_sync.followup_data_ctrl, selected_ctrl);
  EXPECT_EQ(history_sync.followup_data_eq_active, selected_eq_active);

  std::this_thread::sleep_for(std::chrono::milliseconds(100));
  EXPECT_TRUE(events.copy().empty()) << "History scrub emitted reset or state_snapshot notifications";
  {
    const std::unique_lock<std::recursive_mutex> lock(sim_->mutex());
    EXPECT_DOUBLE_EQ(sim_->data()->time, selected_time);
    EXPECT_DOUBLE_EQ(sim_->data()->qpos[0], selected_qpos);
    EXPECT_DOUBLE_EQ(sim_->data()->ctrl[0], selected_ctrl);
    EXPECT_EQ(sim_->data()->eq_active[0], selected_eq_active);
    EXPECT_GT(sim_->data()->warning[mjWARN_BADQPOS].number, 0)
        << "History scrub incorrectly cleared divergence diagnostics as a reset";
  }

  const auto rejected_resume = request_pause(false);
  ASSERT_NE(rejected_resume, nullptr);
  EXPECT_FALSE(rejected_resume->success);
  EXPECT_NE(rejected_resume->message.find("reset"), std::string::npos);
  if (rejected_resume->success)
  {
    request_pause(true);
  }
}

TEST_F(MujocoSimulationTest, CoalescedResetThenHistoryKeepsHistoryAsWinningTransaction)
{
  ASSERT_TRUE(initialize_sim());
  {
    const std::unique_lock<std::recursive_mutex> lock(sim_->mutex());
    sim_->data()->qpos[0] = 0.25;
    sim_->data()->ctrl[0] = 0.35;
    mj_forward(sim_->model(), sim_->data());
  }
  sim_->capture_initial_state();

  EventCollector events;
  auto observer = std::make_shared<RecordingObserverPlugin>(events);
  sim_->add_observer_plugin(observer);
  ASSERT_TRUE(set_paused(true));
  events.clear();
  sim_->start_physics_thread();
  ASSERT_TRUE(wait_for_pause());
  ASSERT_TRUE(wait_until([&]() { return prepare_actual_viewer_sync(); }));

  constexpr double selected_time = 0.0;
  constexpr double selected_qpos = 0.63;
  constexpr double selected_ctrl = 0.47;
  constexpr int selected_eq_active = 1;
  // Reset sets the upstream scrub index to zero before applying the later
  // history request, so place the selected winning state at that exact index.
  store_history_state(selected_time, selected_qpos, selected_ctrl, selected_eq_active, 0);
  latch_divergence_for_viewer_transaction();

  events.clear();
  const ViewerSyncObservation sync =
    process_actual_ui_reset_with_later_operation(true, false, false);
  EXPECT_FALSE(sync.reset_pending_after_poll);
  EXPECT_FALSE(sync.history_pending_after_poll);
  EXPECT_DOUBLE_EQ(sync.data_time, selected_time);
  EXPECT_DOUBLE_EQ(sync.data_qpos, selected_qpos);
  EXPECT_DOUBLE_EQ(sync.data_ctrl, selected_ctrl);
  EXPECT_EQ(sync.data_eq_active, selected_eq_active);
  EXPECT_DOUBLE_EQ(sync.followup_data_time, selected_time);
  EXPECT_DOUBLE_EQ(sync.followup_data_qpos, selected_qpos);
  EXPECT_DOUBLE_EQ(sync.followup_data_ctrl, selected_ctrl);
  EXPECT_EQ(sync.followup_data_eq_active, selected_eq_active);

  std::this_thread::sleep_for(std::chrono::milliseconds(100));
  EXPECT_TRUE(events.copy().empty())
    << "A coalesced reset emitted common-reset recovery after history won the same Sync batch";
  {
    const std::unique_lock<std::recursive_mutex> lock(sim_->mutex());
    EXPECT_DOUBLE_EQ(sim_->data()->time, selected_time);
    EXPECT_DOUBLE_EQ(sim_->data()->qpos[0], selected_qpos);
    EXPECT_DOUBLE_EQ(sim_->data()->ctrl[0], selected_ctrl);
    EXPECT_EQ(sim_->data()->eq_active[0], selected_eq_active);
  }
  const auto rejected_resume = request_pause(false);
  ASSERT_NE(rejected_resume, nullptr);
  EXPECT_FALSE(rejected_resume->success);
  EXPECT_NE(rejected_resume->message.find("reset"), std::string::npos);
}

TEST_F(MujocoSimulationTest, CoalescedResetThenKeyframeKeepsKeyframeAsWinningTransaction)
{
  ASSERT_TRUE(initialize_sim());
  {
    const std::unique_lock<std::recursive_mutex> lock(sim_->mutex());
    sim_->data()->qpos[0] = 0.25;
    sim_->data()->ctrl[0] = 0.35;
    mj_forward(sim_->model(), sim_->data());
  }
  sim_->capture_initial_state();

  EventCollector events;
  auto observer = std::make_shared<RecordingObserverPlugin>(events);
  sim_->add_observer_plugin(observer);
  ASSERT_TRUE(set_paused(true));
  events.clear();
  sim_->start_physics_thread();
  ASSERT_TRUE(wait_for_pause());
  ASSERT_TRUE(wait_until([&]() { return prepare_actual_viewer_sync(); }));
  select_viewer_keyframe(0);
  latch_divergence_for_viewer_transaction();

  events.clear();
  const ViewerSyncObservation sync =
    process_actual_ui_reset_with_later_operation(false, true, false);
  EXPECT_FALSE(sync.reset_pending_after_poll);
  EXPECT_FALSE(sync.key_pending_after_poll);
  EXPECT_DOUBLE_EQ(sync.data_time, 0.0);
  EXPECT_DOUBLE_EQ(sync.data_qpos, 0.5);
  EXPECT_DOUBLE_EQ(sync.data_ctrl, 0.0);
  EXPECT_EQ(sync.data_eq_active, 0);
  EXPECT_DOUBLE_EQ(sync.followup_data_time, 0.0);
  EXPECT_DOUBLE_EQ(sync.followup_data_qpos, 0.5);
  EXPECT_DOUBLE_EQ(sync.followup_data_ctrl, 0.0);
  EXPECT_EQ(sync.followup_data_eq_active, 0);

  std::this_thread::sleep_for(std::chrono::milliseconds(100));
  EXPECT_TRUE(events.copy().empty())
    << "A coalesced reset emitted common-reset recovery after keyframe load won the same Sync batch";
  {
    const std::unique_lock<std::recursive_mutex> lock(sim_->mutex());
    EXPECT_DOUBLE_EQ(sim_->data()->time, 0.0);
    EXPECT_DOUBLE_EQ(sim_->data()->qpos[0], 0.5);
    EXPECT_DOUBLE_EQ(sim_->data()->ctrl[0], 0.0);
    EXPECT_EQ(sim_->data()->eq_active[0], 0);
  }
  const auto rejected_resume = request_pause(false);
  ASSERT_NE(rejected_resume, nullptr);
  EXPECT_FALSE(rejected_resume->success);
  EXPECT_NE(rejected_resume->message.find("reset"), std::string::npos);
}

TEST_F(MujocoSimulationTest, CoalescedResetThenZeroControlKeepsZeroControlAsWinningTransaction)
{
  ASSERT_TRUE(initialize_sim());
  {
    const std::unique_lock<std::recursive_mutex> lock(sim_->mutex());
    sim_->data()->qpos[0] = 0.25;
    sim_->data()->ctrl[0] = 0.35;
    mj_forward(sim_->model(), sim_->data());
  }
  sim_->capture_initial_state();

  EventCollector events;
  auto observer = std::make_shared<RecordingObserverPlugin>(events);
  sim_->add_observer_plugin(observer);
  ASSERT_TRUE(set_paused(true));
  events.clear();
  sim_->start_physics_thread();
  ASSERT_TRUE(wait_for_pause());
  ASSERT_TRUE(wait_until([&]() { return prepare_actual_viewer_sync(); }));
  latch_divergence_for_viewer_transaction();

  events.clear();
  const ViewerSyncObservation sync =
    process_actual_ui_reset_with_later_operation(false, false, true);
  EXPECT_FALSE(sync.reset_pending_after_poll);
  EXPECT_FALSE(sync.zero_ctrl_pending_after_poll);
  EXPECT_DOUBLE_EQ(sync.data_time, 0.0);
  EXPECT_DOUBLE_EQ(sync.data_qpos, 0.0);
  EXPECT_DOUBLE_EQ(sync.data_ctrl, 0.0);
  EXPECT_EQ(sync.data_eq_active, 0);
  EXPECT_DOUBLE_EQ(sync.followup_data_time, 0.0);
  EXPECT_DOUBLE_EQ(sync.followup_data_qpos, 0.0);
  EXPECT_DOUBLE_EQ(sync.followup_data_ctrl, 0.0);
  EXPECT_EQ(sync.followup_data_eq_active, 0);

  std::this_thread::sleep_for(std::chrono::milliseconds(100));
  EXPECT_TRUE(events.copy().empty())
    << "A coalesced reset emitted common-reset recovery after zero-control won the same Sync batch";
  {
    const std::unique_lock<std::recursive_mutex> lock(sim_->mutex());
    EXPECT_DOUBLE_EQ(sim_->data()->time, 0.0);
    EXPECT_DOUBLE_EQ(sim_->data()->qpos[0], 0.0);
    EXPECT_DOUBLE_EQ(sim_->data()->ctrl[0], 0.0);
    EXPECT_EQ(sim_->data()->eq_active[0], 0);
  }
  const auto rejected_resume = request_pause(false);
  ASSERT_NE(rejected_resume, nullptr);
  EXPECT_FALSE(rejected_resume->success);
  EXPECT_NE(rejected_resume->message.find("reset"), std::string::npos);
}

TEST_F(MujocoSimulationTest, PauseRetriesRepublishSnapshotWithoutDuplicatePauseNotification)
{
  ASSERT_TRUE(initialize_sim());

  EventCollector events;
  auto observer = std::make_shared<RecordingObserverPlugin>(events);
  sim_->add_observer_plugin(observer);

  ASSERT_TRUE(set_paused(true));
  EXPECT_EQ(events.copy(), (std::vector<std::string>{ "pause:true", "state_snapshot" }));

  events.clear();
  ASSERT_TRUE(set_paused(true));
  EXPECT_EQ(events.copy(), (std::vector<std::string>{ "state_snapshot" }))
      << "A no-op pause retry must refresh evidence without duplicating the pause transition";

  events.clear();
  ASSERT_TRUE(set_paused(false));
  EXPECT_EQ(events.copy(), (std::vector<std::string>{ "pause:false" }));
}

TEST_F(MujocoSimulationTest, ResetValidationIsAtomicAndSuccessNotifiesAfterSnapshot)
{
  ASSERT_TRUE(initialize_sim());

  EventCollector events;
  auto observer = std::make_shared<RecordingObserverPlugin>(events);
  sim_->add_observer_plugin(observer);
  ASSERT_TRUE(set_paused(true));
  events.clear();

  sim_->data()->qpos[0] = 0.3;
  const std::string ns = std::string(node_->get_fully_qualified_name());
  auto client = node_->create_client<mujoco_ros2_control_msgs::srv::ResetWorld>(ns + "/reset_world");
  ASSERT_TRUE(client->wait_for_service(std::chrono::seconds(5)));

  auto invalid_override = std::make_shared<mujoco_ros2_control_msgs::srv::ResetWorld::Request>();
  invalid_override->state_overrides.joint_states.name = { "hinge", "not_a_joint" };
  invalid_override->state_overrides.joint_states.position = { 0.7, 0.9 };
  auto future = client->async_send_request(invalid_override);
  ASSERT_EQ(future.wait_for(std::chrono::seconds(5)), std::future_status::ready);
  EXPECT_FALSE(future.get()->success);
  EXPECT_DOUBLE_EQ(sim_->data()->qpos[0], 0.3);
  EXPECT_TRUE(events.copy().empty());

  auto invalid_keyframe = std::make_shared<mujoco_ros2_control_msgs::srv::ResetWorld::Request>();
  invalid_keyframe->keyframe = "not_a_keyframe";
  future = client->async_send_request(invalid_keyframe);
  ASSERT_EQ(future.wait_for(std::chrono::seconds(5)), std::future_status::ready);
  EXPECT_FALSE(future.get()->success);
  EXPECT_DOUBLE_EQ(sim_->data()->qpos[0], 0.3);
  EXPECT_TRUE(events.copy().empty());

  auto valid = std::make_shared<mujoco_ros2_control_msgs::srv::ResetWorld::Request>();
  valid->state_overrides.joint_states.name = { "hinge" };
  valid->state_overrides.joint_states.position = { 0.7 };
  future = client->async_send_request(valid);
  ASSERT_EQ(future.wait_for(std::chrono::seconds(5)), std::future_status::ready);
  ASSERT_TRUE(future.get()->success);
  EXPECT_DOUBLE_EQ(sim_->data()->qpos[0], 0.7);
  EXPECT_EQ(events.copy(), (std::vector<std::string>{ "reset", "state_snapshot" }));
  EXPECT_DOUBLE_EQ(observer->snapshot_qpos(), 0.7);
  EXPECT_TRUE(observer->snapshot_paused());
}

TEST_F(MujocoSimulationTest, ResetWorldRequiresPauseWithoutMutatingState)
{
  ASSERT_TRUE(initialize_sim());

  const std::string ns = std::string(node_->get_fully_qualified_name());
  auto pause_client = node_->create_client<mujoco_ros2_control_msgs::srv::SetPause>(ns + "/set_pause");
  auto reset_client = node_->create_client<mujoco_ros2_control_msgs::srv::ResetWorld>(ns + "/reset_world");
  ASSERT_TRUE(pause_client->wait_for_service(std::chrono::seconds(5)));
  ASSERT_TRUE(reset_client->wait_for_service(std::chrono::seconds(5)));

  auto run_request = std::make_shared<mujoco_ros2_control_msgs::srv::SetPause::Request>();
  run_request->paused = false;
  auto run_future = pause_client->async_send_request(run_request);
  ASSERT_EQ(run_future.wait_for(std::chrono::seconds(5)), std::future_status::ready);
  ASSERT_TRUE(run_future.get()->success);

  sim_->data()->qpos[0] = 0.3;
  const std::vector<mjtNum> before_qpos(sim_->data()->qpos, sim_->data()->qpos + sim_->model()->nq);

  auto reset_request = std::make_shared<mujoco_ros2_control_msgs::srv::ResetWorld::Request>();
  auto reset_future = reset_client->async_send_request(reset_request);
  ASSERT_EQ(reset_future.wait_for(std::chrono::seconds(5)), std::future_status::ready);
  const auto response = reset_future.get();

  EXPECT_FALSE(response->success);
  EXPECT_NE(response->message.find("paused"), std::string::npos);
  EXPECT_EQ(before_qpos,
            std::vector<mjtNum>(sim_->data()->qpos, sim_->data()->qpos + sim_->model()->nq));
}

TEST_F(MujocoSimulationTest, ResetWorldTest)
{
  ASSERT_TRUE(initialize_sim());

  // Set a known initial state and capture it
  sim_->data()->qpos[0] = 0.0;
  sim_->data()->qvel[0] = 0.0;
  sim_->data()->ctrl[0] = 0.0;
  sim_->capture_initial_state();

  // Kick off the sim and wait for it to start
  sim_->start_physics_thread();
  ASSERT_TRUE(wait_until([this]() { return sim_->data()->time > 0.0; })) << "Simulation did not start stepping";

  // Setup service clients
  const std::string ns = std::string(node_->get_fully_qualified_name());
  auto pause_client = node_->create_client<mujoco_ros2_control_msgs::srv::SetPause>(ns + "/set_pause");
  auto reset_client = node_->create_client<mujoco_ros2_control_msgs::srv::ResetWorld>(ns + "/reset_world");
  ASSERT_TRUE(pause_client->wait_for_service(std::chrono::seconds(5))) << "set_pause service not found";
  ASSERT_TRUE(reset_client->wait_for_service(std::chrono::seconds(5))) << "reset_world service not found";

  // Let the simulation run so state drifts from initial
  ASSERT_TRUE(wait_until([this]() { return sim_->data()->time > 0.5; }));
  EXPECT_NE(sim_->data()->qpos[0], 0.0) << "Is the simulation not running?";

  // Record the clock time before reset
  const double time_before_reset = sim_->data()->time;
  EXPECT_GT(time_before_reset, 0.0);

  // Pause before resetting so we can inspect state without it changing
  auto pause_req = std::make_shared<mujoco_ros2_control_msgs::srv::SetPause::Request>();
  pause_req->paused = true;
  auto pause_future = pause_client->async_send_request(pause_req);
  ASSERT_EQ(pause_future.wait_for(std::chrono::seconds(5)), std::future_status::ready);
  ASSERT_TRUE(pause_future.get()->success);

  // Wait for pause to take effect
  ASSERT_TRUE(wait_for_pause()) << "Simulation did not pause";

  // Call reset_world with no keyframe (resets to captured initial state)
  auto reset_req = std::make_shared<mujoco_ros2_control_msgs::srv::ResetWorld::Request>();
  auto reset_future = reset_client->async_send_request(reset_req);
  ASSERT_EQ(reset_future.wait_for(std::chrono::seconds(5)), std::future_status::ready);
  auto reset_resp = reset_future.get();
  ASSERT_TRUE(reset_resp->success) << "reset_world failed: " << reset_resp->message;

  // Verify state was restored to initial conditions from the start
  EXPECT_NEAR(sim_->data()->qpos[0], 0.0, TEST_TOLERANCE);
  EXPECT_NEAR(sim_->data()->qvel[0], 0.0, TEST_TOLERANCE);
  EXPECT_NEAR(sim_->data()->ctrl[0], 0.0, TEST_TOLERANCE);

  // Verify applied forces were cleared
  EXPECT_DOUBLE_EQ(sim_->data()->qfrc_applied[0], 0.0) << "qfrc_applied should be zero after reset";
  for (int i = 0; i < 6 * sim_->model()->nbody; ++i)
  {
    EXPECT_DOUBLE_EQ(sim_->data()->xfrc_applied[i], 0.0) << "xfrc_applied[" << i << "] should be zero after reset";
  }

  // Verify clock was NOT reset (continuity preserved)
  EXPECT_GE(sim_->data()->time, time_before_reset) << "Clock should not go backwards after reset";

  // Unpause and verify simulation continues from the reset state
  pause_req->paused = false;
  pause_future = pause_client->async_send_request(pause_req);
  ASSERT_EQ(pause_future.wait_for(std::chrono::seconds(5)), std::future_status::ready);
  ASSERT_TRUE(pause_future.get()->success);

  const double time_after_reset = sim_->data()->time;
  ASSERT_TRUE(wait_until([&]() { return sim_->data()->time > time_after_reset; }))
      << "Time should advance after unpausing post-reset";
}

TEST_F(MujocoSimulationTest, ResetWorldJointStateOverrides)
{
  ASSERT_TRUE(initialize_sim());
  ASSERT_TRUE(set_paused(true));

  // Capture a known initial state, then drift away from it.
  sim_->data()->qpos[0] = 0.0;
  sim_->data()->qvel[0] = 0.0;
  sim_->capture_initial_state();
  sim_->data()->qpos[0] = 0.3;
  sim_->data()->qvel[0] = 2.0;

  const std::string ns = std::string(node_->get_fully_qualified_name());
  auto client = node_->create_client<mujoco_ros2_control_msgs::srv::ResetWorld>(ns + "/reset_world");
  ASSERT_TRUE(client->wait_for_service(std::chrono::seconds(5)));

  auto req = std::make_shared<mujoco_ros2_control_msgs::srv::ResetWorld::Request>();
  req->state_overrides.joint_states.name = { "hinge" };
  req->state_overrides.joint_states.position = { 0.7 };
  req->state_overrides.joint_states.velocity = { 0.25 };

  auto future = client->async_send_request(req);
  ASSERT_EQ(future.wait_for(std::chrono::seconds(5)), std::future_status::ready);
  auto resp = future.get();
  ASSERT_TRUE(resp->success) << resp->message;

  EXPECT_DOUBLE_EQ(sim_->data()->qpos[0], 0.7) << "Override should win over the restored initial position";
  EXPECT_DOUBLE_EQ(sim_->data()->qvel[0], 0.25) << "Override should win over the restored initial velocity";
}

TEST_F(MujocoSimulationTest, ResetWorldKeyframeAndOverrides)
{
  ASSERT_TRUE(initialize_sim());
  ASSERT_TRUE(set_paused(true));

  const std::string ns = std::string(node_->get_fully_qualified_name());
  auto client = node_->create_client<mujoco_ros2_control_msgs::srv::ResetWorld>(ns + "/reset_world");
  ASSERT_TRUE(client->wait_for_service(std::chrono::seconds(5)));

  mujoco_ros2_control_msgs::msg::FreeJointState free_override;
  free_override.name = "free_object_2";
  free_override.pose.pose.position.x = 5.0;
  free_override.pose.pose.position.y = 6.0;
  free_override.pose.pose.position.z = 7.0;
  free_override.pose.pose.orientation.w = 1.0;

  auto req = std::make_shared<mujoco_ros2_control_msgs::srv::ResetWorld::Request>();
  req->keyframe = "home";  // hinge=0.5, free_object at (1,0,1), free_object_2 at (2,0,1)
  req->state_overrides.joint_states.name = { "hinge" };
  req->state_overrides.joint_states.position = { 0.25 };
  req->state_overrides.free_joints.push_back(free_override);

  auto future = client->async_send_request(req);
  ASSERT_EQ(future.wait_for(std::chrono::seconds(5)), std::future_status::ready);
  auto resp = future.get();
  ASSERT_TRUE(resp->success) << resp->message;

  // Overridden entries take their override values, everything else keeps the keyframe values.
  EXPECT_DOUBLE_EQ(sim_->data()->qpos[0], 0.25);
  EXPECT_DOUBLE_EQ(sim_->data()->qpos[1], 1.0);
  EXPECT_DOUBLE_EQ(sim_->data()->qpos[2], 0.0);
  EXPECT_DOUBLE_EQ(sim_->data()->qpos[3], 1.0);
  EXPECT_DOUBLE_EQ(sim_->data()->qpos[8], 5.0);
  EXPECT_DOUBLE_EQ(sim_->data()->qpos[9], 6.0);
  EXPECT_DOUBLE_EQ(sim_->data()->qpos[10], 7.0);
  // Unset twist in the free-joint override comes to rest, like set_free_joint_state.
  for (int i = 7; i < 13; ++i)
  {
    EXPECT_DOUBLE_EQ(sim_->data()->qvel[i], 0.0) << "qvel[" << i << "] should be zero";
  }
}

TEST_F(MujocoSimulationTest, ResetWorldOverridesResolveFramesAfterReset)
{
  ASSERT_TRUE(initialize_sim());
  ASSERT_TRUE(set_paused(true));

  // Move "free_object" away from its keyframe pose so pre-reset and post-reset frame
  // resolution give different answers.
  sim_->data()->qpos[1] = 10.0;
  mj_forward(sim_->model(), sim_->data());

  const std::string ns = std::string(node_->get_fully_qualified_name());
  auto client = node_->create_client<mujoco_ros2_control_msgs::srv::ResetWorld>(ns + "/reset_world");
  ASSERT_TRUE(client->wait_for_service(std::chrono::seconds(5)));

  mujoco_ros2_control_msgs::msg::FreeJointState free_override;
  free_override.name = "free_object_2";
  free_override.pose.header.frame_id = "free_object";
  free_override.pose.pose.position.x = 0.5;
  free_override.pose.pose.orientation.w = 1.0;

  auto req = std::make_shared<mujoco_ros2_control_msgs::srv::ResetWorld::Request>();
  req->keyframe = "home";  // puts free_object at (1,0,1)
  req->state_overrides.free_joints.push_back(free_override);

  auto future = client->async_send_request(req);
  ASSERT_EQ(future.wait_for(std::chrono::seconds(5)), std::future_status::ready);
  auto resp = future.get();
  ASSERT_TRUE(resp->success) << resp->message;

  // Resolved against free_object's post-reset pose (1,0,1), not its pre-reset pose (10,0,1).
  EXPECT_NEAR(sim_->data()->qpos[8], 1.5, TEST_TOLERANCE);
  EXPECT_NEAR(sim_->data()->qpos[9], 0.0, TEST_TOLERANCE);
  EXPECT_NEAR(sim_->data()->qpos[10], 1.0, TEST_TOLERANCE);
}

TEST_F(MujocoSimulationTest, ResetWorldInvalidOverrides)
{
  ASSERT_TRUE(initialize_sim());
  ASSERT_TRUE(set_paused(true));

  sim_->data()->qpos[0] = 0.0;
  sim_->capture_initial_state();
  sim_->data()->qpos[0] = 0.3;

  const std::string ns = std::string(node_->get_fully_qualified_name());
  auto client = node_->create_client<mujoco_ros2_control_msgs::srv::ResetWorld>(ns + "/reset_world");
  ASSERT_TRUE(client->wait_for_service(std::chrono::seconds(5)));

  auto req = std::make_shared<mujoco_ros2_control_msgs::srv::ResetWorld::Request>();
  req->state_overrides.joint_states.name = { "hinge", "nonexistent_joint" };
  req->state_overrides.joint_states.position = { 0.7, 0.1 };

  auto future = client->async_send_request(req);
  ASSERT_EQ(future.wait_for(std::chrono::seconds(5)), std::future_status::ready);
  auto resp = future.get();
  EXPECT_FALSE(resp->success);
  EXPECT_FALSE(resp->message.empty());
  EXPECT_DOUBLE_EQ(sim_->data()->qpos[0], 0.3) << "An invalid override must leave the world un-reset";
}

TEST_F(MujocoSimulationTest, ResetWorldMalformedOverrides)
{
  ASSERT_TRUE(initialize_sim());
  ASSERT_TRUE(set_paused(true));

  const std::string ns = std::string(node_->get_fully_qualified_name());
  auto client = node_->create_client<mujoco_ros2_control_msgs::srv::ResetWorld>(ns + "/reset_world");
  ASSERT_TRUE(client->wait_for_service(std::chrono::seconds(5)));

  // Mismatched position length.
  auto req = std::make_shared<mujoco_ros2_control_msgs::srv::ResetWorld::Request>();
  req->state_overrides.joint_states.name = { "hinge" };
  req->state_overrides.joint_states.position = { 0.1, 0.2 };
  auto future = client->async_send_request(req);
  ASSERT_EQ(future.wait_for(std::chrono::seconds(5)), std::future_status::ready);
  auto resp = future.get();
  EXPECT_FALSE(resp->success);
  EXPECT_FALSE(resp->message.empty());

  // Effort overrides are not supported.
  req = std::make_shared<mujoco_ros2_control_msgs::srv::ResetWorld::Request>();
  req->state_overrides.joint_states.name = { "hinge" };
  req->state_overrides.joint_states.effort = { 1.0 };
  future = client->async_send_request(req);
  ASSERT_EQ(future.wait_for(std::chrono::seconds(5)), std::future_status::ready);
  resp = future.get();
  EXPECT_FALSE(resp->success);
  EXPECT_FALSE(resp->message.empty());
}

TEST_F(MujocoSimulationTest, ResetWorldFreeJointInJointState)
{
  ASSERT_TRUE(initialize_sim());
  ASSERT_TRUE(set_paused(true));

  const std::string ns = std::string(node_->get_fully_qualified_name());
  auto client = node_->create_client<mujoco_ros2_control_msgs::srv::ResetWorld>(ns + "/reset_world");
  ASSERT_TRUE(client->wait_for_service(std::chrono::seconds(5)));

  auto req = std::make_shared<mujoco_ros2_control_msgs::srv::ResetWorld::Request>();
  req->state_overrides.joint_states.name = { "free_object_joint" };
  req->state_overrides.joint_states.position = { 1.0 };

  auto future = client->async_send_request(req);
  ASSERT_EQ(future.wait_for(std::chrono::seconds(5)), std::future_status::ready);
  auto resp = future.get();
  EXPECT_FALSE(resp->success);
  EXPECT_NE(resp->message.find("state_overrides.free_joints"), std::string::npos)
      << "Message should point free joints at the state_overrides.free_joints field, got: " << resp->message;
}

TEST_F(MujocoSimulationTest, SetFreeJointStateSetsPoseAndVelocity)
{
  ASSERT_TRUE(initialize_sim());

  const std::string ns = std::string(node_->get_fully_qualified_name());
  auto client = node_->create_client<mujoco_ros2_control_msgs::srv::SetFreeJointState>(ns + "/set_free_joint_state");
  ASSERT_TRUE(client->wait_for_service(std::chrono::seconds(5))) << "set_free_joint_state service not found";

  // Before the service call
  const int qpos_adr = 1;
  const int qvel_adr = 1;
  EXPECT_DOUBLE_EQ(sim_->data()->qpos[qpos_adr + 0], 1.0);
  EXPECT_DOUBLE_EQ(sim_->data()->qpos[qpos_adr + 1], 0.0);
  EXPECT_DOUBLE_EQ(sim_->data()->qpos[qpos_adr + 2], 1.0);
  EXPECT_NEAR(sim_->data()->qpos[qpos_adr + 3], 1.0, TEST_TOLERANCE);  // w
  EXPECT_NEAR(sim_->data()->qpos[qpos_adr + 4], 0.0, TEST_TOLERANCE);  // x
  EXPECT_NEAR(sim_->data()->qpos[qpos_adr + 5], 0.0, TEST_TOLERANCE);  // y
  EXPECT_NEAR(sim_->data()->qpos[qpos_adr + 6], 0.0, TEST_TOLERANCE);  // z

  EXPECT_DOUBLE_EQ(sim_->data()->qvel[qvel_adr + 0], 0.0);
  EXPECT_DOUBLE_EQ(sim_->data()->qvel[qvel_adr + 5], 0.0);

  mujoco_ros2_control_msgs::msg::FreeJointState entry;
  entry.name = "free_object";
  entry.pose.pose.position.x = 2.0;
  entry.pose.pose.position.y = 3.0;
  entry.pose.pose.position.z = 4.0;
  entry.pose.pose.orientation.w = std::sqrt(0.5);
  entry.pose.pose.orientation.x = std::sqrt(0.5);
  entry.pose.pose.orientation.y = 0.0;
  entry.pose.pose.orientation.z = 0.0;
  entry.twist.twist.linear.x = 0.1;
  entry.twist.twist.angular.z = 0.2;

  auto req = std::make_shared<mujoco_ros2_control_msgs::srv::SetFreeJointState::Request>();
  req->free_joints.push_back(entry);

  auto future = client->async_send_request(req);
  ASSERT_EQ(future.wait_for(std::chrono::seconds(5)), std::future_status::ready);
  auto resp = future.get();
  ASSERT_TRUE(resp->success) << resp->message;

  EXPECT_DOUBLE_EQ(sim_->data()->qpos[qpos_adr + 0], 2.0);
  EXPECT_DOUBLE_EQ(sim_->data()->qpos[qpos_adr + 1], 3.0);
  EXPECT_DOUBLE_EQ(sim_->data()->qpos[qpos_adr + 2], 4.0);
  EXPECT_NEAR(sim_->data()->qpos[qpos_adr + 3], std::sqrt(0.5), TEST_TOLERANCE);  // w
  EXPECT_NEAR(sim_->data()->qpos[qpos_adr + 4], std::sqrt(0.5), TEST_TOLERANCE);  // x
  EXPECT_NEAR(sim_->data()->qpos[qpos_adr + 5], 0.0, TEST_TOLERANCE);             // y
  EXPECT_NEAR(sim_->data()->qpos[qpos_adr + 6], 0.0, TEST_TOLERANCE);             // z

  EXPECT_DOUBLE_EQ(sim_->data()->qvel[qvel_adr + 0], 0.1);
  EXPECT_DOUBLE_EQ(sim_->data()->qvel[qvel_adr + 5], 0.2);
}

TEST_F(MujocoSimulationTest, SetFreeJointStateDefaultsToZeroVelocity)
{
  ASSERT_TRUE(initialize_sim());

  // Give the free object a non-zero velocity before resetting.
  sim_->data()->qvel[1] = 5.0;

  const std::string ns = std::string(node_->get_fully_qualified_name());
  auto client = node_->create_client<mujoco_ros2_control_msgs::srv::SetFreeJointState>(ns + "/set_free_joint_state");
  ASSERT_TRUE(client->wait_for_service(std::chrono::seconds(5)));

  mujoco_ros2_control_msgs::msg::FreeJointState entry;
  entry.name = "free_object";
  entry.pose.pose.position.z = 2.0;
  // twist left at its default (all-zero) -- object should come to rest.

  auto req = std::make_shared<mujoco_ros2_control_msgs::srv::SetFreeJointState::Request>();
  req->free_joints.push_back(entry);

  auto future = client->async_send_request(req);
  ASSERT_EQ(future.wait_for(std::chrono::seconds(5)), std::future_status::ready);
  ASSERT_TRUE(future.get()->success);

  for (int i = 1; i < 7; ++i)
  {
    EXPECT_DOUBLE_EQ(sim_->data()->qvel[i], 0.0) << "qvel[" << i << "] should be reset to zero";
  }
}

TEST_F(MujocoSimulationTest, SetFreeJointStateRejectsUnknownBody)
{
  ASSERT_TRUE(initialize_sim());

  const std::string ns = std::string(node_->get_fully_qualified_name());
  auto client = node_->create_client<mujoco_ros2_control_msgs::srv::SetFreeJointState>(ns + "/set_free_joint_state");
  ASSERT_TRUE(client->wait_for_service(std::chrono::seconds(5)));

  mujoco_ros2_control_msgs::msg::FreeJointState entry;
  entry.name = "nonexistent_body";

  auto req = std::make_shared<mujoco_ros2_control_msgs::srv::SetFreeJointState::Request>();
  req->free_joints.push_back(entry);

  auto future = client->async_send_request(req);
  ASSERT_EQ(future.wait_for(std::chrono::seconds(5)), std::future_status::ready);
  auto resp = future.get();
  EXPECT_FALSE(resp->success);
  EXPECT_FALSE(resp->message.empty());
}

TEST_F(MujocoSimulationTest, SetFreeJointStateRejectsNonFreeBody)
{
  ASSERT_TRUE(initialize_sim());

  const std::string ns = std::string(node_->get_fully_qualified_name());
  auto client = node_->create_client<mujoco_ros2_control_msgs::srv::SetFreeJointState>(ns + "/set_free_joint_state");
  ASSERT_TRUE(client->wait_for_service(std::chrono::seconds(5)));

  mujoco_ros2_control_msgs::msg::FreeJointState entry;
  entry.name = "pendulum";  // driven by a hinge joint, not a free joint

  auto req = std::make_shared<mujoco_ros2_control_msgs::srv::SetFreeJointState::Request>();
  req->free_joints.push_back(entry);

  auto future = client->async_send_request(req);
  ASSERT_EQ(future.wait_for(std::chrono::seconds(5)), std::future_status::ready);
  auto resp = future.get();
  EXPECT_FALSE(resp->success);
  EXPECT_FALSE(resp->message.empty());
}

TEST_F(MujocoSimulationTest, SetFreeJointStateRelativeToBody)
{
  ASSERT_TRUE(initialize_sim());

  // Rotate "pendulum" 90 degrees about Y, so its world pose becomes pos=(0,0,1),
  // quat=(cos45,0,sin45,0).
  sim_->data()->qpos[0] = M_PI_2;
  mj_forward(sim_->model(), sim_->data());

  const std::string ns = std::string(node_->get_fully_qualified_name());
  auto client = node_->create_client<mujoco_ros2_control_msgs::srv::SetFreeJointState>(ns + "/set_free_joint_state");
  ASSERT_TRUE(client->wait_for_service(std::chrono::seconds(5)));

  mujoco_ros2_control_msgs::msg::FreeJointState entry;
  entry.name = "free_object";
  entry.pose.header.frame_id = "pendulum";
  entry.pose.pose.position.x = 1.0;  // rotated 90 deg about Y: (1,0,0) -> (0,0,-1)
  entry.pose.pose.orientation.w = 1.0;
  // twist.header.frame_id left empty: world frame, independent of pose's reference frame.
  entry.twist.twist.linear.x = 5.0;

  auto req = std::make_shared<mujoco_ros2_control_msgs::srv::SetFreeJointState::Request>();
  req->free_joints.push_back(entry);

  auto future = client->async_send_request(req);
  ASSERT_EQ(future.wait_for(std::chrono::seconds(5)), std::future_status::ready);
  auto resp = future.get();
  ASSERT_TRUE(resp->success) << resp->message;

  const int qpos_adr = 1;
  const int qvel_adr = 1;
  // world_pos = ref_pos(0,0,1) + rotate(rel_pos(1,0,0)) = (0,0,0)
  EXPECT_NEAR(sim_->data()->qpos[qpos_adr + 0], 0.0, TEST_TOLERANCE);
  EXPECT_NEAR(sim_->data()->qpos[qpos_adr + 1], 0.0, TEST_TOLERANCE);
  EXPECT_NEAR(sim_->data()->qpos[qpos_adr + 2], 0.0, TEST_TOLERANCE);
  // world_quat = ref_quat * identity = ref_quat = (cos45, 0, sin45, 0)
  EXPECT_NEAR(sim_->data()->qpos[qpos_adr + 3], std::sqrt(0.5), TEST_TOLERANCE);  // w
  EXPECT_NEAR(sim_->data()->qpos[qpos_adr + 4], 0.0, TEST_TOLERANCE);             // x
  EXPECT_NEAR(sim_->data()->qpos[qpos_adr + 5], std::sqrt(0.5), TEST_TOLERANCE);  // y
  EXPECT_NEAR(sim_->data()->qpos[qpos_adr + 6], 0.0, TEST_TOLERANCE);             // z
  // twist stayed in the world frame.
  EXPECT_NEAR(sim_->data()->qvel[qvel_adr + 0], 5.0, TEST_TOLERANCE);
}

TEST_F(MujocoSimulationTest, SetFreeJointStateRelativeToBodyRotatesTwist)
{
  ASSERT_TRUE(initialize_sim());

  // Same rotated "pendulum" setup as SetFreeJointStateRelativeToBody, but here it is the
  // twist's reference frame -- pose.header.frame_id is left empty (world) to show they
  // resolve independently.
  sim_->data()->qpos[0] = M_PI_2;
  mj_forward(sim_->model(), sim_->data());

  const std::string ns = std::string(node_->get_fully_qualified_name());
  auto client = node_->create_client<mujoco_ros2_control_msgs::srv::SetFreeJointState>(ns + "/set_free_joint_state");
  ASSERT_TRUE(client->wait_for_service(std::chrono::seconds(5)));

  mujoco_ros2_control_msgs::msg::FreeJointState entry;
  entry.name = "free_object";
  entry.twist.header.frame_id = "pendulum";
  entry.twist.twist.linear.x = 1.0;   // rotated 90 deg about Y: (1,0,0) -> (0,0,-1)
  entry.twist.twist.angular.x = 1.0;  // rotated 90 deg about Y: (1,0,0) -> (0,0,-1)

  auto req = std::make_shared<mujoco_ros2_control_msgs::srv::SetFreeJointState::Request>();
  req->free_joints.push_back(entry);

  auto future = client->async_send_request(req);
  ASSERT_EQ(future.wait_for(std::chrono::seconds(5)), std::future_status::ready);
  auto resp = future.get();
  ASSERT_TRUE(resp->success) << resp->message;

  const int qvel_adr = 1;
  EXPECT_NEAR(sim_->data()->qvel[qvel_adr + 0], 0.0, TEST_TOLERANCE);
  EXPECT_NEAR(sim_->data()->qvel[qvel_adr + 1], 0.0, TEST_TOLERANCE);
  EXPECT_NEAR(sim_->data()->qvel[qvel_adr + 2], -1.0, TEST_TOLERANCE);
  EXPECT_NEAR(sim_->data()->qvel[qvel_adr + 3], 0.0, TEST_TOLERANCE);
  EXPECT_NEAR(sim_->data()->qvel[qvel_adr + 4], 0.0, TEST_TOLERANCE);
  EXPECT_NEAR(sim_->data()->qvel[qvel_adr + 5], -1.0, TEST_TOLERANCE);
}

TEST_F(MujocoSimulationTest, SetFreeJointStateRejectsUnknownPoseFrame)
{
  ASSERT_TRUE(initialize_sim());

  const std::string ns = std::string(node_->get_fully_qualified_name());
  auto client = node_->create_client<mujoco_ros2_control_msgs::srv::SetFreeJointState>(ns + "/set_free_joint_state");
  ASSERT_TRUE(client->wait_for_service(std::chrono::seconds(5)));

  const int qpos_adr = 1;
  const double original_x = sim_->data()->qpos[qpos_adr + 0];

  mujoco_ros2_control_msgs::msg::FreeJointState entry;
  entry.name = "free_object";
  entry.pose.header.frame_id = "nonexistent_body";
  entry.pose.pose.position.x = 5.0;

  auto req = std::make_shared<mujoco_ros2_control_msgs::srv::SetFreeJointState::Request>();
  req->free_joints.push_back(entry);

  auto future = client->async_send_request(req);
  ASSERT_EQ(future.wait_for(std::chrono::seconds(5)), std::future_status::ready);
  auto resp = future.get();
  EXPECT_FALSE(resp->success);
  EXPECT_FALSE(resp->message.empty());
  EXPECT_DOUBLE_EQ(sim_->data()->qpos[qpos_adr + 0], original_x);
}

TEST_F(MujocoSimulationTest, SetFreeJointStateRejectsUnknownTwistFrame)
{
  ASSERT_TRUE(initialize_sim());

  const std::string ns = std::string(node_->get_fully_qualified_name());
  auto client = node_->create_client<mujoco_ros2_control_msgs::srv::SetFreeJointState>(ns + "/set_free_joint_state");
  ASSERT_TRUE(client->wait_for_service(std::chrono::seconds(5)));

  const int qpos_adr = 1;
  const int qvel_adr = 1;
  const double original_x = sim_->data()->qpos[qpos_adr + 0];
  const double original_qvel_x = sim_->data()->qvel[qvel_adr + 0];

  mujoco_ros2_control_msgs::msg::FreeJointState entry;
  entry.name = "free_object";
  entry.pose.pose.position.x = 5.0;  // valid, world-frame pose -- must not be applied either
  entry.twist.header.frame_id = "nonexistent_body";
  entry.twist.twist.linear.x = 1.0;

  auto req = std::make_shared<mujoco_ros2_control_msgs::srv::SetFreeJointState::Request>();
  req->free_joints.push_back(entry);

  auto future = client->async_send_request(req);
  ASSERT_EQ(future.wait_for(std::chrono::seconds(5)), std::future_status::ready);
  auto resp = future.get();
  EXPECT_FALSE(resp->success);
  EXPECT_FALSE(resp->message.empty());
  EXPECT_DOUBLE_EQ(sim_->data()->qpos[qpos_adr + 0], original_x);
  EXPECT_DOUBLE_EQ(sim_->data()->qvel[qvel_adr + 0], original_qvel_x);
}

TEST_F(MujocoSimulationTest, SetFreeJointStateSetsMultipleBodies)
{
  ASSERT_TRUE(initialize_sim());

  const std::string ns = std::string(node_->get_fully_qualified_name());
  auto client = node_->create_client<mujoco_ros2_control_msgs::srv::SetFreeJointState>(ns + "/set_free_joint_state");
  ASSERT_TRUE(client->wait_for_service(std::chrono::seconds(5)));

  // Resolve addresses per body rather than hardcoding, since "free_object_2" sits after
  // "free_object" (qpos 8 / qvel 7) in the model's qpos/qvel layout.
  const int free_object_id = mj_name2id(sim_->model(), mjOBJ_BODY, "free_object");
  const int free_object_2_id = mj_name2id(sim_->model(), mjOBJ_BODY, "free_object_2");
  ASSERT_NE(free_object_id, -1);
  ASSERT_NE(free_object_2_id, -1);

  auto qpos_adr_for = [&](int body_id) {
    for (int i = 0; i < sim_->model()->njnt; ++i)
    {
      if (sim_->model()->jnt_bodyid[i] == body_id && sim_->model()->jnt_type[i] == mjJNT_FREE)
      {
        return sim_->model()->jnt_qposadr[i];
      }
    }
    return -1;
  };
  auto qvel_adr_for = [&](int body_id) {
    for (int i = 0; i < sim_->model()->njnt; ++i)
    {
      if (sim_->model()->jnt_bodyid[i] == body_id && sim_->model()->jnt_type[i] == mjJNT_FREE)
      {
        return sim_->model()->jnt_dofadr[i];
      }
    }
    return -1;
  };

  const int qpos_adr_1 = qpos_adr_for(free_object_id);
  const int qvel_adr_1 = qvel_adr_for(free_object_id);
  const int qpos_adr_2 = qpos_adr_for(free_object_2_id);
  const int qvel_adr_2 = qvel_adr_for(free_object_2_id);
  ASSERT_NE(qpos_adr_1, -1);
  ASSERT_NE(qpos_adr_2, -1);

  mujoco_ros2_control_msgs::msg::FreeJointState entry_1;
  entry_1.name = "free_object";
  entry_1.pose.pose.position.x = 2.0;
  entry_1.pose.pose.position.y = 3.0;
  entry_1.pose.pose.position.z = 4.0;
  entry_1.pose.pose.orientation.w = 1.0;
  entry_1.twist.twist.linear.x = 0.1;

  mujoco_ros2_control_msgs::msg::FreeJointState entry_2;
  entry_2.name = "free_object_2";
  entry_2.pose.pose.position.x = 5.0;
  entry_2.pose.pose.position.y = 6.0;
  entry_2.pose.pose.position.z = 7.0;
  entry_2.pose.pose.orientation.w = 1.0;
  entry_2.twist.twist.linear.y = 0.2;

  auto req = std::make_shared<mujoco_ros2_control_msgs::srv::SetFreeJointState::Request>();
  req->free_joints.push_back(entry_1);
  req->free_joints.push_back(entry_2);

  auto future = client->async_send_request(req);
  ASSERT_EQ(future.wait_for(std::chrono::seconds(5)), std::future_status::ready);
  auto resp = future.get();
  ASSERT_TRUE(resp->success) << resp->message;

  EXPECT_DOUBLE_EQ(sim_->data()->qpos[qpos_adr_1 + 0], 2.0);
  EXPECT_DOUBLE_EQ(sim_->data()->qpos[qpos_adr_1 + 1], 3.0);
  EXPECT_DOUBLE_EQ(sim_->data()->qpos[qpos_adr_1 + 2], 4.0);
  EXPECT_DOUBLE_EQ(sim_->data()->qvel[qvel_adr_1 + 0], 0.1);

  EXPECT_DOUBLE_EQ(sim_->data()->qpos[qpos_adr_2 + 0], 5.0);
  EXPECT_DOUBLE_EQ(sim_->data()->qpos[qpos_adr_2 + 1], 6.0);
  EXPECT_DOUBLE_EQ(sim_->data()->qpos[qpos_adr_2 + 2], 7.0);
  EXPECT_DOUBLE_EQ(sim_->data()->qvel[qvel_adr_2 + 1], 0.2);
}

TEST_F(MujocoSimulationTest, SetFreeJointStateRejectsBatchAtomically)
{
  ASSERT_TRUE(initialize_sim());

  const std::string ns = std::string(node_->get_fully_qualified_name());
  auto client = node_->create_client<mujoco_ros2_control_msgs::srv::SetFreeJointState>(ns + "/set_free_joint_state");
  ASSERT_TRUE(client->wait_for_service(std::chrono::seconds(5)));

  const int qpos_adr = 1;
  const double original_x = sim_->data()->qpos[qpos_adr + 0];

  // The invalid second entry must reject the whole batch, leaving the first untouched.
  mujoco_ros2_control_msgs::msg::FreeJointState valid_entry;
  valid_entry.name = "free_object";
  valid_entry.pose.pose.position.x = 42.0;

  mujoco_ros2_control_msgs::msg::FreeJointState invalid_entry;
  invalid_entry.name = "nonexistent_body";

  auto req = std::make_shared<mujoco_ros2_control_msgs::srv::SetFreeJointState::Request>();
  req->free_joints.push_back(valid_entry);
  req->free_joints.push_back(invalid_entry);

  auto future = client->async_send_request(req);
  ASSERT_EQ(future.wait_for(std::chrono::seconds(5)), std::future_status::ready);
  auto resp = future.get();
  EXPECT_FALSE(resp->success);
  EXPECT_FALSE(resp->message.empty());
  EXPECT_DOUBLE_EQ(sim_->data()->qpos[qpos_adr + 0], original_x)
      << "Valid entry must not be applied when another entry in the same batch is invalid";
}

int main(int argc, char** argv)
{
  ::testing::InitGoogleTest(&argc, argv);
  int result = RUN_ALL_TESTS();
  return result;
}
