^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package hardware_interface_testing
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

4.45.2 (2026-05-12)
-------------------
* Fix pre-commit of ament_cppcheck on rolling Resolute Raccoon (`#3276 <https://github.com/ros-controls/ros2_control/issues/3276>`_) (`#3277 <https://github.com/ros-controls/ros2_control/issues/3277>`_)
* Add tests for duplicate prevention (fixes `#2952 <https://github.com/ros-controls/ros2_control/issues/2952>`_) (`#3189 <https://github.com/ros-controls/ros2_control/issues/3189>`_) (`#3262 <https://github.com/ros-controls/ros2_control/issues/3262>`_)
* Contributors: mergify[bot]

4.45.1 (2026-04-24)
-------------------

4.45.0 (2026-04-17)
-------------------
* Fix RCLCPP_VERSION_GTE for add_node (backport `#3198 <https://github.com/ros-controls/ros2_control/issues/3198>`_) (`#3200 <https://github.com/ros-controls/ros2_control/issues/3200>`_)
* Fix API breaking change of Executor::add_node (backport `#3080 <https://github.com/ros-controls/ros2_control/issues/3080>`_) (`#3190 <https://github.com/ros-controls/ros2_control/issues/3190>`_)
* Contributors: mergify[bot]

4.44.0 (2026-04-02)
-------------------
* Fix forwarding handle_exceptions parameter to resource manager (`#3107 <https://github.com/ros-controls/ros2_control/issues/3107>`_) (`#3117 <https://github.com/ros-controls/ros2_control/issues/3117>`_)
* Consistently add <cmath> include with define for windows (backport `#3061 <https://github.com/ros-controls/ros2_control/issues/3061>`_) (`#3066 <https://github.com/ros-controls/ros2_control/issues/3066>`_)
* Bump version of pre-commit hooks (`#3055 <https://github.com/ros-controls/ros2_control/issues/3055>`_) (`#3057 <https://github.com/ros-controls/ros2_control/issues/3057>`_)
* Contributors: mergify[bot]

4.43.0 (2026-02-03)
-------------------

4.42.2 (2026-01-10)
-------------------

4.42.1 (2025-12-30)
-------------------

4.42.0 (2025-12-29)
-------------------

4.41.0 (2025-12-10)
-------------------
* Fix the blocking calls of lifecycle_state in the real-time loop (backport `#2884 <https://github.com/ros-controls/ros2_control/issues/2884>`_) (`#2890 <https://github.com/ros-controls/ros2_control/issues/2890>`_)
* Contributors: mergify[bot]

4.40.0 (2025-12-01)
-------------------
* Publish all castable data types to pal_statistics (backport `#2633 <https://github.com/ros-controls/ros2_control/issues/2633>`_) (`#2855 <https://github.com/ros-controls/ros2_control/issues/2855>`_)
* Contributors: mergify[bot]

4.39.2 (2025-11-09)
-------------------
* Avoid deadlocks for failed command switching (`#2774 <https://github.com/ros-controls/ros2_control/issues/2774>`_) (`#2796 <https://github.com/ros-controls/ros2_control/issues/2796>`_)
* Contributors: mergify[bot]

4.39.1 (2025-11-03)
-------------------

4.39.0 (2025-10-27)
-------------------

4.38.0 (2025-10-03)
-------------------
* Add parameter to allow controllers with inactive hardware components (`#2501 <https://github.com/ros-controls/ros2_control/issues/2501>`_) (`#2584 <https://github.com/ros-controls/ros2_control/issues/2584>`_)
* Fix exclusive hardware control mode switching on controller failed activation (`#1522 <https://github.com/ros-controls/ros2_control/issues/1522>`_) (`#2580 <https://github.com/ros-controls/ros2_control/issues/2580>`_)
* Fix shadowed variables, redefinition and old-style casts (`#2569 <https://github.com/ros-controls/ros2_control/issues/2569>`_) (`#2570 <https://github.com/ros-controls/ros2_control/issues/2570>`_)
* Contributors: mergify[bot]

4.37.0 (2025-09-12)
-------------------

4.36.0 (2025-08-26)
-------------------
* Supress deprecated RM API warnings in the tests (`#2428 <https://github.com/ros-controls/ros2_control/issues/2428>`_) (`#2455 <https://github.com/ros-controls/ros2_control/issues/2455>`_)
* Unify `write` behavior between Actuator and System hardware interfaces (`#2453 <https://github.com/ros-controls/ros2_control/issues/2453>`_) (`#2457 <https://github.com/ros-controls/ros2_control/issues/2457>`_)
* Contributors: mergify[bot]

4.35.0 (2025-07-31)
-------------------
* Fix the prepare_command_mode_switch behaviour when HW is INACTIVE (`#2347 <https://github.com/ros-controls/ros2_control/issues/2347>`_) (`#2418 <https://github.com/ros-controls/ros2_control/issues/2418>`_)
* Addition of a Default Node for Hardware Component (`#2348 <https://github.com/ros-controls/ros2_control/issues/2348>`_) (`#2413 <https://github.com/ros-controls/ros2_control/issues/2413>`_)
* Contributors: mergify[bot]

4.34.0 (2025-07-21)
-------------------
* Add deprecations to old methods not using Structs  (backport `#2344 <https://github.com/ros-controls/ros2_control/issues/2344>`_) (`#2359 <https://github.com/ros-controls/ros2_control/issues/2359>`_)
* Contributors: mergify[bot]

4.33.0 (2025-07-02)
-------------------
* Deactivate controllers with command interfaces to hardware on DEACTIVATE (`#2334 <https://github.com/ros-controls/ros2_control/issues/2334>`_) (`#2341 <https://github.com/ros-controls/ros2_control/issues/2341>`_)
* Contributors: mergify[bot]

4.32.0 (2025-06-06)
-------------------

4.31.0 (2025-05-24)
-------------------
* [RM] Isolate start and stop interfaces for each Hardware Component (backport `#2120 <https://github.com/ros-controls/ros2_control/issues/2120>`_) (`#2273 <https://github.com/ros-controls/ros2_control/issues/2273>`_)
* Use target_link_libraries instead of ament_target_dependencies (`#2266 <https://github.com/ros-controls/ros2_control/issues/2266>`_) (`#2271 <https://github.com/ros-controls/ros2_control/issues/2271>`_)
* Contributors: mergify[bot]

4.30.0 (2025-05-21)
-------------------
* Statically allocate string concatenations using FMT formatting (`#2205 <https://github.com/ros-controls/ros2_control/issues/2205>`_) (`#2249 <https://github.com/ros-controls/ros2_control/issues/2249>`_)
* Suppress the deprecation warnings of the hardware_interface API (`#2223 <https://github.com/ros-controls/ros2_control/issues/2223>`_) (`#2247 <https://github.com/ros-controls/ros2_control/issues/2247>`_)
* Contributors: mergify[bot]

4.29.0 (2025-05-04)
-------------------
* [Diagnostics] Add diagnostics of execution time and periodicity of the hardware components (`#2086 <https://github.com/ros-controls/ros2_control/issues/2086>`_)
* Contributors: Sai Kishor Kothakota

4.28.1 (2025-04-17)
-------------------
* Use previous command to enforce the joint limits on position interfaces (`#2183 <https://github.com/ros-controls/ros2_control/issues/2183>`_)
* Contributors: Sai Kishor Kothakota

4.28.0 (2025-04-10)
-------------------
* Integrate joint limit enforcement into `ros2_control` framework functional with Async controllers and components  (`#2047 <https://github.com/ros-controls/ros2_control/issues/2047>`_)
* Make all packages use gmock, not gtest (`#2162 <https://github.com/ros-controls/ros2_control/issues/2162>`_)
* Bump version of pre-commit hooks (`#2156 <https://github.com/ros-controls/ros2_control/issues/2156>`_)
* Use ros2_control_cmake (`#2134 <https://github.com/ros-controls/ros2_control/issues/2134>`_)
* [Handle] Add support for booleans in the handles (`#2065 <https://github.com/ros-controls/ros2_control/issues/2065>`_)
* Improve package descriptions & update maintainers (`#2103 <https://github.com/ros-controls/ros2_control/issues/2103>`_)
* [RM] Fix skipped cycles by adjusting `rw_rate` handling (`#2091 <https://github.com/ros-controls/ros2_control/issues/2091>`_)
* Contributors: Bence Magyar, Christoph Fröhlich, RobertWilbrandt, Sai Kishor Kothakota, Soham Patil, github-actions[bot]

4.27.0 (2025-03-01)
-------------------
* [Handle] Use `get_optional` instead of `get_value<double>` (`#2061 <https://github.com/ros-controls/ros2_control/issues/2061>`_)
* Add new `get_value` API for Handles and Interfaces (`#1976 <https://github.com/ros-controls/ros2_control/issues/1976>`_)
* [CM] Fix the controller deactivation on the control cycles returning ERROR  (`#1756 <https://github.com/ros-controls/ros2_control/issues/1756>`_)
* Contributors: Sai Kishor Kothakota

4.26.0 (2025-02-07)
-------------------
* Fix memory leak in the ros2_control (`#2033 <https://github.com/ros-controls/ros2_control/issues/2033>`_)
* Contributors: Sai Kishor Kothakota

4.25.0 (2025-01-29)
-------------------

4.24.0 (2025-01-13)
-------------------

4.23.0 (2024-12-29)
-------------------

4.22.0 (2024-12-20)
-------------------
* Propagate read/write rate to the HardwareInfo properly (`#1928 <https://github.com/ros-controls/ros2_control/issues/1928>`_)
* Async Hardware Components (`#1567 <https://github.com/ros-controls/ros2_control/issues/1567>`_)
* Contributors: Sai Kishor Kothakota

4.21.0 (2024-12-06)
-------------------
* [Feature] Choose different read and write rate for the hardware components (`#1570 <https://github.com/ros-controls/ros2_control/issues/1570>`_)
* Contributors: Sai Kishor Kothakota

4.20.0 (2024-11-08)
-------------------

4.19.0 (2024-10-26)
-------------------

4.18.0 (2024-10-07)
-------------------
* Adapt controller Reference/StateInterfaces to New Way of Exporting (variant support) (`#1689 <https://github.com/ros-controls/ros2_control/issues/1689>`_)
* Contributors: Manuel Muth

4.17.0 (2024-09-11)
-------------------

4.16.1 (2024-08-24)
-------------------

4.16.0 (2024-08-22)
-------------------

4.15.0 (2024-08-05)
-------------------
* [RM] Add `get_hardware_info` method to the Hardware Components (`#1643 <https://github.com/ros-controls/ros2_control/issues/1643>`_)
* Contributors: Sai Kishor Kothakota

4.14.0 (2024-07-23)
-------------------
* Unused header cleanup (`#1627 <https://github.com/ros-controls/ros2_control/issues/1627>`_)
* Fix typos in test_resource_manager.cpp (`#1609 <https://github.com/ros-controls/ros2_control/issues/1609>`_)
* Contributors: Henry Moore, Parker Drouillard

4.13.0 (2024-07-08)
-------------------
* [ResourceManager] Propagate access to logger and clock interfaces to HardwareComponent (`#1585 <https://github.com/ros-controls/ros2_control/issues/1585>`_)
* Contributors: Sai Kishor Kothakota

4.12.0 (2024-07-01)
-------------------
* [RM] Rename `load_urdf` method to `load_and_initialize_components` and add error handling there to avoid stack crashing when error happens. (`#1354 <https://github.com/ros-controls/ros2_control/issues/1354>`_)
* Contributors: Dr. Denis

4.11.0 (2024-05-14)
-------------------

4.10.0 (2024-05-08)
-------------------

4.9.0 (2024-04-30)
------------------
* Component parser: Get mimic information from URDF (`#1256 <https://github.com/ros-controls/ros2_control/issues/1256>`_)
* Contributors: Christoph Fröhlich

4.8.0 (2024-03-27)
------------------

4.7.0 (2024-03-22)
------------------

4.6.0 (2024-03-02)
------------------
* Add -Werror=missing-braces to compile options (`#1423 <https://github.com/ros-controls/ros2_control/issues/1423>`_)
* Contributors: Sai Kishor Kothakota

4.5.0 (2024-02-12)
------------------

4.4.0 (2024-01-31)
------------------
* Fix version
* Move `test_components` to own package (`#1325 <https://github.com/ros-controls/ros2_control/issues/1325>`_)
* Contributors: Bence Magyar, Christoph Fröhlich
