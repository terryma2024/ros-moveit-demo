#pragma once

#include <array>
#include <atomic>
#include <cstdint>
#include <vector>

namespace mujoco_ros2_control_plugins
{

constexpr size_t TRUTH_MAX_GEOMS = 2000;
struct SegmentationEntry
{
  int segid;
  int object_id;
  int object_type;
};

// Decode the ID-color readback using this exact scene's map. Output is 32SC2
// little-endian with the same OpenGL vertical flip as the original RGB.
inline bool decode_instance_image(const std::vector<uint8_t>& rgb, uint32_t width, uint32_t height,
                                 const std::vector<SegmentationEntry>& mapping,
                                 std::vector<uint8_t>& output)
{
  const uint64_t pixels = static_cast<uint64_t>(width) * height;
  if (!width || !height || pixels > 4096u * 4096u || rgb.size() != pixels * 3 ||
      output.size() != pixels * 8 || mapping.size() > TRUTH_MAX_GEOMS)
    return false;
  std::array<int, TRUTH_MAX_GEOMS> lookup;
  lookup.fill(-1);
  for (size_t index = 0; index < mapping.size(); ++index)
  {
    const auto id = mapping[index].segid;
    if (id < 0 || id >= static_cast<int>(TRUTH_MAX_GEOMS) || lookup[id] != -1)
      return false;
    lookup[id] = static_cast<int>(index);
  }
  for (uint32_t row = 0; row < height; ++row)
    for (uint32_t col = 0; col < width; ++col)
    {
      const size_t source = (static_cast<size_t>(row) * width + col) * 3;
      const uint32_t color = rgb[source] + (uint32_t(rgb[source+1]) << 8) +
                             (uint32_t(rgb[source+2]) << 16);
      int object_id = -1, object_type = -1;
      if (color)
      {
        if (color > TRUTH_MAX_GEOMS || lookup[color-1] < 0)
          return false;
        const auto& entry = mapping[lookup[color-1]];
        object_id = entry.object_id;
        object_type = entry.object_type;
      }
      const size_t destination = (static_cast<size_t>(height-1-row) * width + col) * 8;
      const uint32_t values[] = {static_cast<uint32_t>(object_id), static_cast<uint32_t>(object_type)};
      for (size_t channel = 0; channel < 2; ++channel)
        for (size_t byte = 0; byte < 4; ++byte)
          output[destination + channel*4 + byte] = (values[channel] >> (byte*8)) & 255;
    }
  return true;
}

struct TruthWatermarks
{
  uint64_t generated = 0, enqueued = 0, published = 0, dropped = 0;
  uint64_t last_enqueued = 0, last_published = 0, last_dropped = 0;
  bool loss = false;
};

// One camera render producer, one sender. Both slots count toward capacity,
// including a slot currently inside DDS publish. No render-side mutex or wait.
template<class Message> class FixedTruthQueue
{
public:
  enum State { FREE, WRITING, QUEUED, PUBLISHING };
  struct Slot
  {
    Message value;
    uint64_t sequence = 0;
    std::atomic<State> state{FREE};
  };
  std::array<Slot, 2> slots;

  Slot* try_begin()
  {
    if (!accepting_.load()) return nullptr;
    const uint64_t sequence = generated_.fetch_add(1) + 1;
    for (auto& slot : slots)
    {
      State expected = FREE;
      if (slot.state.compare_exchange_strong(expected, WRITING))
      {
        slot.sequence = sequence;
        return &slot;
      }
    }
    drop(sequence);
    return nullptr;
  }
  void commit(Slot& slot)
  {
    ++enqueued_;
    last_enqueued_ = slot.sequence;
    slot.state.store(QUEUED);
  }
  Slot* try_take()
  {
    Slot* earliest = nullptr;
    for (auto& slot : slots)
      if (slot.state.load() == QUEUED && (!earliest || slot.sequence < earliest->sequence))
        earliest = &slot;
    if (!earliest) return nullptr;
    State expected = QUEUED;
    return earliest->state.compare_exchange_strong(expected, PUBLISHING) ? earliest : nullptr;
  }
  void published(Slot& slot)
  {
    ++published_;
    last_published_ = slot.sequence;
    slot.state.store(FREE);
  }
  void rejected(Slot& slot)
  {
    drop(slot.sequence);
    slot.state.store(FREE);
  }
  void stop_ingress() { accepting_.store(false); }
  void latch_loss() { drop(generated_.fetch_add(1) + 1); }
  void drop_queued()
  {
    for (auto& slot : slots)
    {
      State expected = QUEUED;
      if (slot.state.compare_exchange_strong(expected, WRITING)) rejected(slot);
    }
  }
  TruthWatermarks watermarks() const
  {
    return {generated_.load(), enqueued_.load(), published_.load(), dropped_.load(),
            last_enqueued_.load(), last_published_.load(), last_dropped_.load(), dropped_.load() != 0};
  }

private:
  void drop(uint64_t sequence)
  {
    ++dropped_;
    auto old = last_dropped_.load();
    while (old < sequence && !last_dropped_.compare_exchange_weak(old, sequence)) {}
  }
  std::atomic_bool accepting_{true};
  std::atomic<uint64_t> generated_{0}, enqueued_{0}, published_{0}, dropped_{0};
  std::atomic<uint64_t> last_enqueued_{0}, last_published_{0}, last_dropped_{0};
};

}  // namespace mujoco_ros2_control_plugins
