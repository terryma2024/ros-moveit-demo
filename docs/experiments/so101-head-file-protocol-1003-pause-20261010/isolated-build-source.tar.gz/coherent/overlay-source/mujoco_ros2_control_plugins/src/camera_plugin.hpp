/**
 * Copyright (c) 2026, United States Government, as represented by the
 * Administrator of the National Aeronautics and Space Administration.
 *
 * All rights reserved.
 *
 * This software is licensed under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with the
 * License. You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations
 * under the License.
 */

#pragma once

#include <algorithm>
#include <atomic>
#include <functional>
#include <mutex>
#include <queue>
#include <string>
#include <thread>
#include <vector>
#include "camera_truth.hpp"
#include "camera_truth_reference.hpp"
#include <mujoco_ros2_control_msgs/msg/camera_truth_frame.hpp>
#include <mujoco_ros2_control_msgs/msg/camera_truth_frame_v2.hpp>

#include "sensor_msgs/image_encodings.hpp"

#include <dlfcn.h>

#include "mujoco_ros2_control_plugins/mujoco_ros2_control_plugin_capabilities.hpp"
#include "mujoco_ros2_control_plugins/mujoco_ros2_control_plugins_base.hpp"

#ifndef __APPLE__
#include <EGL/egl.h>
#include <EGL/eglext.h>
#else
#include <OpenGL/OpenGL.h>
#endif
#include <GLFW/glfw3.h>
#include <mujoco/mujoco.h>

#include <rclcpp/node.hpp>
#include <rclcpp/publisher.hpp>
#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/camera_info.hpp>
#include <sensor_msgs/msg/image.hpp>
#include <std_srvs/srv/trigger.hpp>

#include <pluginlib/class_list_macros.hpp>

namespace mujoco_ros2_control_plugins
{

/**
 * @brief Selects when a camera's images are rendered and published.
 */
enum class CameraPolicy
{
  DISABLED = 0,  // Publishing is disabled.
  STREAMING,     // Publishing is constant at the specified publish rate.
  POLLED         // Publishing happens only when triggered by a service.
};

// Shared sender state outlives the plugin if a middleware call misses retirement.
// Such a stream is explicitly unretired; it cannot permit another attempt.
struct CameraTruthSender
{
  using Frame = mujoco_ros2_control_msgs::msg::CameraTruthFrame;
  using Envelope = mujoco_ros2_control_msgs::msg::CameraTruthFrameV2;
  FixedTruthQueue<Envelope> queue;
  rclcpp::Publisher<Frame>::SharedPtr publisher;
  rclcpp::Publisher<Envelope>::SharedPtr publisher_v2;
  Envelope final_watermark;
  std::atomic_bool stopping{false}, done{false}, retirement_failed{false};
  std::atomic<int64_t> deadline_ns{0};
  std::mutex wake_mutex;
  std::condition_variable wake;
  std::thread worker;
  ~CameraTruthSender();
  void start(const std::shared_ptr<CameraTruthSender>& self);
  bool retire(std::chrono::steady_clock::time_point deadline);
};

struct CameraTruthBuffers
{
  int schema_version = 1;
  TruthReferenceKind reference_kind = TruthReferenceKind::NONE;
  std::vector<double> baseline_diffuse, baseline_specular;
  std::vector<int> hidden_geom_ids;
  std::shared_ptr<CameraTruthSender> sender;
  std::vector<uint8_t> id_color;
  std::vector<SegmentationEntry> mapping;
  std::vector<mjvGeom> frozen_geoms;
  mjvScene frozen_scene;
};

/**
 * @brief Per-camera bookkeeping: configuration, buffers, and ROS publishers/service for one
 * MuJoCo camera.
 *
 * One instance exists per camera registered by CameraPlugin::register_cameras(). Buffers and
 * messages are reused across renders to avoid reallocating on every publish.
 */
struct CameraData
{
  CameraPolicy policy = CameraPolicy::STREAMING;
  bool publish_depth{ true };

  // Set by the trigger service for polled cameras to request a one-shot capture.
  bool poll_requested{ false };

  // Set when this camera is selected to render on the next pass and is waiting
  // for the rendering thread to consume it, then clear it when rendering occurs.
  bool render_pending{ false };

  mjvCamera mjv_cam;
  mjrRect viewport;

  std::string name;
  std::string frame_name;
  std::string info_topic;
  std::string image_topic;
  std::string depth_topic;
  std::string trigger_service_name;

  uint32_t width;
  uint32_t height;

  std::vector<uint8_t> image_buffer;
  std::vector<float> depth_buffer;

  sensor_msgs::msg::Image image;
  sensor_msgs::msg::Image depth_image;
  sensor_msgs::msg::CameraInfo camera_info;

  rclcpp::Publisher<sensor_msgs::msg::Image>::SharedPtr image_pub;
  rclcpp::Publisher<sensor_msgs::msg::Image>::SharedPtr depth_image_pub;
  rclcpp::Publisher<sensor_msgs::msg::CameraInfo>::SharedPtr camera_info_pub;
  rclcpp::Service<std_srvs::srv::Trigger>::SharedPtr trigger_service;
  std::shared_ptr<CameraTruthBuffers> truth;
};

/**
 * @brief Plugin that publishes the mujoco camera data to ROS 2 topics.
 *
 * Camera topics can be named in the ROS 2 controls plugins YAML config file
 * and loaded as node parameters.
 * If any of the parameters are not specified, default topic names will be assigned.
 * A user can provide topic names for multiple cameras as long as cameras are not named the same.
 * Name collision is resolved by last name in the yaml file.
 *
 * Plugin Parameters Structure (and default topics)
 * ---------------------------
 *
 * mujoco_camera_plugin:
 *   type: "mujoco_ros2_control_plugins/CameraPlugin"
 *   # All cameras will publish data at the same rate
 *   camera_publish_rate: 6.0
 *   <camera_name>:
 *     policy: <policy>  # "disabled", "polled", or "streaming"
 *     frame_name: <camera_name>_frame
 *     info_topic: <camera_name>/camera_info
 *     image_topic: <camera_name>/color
 *     publish_depth: true  # false creates RGB and CameraInfo only
 *     depth_topic: <camera_name>/depth
 *     trigger_service_name: <camera_name>/trigger  # only used for polling camera policy
 *
 * Implementation notes
 * --------------------
 * If the camera name, in the parameters, does not match any of the mujoco cameras
 * the data will not be published to ROS topics.
 * If no camera parameters are given, but the mujoco_camera_plugin and its policy are
 * declared, the default policy (streaming), topics, and frame are used automatically.
 *
 */
class CameraPlugin : public MuJoCoROS2ControlPluginBase, public MuJoCoROS2ControlRenderingPlugin,
                     public MuJoCoROS2ControlSimulationObserver
{
public:
  /** Signature of the GLFW initializer; injectable for testing. */
  using GlfwInitFn = std::function<int()>;

  CameraPlugin() = default;
  ~CameraPlugin() override = default;

  bool init(rclcpp::Node::SharedPtr node, const mjModel* model, mjData* data) override;
  void set_platform_render_context(void* context) override;
  void set_rendering_enabled(bool enabled) override;
  void close_rendering() override;

  /**
   * @brief Overload of init() that takes an injectable GLFW initializer.
   *
   * Exists so tests can substitute a fake @p glfw_init_fn (e.g. one that always fails) to
   * exercise the EGL fallback / rendering-disabled paths without requiring a real display or
   * GL context. The public init() override simply forwards to this overload using the real
   * `glfwInit`.
   *
   * @param glfw_init_fn Function used to attempt GLFW initialization; same signature as `glfwInit`.
   */
  bool init(rclcpp::Node::SharedPtr node, const mjModel* model, mjData* data, GlfwInitFn glfw_init_fn);
  void on_physics_step(const mjModel* model, const mjData* data) override;
  void on_reset() override;
  void on_state_snapshot(const mjModel* model, const mjData* data, bool paused) override;
  void cleanup() override;

  /**
   * @brief Request a single render/publish cycle.
   *
   * Streaming cameras are always selected, and polled cameras are selected only if their
   * trigger service has been called since the last cycle. On macOS the request is queued to
   * the context-owning worker; on other platforms it is rendered synchronously by the caller.
   * This method is intended for deterministic tests.
   */
  void trigger_update();

  /**
   * @brief Whether the rendering thread has successfully initialized its GL context.
   *
   * Primarily useful for tests that need to wait for the asynchronous rendering thread to
   * come up before forcing a render.
   */
  bool is_rendering_available() const
  {
    return publish_images_.load();
  }

  bool truth_retired() const;

private:
  // ROS interfaces
  rclcpp::Logger logger_{ rclcpp::get_logger("CameraPlugin") };

  /**
   * @brief Stops the camera processing thread and closes the relevant objects, call before shutdown.
   */
  void close();

  /**
   * @brief Parses camera information from the mujoco model and node parameters.
   * @return true if registering cameras succeeds, otherwise false.
   */
  bool register_cameras();

  /**
   * @brief Initializes the rendering context and starts processing.
   */
  void update_loop();

  /**
   * @brief Renders and publishes every camera that is flagged to render.
   */
  void update_cameras();

  /**
   * @brief Renders and publishes data for a specific camera.
   * @param camera The camera data structure.
   * @param stamp Timestamp applied to all messages published this step.
   */
  void render_and_publish_camera(CameraData& camera, const rclcpp::Time& stamp);
  void capture_truth(CameraData& camera, int64_t render_started_ns);

  /**
   * @brief Handles a polled camera trigger to render and publish messages.
   * @param camera The camera data structure.
   */
  void handle_trigger(const std::shared_ptr<std_srvs::srv::Trigger::Request> /*request*/,
                      std::shared_ptr<std_srvs::srv::Trigger::Response> response, const int camera_idx);

  rclcpp::Node::SharedPtr node_;

  // Ensures locked access to simulation data for rendering.
  std::recursive_mutex* sim_mutex_{ nullptr };

  mjData* mj_data_;
  const mjModel* mj_model_;
  mjData* mj_camera_data_;

  // Image publishing rate (applies to streaming cameras only)
  double camera_publish_rate_{ 5.0 };
  rclcpp::Time last_publish_time_{ 0, 0, RCL_ROS_TIME };

  // Whether any streaming camera is registered. This lets the update loop skip the
  // streaming time check entirely when only polled/disabled cameras exist.
  bool has_streaming_cameras_{ false };

  // Whether at least one polled camera has a pending trigger request.
  std::atomic_bool poll_pending_{ false };

  // Rendering options for the cameras, currently hard coded to defaults
  mjvOption mjv_opt_;
  mjvScene mjv_scn_;
  mjrContext mjr_con_;

  // Scene parameters to keep around to avoid recomputing
  float camera_near_distance_;
  float camera_depth_scale_;

  // Containers for camera data and ROS constructs
  std::vector<CameraData> cameras_;

  // List of camera indices to render on a given pass.
  // Reserved once to the camera count so we do not allocate.
  std::vector<size_t> render_indices_;

  // Camera processing thread and objects for syncing
  std::thread rendering_thread_;
  std::atomic_bool rendering_enabled_{ true };
  std::atomic_bool publish_images_{ false };
  std::atomic_bool render_resources_ready_{ false };
  std::atomic_bool stop_requested_{ false };
  std::mutex lifecycle_mutex_;
  std::mutex render_mutex_;
  std::mutex data_mutex_;
  std::condition_variable data_cv_;
  bool new_data_{ false };
  uint64_t truth_reset_count_{0};
  bool truth_capture_armed_{false};

  // Owned offscreen contexts for headless rendering.
#ifndef __APPLE__
  EGLDisplay egl_display_{ EGL_NO_DISPLAY };
  EGLContext egl_context_{ EGL_NO_CONTEXT };
  EGLSurface egl_surface_{ EGL_NO_SURFACE };
#else
  CGLPixelFormatObj cgl_pixel_format_{ nullptr };
  CGLContextObj cgl_context_{ nullptr };
  bool cgl_locked_{ false };
#endif
  bool use_egl_{ false };
#ifdef __APPLE__
  GLFWwindow* macos_window_{ nullptr };
  bool use_cgl_{ false };
#endif

  /**
   * @brief Initializes EGL context for headless rendering.
   * @return true if EGL initialization succeeded, false otherwise.
   */
  bool init_egl_context();

  /**
   * @brief Cleans up EGL resources.
   */
  void cleanup_egl_context();

#ifdef __APPLE__
  /** Initialize an accelerated worker-owned CGL context for headless rendering. */
  bool init_cgl_context();

  /** Release the worker-owned CGL context after MuJoCo render resources are freed. */
  void cleanup_cgl_context();
#endif
};

}  // namespace mujoco_ros2_control_plugins
