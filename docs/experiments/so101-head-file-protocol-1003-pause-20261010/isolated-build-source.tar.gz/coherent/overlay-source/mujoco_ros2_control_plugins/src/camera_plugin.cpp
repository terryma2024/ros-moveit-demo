/**
 * Copyright (c) 2026, United States Government, as represented by the
 * Administrator of the National Aeronautics and Space Administration.
 *
 * All rights reserved.
 *
 * This software is licensed under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with the
 * License. You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations
 * under the License.
 */

#include "camera_plugin.hpp"
#include <algorithm>
#include <cmath>
#include <cstring>
#include <stdexcept>

namespace mujoco_ros2_control_plugins
{


namespace
{
int64_t steady_nanoseconds()
{
  return std::chrono::duration_cast<std::chrono::nanoseconds>(
    std::chrono::steady_clock::now().time_since_epoch()).count();
}
void stamp_watermarks(CameraTruthSender::Frame& frame, const TruthWatermarks& watermarks)
{
  frame.generated_count = watermarks.generated;
  frame.enqueued_count = watermarks.enqueued;
  frame.published_count = watermarks.published;
  frame.dropped_count = watermarks.dropped;
  frame.last_enqueued_sequence = watermarks.last_enqueued;
  frame.last_published_sequence = watermarks.last_published;
  frame.last_dropped_sequence = watermarks.last_dropped;
  frame.loss_latched = watermarks.loss;
}
class ScopedSegmentationFlags
{
public:
  explicit ScopedSegmentationFlags(mjvScene& scene) : scene_(scene)
  {
    std::memcpy(flags_, scene.flags, sizeof(flags_));
    scene.flags[mjRND_SEGMENT] = 1;
    scene.flags[mjRND_IDCOLOR] = 1;
  }
  ~ScopedSegmentationFlags() { std::memcpy(scene_.flags, flags_, sizeof(flags_)); }
private:
  mjvScene& scene_;
  mjtByte flags_[mjNRNDFLAG];
};
bool valid_sha(const std::string& value)
{
  return value.size() == 64 && std::all_of(value.begin(), value.end(), [](char c) {
    return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f');
  });
}
}  // namespace

CameraTruthSender::~CameraTruthSender()
{
  // A missed middleware deadline preserves the shared publisher until its call
  // returns, with retirement_failed sticky. Never terminate/kill and report PASS.
  if (worker.joinable()) worker.detach();
}
void CameraTruthSender::start(const std::shared_ptr<CameraTruthSender>& self)
{
  worker = std::thread([self]() {
    while (true)
    {
      if (self->stopping.load() && steady_nanoseconds() >= self->deadline_ns.load())
      {
        self->queue.drop_queued();
        break;
      }
      if (auto* slot = self->queue.try_take())
      {
        slot->value.original.frame_sequence = slot->sequence;
        stamp_watermarks(slot->value.original, self->queue.watermarks());
        try
        {
          if (self->publisher_v2) self->publisher_v2->publish(slot->value);
          else self->publisher->publish(slot->value.original);
          self->queue.published(*slot);
        }
        catch (...)
        {
          self->queue.rejected(*slot);
        }
        continue;
      }
      if (self->stopping.load()) break;
      std::unique_lock<std::mutex> lock(self->wake_mutex);
      self->wake.wait_for(lock, std::chrono::milliseconds(1));
    }
    stamp_watermarks(self->final_watermark.original, self->queue.watermarks());
    self->final_watermark.original.frame_sequence = self->final_watermark.original.generated_count;
    // Missing this best-effort terminal watermark is UNKNOWN at the receiver.
    // It does not by itself assert publisher/thread retirement or a Stop ACK.
    if (steady_nanoseconds() < self->deadline_ns.load())
    {
      try
      {
        if (self->publisher_v2) self->publisher_v2->publish(self->final_watermark);
        else self->publisher->publish(self->final_watermark.original);
      }
      catch (...) { self->retirement_failed.store(true); }
    }
    else self->retirement_failed.store(true);
    self->done.store(true);
    self->wake.notify_all();
  });
}
bool CameraTruthSender::retire(std::chrono::steady_clock::time_point deadline)
{
  queue.stop_ingress();
  deadline_ns.store(std::chrono::duration_cast<std::chrono::nanoseconds>(deadline.time_since_epoch()).count());
  stopping.store(true);
  wake.notify_all();
  if (!worker.joinable())
  {
    if (retirement_failed.load()) return false;
    done.store(true);
    return !retirement_failed.load();
  }
  {
    std::unique_lock<std::mutex> lock(wake_mutex);
    if (!wake.wait_until(lock, deadline, [this]() { return done.load(); }))
    {
      retirement_failed.store(true);
      // All worker accesses are to self-owned shared state, never the plugin/model.
      worker.detach();
      return false;
    }
  }
  worker.join();
  publisher.reset();
  publisher_v2.reset();
  return !retirement_failed.load();
}
bool CameraPlugin::truth_retired() const
{
  return std::all_of(cameras_.begin(), cameras_.end(), [](const auto& camera) {
    return !camera.truth || (camera.truth->sender->done.load() &&
                            !camera.truth->sender->retirement_failed.load());
  });
}

#ifdef __APPLE__
namespace
{

class ScopedGlfwContext
{
public:
  explicit ScopedGlfwContext(GLFWwindow* window)
  {
    glfwMakeContextCurrent(window);
  }

  ~ScopedGlfwContext()
  {
    glfwMakeContextCurrent(nullptr);
  }

  ScopedGlfwContext(const ScopedGlfwContext&) = delete;
  ScopedGlfwContext& operator=(const ScopedGlfwContext&) = delete;
};

}  // namespace
#endif

bool CameraPlugin::init(rclcpp::Node::SharedPtr node, const mjModel* model, mjData* data)
{
  // by default use `glfwInit` to check if the GLFW is initialized.
  return this->init(node, model, data, glfwInit);
}

void CameraPlugin::set_platform_render_context(void* context)
{
#ifdef __APPLE__
  std::lock_guard<std::mutex> lock(lifecycle_mutex_);
  macos_window_ = static_cast<GLFWwindow*>(context);
#else
  (void)context;
#endif
}

void CameraPlugin::set_rendering_enabled(bool enabled)
{
  rendering_enabled_.store(enabled);
  if (enabled)
  {
    if (render_resources_ready_.load())
    {
      publish_images_.store(true);
    }
    return;
  }

  // Wait for any in-flight render to finish, then discard work that has not started. This
  // guarantees that no new frame begins after a disable request returns.
  std::lock_guard<std::mutex> render_lock(render_mutex_);
  std::lock_guard<std::mutex> data_lock(data_mutex_);
  publish_images_.store(false);
  new_data_ = false;
  poll_pending_.store(false);
  for (auto& camera : cameras_)
  {
    camera.poll_requested = false;
    camera.render_pending = false;
  }
}

void CameraPlugin::close_rendering()
{
  set_rendering_enabled(false);
  close();
}

bool CameraPlugin::init(rclcpp::Node::SharedPtr node, const mjModel* model, mjData* data, GlfwInitFn glfw_init_fn)
{
  node_ = node;
  mj_model_ = model;
  mj_data_ = data;

  // Ensure the logger has a name
  logger_ = node_->get_logger().get_child(node->get_sub_namespace());
  RCLCPP_INFO(node_->get_logger(), "CameraPlugin initializing cameras...");

  // Read the mj_model_, identify the number of cameras, and populate containers for them.
  {
    // Disable/close also takes this lock before inspecting per-camera work flags. Holding it
    // throughout registration prevents shutdown from iterating a partially built registry.
    std::lock_guard<std::mutex> data_lock(data_mutex_);
    if (!register_cameras())
    {
      RCLCPP_ERROR(node_->get_logger(), "Failed to register cameras.");
      return false;
    }
  }
  if (cameras_.empty())
  {
    return true;
  }

  if (!rendering_enabled_.load())
  {
    RCLCPP_INFO(node_->get_logger(), "Camera rendering is disabled by the simulation lifecycle.");
    return true;
  }

  // Select the rendering backend before entering the lifecycle critical section. Worker
  // construction itself is serialized with close() below.
#ifndef __APPLE__
  bool use_egl = false;
  if (glfw_init_fn())
  {
    use_egl = false;
  }
  else
  {
    RCLCPP_WARN(node_->get_logger(), "Failed to initialize GLFW. Attempting EGL for headless rendering.");
    use_egl = true;
  }
#else
  (void)glfw_init_fn;
#endif

  // close() uses this same lock. Consequently it either prevents the worker from starting,
  // or observes the newly assigned std::thread and joins it before returning.
  std::lock_guard<std::mutex> lifecycle_lock(lifecycle_mutex_);
  if (!rendering_enabled_.load() || stop_requested_.load())
  {
    RCLCPP_INFO(node_->get_logger(), "Camera rendering was disabled during initialization.");
    return true;
  }
#ifdef __APPLE__
  // Interactive simulation borrows the GLFW context created on the macOS main thread.
  // A rendering-enabled headless simulation supplies no window, so the worker owns CGL.
  use_cgl_ = macos_window_ == nullptr;
  use_egl_ = false;
#else
  use_egl_ = use_egl;
#endif
  rendering_thread_ = std::thread(&CameraPlugin::update_loop, this);
  return true;
}

void CameraPlugin::on_physics_step(const mjModel* model_arg, const mjData* data)
{
  if (!rendering_enabled_.load() || !publish_images_.load())
  {
    return;
  }

  // Streaming cameras render on a fixed-rate clock; polled cameras render as soon as a
  // trigger has been received. The existing observer runs immediately after each
  // successful physics step, with the authoritative data protected by the sim mutex.
  // TODO: Support per-camera publish rates?
  // Schedule from the same actual simulation snapshot whose time is placed
  // in the image headers. Node /clock delivery can lag that snapshot by a
  // step, and a floating seconds comparison can defer an exact-rate exposure.
  const rclcpp::Time now(std::llround(data->time * 1000000000.0), RCL_ROS_TIME);
  const auto period_ns = rclcpp::Duration::from_seconds(1.0 / camera_publish_rate_).nanoseconds();
  const bool stream_due =
      has_streaming_cameras_ && (now - last_publish_time_).nanoseconds() >= period_ns;
  const bool poll_due = poll_pending_.load();

  // Nothing to do this step: avoid taking the lock or copying data.
  if (!stream_due && !poll_due)
  {
    return;
  }

  bool any_selected = false;
  {
    // Rendering holds this mutex across GL work. A physics step must never
    // wait for that work or overwrite an original snapshot still queued to render.
    std::unique_lock<std::mutex> lock(data_mutex_, std::try_to_lock);
    if (!lock.owns_lock())
    {
      return;
    }

    if (!rendering_enabled_.load())
    {
      return;
    }
    if (new_data_ || std::any_of(cameras_.begin(), cameras_.end(),
                               [](const auto& camera) { return camera.render_pending; }))
    {
      return;
    }
    poll_pending_.store(false);

    // Flag streaming cameras when their interval is due and any polled cameras that have a
    // pending trigger (consuming the one-shot request so they render exactly once).
    for (auto& camera : cameras_)
    {
      if (camera.policy == CameraPolicy::STREAMING && stream_due)
      {
        camera.render_pending = true;
        any_selected = true;
      }
      else if (camera.policy == CameraPolicy::POLLED && camera.poll_requested)
      {
        camera.poll_requested = false;
        camera.render_pending = true;
        any_selected = true;
      }
    }

    if (stream_due)
    {
      last_publish_time_ = now;
    }

    // Only snapshot the simulation data when there is actually a camera to render.
    if (any_selected)
    {
      mjv_copyData(mj_camera_data_, model_arg, data);
      new_data_ = true;
    }
  }

  if (any_selected)
  {
    data_cv_.notify_one();
  }
}

void CameraPlugin::on_reset()
{
  // Reset and step observers are serialized by the existing physics mutex.
  last_publish_time_ = rclcpp::Time(0, 0, RCL_ROS_TIME);
  if (std::any_of(cameras_.begin(), cameras_.end(), [](const auto& camera) { return bool(camera.truth); }))
  {
    std::lock_guard<std::mutex> render_lock(render_mutex_);
    std::lock_guard<std::mutex> data_lock(data_mutex_);
    // Capture begins only after this attempt's actual native ResetWorld.
    // Reject pre-reset pending snapshots and never silently rebind a stream.
    new_data_ = false;
    for (auto& camera : cameras_) camera.render_pending = false;
    truth_capture_armed_ = ++truth_reset_count_ == 1;
    if (!truth_capture_armed_)
      for (auto& camera : cameras_)
        if (camera.truth) camera.truth->sender->queue.latch_loss();
  }
}

void CameraPlugin::on_state_snapshot(const mjModel* model_arg, const mjData* data, bool paused)
{
  if (paused)
  {
    on_physics_step(model_arg, data);
  }
}

void CameraPlugin::cleanup()
{
  close_rendering();
}

void CameraPlugin::trigger_update()
{
  {
    std::lock_guard<std::mutex> lock(data_mutex_);
    if (!rendering_enabled_.load() || !render_resources_ready_.load())
    {
      return;
    }

    // Force every streaming camera and consume any pending polls.
    for (auto& camera : cameras_)
    {
      if (camera.policy == CameraPolicy::STREAMING)
      {
        camera.render_pending = true;
      }
      else if (camera.policy == CameraPolicy::POLLED && camera.poll_requested)
      {
        camera.poll_requested = false;
        camera.render_pending = true;
      }
    }

#ifdef __APPLE__
    // Cocoa contexts are owned by the camera worker. Queue the deterministic test cycle there
    // instead of moving the context onto the caller thread.
    mjv_copyData(mj_camera_data_, mj_model_, mj_data_);
    new_data_ = true;
#endif
  }

#ifdef __APPLE__
  data_cv_.notify_one();
#else
  std::lock_guard<std::mutex> render_lock(render_mutex_);
  std::lock_guard<std::mutex> data_lock(data_mutex_);
  if (!rendering_enabled_.load())
  {
    return;
  }
  update_cameras();
#endif
}

bool CameraPlugin::register_cameras()
{
  const std::string param_prefix = "mujoco_plugins.mujoco_camera_plugin.";

  if (!node_->has_parameter(param_prefix + "camera_publish_rate"))
  {
    node_->declare_parameter(param_prefix + "camera_publish_rate", 5.0);
  }

  camera_publish_rate_ = node_->get_parameter(param_prefix + "camera_publish_rate").as_double();
  RCLCPP_INFO(node_->get_logger(), "Publishing camera data at rate %f per second.", camera_publish_rate_);

  cameras_.resize(0);
  for (auto i = 0; i < mj_model_->ncam; ++i)
  {
    const char* cam_name = mj_model_->names + mj_model_->name_camadr[i];
    const int* cam_resolution = mj_model_->cam_resolution + 2 * i;
    const mjtNum cam_fovy = mj_model_->cam_fovy[i];

    // Construct CameraData wrapper and set defaults
    CameraData camera;
    camera.name = cam_name;
    camera.mjv_cam.type = mjCAMERA_FIXED;
    camera.mjv_cam.fixedcamid = i;
    camera.width = static_cast<uint32_t>(cam_resolution[0]);
    camera.height = static_cast<uint32_t>(cam_resolution[1]);
    camera.viewport = { 0, 0, cam_resolution[0], cam_resolution[1] };

    const std::string param_ns = param_prefix + cam_name + ".";

    const std::string policy_param = param_ns + "policy";
    if (!node_->has_parameter(policy_param))
    {
      node_->declare_parameter(policy_param, "streaming");
    }
    std::string policy_str = node_->get_parameter(policy_param).as_string();
    if (policy_str == "streaming")
    {
      camera.policy = CameraPolicy::STREAMING;
    }
    else if (policy_str == "polled")
    {
      camera.policy = CameraPolicy::POLLED;
    }
    else if (policy_str == "disabled")
    {
      camera.policy = CameraPolicy::DISABLED;
    }
    else
    {
      RCLCPP_ERROR(node_->get_logger(), "Invalid policy for camera '%s'", cam_name);
      return false;
    }

    const std::string frame_param = param_ns + "frame_name";
    if (!node_->has_parameter(frame_param))
    {
      node_->declare_parameter(frame_param, camera.name + "_frame");
    }
    camera.frame_name = node_->get_parameter(frame_param).as_string();

    if (!node_->has_parameter(param_ns + "info_topic"))
    {
      node_->declare_parameter(param_ns + "info_topic", camera.name + "/camera_info");
    }
    camera.info_topic = node_->get_parameter(param_ns + "info_topic").as_string();

    if (!node_->has_parameter(param_ns + "image_topic"))
    {
      node_->declare_parameter(param_ns + "image_topic", camera.name + "/color");
    }
    camera.image_topic = node_->get_parameter(param_ns + "image_topic").as_string();

    if (!node_->has_parameter(param_ns + "publish_depth"))
    {
      node_->declare_parameter(param_ns + "publish_depth", true);
    }
    camera.publish_depth = node_->get_parameter(param_ns + "publish_depth").as_bool();

    if (!node_->has_parameter(param_ns + "depth_topic"))
    {
      node_->declare_parameter(param_ns + "depth_topic", camera.name + "/depth");
    }
    camera.depth_topic = node_->get_parameter(param_ns + "depth_topic").as_string();

    if (!node_->has_parameter(param_ns + "trigger_service_name"))
    {
      node_->declare_parameter(param_ns + "trigger_service_name", camera.name + "/trigger");
    }
    camera.trigger_service_name = node_->get_parameter(param_ns + "trigger_service_name").as_string();

    RCLCPP_INFO(node_->get_logger(), "Adding camera: '%s'", cam_name);
    RCLCPP_INFO(node_->get_logger(), "    policy: '%s'", policy_str.c_str());
    RCLCPP_INFO(node_->get_logger(), "    frame_name: '%s'", camera.frame_name.c_str());
    if (camera.policy == CameraPolicy::DISABLED)
    {
      continue;
    }
    RCLCPP_INFO(node_->get_logger(), "    info_topic: '%s'", camera.info_topic.c_str());
    RCLCPP_INFO(node_->get_logger(), "    image_topic: '%s'", camera.image_topic.c_str());
    RCLCPP_INFO(node_->get_logger(), "    depth_topic: '%s'", camera.depth_topic.c_str());
    if (camera.policy == CameraPolicy::POLLED)
    {
      RCLCPP_INFO(node_->get_logger(), "    trigger_service_name: '%s'", camera.trigger_service_name.c_str());
    }

    // Configure publishers and services
    camera.camera_info_pub = node_->create_publisher<sensor_msgs::msg::CameraInfo>(camera.info_topic, 1);
    camera.image_pub = node_->create_publisher<sensor_msgs::msg::Image>(camera.image_topic, 1);
    if (camera.publish_depth)
    {
      camera.depth_image_pub = node_->create_publisher<sensor_msgs::msg::Image>(camera.depth_topic, 1);
    }
    if (camera.policy == CameraPolicy::POLLED)
    {
      camera.trigger_service = node_->create_service<std_srvs::srv::Trigger>(
          camera.trigger_service_name, [this, i](const std::shared_ptr<std_srvs::srv::Trigger::Request> request,
                                                 std::shared_ptr<std_srvs::srv::Trigger::Response> response) {
            this->handle_trigger(request, response, i);
          });
    }
    // Setup containers for color image data
    camera.image.header.frame_id = camera.frame_name;

    const auto image_size = camera.width * camera.height * 3;
    camera.image_buffer.resize(image_size);
    camera.image.data.resize(image_size);
    camera.image.width = camera.width;
    camera.image.height = camera.height;
    camera.image.step = camera.width * 3;
    camera.image.encoding = sensor_msgs::image_encodings::RGB8;

    // Depth image data
    if (camera.publish_depth)
    {
      camera.depth_image.header.frame_id = camera.frame_name;
      camera.depth_buffer.resize(camera.width * camera.height);
      camera.depth_image.data.resize(camera.width * camera.height * sizeof(float));
      camera.depth_image.width = camera.width;
      camera.depth_image.height = camera.height;
      camera.depth_image.step = camera.width * sizeof(float);
      camera.depth_image.encoding = sensor_msgs::image_encodings::TYPE_32FC1;
    }

    // Camera info
    camera.camera_info.header.frame_id = camera.frame_name;
    camera.camera_info.width = camera.width;
    camera.camera_info.height = camera.height;
    camera.camera_info.distortion_model = "plumb_bob";
    camera.camera_info.k.fill(0.0);
    camera.camera_info.r.fill(0.0);
    camera.camera_info.p.fill(0.0);
    camera.camera_info.d.resize(5, 0.0);

    double focal_scaling = (1.0 / std::tan((cam_fovy * M_PI / 180.0) / 2.0)) * camera.height / 2.0;
    camera.camera_info.k[0] = camera.camera_info.p[0] = focal_scaling;
    camera.camera_info.k[2] = camera.camera_info.p[2] = static_cast<double>(camera.width) / 2.0;
    camera.camera_info.k[4] = camera.camera_info.p[5] = focal_scaling;
    camera.camera_info.k[5] = camera.camera_info.p[6] = static_cast<double>(camera.height) / 2.0;
    camera.camera_info.k[8] = camera.camera_info.p[10] = 1.0;


    if (!node_->has_parameter(param_ns + "truth_enabled"))
      node_->declare_parameter(param_ns + "truth_enabled", false);
    if (node_->get_parameter(param_ns + "truth_enabled").as_bool())
    {
      const auto parameter = [&](const std::string& name) {
        if (!node_->has_parameter(param_ns + name)) node_->declare_parameter(param_ns + name, "");
        return node_->get_parameter(param_ns + name).as_string();
      };
      const auto topic = parameter("truth_topic");
      const auto capture = parameter("truth_capture_identity");
      const auto model_sha = parameter("truth_model_sha256");
      const auto config_sha = parameter("truth_render_config_sha256");
      if (!node_->has_parameter(param_ns + "truth_schema_version"))
        node_->declare_parameter(param_ns + "truth_schema_version", 1);
      const auto schema_version = node_->get_parameter(param_ns + "truth_schema_version").as_int();
      const auto reference_kind = parameter("truth_reference_kind");
      if (topic.empty() || topic.front() != '/' || capture.empty() || capture.size() > 64 ||
          camera.name.size() > 128 || !valid_sha(model_sha) || !valid_sha(config_sha) ||
          !camera.width || !camera.height || camera.width > 4096 || camera.height > 4096 ||
          mj_model_->nflex || mj_model_->nskin || mj_model_->nmocap ||
          (schema_version != 1 && schema_version != 2) ||
          (schema_version == 1 && !reference_kind.empty() && reference_kind != "none") ||
          (schema_version == 2 && reference_kind != "none" && reference_kind != "normal_light" &&
           reference_kind != "amodal_cup"))
      {
        RCLCPP_ERROR(logger_, "Invalid or unsupported frozen camera truth configuration.");
        return false;
      }
      camera.truth = std::make_shared<CameraTruthBuffers>();
      auto& buffers = *camera.truth;
      buffers.schema_version = static_cast<int>(schema_version);
      buffers.reference_kind = reference_kind == "normal_light" ? TruthReferenceKind::NORMAL_LIGHT :
        reference_kind == "amodal_cup" ? TruthReferenceKind::AMODAL_CUP : TruthReferenceKind::NONE;
      const auto doubles = [&](const std::string& name) {
        if (!node_->has_parameter(param_ns+name))
          node_->declare_parameter(param_ns+name, std::vector<double>{});
        return node_->get_parameter(param_ns+name).as_double_array();
      };
      buffers.baseline_diffuse = doubles("truth_baseline_diffuse");
      buffers.baseline_specular = doubles("truth_baseline_specular");
      if (!node_->has_parameter(param_ns+"truth_hidden_geom_ids"))
        node_->declare_parameter(param_ns+"truth_hidden_geom_ids", std::vector<int64_t>{});
      const auto hidden = node_->get_parameter(param_ns+"truth_hidden_geom_ids").as_integer_array();
      if (hidden.size()>TRUTH_MAX_GEOMS || buffers.baseline_diffuse.size()>3*mjMAXLIGHT ||
          buffers.baseline_specular.size()>3*mjMAXLIGHT)
        return false;
      for (const auto id : hidden)
      {
        if (id<0 || id>=mj_model_->ngeom) return false;
        buffers.hidden_geom_ids.push_back(static_cast<int>(id));
      }
      if ((buffers.reference_kind==TruthReferenceKind::NONE &&
           (!hidden.empty() || !buffers.baseline_diffuse.empty() || !buffers.baseline_specular.empty())) ||
          (buffers.reference_kind==TruthReferenceKind::NORMAL_LIGHT &&
           (!hidden.empty() || mj_model_->nlight<=0 || mj_model_->nlight>=mjMAXLIGHT ||
            buffers.baseline_diffuse.size()!=size_t(3*mj_model_->nlight) ||
            buffers.baseline_specular.size()!=buffers.baseline_diffuse.size())) ||
          (buffers.reference_kind==TruthReferenceKind::AMODAL_CUP &&
           (hidden.empty() || !buffers.baseline_diffuse.empty() || !buffers.baseline_specular.empty())))
        return false;
      buffers.id_color.resize(image_size);
      buffers.mapping.reserve(TRUTH_MAX_GEOMS);
      buffers.frozen_geoms.resize(TRUTH_MAX_GEOMS);
      buffers.sender = std::make_shared<CameraTruthSender>();
      auto& sender = *buffers.sender;
      sender.final_watermark.schema_version = 2;
      auto& prototype = sender.final_watermark.original;
      prototype.schema_version = 1;
      prototype.record_type = CameraTruthSender::Frame::FINAL_WATERMARK;
      prototype.capture_identity = capture;
      prototype.camera_name = camera.name;
      prototype.model_sha256 = model_sha;
      prototype.render_config_sha256 = config_sha;
      prototype.render_phase = "frozen_mjv_scene_after_original_rgb";
      for (auto& slot : sender.queue.slots)
      {
        slot.value.schema_version = 2;
        auto& frame = slot.value.original;
        frame = prototype;
        frame.record_type = CameraTruthSender::Frame::FRAME;
        frame.rgb = camera.image;
        frame.camera_info = camera.camera_info;
        frame.instances.header.frame_id = camera.frame_name;
        frame.instances.width = camera.width;
        frame.instances.height = camera.height;
        frame.instances.encoding = "32SC2";
        frame.instances.is_bigendian = false;
        frame.instances.step = camera.width * 8;
        frame.instances.data.resize(static_cast<size_t>(camera.width) * camera.height * 8);
        frame.segmentation_ids.reserve(TRUTH_MAX_GEOMS);
        frame.object_ids.reserve(TRUTH_MAX_GEOMS);
        frame.object_types.reserve(TRUTH_MAX_GEOMS);
        auto& envelope = slot.value;
        const size_t reference_channels = buffers.reference_kind==TruthReferenceKind::NORMAL_LIGHT ? 3 :
          buffers.reference_kind==TruthReferenceKind::AMODAL_CUP ? 8 : 0;
        envelope.reference.data.reserve(size_t(camera.width)*camera.height*reference_channels);
        envelope.reference.header.frame_id.reserve(camera.frame_name.size());
        envelope.reference.encoding.reserve(5);
        envelope.scene_light_model_ids.reserve(mjMAXLIGHT);
        envelope.hidden_geom_ids.reserve(buffers.hidden_geom_ids.size());
        envelope.reference_light_diffuse.reserve(buffers.baseline_diffuse.size());
        envelope.reference_light_specular.reserve(buffers.baseline_specular.size());
        envelope.frozen_cameras.reserve(32);
      }
      if (schema_version == 2)
        sender.publisher_v2 = node_->create_publisher<CameraTruthSender::Envelope>(
          topic, rclcpp::QoS(rclcpp::KeepLast(1)).best_effort());
      else
        sender.publisher = node_->create_publisher<CameraTruthSender::Frame>(
          topic, rclcpp::QoS(rclcpp::KeepLast(1)).best_effort());
    }

    // Add to list of cameras
    cameras_.push_back(camera);
  }

  has_streaming_cameras_ = std::any_of(cameras_.begin(), cameras_.end(),
                                       [](const CameraData& cam) { return cam.policy == CameraPolicy::STREAMING; });

  // Reserve once so the per-pass render bookkeeping in `update_cameras()` never allocates.
  render_indices_.reserve(cameras_.size());

  return true;
}

void CameraPlugin::close()
{
  std::lock_guard<std::mutex> lifecycle_lock(lifecycle_mutex_);
  {
    std::lock_guard<std::mutex> lock(data_mutex_);
    stop_requested_ = true;
    publish_images_ = false;
  }
  data_cv_.notify_one();
  if (rendering_thread_.joinable())
  {
    rendering_thread_.join();
  }
  render_resources_ready_.store(false);
  const auto deadline = std::chrono::steady_clock::now() + std::chrono::milliseconds(50);
  for (auto& camera : cameras_)
    if (camera.truth && !camera.truth->sender->retire(deadline))
      RCLCPP_ERROR(logger_, "Camera truth sender retirement unconfirmed; next attempt forbidden.");
}

bool CameraPlugin::init_egl_context()
{
#ifdef __APPLE__
  return false;
#else
  // Get EGL display
  egl_display_ = eglGetPlatformDisplay(EGL_PLATFORM_SURFACELESS_MESA, EGL_DEFAULT_DISPLAY, NULL);

  // Initialize EGL
  EGLint major, minor;
  if (!eglInitialize(egl_display_, &major, &minor))
  {
    RCLCPP_ERROR(node_->get_logger(), "EGL: Failed to initialize (error: 0x%x)", eglGetError());
    return false;
  }
  const char* client_apis = eglQueryString(egl_display_, EGL_CLIENT_APIS);
  const char* vendor = eglQueryString(egl_display_, EGL_VENDOR);
  RCLCPP_INFO(node_->get_logger(), "EGL: Initialized version %d.%d", major, minor);
  RCLCPP_INFO(node_->get_logger(), "EGL: Vendor: %s, APIs: %s", vendor, client_apis);
  // Choose EGL config for offscreen rendering
  const EGLint config_attribs[] = { EGL_SURFACE_TYPE,
                                    EGL_PBUFFER_BIT,
                                    EGL_RED_SIZE,
                                    8,
                                    EGL_GREEN_SIZE,
                                    8,
                                    EGL_BLUE_SIZE,
                                    8,
                                    EGL_ALPHA_SIZE,
                                    8,
                                    EGL_DEPTH_SIZE,
                                    24,
                                    EGL_RENDERABLE_TYPE,
                                    EGL_OPENGL_BIT,
                                    EGL_NONE };

  EGLConfig egl_config;
  EGLint num_configs;
  if (!eglChooseConfig(egl_display_, config_attribs, &egl_config, 1, &num_configs) || num_configs == 0)
  {
    RCLCPP_ERROR(node_->get_logger(), "EGL: Failed to choose config (error: 0x%x)", eglGetError());
    eglTerminate(egl_display_);
    egl_display_ = EGL_NO_DISPLAY;
    return false;
  }

  // Bind OpenGL API
  if (!eglBindAPI(EGL_OPENGL_API))
  {
    RCLCPP_ERROR(node_->get_logger(), "EGL: Failed to bind OpenGL API (error: 0x%x)", eglGetError());
    eglTerminate(egl_display_);
    egl_display_ = EGL_NO_DISPLAY;
    return false;
  }

  // Create EGL context
  egl_context_ = eglCreateContext(egl_display_, egl_config, EGL_NO_CONTEXT, nullptr);
  if (egl_context_ == EGL_NO_CONTEXT)
  {
    RCLCPP_ERROR(node_->get_logger(), "EGL: Failed to create context (error: 0x%x)", eglGetError());
    eglTerminate(egl_display_);
    egl_display_ = EGL_NO_DISPLAY;
    return false;
  }

  // Create PBuffer surface for offscreen rendering
  const EGLint pbuffer_attribs[] = { EGL_WIDTH, 1, EGL_HEIGHT, 1, EGL_NONE };
  egl_surface_ = eglCreatePbufferSurface(egl_display_, egl_config, pbuffer_attribs);
  if (egl_surface_ == EGL_NO_SURFACE)
  {
    RCLCPP_ERROR(node_->get_logger(), "EGL: Failed to create PBuffer surface (error: 0x%x)", eglGetError());
    eglDestroyContext(egl_display_, egl_context_);
    eglTerminate(egl_display_);
    egl_context_ = EGL_NO_CONTEXT;
    egl_display_ = EGL_NO_DISPLAY;
    return false;
  }

  // Make the context current
  if (!eglMakeCurrent(egl_display_, egl_surface_, egl_surface_, egl_context_))
  {
    RCLCPP_ERROR(node_->get_logger(), "EGL: Failed to make context current (error: 0x%x)", eglGetError());
    cleanup_egl_context();
    return false;
  }

  RCLCPP_INFO(node_->get_logger(), "EGL: Successfully initialized headless OpenGL context");
  return true;
#endif
}

void CameraPlugin::cleanup_egl_context()
{
#ifndef __APPLE__
  if (egl_display_ != EGL_NO_DISPLAY)
  {
    eglMakeCurrent(egl_display_, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
    if (egl_surface_ != EGL_NO_SURFACE)
    {
      eglDestroySurface(egl_display_, egl_surface_);
      egl_surface_ = EGL_NO_SURFACE;
    }
    if (egl_context_ != EGL_NO_CONTEXT)
    {
      eglDestroyContext(egl_display_, egl_context_);
      egl_context_ = EGL_NO_CONTEXT;
    }
    eglTerminate(egl_display_);
    egl_display_ = EGL_NO_DISPLAY;
  }
#endif
}

#ifdef __APPLE__
bool CameraPlugin::init_cgl_context()
{
  const CGLPixelFormatAttribute attributes[] = {
    kCGLPFAOpenGLProfile,
    static_cast<CGLPixelFormatAttribute>(kCGLOGLPVersion_Legacy),
    kCGLPFAColorSize,
    static_cast<CGLPixelFormatAttribute>(24),
    kCGLPFAAlphaSize,
    static_cast<CGLPixelFormatAttribute>(8),
    kCGLPFADepthSize,
    static_cast<CGLPixelFormatAttribute>(24),
    kCGLPFAStencilSize,
    static_cast<CGLPixelFormatAttribute>(8),
    kCGLPFAMultisample,
    kCGLPFASampleBuffers,
    static_cast<CGLPixelFormatAttribute>(1),
    kCGLPFASamples,
    static_cast<CGLPixelFormatAttribute>(4),
    kCGLPFAAccelerated,
    static_cast<CGLPixelFormatAttribute>(0),
  };
  GLint pixel_format_count = 0;
  CGLError error = CGLChoosePixelFormat(attributes, &cgl_pixel_format_, &pixel_format_count);
  if (error != kCGLNoError || cgl_pixel_format_ == nullptr || pixel_format_count == 0)
  {
    RCLCPP_ERROR(node_->get_logger(), "CGL: Failed to choose pixel format: %s", CGLErrorString(error));
    cleanup_cgl_context();
    return false;
  }

  error = CGLCreateContext(cgl_pixel_format_, nullptr, &cgl_context_);
  if (error != kCGLNoError || cgl_context_ == nullptr)
  {
    RCLCPP_ERROR(node_->get_logger(), "CGL: Failed to create context: %s", CGLErrorString(error));
    cleanup_cgl_context();
    return false;
  }

  error = CGLSetCurrentContext(cgl_context_);
  if (error != kCGLNoError)
  {
    RCLCPP_ERROR(node_->get_logger(), "CGL: Failed to make context current: %s", CGLErrorString(error));
    cleanup_cgl_context();
    return false;
  }

  error = CGLLockContext(cgl_context_);
  if (error != kCGLNoError)
  {
    RCLCPP_ERROR(node_->get_logger(), "CGL: Failed to lock context: %s", CGLErrorString(error));
    cleanup_cgl_context();
    return false;
  }
  cgl_locked_ = true;
  RCLCPP_INFO(node_->get_logger(), "CGL: Successfully initialized headless OpenGL context");
  return true;
}

void CameraPlugin::cleanup_cgl_context()
{
  if (cgl_context_ != nullptr && cgl_locked_)
  {
    CGLUnlockContext(cgl_context_);
    cgl_locked_ = false;
  }
  if (cgl_context_ != nullptr)
  {
    CGLSetCurrentContext(nullptr);
    CGLReleaseContext(cgl_context_);
    cgl_context_ = nullptr;
  }
  if (cgl_pixel_format_ != nullptr)
  {
    CGLReleasePixelFormat(cgl_pixel_format_);
    cgl_pixel_format_ = nullptr;
  }
}
#endif

void CameraPlugin::update_loop()
{
  GLFWwindow* window = nullptr;

#ifdef __APPLE__
  window = macos_window_;
  if (use_cgl_ && !init_cgl_context())
  {
    RCLCPP_ERROR(node_->get_logger(), "Failed to initialize CGL context. Disabling camera publishing.");
    publish_images_ = false;
    return;
  }
#else
  if (use_egl_)
  {
    // Initialize EGL for headless rendering
    if (!init_egl_context())
    {
      RCLCPP_ERROR(node_->get_logger(), "Failed to initialize EGL context. Disabling camera publishing.");
      publish_images_ = false;
      return;
    }
  }
  else
  {
    // Use GLFW for offscreen context (display available)
    glfwWindowHint(GLFW_VISIBLE, GLFW_FALSE);
    window = glfwCreateWindow(1, 1, "", NULL, NULL);
    if (!window)
    {
      RCLCPP_ERROR(node_->get_logger(), "Failed to create GLFW window. Disabling camera publishing.");
      publish_images_ = false;
      return;
    }
    glfwMakeContextCurrent(window);
  }
#endif

  // Determine rendering backend name for logging
#ifdef __APPLE__
  const char* backend = use_cgl_ ? "CGL" : "GLFW";
#else
  const char* backend = use_egl_ ? "EGL" : "GLFW";
#endif

  // Initialization of the context and data structures has to happen in the rendering thread
  RCLCPP_INFO(node_->get_logger(), "Initializing rendering for cameras (using %s)", backend);
  mjv_defaultOption(&mjv_opt_);
  mjv_defaultScene(&mjv_scn_);
  mjr_defaultContext(&mjr_con_);

  // Turn rangefinder rendering off so we don't get rays in camera images
  mjv_opt_.flags[mjtVisFlag::mjVIS_RANGEFINDER] = 0;
  // Turn off site rendering so that visualization is more realistic in cameras for testing perception.
  for (int i = 0; i < mjNGROUP; i++)
  {
    mjv_opt_.sitegroup[i] = 0;
  }

  // Initialize data for camera rendering
  mj_camera_data_ = mj_makeData(mj_model_);
  RCLCPP_INFO(node_->get_logger(), "Starting the camera rendering loop, publishing at %f Hz", camera_publish_rate_);

  const auto initialize_render_resources = [this]() {
    // create scene and context
    mjv_makeScene(mj_model_, &mjv_scn_, 2000);

    mjr_makeContext(mj_model_, &mjr_con_, mjFONTSCALE_150);

    // Ensure the context will support the largest cameras
    int max_width = 1, max_height = 1;
    for (const auto& cam : cameras_)
    {
      max_width = std::max(max_width, static_cast<int>(cam.width));
      max_height = std::max(max_height, static_cast<int>(cam.height));
    }
    mjr_resizeOffscreen(max_width, max_height, &mjr_con_);
    RCLCPP_INFO(node_->get_logger(), "Resized offscreen buffer to %d x %d", max_width, max_height);
  };

  {
    std::lock_guard<std::mutex> render_lock(render_mutex_);
#ifdef __APPLE__
    if (use_cgl_)
    {
      initialize_render_resources();
    }
    else
    {
      ScopedGlfwContext context(window);
      initialize_render_resources();
    }
#else
    initialize_render_resources();
#endif
  }
  for (auto& camera : cameras_)
    if (camera.truth) camera.truth->sender->start(camera.truth->sender);
  render_resources_ready_.store(true);

  // Only process images once all data has been initialized, and do it until told to stop.
  // Publishing is enabled under the lock so that a shutdown requested during the (possibly
  // slow) initialization above is observed here rather than being clobbered.
  {
    std::lock_guard<std::mutex> lock(data_mutex_);
    publish_images_ = rendering_enabled_.load() && !stop_requested_.load();
  }
  while (rclcpp::ok() && !stop_requested_)
  {
    std::unique_lock<std::mutex> lock(data_mutex_);

    // Wait for the main thread to copy the data and trigger this to process and publish
    // images. Note that condition_variables can be awoken spuriously, so the additional
    // checks are necessary to avoid doing work excepting when updated rendering data has
    // been made available.
    data_cv_.wait(lock, [this] { return new_data_ || stop_requested_; });

    // Shutdown triggered, kill the loop and clean up.
    if (stop_requested_)
    {
      break;
    }
    new_data_ = false;
    lock.unlock();

    std::lock_guard<std::mutex> render_lock(render_mutex_);
    std::lock_guard<std::mutex> data_lock(data_mutex_);
    if (!rendering_enabled_.load())
    {
      continue;
    }
#ifdef __APPLE__
    if (use_cgl_)
    {
      update_cameras();
    }
    else
    {
      ScopedGlfwContext context(window);
      update_cameras();
    }
#else
    update_cameras();
#endif
  }
  publish_images_ = false;
  render_resources_ready_ = false;

  {
    std::lock_guard<std::mutex> render_lock(render_mutex_);
#ifdef __APPLE__
    if (use_cgl_)
    {
      mjv_freeScene(&mjv_scn_);
      mjr_freeContext(&mjr_con_);
    }
    else
    {
      ScopedGlfwContext context(window);
      mjv_freeScene(&mjv_scn_);
      mjr_freeContext(&mjr_con_);
    }
#else
    mjv_freeScene(&mjv_scn_);
    mjr_freeContext(&mjr_con_);
#endif
  }
  mj_deleteData(mj_camera_data_);

#ifdef __APPLE__
  if (use_cgl_)
  {
    cleanup_cgl_context();
  }
#else
  if (use_egl_)
  {
    cleanup_egl_context();
  }
  else if (window)
  {
    glfwDestroyWindow(window);
  }
#endif
}

void CameraPlugin::update_cameras()
{
  // Callers hold render_mutex_ followed by data_mutex_. The latter protects both the pending
  // flags and mj_camera_data_ from being overwritten by the simulation while a frame is read.
  // Gather the cameras flagged for rendering this pass, clearing the flag as we go.
  render_indices_.clear();
  for (size_t i = 0; i < cameras_.size(); ++i)
  {
    auto& camera = cameras_[i];
    if (camera.render_pending)
    {
      camera.render_pending = false;
      render_indices_.push_back(i);
    }
  }
  if (render_indices_.empty())
  {
    return;
  }

  // Rendering is done offscreen using the data snapshot taken in `update`.
  mjr_setBuffer(mjFB_OFFSCREEN, &mjr_con_);

  camera_near_distance_ = static_cast<float>(mj_model_->vis.map.znear * mj_model_->stat.extent);
  const float far = static_cast<float>(mj_model_->vis.map.zfar * mj_model_->stat.extent);
  camera_depth_scale_ = 1.0f - camera_near_distance_ / far;

  // Use the snapshotted data's timestamp in the ROS header, as that is when the data was actually pulled.
  const rclcpp::Time stamp(std::llround(mj_camera_data_->time * 1000000000.0), RCL_ROS_TIME);

  for (const auto idx : render_indices_)
  {
    render_and_publish_camera(cameras_[idx], stamp);
  }
}

void CameraPlugin::render_and_publish_camera(CameraData& camera, const rclcpp::Time& stamp)
{
  const auto render_started_ns = camera.truth ? steady_nanoseconds() : 0;
  // Step 1: Render the scene and copy images to relevant camera data containers.
  // Render scene
  mjv_updateScene(mj_model_, mj_camera_data_, &mjv_opt_, NULL, &camera.mjv_cam, mjCAT_ALL, &mjv_scn_);
  mjr_render(camera.viewport, &mjv_scn_, &mjr_con_);

  // Copy image into relevant buffers
  mjr_readPixels(camera.image_buffer.data(),
                 camera.publish_depth ? camera.depth_buffer.data() : nullptr, camera.viewport, &mjr_con_);

  // Step 2: Adjust the images and copy depth data.
  // Fix non-linear depth buffer and flip it vertically (OpenGL's origin is the bottom left)
  // https://github.com/google-deepmind/mujoco/blob/3.4.0/python/mujoco/renderer.py#L190
  if (camera.publish_depth)
  {
    auto* depth_out = reinterpret_cast<float*>(camera.depth_image.data.data());
    for (uint32_t h = 0; h < camera.height; ++h)
    {
      const float* src_row = camera.depth_buffer.data() + static_cast<size_t>(h) * camera.width;
      float* dst_row = depth_out + static_cast<size_t>(camera.height - 1 - h) * camera.width;
      for (uint32_t w = 0; w < camera.width; ++w)
      {
        dst_row[w] = camera_near_distance_ / (1.0f - src_row[w] * camera_depth_scale_);
      }
    }
  }

  // OpenGL's coordinate system's origin is in the bottom left, so we invert the images row-by-row
  const auto row_size = camera.width * 3;
  for (uint32_t h = 0; h < camera.height; ++h)
  {
    const auto src_idx = h * row_size;
    const auto dest_idx = (camera.height - 1 - h) * row_size;
    std::memcpy(&camera.image.data[dest_idx], &camera.image_buffer[src_idx], row_size);
  }

  // Step 3: Publish the images and camera info.
  camera.image.header.stamp = stamp;
  camera.camera_info.header.stamp = stamp;

  camera.image_pub->publish(camera.image);
  if (camera.publish_depth)
  {
    camera.depth_image.header.stamp = stamp;
    camera.depth_image_pub->publish(camera.depth_image);
  }
  camera.camera_info_pub->publish(camera.camera_info);
  if (camera.truth && truth_capture_armed_) capture_truth(camera, render_started_ns);
}

void CameraPlugin::capture_truth(CameraData& camera, int64_t render_started_ns)
{
  auto& buffers = *camera.truth;
  auto& sender = *buffers.sender;
  auto* slot = sender.queue.try_begin();
  if (!slot) return;
  try
  {
    if (mjv_scn_.ngeom < 0 || mjv_scn_.ngeom > static_cast<int>(TRUTH_MAX_GEOMS) ||
        mjv_scn_.nflex || mjv_scn_.nskin || mjv_scn_.status)
      throw std::runtime_error("TRUTH_SCENE_LIMIT");
    buffers.frozen_scene = mjv_scn_;
    std::copy_n(mjv_scn_.geoms, mjv_scn_.ngeom, buffers.frozen_geoms.begin());
    const auto snapshot_time = mj_camera_data_->time;
    buffers.mapping.clear();
    auto& envelope = slot->value;
    envelope.reference_kind = CameraTruthSender::Envelope::NONE;
    envelope.reference.width = envelope.reference.height = envelope.reference.step = 0;
    envelope.reference.encoding.clear();
    envelope.reference.header.frame_id.clear();
    envelope.reference.header.stamp = builtin_interfaces::msg::Time();
    envelope.reference.data.clear();
    envelope.scene_light_model_ids.clear();
    envelope.hidden_geom_ids.clear();
    envelope.reference_light_diffuse.clear();
    envelope.reference_light_specular.clear();
    envelope.frozen_cameras.clear();
    envelope.scene_restored = false;
    envelope.initial_render_elapsed_ns = 0;
    auto& frame = envelope.original;
    frame.rgb = camera.image;
    frame.camera_info = camera.camera_info;
    frame.instances.header = camera.image.header;
    frame.segmentation_ids.clear();
    frame.object_ids.clear();
    frame.object_types.clear();
    for (int index = 0; index < mjv_scn_.ngeom; ++index)
    {
      const auto& geom = mjv_scn_.geoms[index];
      if (geom.segid < 0) continue;
      buffers.mapping.push_back({geom.segid, geom.objid, geom.objtype});
      frame.segmentation_ids.push_back(geom.segid);
      frame.object_ids.push_back(geom.objid);
      frame.object_types.push_back(geom.objtype);
    }
    {
      ScopedSegmentationFlags flags(mjv_scn_);
      mjr_render(camera.viewport, &mjv_scn_, &mjr_con_);
      mjr_readPixels(buffers.id_color.data(), nullptr, camera.viewport, &mjr_con_);
    }
    // Physics may advance elsewhere. Only this protected snapshot/scene may not
    // change between the production RGB render and the ID-color readback.
    if (snapshot_time != mj_camera_data_->time ||
        std::memcmp(&buffers.frozen_scene, &mjv_scn_, sizeof(mjvScene)) != 0 ||
        std::memcmp(buffers.frozen_geoms.data(), mjv_scn_.geoms,
                    static_cast<size_t>(mjv_scn_.ngeom) * sizeof(mjvGeom)) != 0)
      throw std::runtime_error("TRUTH_RENDER_SCENE_CHANGED");
    if (!decode_instance_image(buffers.id_color, camera.width, camera.height,
                               buffers.mapping, frame.instances.data))
      throw std::runtime_error("TRUTH_INSTANCE_DECODE_INVALID");
    if (slot->sequence==1 && buffers.reference_kind!=TruthReferenceKind::NONE)
    {
      const bool normal_light = buffers.reference_kind==TruthReferenceKind::NORMAL_LIGHT;
      envelope.reference_kind = normal_light ? CameraTruthSender::Envelope::NORMAL_LIGHT :
                                               CameraTruthSender::Envelope::AMODAL_CUP;
      auto& reference = envelope.reference;
      reference.header = camera.image.header;
      reference.width = camera.width; reference.height = camera.height;
      reference.encoding = normal_light ? "rgb8" : "32SC2";
      reference.is_bigendian = false;
      reference.step = camera.width*(normal_light ? 3 : 8);
      reference.data.resize(size_t(reference.step)*camera.height);
      for(int index=0;index<mjv_scn_.nlight;++index)
        envelope.scene_light_model_ids.push_back(mjv_scn_.lights[index].id);
      envelope.hidden_geom_ids.assign(buffers.hidden_geom_ids.begin(),buffers.hidden_geom_ids.end());
      envelope.reference_light_diffuse.assign(buffers.baseline_diffuse.begin(),buffers.baseline_diffuse.end());
      envelope.reference_light_specular.assign(buffers.baseline_specular.begin(),buffers.baseline_specular.end());
      for(const auto& view : mjv_scn_.camera)
      {
        for(const auto value : view.pos)envelope.frozen_cameras.push_back(value);
        for(const auto value : view.forward)envelope.frozen_cameras.push_back(value);
        for(const auto value : view.up)envelope.frozen_cameras.push_back(value);
        for(const auto value : {view.frustum_center,view.frustum_width,view.frustum_bottom,
                               view.frustum_top,view.frustum_near,view.frustum_far})
          envelope.frozen_cameras.push_back(value);
        envelope.frozen_cameras.push_back(view.orthographic);
      }
      {
        ScopedTruthReference changed(mjv_scn_,*mj_model_,buffers.reference_kind,
                                     buffers.baseline_diffuse,buffers.baseline_specular,buffers.hidden_geom_ids);
        if(normal_light)
        {
          mjr_render(camera.viewport,&mjv_scn_,&mjr_con_);
          mjr_readPixels(buffers.id_color.data(),nullptr,camera.viewport,&mjr_con_);
          for(uint32_t row=0;row<camera.height;++row)
            std::memcpy(reference.data.data()+size_t(camera.height-1-row)*camera.width*3,
                        buffers.id_color.data()+size_t(row)*camera.width*3,size_t(camera.width)*3);
        }
        else
        {
          ScopedSegmentationFlags flags(mjv_scn_);
          mjr_render(camera.viewport,&mjv_scn_,&mjr_con_);
          mjr_readPixels(buffers.id_color.data(),nullptr,camera.viewport,&mjr_con_);
          if(!decode_instance_image(buffers.id_color,camera.width,camera.height,buffers.mapping,reference.data))
            throw std::runtime_error("TRUTH_REFERENCE_INSTANCE_INVALID");
        }
        changed.verify_frozen_scene(buffers.frozen_geoms);
      }
      if(snapshot_time!=mj_camera_data_->time ||
         std::memcmp(&buffers.frozen_scene,&mjv_scn_,sizeof(mjvScene))!=0 ||
         std::memcmp(buffers.frozen_geoms.data(),mjv_scn_.geoms,size_t(mjv_scn_.ngeom)*sizeof(mjvGeom))!=0)
        throw std::runtime_error("TRUTH_REFERENCE_SCENE_NOT_RESTORED");
      envelope.scene_restored = true;
      envelope.initial_render_elapsed_ns = steady_nanoseconds()-render_started_ns;
    }
    sender.queue.commit(*slot);
    sender.wake.notify_one();
  }
  catch (const std::exception& error)
  {
    sender.queue.rejected(*slot);
    RCLCPP_ERROR(logger_, "Camera truth rejected: %s", error.what());
  }
  catch (...)
  {
    sender.queue.rejected(*slot);
    RCLCPP_ERROR(logger_, "Camera truth rejected at render boundary.");
  }
}

void CameraPlugin::handle_trigger(const std::shared_ptr<std_srvs::srv::Trigger::Request> /*request*/,
                                  std::shared_ptr<std_srvs::srv::Trigger::Response> response, const int camera_idx)
{
  {
    std::lock_guard<std::mutex> lock(data_mutex_);
    cameras_.at(static_cast<size_t>(camera_idx)).poll_requested = true;
  }
  // Wake the fast path in `update()` so the request is picked up on the next sim step.
  poll_pending_.store(true);
  response->success = true;
}

}  // namespace mujoco_ros2_control_plugins

// Export the plugin
PLUGINLIB_EXPORT_CLASS(mujoco_ros2_control_plugins::CameraPlugin,
                       mujoco_ros2_control_plugins::MuJoCoROS2ControlPluginBase)
