#pragma once

#include <mujoco/mujoco.h>
#include <array>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <stdexcept>
#include <vector>
#include "camera_truth.hpp"

namespace mujoco_ros2_control_plugins
{
enum class TruthReferenceKind { NONE=0, NORMAL_LIGHT=1, AMODAL_CUP=2 };

// Render-only mutations to the already frozen private scene. Validate the whole
// change before applying any part; no model/data access is mutable here.
class ScopedTruthReference
{
public:
  ScopedTruthReference(mjvScene& scene,const mjModel& model,TruthReferenceKind kind,
                       const std::vector<double>& diffuse,const std::vector<double>& specular,
                       const std::vector<int>& hidden) : scene_(scene), original_(scene)
  {
    if(scene.ngeom<0 || scene.ngeom>int(TRUTH_MAX_GEOMS) || scene.nlight<0 || scene.nlight>mjMAXLIGHT)
      throw std::runtime_error("TRUTH_REFERENCE_SCENE_LIMIT");
    if(scene.ngeom && (!scene.geoms || !scene.geomorder))
      throw std::runtime_error("TRUTH_REFERENCE_SCENE_BUFFERS");
    std::copy_n(scene.geoms,scene.ngeom,original_geoms_.begin());
    std::copy_n(scene.geomorder,scene.ngeom,original_geomorder_.begin());
    for(int index=0;index<scene.ngeom;++index)kept_indices_[index]=index;
    if(kind==TruthReferenceKind::NORMAL_LIGHT)
    {
      if(!hidden.empty() || model.nlight<=0 || model.nlight>=mjMAXLIGHT ||
         diffuse.size()!=size_t(3*model.nlight) || specular.size()!=diffuse.size())
        throw std::runtime_error("TRUTH_REFERENCE_BASELINE_LAYOUT");
      for(size_t index=0;index<diffuse.size();++index)
        if(!std::isfinite(diffuse[index]) || !std::isfinite(specular[index]) ||
           diffuse[index]<0 || specular[index]<0 ||
           model.light_diffuse[index]!=static_cast<float>(diffuse[index]*.35) ||
           model.light_specular[index]!=static_cast<float>(specular[index]*.35))
          throw std::runtime_error("TRUTH_REFERENCE_BASELINE_COEFFICIENT");
      std::array<bool,mjMAXLIGHT> seen{};
      int headlights=0,active=0;
      for(int id=0;id<model.nlight;++id)active+=bool(model.light_active[id]);
      for(int index=0;index<scene.nlight;++index)
      {
        const auto& light=scene.lights[index];
        if(light.headlight)
        {
          if(light.id!=-1 || ++headlights>1 || !model.vis.headlight.active)
            throw std::runtime_error("TRUTH_REFERENCE_HEADLIGHT_MAPPING");
          continue;
        }
        const int id=light.id;
        if(id<0 || id>=model.nlight || !model.light_active[id] || seen[id])
          throw std::runtime_error("TRUTH_REFERENCE_LIGHT_MAPPING");
        seen[id]=true;
        for(int channel=0;channel<3;++channel)
          if(light.diffuse[channel]!=model.light_diffuse[3*id+channel] ||
             light.specular[channel]!=model.light_specular[3*id+channel] ||
             light.ambient[channel]!=model.light_ambient[3*id+channel])
            throw std::runtime_error("TRUTH_REFERENCE_LIGHT_COEFFICIENT");
      }
      if(scene.nlight!=active+headlights || headlights!=int(bool(model.vis.headlight.active)))
        throw std::runtime_error("TRUTH_REFERENCE_LIGHT_TRUNCATED");
      for(int id=0;id<model.nlight;++id)
        if(seen[id]!=bool(model.light_active[id]))
          throw std::runtime_error("TRUTH_REFERENCE_LIGHT_MISSING");
      for(int index=0;index<scene.nlight;++index)
      {
        auto& light=scene.lights[index];
        if(light.headlight)continue;
        for(int channel=0;channel<3;++channel)
        {
          light.diffuse[channel]=static_cast<float>(diffuse[3*light.id+channel]);
          light.specular[channel]=static_cast<float>(specular[3*light.id+channel]);
        }
      }
    }
    else if(kind==TruthReferenceKind::AMODAL_CUP)
    {
      if(!diffuse.empty() || !specular.empty() || hidden.empty() || hidden.size()>TRUTH_MAX_GEOMS)
        throw std::runtime_error("TRUTH_REFERENCE_OCCLUDER_LAYOUT");
      for(size_t index=0;index<hidden.size();++index)
      {
        const int id=hidden[index];
        if(id<0 || id>=model.ngeom || std::find(hidden.begin(),hidden.begin()+index,id)!=hidden.begin()+index)
          throw std::runtime_error("TRUTH_REFERENCE_OCCLUDER_ID");
        int found=-1;
        for(int geom=0;geom<scene.ngeom;++geom)
          if(scene.geoms[geom].objtype==mjOBJ_GEOM && scene.geoms[geom].objid==id)
          {
            if(found!=-1)throw std::runtime_error("TRUTH_REFERENCE_OCCLUDER_AMBIGUOUS");
            found=geom;
          }
        if(found<0 || scene.geoms[found].rgba[3]<=0)
          throw std::runtime_error("TRUTH_REFERENCE_OCCLUDER_MISSING");
        hidden_flags_[found]=true;
      }
      // Alpha zero still occludes in MuJoCo's categorical render. Exclude only
      // these visual entries from this frozen scene, retaining original segids.
      // This neither updates the scene nor changes live model/data.
      int remaining=0;
      for(int index=0;index<original_.ngeom;++index)
        if(!hidden_flags_[index])
        {
          scene.geoms[remaining]=original_geoms_[index];
          kept_indices_[remaining++]=index;
        }
      scene.ngeom=remaining;
    }
    else throw std::runtime_error("TRUTH_REFERENCE_KIND");
    expected_=scene;
  }
  void verify_frozen_scene(const std::vector<mjvGeom>& geoms) const
  {
    if(std::memcmp(&expected_,&scene_,sizeof(mjvScene))!=0 || geoms.size()<size_t(original_.ngeom))
      throw std::runtime_error("TRUTH_REFERENCE_FROZEN_SCENE_CHANGED");
    for(int index=0;index<scene_.ngeom;++index)
    {
      const auto& expected_geom=geoms[kept_indices_[index]];
      if(std::memcmp(&expected_geom,&scene_.geoms[index],sizeof(mjvGeom))!=0)
        throw std::runtime_error("TRUTH_REFERENCE_FROZEN_GEOMETRY_CHANGED");
    }
  }
  ~ScopedTruthReference()
  {
    std::copy_n(original_geoms_.begin(),original_.ngeom,scene_.geoms);
    std::copy_n(original_geomorder_.begin(),original_.ngeom,scene_.geomorder);
    // Inline lights, cameras and render flags return to their exact prior bytes.
    scene_=original_;
  }
  ScopedTruthReference(const ScopedTruthReference&)=delete;
  ScopedTruthReference& operator=(const ScopedTruthReference&)=delete;
private:
  mjvScene& scene_;
  mjvScene original_;
  mjvScene expected_{};
  std::array<bool,TRUTH_MAX_GEOMS> hidden_flags_{};
  std::array<mjvGeom,TRUTH_MAX_GEOMS> original_geoms_;
  std::array<int,TRUTH_MAX_GEOMS> original_geomorder_, kept_indices_;
};
}  // namespace mujoco_ros2_control_plugins
