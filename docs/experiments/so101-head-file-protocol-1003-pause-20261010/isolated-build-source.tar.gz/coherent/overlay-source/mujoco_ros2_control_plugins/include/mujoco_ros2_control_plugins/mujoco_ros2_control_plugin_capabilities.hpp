// Copyright 2026 PAL Robotics S.L.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef MUJOCO_ROS2_CONTROL_PLUGINS__PLUGIN_CAPABILITIES_HPP_
#define MUJOCO_ROS2_CONTROL_PLUGINS__PLUGIN_CAPABILITIES_HPP_

#include <mujoco/mujoco.h>

namespace mujoco_ros2_control_plugins
{

class MuJoCoROS2ControlSimulationObserver
{
public:
  virtual ~MuJoCoROS2ControlSimulationObserver() = default;
  virtual void on_physics_step(const mjModel*, const mjData*)
  {
  }
  virtual void on_reset()
  {
  }
  virtual void on_pause(bool)
  {
  }
  virtual void on_state_snapshot(const mjModel*, const mjData*, bool)
  {
  }
};

class MuJoCoROS2ControlRenderingPlugin
{
public:
  virtual ~MuJoCoROS2ControlRenderingPlugin() = default;
  virtual void set_platform_render_context(void* context) = 0;
  virtual void set_rendering_enabled(bool enabled) = 0;
  virtual void close_rendering() = 0;
};

}  // namespace mujoco_ros2_control_plugins

#endif  // MUJOCO_ROS2_CONTROL_PLUGINS__PLUGIN_CAPABILITIES_HPP_
