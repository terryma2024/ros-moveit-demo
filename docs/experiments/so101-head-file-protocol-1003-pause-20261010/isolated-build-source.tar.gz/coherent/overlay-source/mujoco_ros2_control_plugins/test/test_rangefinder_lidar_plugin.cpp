// Copyright 2026 PAL Robotics S.L.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include <gtest/gtest.h>

#include <cmath>
#include <memory>
#include <string>

#include <mujoco/mujoco.h>
#include <rclcpp/rclcpp.hpp>

#include "rangefinder_lidar_plugin.hpp"

namespace
{
constexpr const char* kThreeRangefinderMjcf = R"(
<mujoco model="rangefinder_lidar_test">
  <worldbody>
    <body name="sensor_body" pos="0 0 1">
      <geom type="sphere" size="0.01"/>
      <site name="rangefinder_site_0" pos="0 0 0"/>
      <site name="rangefinder_site_1" pos="0.01 0 0"/>
      <site name="rangefinder_site_2" pos="-0.01 0 0"/>
    </body>
  </worldbody>
  <sensor>
    <rangefinder name="lidar-0" site="rangefinder_site_0"/>
    <rangefinder name="lidar-1" site="rangefinder_site_1"/>
    <rangefinder name="lidar-2" site="rangefinder_site_2"/>
  </sensor>
</mujoco>
)";

constexpr const char* kTwentyFourRangefinderMjcf = R"(
<mujoco model="rangefinder_lidar_production_count_test">
  <worldbody>
    <body name="sensor_body" pos="0 0 1">
      <geom type="sphere" size="0.01"/>
      <replicate count="24" sep="-" offset="0 0 0">
        <site name="rangefinder_site" pos="0 0 0"/>
      </replicate>
    </body>
  </worldbody>
  <sensor>
    <rangefinder name="lidar" site="rangefinder_site"/>
  </sensor>
</mujoco>
)";

mjModel* compileModel(const char* xml)
{
  char error[1024] = { 0 };
  mjSpec* spec = mj_parseXMLString(xml, nullptr, error, sizeof(error));
  if (spec == nullptr)
  {
    ADD_FAILURE() << error;
    return nullptr;
  }
  mjModel* model = mj_compile(spec, nullptr);
  if (model == nullptr)
  {
    ADD_FAILURE() << (mjs_getError(spec) ? mjs_getError(spec) : "mj_compile failed");
  }
  mj_deleteSpec(spec);
  return model;
}
}  // namespace

class RangefinderLidarPluginTest : public ::testing::Test
{
protected:
  static void SetUpTestSuite()
  {
    if (!rclcpp::ok())
    {
      rclcpp::init(0, nullptr);
    }
  }

  static void TearDownTestSuite()
  {
    if (rclcpp::ok())
    {
      rclcpp::shutdown();
    }
  }

  void SetUp() override
  {
    node_ = std::make_shared<rclcpp::Node>("rangefinder_lidar_plugin_test_node");
    model_ = compileModel(kThreeRangefinderMjcf);
    ASSERT_NE(model_, nullptr);
    data_ = mj_makeData(model_);
    ASSERT_NE(data_, nullptr);
  }

  void TearDown() override
  {
    node_.reset();
    mj_deleteData(data_);
    data_ = nullptr;
    mj_deleteModel(model_);
    model_ = nullptr;
  }

  void declareAngularConfiguration(double min_angle, double max_angle, double angle_increment)
  {
    const std::string ns = "mujoco_plugins.rangefinder_lidar_plugin.lidar.";
    node_->declare_parameter(ns + "frame_name", std::string("lidar_frame"));
    node_->declare_parameter(ns + "min_angle", min_angle);
    node_->declare_parameter(ns + "max_angle", max_angle);
    node_->declare_parameter(ns + "angle_increment", angle_increment);
  }

  void loadModel(const char* xml)
  {
    mj_deleteData(data_);
    data_ = nullptr;
    mj_deleteModel(model_);
    model_ = compileModel(xml);
    ASSERT_NE(model_, nullptr);
    data_ = mj_makeData(model_);
    ASSERT_NE(data_, nullptr);
  }

  rclcpp::Node::SharedPtr node_;
  mjModel* model_{ nullptr };
  mjData* data_{ nullptr };
};

TEST_F(RangefinderLidarPluginTest, RejectsTwoToTheMinus64IncrementWithoutThrowing)
{
  declareAngularConfiguration(0.0, 1.0, std::ldexp(1.0, -64));
  mujoco_ros2_control_plugins::RangefinderLidarPlugin plugin;

  bool initialized = true;
  EXPECT_NO_THROW(initialized = plugin.init(node_, model_, data_));
  EXPECT_FALSE(initialized);
  plugin.cleanup();
}

TEST_F(RangefinderLidarPluginTest, RejectsFiniteMillionRayRequestWithoutThrowing)
{
  declareAngularConfiguration(0.0, 1.0, 1.0e-6);
  mujoco_ros2_control_plugins::RangefinderLidarPlugin plugin;

  bool initialized = true;
  EXPECT_NO_THROW(initialized = plugin.init(node_, model_, data_));
  EXPECT_FALSE(initialized);
  plugin.cleanup();
}

TEST_F(RangefinderLidarPluginTest, AcceptsConfigurationWithinModelRangefinderCount)
{
  declareAngularConfiguration(-1.0, 1.0, 1.0);
  mujoco_ros2_control_plugins::RangefinderLidarPlugin plugin;

  bool initialized = false;
  EXPECT_NO_THROW(initialized = plugin.init(node_, model_, data_));
  EXPECT_TRUE(initialized);
  plugin.cleanup();
}

TEST_F(RangefinderLidarPluginTest, AcceptsProductionTwentyFourRayConfiguration)
{
  loadModel(kTwentyFourRangefinderMjcf);
  declareAngularConfiguration(-0.3, 0.3, 0.025);
  mujoco_ros2_control_plugins::RangefinderLidarPlugin plugin;

  bool initialized = false;
  EXPECT_NO_THROW(initialized = plugin.init(node_, model_, data_));
  EXPECT_TRUE(initialized);
  plugin.cleanup();
}
