#include <gtest/gtest.h>
#include <mujoco/mujoco.h>
#include <cstring>
#include "camera_truth_reference.hpp"

using namespace mujoco_ros2_control_plugins;

class TruthReferenceTest : public ::testing::Test
{
protected:
  mjModel* model=nullptr;
  mjData* data=nullptr;
  mjvScene scene{};
  void SetUp() override
  {
    char error[1000]{};
    auto* spec=mj_parseXMLString(R"(<mujoco><worldbody>
      <light name="key" diffuse=".28 .28 .28" specular=".07 .07 .07"/>
      <geom name="target" type="sphere" size=".1"/>
      <geom name="occluder" type="sphere" size=".05" pos=".05 0 .2"/>
      <camera name="cam" pos="0 0 1" resolution="640 480"/>
    </worldbody></mujoco>)",nullptr,error,sizeof(error));
    ASSERT_NE(spec,nullptr)<<error;
    model=mj_compile(spec,nullptr);mj_deleteSpec(spec);ASSERT_NE(model,nullptr);
    data=mj_makeData(model);mj_forward(model,data);
    mjv_defaultScene(&scene);mjv_makeScene(model,&scene,2000);
    mjvOption options; mjv_defaultOption(&options);
    mjvCamera camera; mjv_defaultCamera(&camera);camera.type=mjCAMERA_FIXED;camera.fixedcamid=0;
    mjv_updateScene(model,data,&options,nullptr,&camera,mjCAT_ALL,&scene);
  }
  void TearDown() override
  {
    mjv_freeScene(&scene);mj_deleteData(data);mj_deleteModel(model);
  }
};

TEST_F(TruthReferenceTest, ActualLightIdentityPreservesHeadlightAndRestoresOnException)
{
  const auto original=scene;
  ASSERT_EQ(scene.nlight,2);
  try
  {
    ScopedTruthReference reference(scene,*model,TruthReferenceKind::NORMAL_LIGHT,
                                   {.8,.8,.8},{.2,.2,.2},{});
    for(int index=0;index<scene.nlight;++index)
      if(scene.lights[index].headlight)
        EXPECT_EQ(std::memcmp(&scene.lights[index],&original.lights[index],sizeof(mjvLight)),0);
      else EXPECT_FLOAT_EQ(scene.lights[index].diffuse[0],.8F);
    throw std::runtime_error("reference render exception");
  }
  catch(const std::runtime_error&){}
  EXPECT_EQ(std::memcmp(&original,&scene,sizeof(scene)),0);
}

TEST_F(TruthReferenceTest, AmbiguousMissingOrTruncatedLightsRefuseWithoutMutation)
{
  for(int damage=0;damage<4;++damage)
  {
    const auto pristine=scene;
    if(damage==0)scene.lights[1].id=-1;
    if(damage==1)scene.nlight=1;
    if(damage==2)scene.lights[0].headlight=0;
    if(damage==3)scene.lights[1].diffuse[0]=.9F;
    const auto damaged=scene;
    EXPECT_THROW((ScopedTruthReference(scene,*model,TruthReferenceKind::NORMAL_LIGHT,
                                      {.8,.8,.8},{.2,.2,.2},{})),std::runtime_error);
    EXPECT_EQ(std::memcmp(&damaged,&scene,sizeof(scene)),0);
    scene=pristine;
  }
}

TEST_F(TruthReferenceTest, OnlyDeclaredOccluderIsExcludedAndRestored)
{
  const int id=mj_name2id(model,mjOBJ_GEOM,"occluder");
  const std::vector<mjvGeom> original(scene.geoms,scene.geoms+scene.ngeom);
  const auto pristine=scene;
  {
    ScopedTruthReference reference(scene,*model,TruthReferenceKind::AMODAL_CUP,{},{},{id});
    EXPECT_EQ(scene.ngeom,pristine.ngeom-1);
    for(int index=0;index<scene.ngeom;++index)
    {
      EXPECT_NE(scene.geoms[index].objid,id);
      auto found=std::find_if(original.begin(),original.end(),[&](const auto& geom){
        return geom.objtype==scene.geoms[index].objtype && geom.objid==scene.geoms[index].objid;
      });
      ASSERT_NE(found,original.end());
      EXPECT_EQ(std::memcmp(&scene.geoms[index],&*found,sizeof(mjvGeom)),0);
    }
  }
  EXPECT_EQ(std::memcmp(&scene,&pristine,sizeof(scene)),0);
  EXPECT_EQ(std::memcmp(scene.geoms,original.data(),original.size()*sizeof(mjvGeom)),0);
  EXPECT_THROW((ScopedTruthReference(scene,*model,TruthReferenceKind::AMODAL_CUP,{},{},{9999})),std::runtime_error);
}

TEST_F(TruthReferenceTest, FrozenCameraChangeCannotBeHiddenByScopeRestoration)
{
  const std::vector<mjvGeom> original(scene.geoms,scene.geoms+scene.ngeom);
  const auto pristine=scene;
  {
    ScopedTruthReference reference(scene,*model,TruthReferenceKind::NORMAL_LIGHT,{.8,.8,.8},{.2,.2,.2},{});
    scene.camera[0].pos[0]+=.1F;
    EXPECT_THROW(reference.verify_frozen_scene(original),std::runtime_error);
  }
  EXPECT_EQ(std::memcmp(&pristine,&scene,sizeof(scene)),0);
}

TEST_F(TruthReferenceTest, TransformChangesRefuseAndFullSceneReturnsToOriginalBytes)
{
  const int id=mj_name2id(model,mjOBJ_GEOM,"occluder");
  const std::vector<mjvGeom> original(scene.geoms,scene.geoms+scene.ngeom);
  {
    ScopedTruthReference reference(scene,*model,TruthReferenceKind::AMODAL_CUP,{},{},{id});
    EXPECT_NO_THROW(reference.verify_frozen_scene(original));
    scene.geoms[0].pos[0]+=.1F;
    EXPECT_THROW(reference.verify_frozen_scene(original),std::runtime_error);
  }
  EXPECT_EQ(std::memcmp(scene.geoms,original.data(),original.size()*sizeof(mjvGeom)),0);
}
