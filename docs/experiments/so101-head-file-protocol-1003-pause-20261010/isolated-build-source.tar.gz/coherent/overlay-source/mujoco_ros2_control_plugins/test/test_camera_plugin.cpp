/**
 * Copyright (c) 2026, United States Government, as represented by the
 * Administrator of the National Aeronautics and Space Administration.
 *
 * All rights reserved.
 *
 * This software is licensed under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with the
 * License. You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations
 * under the License.
 */

#include <gtest/gtest.h>

#include <chrono>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <numeric>
#include <cstring>
#include <thread>
#include <stdexcept>

#include <mujoco/mujoco.h>
#include <rclcpp/rclcpp.hpp>
#include <std_srvs/srv/trigger.hpp>

#include "camera_plugin.hpp"
#include <mujoco_ros2_control_msgs/msg/camera_truth_frame_v2.hpp>
#include "mujoco_ros2_control_plugins/mujoco_ros2_control_plugin_capabilities.hpp"

using namespace std::chrono_literals;


#ifndef __APPLE__
namespace
{
std::mutex camera_readback_mutex;
std::condition_variable camera_readback_cv;
bool block_camera_readback = false;
bool camera_readback_entered = false;
bool release_camera_readback = false;
std::atomic_bool fail_truth_readback{false}, mutate_truth_scene{false};
std::atomic_bool truth_render_inflight{false};
std::atomic_uint64_t normal_renders{0}, truth_renders{0};
}


extern "C" void mjr_render(mjrRect viewport, mjvScene* scene, const mjrContext* context)
{
  using Render = void (*)(mjrRect, mjvScene*, const mjrContext*);
  static const auto real_render = reinterpret_cast<Render>(dlsym(RTLD_NEXT, "mjr_render"));
  if (!real_render) std::abort();
  const bool truth = scene->flags[mjRND_SEGMENT] && scene->flags[mjRND_IDCOLOR];
  truth_render_inflight.store(truth);
  if (truth) ++truth_renders; else ++normal_renders;
  real_render(viewport, scene, context);
  if (truth && mutate_truth_scene.exchange(false) && scene->ngeom)
    scene->geoms[0].pos[0] += 0.5F; // Corrupt frozen scene, never live simulation.
}

// Interpose only this test binary's real render boundary, then forward to MuJoCo.
// The production worker and its data mutex remain unchanged.
extern "C" void mjr_readPixels(unsigned char* rgb, float* depth, mjrRect viewport,
                               const mjrContext* context)
{
  using ReadPixels = void (*)(unsigned char*, float*, mjrRect, const mjrContext*);
  static const auto real_read = reinterpret_cast<ReadPixels>(dlsym(RTLD_NEXT, "mjr_readPixels"));
  if (real_read == nullptr)
  {
    std::abort();
  }
  {
    std::unique_lock<std::mutex> lock(camera_readback_mutex);
    if (block_camera_readback)
    {
      block_camera_readback = false;
      camera_readback_entered = true;
      camera_readback_cv.notify_all();
      camera_readback_cv.wait(lock, []() { return release_camera_readback; });
    }
  }
  if (truth_render_inflight.load() && fail_truth_readback.exchange(false))
    throw std::runtime_error("TEST_TRUTH_READBACK_FAILURE");
  real_read(rgb, depth, viewport, context);
}
#endif

class CameraPluginTest : public ::testing::Test
{
protected:
  static constexpr auto WAIT_TIMEOUT = 2s;
  static constexpr auto POLL_INTERVAL = 20ms;

  static void SetUpTestSuite()
  {
    if (!rclcpp::ok())
    {
      rclcpp::init(0, nullptr);
    }
  }

  static void TearDownTestSuite()
  {
    if (rclcpp::ok())
    {
      rclcpp::shutdown();
    }
  }

  void SetUp() override
  {
    node_ = rclcpp::Node::make_shared("test_camera_plugin_node");
    plugin_node_ = node_->create_sub_node("camera_plugin");
  }

  void start_executor()
  {
    if (executor_)
    {
      return;
    }
    executor_ = std::make_unique<rclcpp::executors::MultiThreadedExecutor>();
    executor_->add_node(node_);
    spin_thread_ = std::thread([this]() { executor_->spin(); });
  }

  void TearDown() override
  {
    if (executor_)
    {
      executor_->cancel();
    }
    if (spin_thread_.joinable())
    {
      spin_thread_.join();
    }

    executor_.reset();
    plugin_node_.reset();
    node_.reset();

    if (data_)
    {
      mj_deleteData(data_);
      data_ = nullptr;
    }
    if (model_)
    {
      mj_deleteModel(model_);
      model_ = nullptr;
    }

    for (const auto& path : temp_files_)
    {
      if (std::filesystem::exists(path))
      {
        std::filesystem::remove(path);
      }
    }
  }

  void load_model(const std::string& xml)
  {
    auto path = "/tmp/test_camera_plugin_" + std::to_string(temp_files_.size()) + ".xml";
    {
      std::ofstream f(path);
      f << xml;
    }
    temp_files_.push_back(path);

    char error[1000] = "";
    model_ = mj_loadXML(path.c_str(), nullptr, error, sizeof(error));
    ASSERT_NE(model_, nullptr) << "mj_loadXML failed: " << error;
    data_ = mj_makeData(model_);
    ASSERT_NE(data_, nullptr);
  }

  // Blocks until the rendering thread has finished initializing its GL context.
  void wait_for_rendering(mujoco_ros2_control_plugins::CameraPlugin& plugin)
  {
    const auto deadline = std::chrono::steady_clock::now() + WAIT_TIMEOUT;
    while (!plugin.is_rendering_available() && std::chrono::steady_clock::now() < deadline)
    {
      std::this_thread::sleep_for(POLL_INTERVAL);
    }
    // TODO: We could optionally skip the test in CI if this happens consistently. Though
    // for now we hope that failures due to uninitialized contexts will be extremely rare.
    // https://github.com/ros-controls/mujoco_ros2_control/issues/216
    ASSERT_TRUE(plugin.is_rendering_available()) << "OpenGL rendering unavailable in this environment!!! Failing...";
  }

  // Block until every subscription in the list has matched at least one publisher.
  template <typename... Subs>
  void wait_for_subscriber_match(const Subs&... subs)
  {
    auto all_matched = [&]() { return ((subs->get_publisher_count() > 0) && ...); };
    const auto deadline = std::chrono::steady_clock::now() + WAIT_TIMEOUT;
    while (!all_matched() && std::chrono::steady_clock::now() < deadline)
    {
      std::this_thread::sleep_for(POLL_INTERVAL);
    }
    ASSERT_TRUE(all_matched()) << "Subscribers never matched publishers within timeout";
  }

  // Calls a Trigger service and returns whether the call succeeded.
  bool call_trigger(const std::string& service_name)
  {
    auto client = node_->create_client<std_srvs::srv::Trigger>(service_name);
    if (!client->wait_for_service(WAIT_TIMEOUT))
    {
      return false;
    }
    auto future = client->async_send_request(std::make_shared<std_srvs::srv::Trigger::Request>());
    if (future.wait_for(WAIT_TIMEOUT) != std::future_status::ready)
    {
      return false;
    }
    return future.get()->success;
  }

  std::unique_ptr<rclcpp::executors::MultiThreadedExecutor> executor_;
  std::thread spin_thread_;
  rclcpp::Node::SharedPtr node_;
  rclcpp::Node::SharedPtr plugin_node_;
  mjModel* model_{ nullptr };
  mjData* data_{ nullptr };
  std::vector<std::string> temp_files_;
};


#ifndef __APPLE__
TEST_F(CameraPluginTest, RejectsUnknownInitialReferenceBeforeStartingTruth)
{
  load_model(R"(<mujoco><worldbody>
    <geom type="sphere" size="0.1"/>
    <camera name="test_cam" pos="0 0 1" resolution="640 480"/>
  </worldbody></mujoco>)");
  const std::string prefix = "mujoco_plugins.mujoco_camera_plugin.test_cam.";
  plugin_node_->declare_parameter(prefix + "truth_enabled", true);
  plugin_node_->declare_parameter(prefix + "truth_topic", "/hs40/test/reference");
  plugin_node_->declare_parameter(prefix + "truth_capture_identity", "test-reference");
  plugin_node_->declare_parameter(prefix + "truth_model_sha256", std::string(64, 'a'));
  plugin_node_->declare_parameter(prefix + "truth_render_config_sha256", std::string(64, 'b'));
  plugin_node_->declare_parameter(prefix + "truth_schema_version", 2);
  plugin_node_->declare_parameter(prefix + "truth_reference_kind", "unknown");
  plugin_node_->declare_parameter(prefix + "publish_depth", false);
  mujoco_ros2_control_plugins::CameraPlugin plugin;
  EXPECT_FALSE(plugin.init(plugin_node_, model_, data_, []() { return 0; }));
  EXPECT_EQ(plugin_node_->count_publishers("/hs40/test/reference"), 0u);
  plugin.cleanup();
}

class CameraReferenceTest : public CameraPluginTest, public ::testing::WithParamInterface<bool> {};

TEST_P(CameraReferenceTest, Native640ReferenceIsInitialOnlyAndPreservesProduction)
{
  const bool normal_light = GetParam();
  load_model(normal_light ? R"(<mujoco><visual><headlight diffuse="0 0 0" specular="0 0 0"/></visual>
    <worldbody><light name="key" pos="0 0 2" diffuse=".28 .28 .28" specular=".07 .07 .07"/>
      <geom name="target" type="sphere" size=".15" rgba=".8 .5 .2 1"/>
      <camera name="test_cam" pos="0 0 1" resolution="640 480"/>
    </worldbody></mujoco>)" : R"(<mujoco><worldbody>
      <geom name="target" type="sphere" size=".15"/>
      <geom name="occluder" type="sphere" size=".055" pos=".06 0 .3"/>
      <camera name="test_cam" pos="0 0 1" resolution="640 480"/>
    </worldbody></mujoco>)");
  const int target = mj_name2id(model_, mjOBJ_GEOM, "target");
  const int hidden = mj_name2id(model_, mjOBJ_GEOM, "occluder");
  const std::string prefix = "mujoco_plugins.mujoco_camera_plugin.test_cam.";
  plugin_node_->declare_parameter(prefix + "truth_enabled", true);
  plugin_node_->declare_parameter(prefix + "truth_topic", "/hs40/test/native_reference");
  plugin_node_->declare_parameter(prefix + "truth_capture_identity", "native-reference");
  plugin_node_->declare_parameter(prefix + "truth_model_sha256", std::string(64, 'a'));
  plugin_node_->declare_parameter(prefix + "truth_render_config_sha256", std::string(64, 'b'));
  plugin_node_->declare_parameter(prefix + "truth_schema_version", 2);
  plugin_node_->declare_parameter(prefix + "truth_reference_kind", normal_light ? "normal_light" : "amodal_cup");
  if (normal_light)
  {
    plugin_node_->declare_parameter(prefix + "truth_baseline_diffuse", std::vector<double>{.8,.8,.8});
    plugin_node_->declare_parameter(prefix + "truth_baseline_specular", std::vector<double>{.2,.2,.2});
  }
  else plugin_node_->declare_parameter(prefix + "truth_hidden_geom_ids", std::vector<int64_t>{hidden});
  plugin_node_->declare_parameter(prefix + "publish_depth", false);
  using Frame = mujoco_ros2_control_msgs::msg::CameraTruthFrameV2;
  std::mutex mutex;
  std::condition_variable changed;
  std::vector<Frame> frames;
  std::vector<sensor_msgs::msg::Image> images;
  auto truth_sub = node_->create_subscription<Frame>("/hs40/test/native_reference",
    rclcpp::QoS(10).best_effort(), [&](Frame::SharedPtr frame) {
      std::lock_guard<std::mutex> lock(mutex); frames.push_back(*frame); changed.notify_all();
    });
  auto image_sub = node_->create_subscription<sensor_msgs::msg::Image>("/camera_plugin/test_cam/color",10,
    [&](sensor_msgs::msg::Image::SharedPtr image) {
      std::lock_guard<std::mutex> lock(mutex); images.push_back(*image); changed.notify_all();
    });
  mujoco_ros2_control_plugins::CameraPlugin plugin;
  ASSERT_TRUE(plugin.init(plugin_node_, model_, data_, []() { return 0; }));
  wait_for_rendering(plugin);
  start_executor();
  // A missing V2 endpoint must fail here, before a rendered record can be trusted.
  wait_for_subscriber_match(truth_sub,image_sub);
  mj_forward(model_,data_);
  const auto model_diffuse = std::vector<float>(model_->light_diffuse,model_->light_diffuse+3*model_->nlight);
  const auto live_qpos = std::vector<mjtNum>(data_->qpos,data_->qpos+model_->nq);
  const auto normal_before=normal_renders.load(), ids_before=truth_renders.load();
  plugin.on_reset();
  for (int index=0;index<2;++index)
  {
    data_->time=.2+.2*index;
    plugin.on_state_snapshot(model_,data_,true);
    std::unique_lock<std::mutex> lock(mutex);
    EXPECT_TRUE(changed.wait_for(lock,WAIT_TIMEOUT,[&](){return frames.size()>=size_t(index+1);}));
  }
  plugin.cleanup();
  EXPECT_TRUE(plugin.truth_retired());
  std::unique_lock<std::mutex> lock(mutex);
  EXPECT_TRUE(changed.wait_for(lock,WAIT_TIMEOUT,[&](){return frames.size()>=3;}));
  ASSERT_EQ(frames.size(),3u);
  const auto& first=frames[0]; const auto& second=frames[1]; const auto& final=frames[2];
  EXPECT_EQ(first.schema_version,2u);
  EXPECT_EQ(first.reference_kind,normal_light ? Frame::NORMAL_LIGHT : Frame::AMODAL_CUP);
  EXPECT_EQ(first.reference.header,first.original.rgb.header);
  EXPECT_TRUE(first.scene_restored);
  EXPECT_GT(first.initial_render_elapsed_ns,0u);
  std::cout << "INITIAL_RGB_ID_REFERENCE_ELAPSED_NS " << first.initial_render_elapsed_ns << std::endl;
  EXPECT_LT(first.initial_render_elapsed_ns,100000000u);
  EXPECT_EQ(second.reference_kind,Frame::NONE); EXPECT_TRUE(second.reference.data.empty());
  EXPECT_EQ(final.reference_kind,Frame::NONE); EXPECT_TRUE(final.reference.data.empty());
  EXPECT_EQ(final.original.record_type,final.original.FINAL_WATERMARK);
  EXPECT_EQ(final.original.generated_count,2u); EXPECT_EQ(final.original.published_count,2u);
  EXPECT_FALSE(final.original.loss_latched);
  for (size_t index=0;index<2;++index)
  {
    const auto& rgb=frames[index].original.rgb;
    const auto actual=std::find_if(images.begin(),images.end(),[&](const auto& im){return im.header==rgb.header;});
    ASSERT_NE(actual,images.end()); EXPECT_EQ(*actual,rgb);
  }
  EXPECT_EQ(model_diffuse,std::vector<float>(model_->light_diffuse,model_->light_diffuse+3*model_->nlight));
  EXPECT_EQ(live_qpos,std::vector<mjtNum>(data_->qpos,data_->qpos+model_->nq));
  if (normal_light)
  {
    ASSERT_EQ(first.reference.encoding,"rgb8");
    EXPECT_GT(std::accumulate(first.reference.data.begin(),first.reference.data.end(),uint64_t{0}),
              std::accumulate(first.original.rgb.data.begin(),first.original.rgb.data.end(),uint64_t{0}));
    EXPECT_EQ(normal_renders.load()-normal_before,3u); EXPECT_EQ(truth_renders.load()-ids_before,2u);
    EXPECT_EQ(first.scene_light_model_ids.size(),2u);
  }
  else
  {
    ASSERT_EQ(first.reference.encoding,"32SC2");
    size_t visible=0,amodal=0;
    for(size_t offset=0;offset<first.reference.data.size();offset+=8)
    {
      int32_t original_id,reference_id;
      std::memcpy(&original_id,first.original.instances.data.data()+offset,4);
      std::memcpy(&reference_id,first.reference.data.data()+offset,4);
      if(original_id==target){++visible; EXPECT_EQ(reference_id,target);}
      if(reference_id==target)++amodal;
      EXPECT_NE(reference_id,hidden);
    }
    EXPECT_GT(visible,0u); EXPECT_GT(amodal,visible);
    EXPECT_EQ(normal_renders.load()-normal_before,2u); EXPECT_EQ(truth_renders.load()-ids_before,3u);
  }
}
INSTANTIATE_TEST_SUITE_P(InitialConditions,CameraReferenceTest,::testing::Bool());

TEST_F(CameraPluginTest, OptInTruthCreatesNativePublisherAfterRealRgbRender)
{
  load_model(R"(<mujoco><worldbody>
    <geom name="target" type="sphere" size="0.1" pos="0 0 0"/>
    <camera name="test_cam" pos="0 0 1" resolution="32 24"/>
  </worldbody></mujoco>)");
  const std::string prefix = "mujoco_plugins.mujoco_camera_plugin.test_cam.";
  plugin_node_->declare_parameter(prefix + "truth_enabled", true);
  plugin_node_->declare_parameter(prefix + "truth_topic", "/hs40/test/truth");
  plugin_node_->declare_parameter(prefix + "truth_capture_identity", "test-capture");
  plugin_node_->declare_parameter(prefix + "truth_model_sha256", std::string(64, 'a'));
  plugin_node_->declare_parameter(prefix + "truth_render_config_sha256", std::string(64, 'b'));
  plugin_node_->declare_parameter(prefix + "publish_depth", false);
  mj_forward(model_, data_);
  mujoco_ros2_control_plugins::CameraPlugin plugin;
  ASSERT_TRUE(plugin.init(plugin_node_, model_, data_, []() { return 0; }));
  wait_for_rendering(plugin);
  start_executor();
  std::atomic_bool received{false};
  auto image_sub = node_->create_subscription<sensor_msgs::msg::Image>(
    "/camera_plugin/test_cam/color", 1,
    [&](sensor_msgs::msg::Image::SharedPtr image) { received = image->data.size() == 32 * 24 * 3; });
  wait_for_subscriber_match(image_sub);
  data_->time = 0.2;
  plugin.on_physics_step(model_, data_);
  const auto deadline = std::chrono::steady_clock::now() + WAIT_TIMEOUT;
  while (!received && std::chrono::steady_clock::now() < deadline)
    std::this_thread::sleep_for(POLL_INTERVAL);
  EXPECT_TRUE(received);
  EXPECT_EQ(plugin_node_->count_publishers("/hs40/test/truth"), 1u);
  plugin.cleanup();
}
#endif


#ifndef __APPLE__
TEST_F(CameraPluginTest, PairedTruthKeepsExactRgbInfoAndCategoricalIdsAcrossMotion)
{
  load_model(R"(<mujoco><worldbody>
    <geom name="target" type="sphere" size="0.1" pos="0.2 0.1 0"/>
    <body><joint name="neck" type="hinge" axis="0 0 1"/>
      <inertial pos="0 0 0" mass="1" diaginertia="1 1 1"/>
      <camera name="test_cam" pos="0 0 1" resolution="64 48"/>
    </body>
  </worldbody></mujoco>)");
  const std::string prefix = "mujoco_plugins.mujoco_camera_plugin.test_cam.";
  plugin_node_->declare_parameter(prefix + "truth_enabled", true);
  plugin_node_->declare_parameter(prefix + "truth_topic", "/hs40/test/paired");
  plugin_node_->declare_parameter(prefix + "truth_capture_identity", "test-paired-motion");
  plugin_node_->declare_parameter(prefix + "truth_model_sha256", std::string(64, 'a'));
  plugin_node_->declare_parameter(prefix + "truth_render_config_sha256", std::string(64, 'b'));
  plugin_node_->declare_parameter(prefix + "publish_depth", false);
  using Frame = mujoco_ros2_control_msgs::msg::CameraTruthFrame;
  std::mutex received_mutex;
  std::vector<Frame> originals;
  std::vector<sensor_msgs::msg::Image> rgbs;
  std::vector<sensor_msgs::msg::CameraInfo> infos;
  auto truth_sub = node_->create_subscription<Frame>("/hs40/test/paired",
    rclcpp::QoS(rclcpp::KeepLast(10)).best_effort(), [&](Frame::SharedPtr frame) {
      std::lock_guard<std::mutex> lock(received_mutex); originals.push_back(*frame);
    });
  auto image_sub = node_->create_subscription<sensor_msgs::msg::Image>(
    "/camera_plugin/test_cam/color", 10, [&](sensor_msgs::msg::Image::SharedPtr image) {
      std::lock_guard<std::mutex> lock(received_mutex); rgbs.push_back(*image);
    });
  auto info_sub = node_->create_subscription<sensor_msgs::msg::CameraInfo>(
    "/camera_plugin/test_cam/camera_info", 10, [&](sensor_msgs::msg::CameraInfo::SharedPtr info) {
      std::lock_guard<std::mutex> lock(received_mutex); infos.push_back(*info);
    });
  mujoco_ros2_control_plugins::CameraPlugin plugin;
  ASSERT_TRUE(plugin.init(plugin_node_, model_, data_, []() { return 0; }));
  wait_for_rendering(plugin);
  start_executor();
  wait_for_subscriber_match(truth_sub, image_sub, info_sub);
  mj_forward(model_, data_);
  data_->time = 0.2;
  plugin.on_physics_step(model_, data_);
  const auto before_reset_deadline = std::chrono::steady_clock::now() + WAIT_TIMEOUT;
  bool startup_rgb = false;
  while (!startup_rgb && std::chrono::steady_clock::now() < before_reset_deadline)
  {
    { std::lock_guard<std::mutex> lock(received_mutex); startup_rgb = !rgbs.empty(); }
    std::this_thread::sleep_for(POLL_INTERVAL);
  }
  EXPECT_TRUE(startup_rgb);
  std::this_thread::sleep_for(50ms);
  { std::lock_guard<std::mutex> lock(received_mutex);
    EXPECT_TRUE(originals.empty()) << "Truth ingress must remain closed until native reset.";
    originals.clear(); rgbs.clear(); infos.clear(); }
  plugin.on_reset();
  for (int index = 0; index < 3; ++index)
  {
    data_->qpos[0] = -0.3 + index * 0.3;
    data_->qvel[0] = index == 1 ? 0.02 : 0;
    mj_forward(model_, data_);
    mj_step(model_, data_); // Native observer phase: cached scene, post-integration qpos.
    data_->time = 0.2 * (index + 2);
    plugin.on_physics_step(model_, data_);
    const auto deadline = std::chrono::steady_clock::now() + WAIT_TIMEOUT;
    bool complete = false;
    while (!complete && std::chrono::steady_clock::now() < deadline)
    {
      { std::lock_guard<std::mutex> lock(received_mutex);
        complete = originals.size() >= size_t(index+1) && rgbs.size() >= size_t(index+1) &&
                   infos.size() >= size_t(index+1); }
      std::this_thread::sleep_for(POLL_INTERVAL);
    }
    EXPECT_TRUE(complete) << "same-scene original not received for index " << index;
  }
  plugin.cleanup();
  EXPECT_TRUE(plugin.truth_retired());
  const auto deadline = std::chrono::steady_clock::now() + WAIT_TIMEOUT;
  bool final_received = false;
  while (!final_received && std::chrono::steady_clock::now() < deadline)
  {
    { std::lock_guard<std::mutex> lock(received_mutex);
      final_received = !originals.empty() && originals.back().record_type == Frame::FINAL_WATERMARK; }
    std::this_thread::sleep_for(POLL_INTERVAL);
  }
  EXPECT_TRUE(final_received);
  std::lock_guard<std::mutex> lock(received_mutex);
  ASSERT_EQ(originals.size(), 4u);
  ASSERT_EQ(rgbs.size(), 3u);
  ASSERT_EQ(infos.size(), 3u);
  for (size_t index = 0; index < 3; ++index)
  {
    const auto& frame = originals[index];
    EXPECT_EQ(frame.rgb, rgbs[index]);
    EXPECT_EQ(frame.camera_info, infos[index]);
    EXPECT_EQ(frame.instances.header, frame.rgb.header);
    EXPECT_EQ(frame.instances.encoding, "32SC2");
    EXPECT_EQ(frame.instances.step, 64u * 8);
    EXPECT_EQ(frame.instances.is_bigendian, false);
    EXPECT_EQ(frame.frame_sequence, index+1);
    size_t target_pixels = 0;
    for (size_t pixel = 0; pixel < 64*48; ++pixel)
    {
      const auto* bytes = frame.instances.data.data() + pixel*8;
      const auto read32 = [](const uint8_t* value) {
        return int32_t(uint32_t(value[0]) | (uint32_t(value[1])<<8) |
                       (uint32_t(value[2])<<16) | (uint32_t(value[3])<<24));
      };
      const auto id = read32(bytes), type = read32(bytes+4);
      EXPECT_TRUE((id == -1 && type == -1) || (id == 0 && type == mjOBJ_GEOM));
      if (id == 0) ++target_pixels;
    }
    EXPECT_GT(target_pixels, 20u);
  }
  EXPECT_NE(originals[0].instances.data, originals[2].instances.data);
  EXPECT_EQ(originals.back().generated_count, 3u);
  EXPECT_EQ(originals.back().enqueued_count, 3u);
  EXPECT_EQ(originals.back().published_count, 3u);
  EXPECT_EQ(originals.back().dropped_count, 0u);
  EXPECT_FALSE(originals.back().loss_latched);
}
#endif


TEST(CameraTruthSender, RepeatedRetireCannotClaimADetachedBlockedWorkerIsDone)
{
  auto sender = std::make_shared<mujoco_ros2_control_plugins::CameraTruthSender>();
  std::mutex mutex;
  std::condition_variable condition;
  bool release = false;
  sender->worker = std::thread([sender, &mutex, &condition, &release]() {
    {
      std::unique_lock<std::mutex> lock(mutex);
      condition.wait(lock, [&]() { return release; });
    }
    sender->done.store(true);
    sender->wake.notify_all();
  });
  EXPECT_FALSE(sender->retire(std::chrono::steady_clock::now() + 2ms));
  EXPECT_FALSE(sender->done.load());
  EXPECT_FALSE(sender->retire(std::chrono::steady_clock::now() + 2ms));
  EXPECT_FALSE(sender->done.load());
  { std::lock_guard<std::mutex> lock(mutex); release = true; }
  condition.notify_one();
  const auto deadline = std::chrono::steady_clock::now() + 2s;
  while (!sender->done.load() && std::chrono::steady_clock::now() < deadline)
    std::this_thread::sleep_for(1ms);
  EXPECT_TRUE(sender->done.load());
  EXPECT_TRUE(sender->retirement_failed.load());
}


#ifndef __APPLE__
TEST_F(CameraPluginTest, TruthFailureRestoresFlagsAndLatchesTailLoss)
{
  load_model(R"(<mujoco><worldbody><geom type="sphere" size="0.1"/>
    <camera name="test_cam" pos="0 0 1" resolution="32 24"/>
  </worldbody></mujoco>)");
  const std::string prefix = "mujoco_plugins.mujoco_camera_plugin.test_cam.";
  plugin_node_->declare_parameter(prefix + "truth_enabled", true);
  plugin_node_->declare_parameter(prefix + "truth_topic", "/hs40/test/failure");
  plugin_node_->declare_parameter(prefix + "truth_capture_identity", "test-failures");
  plugin_node_->declare_parameter(prefix + "truth_model_sha256", std::string(64, 'a'));
  plugin_node_->declare_parameter(prefix + "truth_render_config_sha256", std::string(64, 'b'));
  using Frame = mujoco_ros2_control_msgs::msg::CameraTruthFrame;
  std::mutex records_mutex;
  std::vector<Frame> records;
  auto sub = node_->create_subscription<Frame>("/hs40/test/failure",
    rclcpp::QoS(rclcpp::KeepLast(10)).best_effort(), [&](Frame::SharedPtr value) {
      std::lock_guard<std::mutex> lock(records_mutex); records.push_back(*value);
    });
  mujoco_ros2_control_plugins::CameraPlugin plugin;
  ASSERT_TRUE(plugin.init(plugin_node_, model_, data_, []() { return 0; }));
  wait_for_rendering(plugin);
  start_executor();
  wait_for_subscriber_match(sub);
  plugin.on_reset();
  const auto normal_before = normal_renders.load(), truth_before = truth_renders.load();
  for (int index = 0; index < 3; ++index)
  {
    if (index == 0) fail_truth_readback.store(true);
    if (index == 2) mutate_truth_scene.store(true);
    mj_forward(model_, data_);
    data_->time = 0.2*(index+1);
    plugin.on_physics_step(model_, data_);
    const auto deadline = std::chrono::steady_clock::now() + WAIT_TIMEOUT;
    while (truth_renders.load() < truth_before+index+1 && std::chrono::steady_clock::now() < deadline)
      std::this_thread::sleep_for(POLL_INTERVAL);
    EXPECT_EQ(truth_renders.load(), truth_before+index+1);
  }
  plugin.cleanup();
  EXPECT_TRUE(plugin.truth_retired());
  const auto deadline = std::chrono::steady_clock::now() + WAIT_TIMEOUT;
  bool terminal = false;
  while (!terminal && std::chrono::steady_clock::now() < deadline)
  {
    { std::lock_guard<std::mutex> lock(records_mutex);
      terminal = !records.empty() && records.back().record_type == Frame::FINAL_WATERMARK; }
    std::this_thread::sleep_for(POLL_INTERVAL);
  }
  EXPECT_TRUE(terminal);
  EXPECT_EQ(normal_renders.load()-normal_before, 3u); // Flags restored after exception.
  std::lock_guard<std::mutex> lock(records_mutex);
  ASSERT_EQ(records.size(), 2u); // Only middle frame plus final; rejected tails never masquerade as truth.
  EXPECT_EQ(records[0].frame_sequence, 2u);
  EXPECT_EQ(records.back().generated_count, 3u);
  EXPECT_EQ(records.back().published_count, 1u);
  EXPECT_EQ(records.back().dropped_count, 2u);
  EXPECT_EQ(records.back().last_dropped_sequence, 3u);
  EXPECT_TRUE(records.back().loss_latched);
}

TEST_F(CameraPluginTest, DefaultCameraAddsNoTruthRenderOrEndpoint)
{
  load_model(R"(<mujoco><worldbody><geom type="sphere" size="0.1"/>
    <camera name="test_cam" pos="0 0 1" resolution="32 24"/>
  </worldbody></mujoco>)");
  mujoco_ros2_control_plugins::CameraPlugin plugin;
  ASSERT_TRUE(plugin.init(plugin_node_, model_, data_, []() { return 0; }));
  wait_for_rendering(plugin);
  const auto normal_before = normal_renders.load(), truth_before = truth_renders.load();
  mj_forward(model_, data_);
  data_->time = 0.2;
  plugin.on_physics_step(model_, data_);
  const auto deadline = std::chrono::steady_clock::now() + WAIT_TIMEOUT;
  while (normal_renders.load() == normal_before && std::chrono::steady_clock::now() < deadline)
    std::this_thread::sleep_for(POLL_INTERVAL);
  plugin.cleanup();
  EXPECT_EQ(normal_renders.load()-normal_before, 1u);
  EXPECT_EQ(truth_renders.load()-truth_before, 0u);
  EXPECT_TRUE(plugin.truth_retired());
  for (const auto& endpoint : plugin_node_->get_topic_names_and_types())
    for (const auto& type : endpoint.second)
      if (type == "mujoco_ros2_control_msgs/msg/CameraTruthFrame")
        EXPECT_EQ(plugin_node_->count_publishers(endpoint.first), 0u);
}
#endif

// Removing the optional rendering capability would prevent MujocoSimulation from discovering
// and coordinating the camera worker without changing the upstream plugin base ABI.
TEST_F(CameraPluginTest, ImplementsOptionalRenderingCapability)
{
  mujoco_ros2_control_plugins::CameraPlugin plugin;

  auto* rendering = dynamic_cast<mujoco_ros2_control_plugins::MuJoCoROS2ControlRenderingPlugin*>(&plugin);

  EXPECT_NE(rendering, nullptr);
}

// Disabling rendering before initialization must leave the registered ROS policy intact while
// preventing any platform context probing or worker startup.
TEST_F(CameraPluginTest, RenderingDisabledBeforeInitSkipsContextAndWorker)
{
  load_model(R"(<?xml version="1.0"?>
<mujoco model="disabled_rendering">
  <worldbody>
    <body name="box" pos="0 0 0.1">
      <freejoint/>
      <inertial pos="0 0 0" mass="1.0" diaginertia="0.01 0.01 0.01"/>
      <geom type="box" size="0.05 0.05 0.05"/>
    </body>
    <camera name="test_cam" pos="0 -1 1" xyaxes="1 0 0 0 0.707 0.707"
            fovy="60" resolution="64 48"/>
  </worldbody>
</mujoco>
)");

  mujoco_ros2_control_plugins::CameraPlugin plugin;
  auto* rendering = dynamic_cast<mujoco_ros2_control_plugins::MuJoCoROS2ControlRenderingPlugin*>(&plugin);
  ASSERT_NE(rendering, nullptr);
  rendering->set_rendering_enabled(false);

  bool glfw_init_called = false;
  EXPECT_TRUE(plugin.init(plugin_node_, model_, data_, [&glfw_init_called]() {
    glfw_init_called = true;
    return 0;
  }));
  EXPECT_FALSE(glfw_init_called);
  EXPECT_FALSE(plugin.is_rendering_available());

  rendering->close_rendering();
  rendering->close_rendering();
}

#ifdef __APPLE__
// A headless camera worker owns CGL and never fabricates a Cocoa/GLFW window.
TEST_F(CameraPluginTest, MissingInjectedMacosContextStartsOwnedCglRendering)
{
  load_model(R"(<?xml version="1.0"?>
<mujoco model="missing_macos_context">
  <worldbody>
    <body name="box" pos="0 0 0.1">
      <freejoint/>
      <inertial pos="0 0 0" mass="1.0" diaginertia="0.01 0.01 0.01"/>
      <geom type="box" size="0.05 0.05 0.05"/>
    </body>
    <camera name="test_cam" pos="0 -1 1" xyaxes="1 0 0 0 0.707 0.707"
            fovy="60" resolution="64 48"/>
  </worldbody>
</mujoco>
)");

  mujoco_ros2_control_plugins::CameraPlugin plugin;
  bool glfw_init_called = false;
  ASSERT_TRUE(plugin.init(plugin_node_, model_, data_, [&glfw_init_called]() {
    glfw_init_called = true;
    return 0;
  }));
  EXPECT_FALSE(glfw_init_called);

  const auto deadline = std::chrono::steady_clock::now() + WAIT_TIMEOUT;
  while (!plugin.is_rendering_available() && std::chrono::steady_clock::now() < deadline)
  {
    std::this_thread::sleep_for(POLL_INTERVAL);
  }
  EXPECT_TRUE(plugin.is_rendering_available());
  plugin.close_rendering();
}

#endif

// A camera configured with the upstream disabled policy must not create ROS endpoints or
// require a rendering context. This is distinct from disabling the whole rendering lifecycle.
TEST_F(CameraPluginTest, DisabledCameraPolicyCreatesNoEndpointsOrWorker)
{
  plugin_node_->declare_parameter("mujoco_plugins.mujoco_camera_plugin.disabled_cam.policy",
                                  std::string("disabled"));
  load_model(R"(<?xml version="1.0"?>
<mujoco model="disabled_camera_policy">
  <worldbody>
    <body name="box" pos="0 0 0.1">
      <freejoint/>
      <inertial pos="0 0 0" mass="1.0" diaginertia="0.01 0.01 0.01"/>
      <geom type="box" size="0.05 0.05 0.05"/>
    </body>
    <camera name="disabled_cam" pos="0 -1 1" xyaxes="1 0 0 0 0.707 0.707"
            fovy="60" resolution="64 48"/>
  </worldbody>
</mujoco>
)");

  mujoco_ros2_control_plugins::CameraPlugin plugin;
  bool glfw_init_called = false;
  EXPECT_TRUE(plugin.init(plugin_node_, model_, data_, [&glfw_init_called]() {
    glfw_init_called = true;
    return 0;
  }));

  EXPECT_FALSE(glfw_init_called);
  EXPECT_FALSE(plugin.is_rendering_available());
  EXPECT_EQ(plugin_node_->count_publishers("/camera_plugin/disabled_cam/color"), 0u);
  EXPECT_EQ(plugin_node_->count_publishers("/camera_plugin/disabled_cam/depth"), 0u);
  EXPECT_EQ(plugin_node_->count_publishers("/camera_plugin/disabled_cam/camera_info"), 0u);
  EXPECT_EQ(node_->get_service_names_and_types().count("/camera_plugin/disabled_cam/trigger"), 0u);

  plugin.close_rendering();
  plugin.close_rendering();
}

// Verify init returns true and does not start a render thread when model has no cameras.
TEST_F(CameraPluginTest, InitSucceedsWithNoCameras)
{
  load_model(R"(<?xml version="1.0"?>
<mujoco model="no_cameras">
  <worldbody>
    <body name="box" pos="0 0 0.1">
      <freejoint/>
      <inertial pos="0 0 0" mass="1.0" diaginertia="0.01 0.01 0.01"/>
      <geom type="box" size="0.05 0.05 0.05"/>
    </body>
  </worldbody>
</mujoco>
)");

  ASSERT_EQ(model_->ncam, 0);

  mujoco_ros2_control_plugins::CameraPlugin plugin;
  EXPECT_TRUE(plugin.init(plugin_node_, model_, data_));
  plugin.update(model_, data_);
  plugin.cleanup();
}

#ifndef __APPLE__
// Verify init finds cameras and returns true, ensure the egl context does the rendering.
TEST_F(CameraPluginTest, InitAndPublish)
{
  load_model(R"(<?xml version="1.0"?>
<mujoco model="with_camera">
  <worldbody>
    <body name="box" pos="0 0 0.1">
      <freejoint/>
      <inertial pos="0 0 0" mass="1.0" diaginertia="0.01 0.01 0.01"/>
      <geom type="box" size="0.05 0.05 0.05"/>
    </body>
    <camera name="test_cam" pos="0 -1 1" xyaxes="1 0 0 0 0.707 0.707"
            fovy="60" resolution="320 240"/>
  </worldbody>
</mujoco>
)");

  ASSERT_EQ(model_->ncam, 1);
  mujoco_ros2_control_plugins::CameraPlugin plugin;
  // GLFW is not initialized, and No OpenGL framebuffer will be available so we make the init fall back on to EGL.
  EXPECT_TRUE(plugin.init(plugin_node_, model_, data_, []() { return 0; }));

  // Wait for the rendering thread to come up
  wait_for_rendering(plugin);
  start_executor();

  // Verify publishers were created
  EXPECT_EQ(plugin_node_->count_publishers("/camera_plugin/test_cam/color"), 1u);
  EXPECT_EQ(plugin_node_->count_publishers("/camera_plugin/test_cam/depth"), 1u);
  EXPECT_EQ(plugin_node_->count_publishers("/camera_plugin/test_cam/camera_info"), 1u);

  // Create subscribers for the color images and info
  std::atomic<bool> received_image{ false };
  std::atomic<bool> received_depth{ false };
  std::atomic<bool> received_info{ false };
  std::atomic<bool> received_expected_frame_id{ false };
  auto image_sub = node_->create_subscription<sensor_msgs::msg::Image>(
      "/camera_plugin/test_cam/color", 1, [&](sensor_msgs::msg::Image::SharedPtr) { received_image = true; });
  auto depth_sub = node_->create_subscription<sensor_msgs::msg::Image>(
      "/camera_plugin/test_cam/depth", 1, [&](sensor_msgs::msg::Image::SharedPtr) { received_depth = true; });
  auto info_sub = node_->create_subscription<sensor_msgs::msg::CameraInfo>(
      "/camera_plugin/test_cam/camera_info", 1, [&](sensor_msgs::msg::CameraInfo::SharedPtr msg) {
        received_info = true;
        received_expected_frame_id = (msg->header.frame_id == "test_cam_frame");
      });

  // Ensure publishers are connected to subscribers
  wait_for_subscriber_match(image_sub, depth_sub, info_sub);

  // Force a publish and verify we get results
  const auto deadline = std::chrono::steady_clock::now() + WAIT_TIMEOUT;
  while (!(received_image && received_depth && received_info && received_expected_frame_id) &&
         std::chrono::steady_clock::now() < deadline)
  {
    plugin.trigger_update();
    std::this_thread::sleep_for(POLL_INTERVAL);
  }

  ASSERT_TRUE(received_image);
  ASSERT_TRUE(received_depth);
  ASSERT_TRUE(received_info);
  ASSERT_TRUE(received_expected_frame_id);

  plugin.cleanup();
}
#endif

// Exposure scheduling and headers must use the same actual simulation clock.
// A delayed /clock subscription must not delay or jitter MuJoCo snapshots.
TEST_F(CameraPluginTest, ExposesAuthoritativePhysicsObserverCapability)
{
  auto plugin = std::make_shared<mujoco_ros2_control_plugins::CameraPlugin>();
  auto observer = std::dynamic_pointer_cast<
      mujoco_ros2_control_plugins::MuJoCoROS2ControlSimulationObserver>(plugin);
  EXPECT_NE(observer, nullptr);
}

TEST_F(CameraPluginTest, DuePhysicsExposureSurvivesAMissedControllerWrite)
{
  plugin_node_->declare_parameter("mujoco_plugins.mujoco_camera_plugin.camera_publish_rate", 10.0);
  plugin_node_->declare_parameter("mujoco_plugins.mujoco_camera_plugin.test_cam.publish_depth", false);
  const std::string xml = R"(<mujoco model="missed_control_camera">
    <option timestep="0.002"/>
    <worldbody>
      <geom type="box" size="0.1 0.1 0.1"/>
      <camera name="test_cam" pos="0 -1 1" xyaxes="1 0 0 0 0.707 0.707"
              fovy="60" resolution="320 240"/>
    </worldbody>
  </mujoco>)";
  char error[1000] = "";
  mjSpec* spec = mj_parseXMLString(xml.c_str(), nullptr, error, sizeof(error));
  ASSERT_NE(spec, nullptr) << error;
  model_ = mj_compile(spec, nullptr);
  mj_deleteSpec(spec);
  ASSERT_NE(model_, nullptr);
  data_ = mj_makeData(model_);
  ASSERT_NE(data_, nullptr);
  auto plugin = std::make_shared<mujoco_ros2_control_plugins::CameraPlugin>();
  auto observer = std::dynamic_pointer_cast<
      mujoco_ros2_control_plugins::MuJoCoROS2ControlSimulationObserver>(plugin);
  ASSERT_TRUE(plugin->init(plugin_node_, model_, data_, []() { return 0; }));
  wait_for_rendering(*plugin);
  start_executor();
  std::mutex received_mutex;
  std::condition_variable received_cv;
  std::vector<int64_t> sources;
  auto subscription = node_->create_subscription<sensor_msgs::msg::Image>(
      "/camera_plugin/test_cam/color", 32, [&](sensor_msgs::msg::Image::SharedPtr message) {
        std::lock_guard<std::mutex> lock(received_mutex);
        sources.push_back(rclcpp::Time(message->header.stamp).nanoseconds());
        received_cv.notify_all();
      });
  wait_for_subscriber_match(subscription);
  auto* clock_handle = plugin_node_->get_clock()->get_clock_handle();
  ASSERT_EQ(rcl_enable_ros_time_override(clock_handle), RCL_RET_OK);
  ASSERT_EQ(rcl_set_ros_time_override(clock_handle, 0), RCL_RET_OK);
  data_->time = 32.498;
  mj_step(model_, data_);
  if (observer)
  {
    observer->on_physics_step(model_, data_);
  }
  else
  {
    plugin->update(model_, data_);
  }
  {
    std::unique_lock<std::mutex> lock(received_mutex);
    ASSERT_TRUE(received_cv.wait_for(lock, WAIT_TIMEOUT, [&]() { return !sources.empty(); }));
  }
  // The controller misses the due step and next consumes the actual32.602 snapshot.
  // The existing physics observer sees the successful32.600 step before that write.
  data_->time = 32.598;
  mj_step(model_, data_);
  if (observer)
  {
    observer->on_physics_step(model_, data_);
  }
  mj_step(model_, data_);
  plugin->update(model_, data_);
  {
    std::unique_lock<std::mutex> lock(received_mutex);
    ASSERT_TRUE(received_cv.wait_for(lock, WAIT_TIMEOUT, [&]() { return sources.size() >= 2; }));
    EXPECT_EQ(sources.size(), 2u);
    EXPECT_EQ(sources[0], 32500000000LL);
    EXPECT_EQ(sources[1], 32600000000LL);
    EXPECT_EQ(sources[1] - sources[0], 100000000LL);
  }
  // A controller-only update at the next due time must not create another writer.
  data_->time = 32.7;
  plugin->update(model_, data_);
  std::this_thread::sleep_for(50ms);
  {
    std::lock_guard<std::mutex> lock(received_mutex);
    EXPECT_EQ(sources.size(), 2u);
  }
  if (observer)
  {
    observer->on_physics_step(model_, data_);
    std::unique_lock<std::mutex> lock(received_mutex);
    EXPECT_TRUE(received_cv.wait_for(lock, WAIT_TIMEOUT, [&]() { return sources.size() >= 3; }));
    EXPECT_EQ(sources.back(), 32700000000LL);
  }
  if (observer)
  {
    data_->time = 32.8;
    observer->on_state_snapshot(model_, data_, false);
    std::this_thread::sleep_for(50ms);
    {
      std::lock_guard<std::mutex> lock(received_mutex);
      EXPECT_EQ(sources.size(), 3u);
    }
    observer->on_state_snapshot(model_, data_, true);
    {
      std::unique_lock<std::mutex> lock(received_mutex);
      EXPECT_TRUE(received_cv.wait_for(lock, WAIT_TIMEOUT, [&]() { return sources.size() >= 4; }));
      EXPECT_EQ(sources.back(), 32800000000LL);
    }
    observer->on_reset();
    data_->time = .1;
    observer->on_physics_step(model_, data_);
    {
      std::unique_lock<std::mutex> lock(received_mutex);
      EXPECT_TRUE(received_cv.wait_for(lock, WAIT_TIMEOUT, [&]() { return sources.size() >= 5; }));
      EXPECT_EQ(sources.back(), 100000000LL);
    }
  }
  plugin->cleanup();
}

#ifndef __APPLE__
TEST_F(CameraPluginTest, PhysicsCaptureDoesNotWaitForInFlightRendering)
{
  plugin_node_->declare_parameter("mujoco_plugins.mujoco_camera_plugin.camera_publish_rate", 10.0);
  plugin_node_->declare_parameter("mujoco_plugins.mujoco_camera_plugin.test_cam.publish_depth", false);
  const std::string xml = R"(<mujoco model="busy_camera">
    <option timestep="0.002"/>
    <worldbody>
      <geom type="box" size="0.1 0.1 0.1"/>
      <camera name="test_cam" pos="0 -1 1" xyaxes="1 0 0 0 0.707 0.707"
              fovy="60" resolution="320 240"/>
    </worldbody>
  </mujoco>)";
  char error[1000] = "";
  mjSpec* spec = mj_parseXMLString(xml.c_str(), nullptr, error, sizeof(error));
  ASSERT_NE(spec, nullptr) << error;
  model_ = mj_compile(spec, nullptr);
  mj_deleteSpec(spec);
  ASSERT_NE(model_, nullptr);
  data_ = mj_makeData(model_);
  ASSERT_NE(data_, nullptr);
  auto plugin = std::make_shared<mujoco_ros2_control_plugins::CameraPlugin>();
  auto observer = std::dynamic_pointer_cast<
      mujoco_ros2_control_plugins::MuJoCoROS2ControlSimulationObserver>(plugin);
  ASSERT_TRUE(plugin->init(plugin_node_, model_, data_, []() { return 0; }));
  wait_for_rendering(*plugin);
  {
    std::lock_guard<std::mutex> lock(camera_readback_mutex);
    block_camera_readback = true;
    camera_readback_entered = release_camera_readback = false;
  }
  data_->time = 32.5;
  if (observer)
  {
    observer->on_physics_step(model_, data_);
  }
  else
  {
    plugin->update(model_, data_);
  }
  bool entered;
  {
    std::unique_lock<std::mutex> lock(camera_readback_mutex);
    entered = camera_readback_cv.wait_for(lock, WAIT_TIMEOUT, []() { return camera_readback_entered; });
  }
  EXPECT_TRUE(entered);
  data_->time = 32.6;
  std::mutex finished_mutex;
  std::condition_variable finished_cv;
  bool finished = false;
  std::thread sampler([&]() {
    if (observer)
    {
      observer->on_physics_step(model_, data_);
    }
    else
    {
      plugin->update(model_, data_);
    }
    std::lock_guard<std::mutex> lock(finished_mutex);
    finished = true;
    finished_cv.notify_all();
  });
  {
    std::unique_lock<std::mutex> lock(finished_mutex);
    EXPECT_TRUE(finished_cv.wait_for(lock, 100ms, [&]() { return finished; }))
        << "actual physics capture waited for the still-blocked renderer";
  }
  {
    std::lock_guard<std::mutex> lock(camera_readback_mutex);
    release_camera_readback = true;
    camera_readback_cv.notify_all();
  }
  sampler.join();
  plugin->cleanup();
}
#endif

TEST_F(CameraPluginTest, StreamingCadenceUsesSnapshotTimeWithDelayedNodeClock)
{
  plugin_node_->declare_parameter("mujoco_plugins.mujoco_camera_plugin.camera_publish_rate", 10.0);
  plugin_node_->declare_parameter("mujoco_plugins.mujoco_camera_plugin.test_cam.publish_depth", false);
  const std::string xml = R"(<mujoco model="source_clock">
    <worldbody>
      <geom type="box" size="0.1 0.1 0.1"/>
      <camera name="test_cam" pos="0 -1 1" xyaxes="1 0 0 0 0.707 0.707"
              fovy="60" resolution="320 240"/>
    </worldbody>
  </mujoco>)";
  char error[1000] = "";
  mjSpec* spec = mj_parseXMLString(xml.c_str(), nullptr, error, sizeof(error));
  ASSERT_NE(spec, nullptr) << error;
  model_ = mj_compile(spec, nullptr);
  mj_deleteSpec(spec);
  ASSERT_NE(model_, nullptr);
  data_ = mj_makeData(model_);
  ASSERT_NE(data_, nullptr);
  mj_forward(model_, data_);
  mujoco_ros2_control_plugins::CameraPlugin plugin;
  ASSERT_TRUE(plugin.init(plugin_node_, model_, data_, []() { return 0; }));
  wait_for_rendering(plugin);
  start_executor();
  std::mutex received_mutex;
  std::condition_variable received_cv;
  std::vector<int64_t> image_sources;
  auto subscription = node_->create_subscription<sensor_msgs::msg::Image>(
      "/camera_plugin/test_cam/color", 32, [&](sensor_msgs::msg::Image::SharedPtr message) {
        std::lock_guard<std::mutex> lock(received_mutex);
        image_sources.push_back(rclcpp::Time(message->header.stamp).nanoseconds());
        received_cv.notify_all();
      });
  wait_for_subscriber_match(subscription);
  // Control the actual plugin clock directly; a parameter event has its own
  // asynchronous delivery and cannot establish the test's delayed-clock seam.
  auto* clock_handle = plugin_node_->get_clock()->get_clock_handle();
  EXPECT_EQ(rcl_enable_ros_time_override(clock_handle), RCL_RET_OK);
  EXPECT_EQ(rcl_set_ros_time_override(clock_handle, 0), RCL_RET_OK);
  EXPECT_EQ(plugin_node_->get_clock()->now().nanoseconds(), 0);
  for (int exposure = 0; exposure < 4; ++exposure)
  {
    data_->time = 1.0 + exposure * 0.1;
    const int64_t expected = 1000000000LL + exposure * 100000000LL;
    plugin.on_physics_step(model_, data_);
    std::unique_lock<std::mutex> lock(received_mutex);
    const bool published = received_cv.wait_for(lock, WAIT_TIMEOUT, [&]() {
      return std::any_of(image_sources.begin(), image_sources.end(), [&](int64_t source) {
        return std::abs(source - expected) <= 1000;
      });
    });
    EXPECT_TRUE(published) << "actual snapshot source " << expected << " was blocked by delayed Node clock";
    if (!published)
    {
      break;
    }
  }
  // A clock-only advance and a sub-period snapshot must not manufacture an
  // exposure or refresh its source stamp. The next actual full period must.
  size_t before_count;
  {
    std::lock_guard<std::mutex> lock(received_mutex);
    before_count = image_sources.size();
  }
  EXPECT_EQ(rcl_set_ros_time_override(clock_handle, 1000000000000LL), RCL_RET_OK);
  plugin.on_physics_step(model_, data_);
  data_->time = 1.398;
  plugin.on_physics_step(model_, data_);
  std::this_thread::sleep_for(50ms);
  {
    std::lock_guard<std::mutex> lock(received_mutex);
    EXPECT_EQ(image_sources.size(), before_count);
  }
  data_->time = 1.4;
  plugin.on_physics_step(model_, data_);
  {
    std::unique_lock<std::mutex> lock(received_mutex);
    EXPECT_TRUE(received_cv.wait_for(lock, WAIT_TIMEOUT, [&]() {
      return std::any_of(image_sources.begin(), image_sources.end(), [](int64_t source) {
        return std::abs(source - 1400000000LL) <= 1000;
      });
    }));
  }
  plugin.cleanup();
}

// Only polled cameras should expose a trigger service; streaming cameras should not.
TEST_F(CameraPluginTest, OnlyPolledCamerasCreateTriggerService)
{
  plugin_node_->declare_parameter("mujoco_plugins.mujoco_camera_plugin.stream_cam.policy", std::string("streaming"));
  plugin_node_->declare_parameter("mujoco_plugins.mujoco_camera_plugin.poll_cam.policy", std::string("polled"));
  load_model(R"(<?xml version="1.0"?>
<mujoco model="two_cameras">
  <worldbody>
    <body name="box" pos="0 0 0.1">
      <freejoint/>
      <inertial pos="0 0 0" mass="1.0" diaginertia="0.01 0.01 0.01"/>
      <geom type="box" size="0.05 0.05 0.05"/>
    </body>
    <camera name="stream_cam" pos="0 -1 1" xyaxes="1 0 0 0 0.707 0.707"
            fovy="60" resolution="64 48"/>
    <camera name="poll_cam" pos="0 1 1" xyaxes="-1 0 0 0 0.707 -0.707"
            fovy="60" resolution="64 48"/>
  </worldbody>
</mujoco>
)");
  ASSERT_EQ(model_->ncam, 2);

  mujoco_ros2_control_plugins::CameraPlugin plugin;
  plugin.set_rendering_enabled(false);
  EXPECT_TRUE(plugin.init(plugin_node_, model_, data_, []() { return 0; }));

  // The polled camera's trigger service must come up.
  auto poll_client = node_->create_client<std_srvs::srv::Trigger>("/camera_plugin/poll_cam/trigger");
  EXPECT_TRUE(poll_client->wait_for_service(WAIT_TIMEOUT));

  // The streaming camera must not have a trigger service registered.
  const auto services = node_->get_service_names_and_types();
  EXPECT_EQ(services.count("/camera_plugin/stream_cam/trigger"), 0u);

  // Both cameras still publish their image/info topics.
  EXPECT_EQ(plugin_node_->count_publishers("/camera_plugin/stream_cam/color"), 1u);
  EXPECT_EQ(plugin_node_->count_publishers("/camera_plugin/poll_cam/color"), 1u);

  plugin.cleanup();
}

#ifndef __APPLE__
// A polled camera must publish only in response to a trigger, never on the streaming clock,
// and exactly once per trigger. macOS exercises this contract with its injected fake context
// in test_camera_plugin_macos_lifecycle.cpp.
TEST_F(CameraPluginTest, PolledCameraPublishesOncePerTrigger)
{
  load_model(R"(<?xml version="1.0"?>
<mujoco model="polled_only">
  <worldbody>
    <body name="box" pos="0 0 0.1">
      <freejoint/>
      <inertial pos="0 0 0" mass="1.0" diaginertia="0.01 0.01 0.01"/>
      <geom type="box" size="0.05 0.05 0.05"/>
    </body>
    <camera name="poll_cam" pos="0 -1 1" xyaxes="1 0 0 0 0.707 0.707"
            fovy="60" resolution="64 48"/>
  </worldbody>
</mujoco>
)");
  ASSERT_EQ(model_->ncam, 1);

  plugin_node_->declare_parameter("mujoco_plugins.mujoco_camera_plugin.poll_cam.policy", std::string("polled"));

  mujoco_ros2_control_plugins::CameraPlugin plugin;
  EXPECT_TRUE(plugin.init(plugin_node_, model_, data_, []() { return 0; }));

  std::atomic<int> image_count{ 0 };
  auto image_sub = node_->create_subscription<sensor_msgs::msg::Image>(
      "/camera_plugin/poll_cam/color", 10, [&](sensor_msgs::msg::Image::SharedPtr) { ++image_count; });

  // Wait for the rendering thread to come up
  wait_for_rendering(plugin);
  start_executor();

  // Ensure publishers are connected to subscribers
  wait_for_subscriber_match(image_sub);

  // Without a trigger, running render cycles must not publish anything for a polled camera.
  for (auto i = 0; i < 5; ++i)
  {
    plugin.trigger_update();
    std::this_thread::sleep_for(POLL_INTERVAL);
  }
  EXPECT_EQ(image_count.load(), 0);

  // Trigger once; the next render cycle should publish exactly one image.
  ASSERT_TRUE(call_trigger("/camera_plugin/poll_cam/trigger"));
  plugin.on_state_snapshot(model_, data_, true);
  {
    const auto deadline = std::chrono::steady_clock::now() + WAIT_TIMEOUT;
    while (image_count.load() < 1 && std::chrono::steady_clock::now() < deadline)
    {
      std::this_thread::sleep_for(POLL_INTERVAL);
    }
  }
  EXPECT_EQ(image_count.load(), 1);

  // The trigger is one-shot: subsequent render cycles without a new trigger publish nothing more.
  for (auto i = 0; i < 5; ++i)
  {
    plugin.trigger_update();
    std::this_thread::sleep_for(POLL_INTERVAL);
  }
  EXPECT_EQ(image_count.load(), 1);

  plugin.cleanup();
}
#endif

int main(int argc, char** argv)
{
  ::testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}

TEST(CameraDataContract, DepthRemainsEnabledByDefault)
{
  mujoco_ros2_control_plugins::CameraData camera;
  EXPECT_TRUE(camera.publish_depth);
}

#ifndef __APPLE__
TEST_F(CameraPluginTest, MixedRgbOnlyAndDefaultRgbdRenderSameSnapshot)
{
  load_model(R"(<mujoco model="mixed_rgb">
  <worldbody>
    <geom type="box" size="0.1 0.1 0.1" rgba="1 0 0 1"/>
    <camera name="head" pos="0 -1 1" xyaxes="1 0 0 0 0.707 0.707" fovy="60" resolution="640 480"/>
    <camera name="teacher" pos="0 -1 1" xyaxes="1 0 0 0 0.707 0.707" fovy="60" resolution="640 480"/>
  </worldbody>
</mujoco>)");
  plugin_node_->declare_parameter("mujoco_plugins.mujoco_camera_plugin.head.publish_depth", false);
  mujoco_ros2_control_plugins::CameraPlugin plugin;
  ASSERT_TRUE(plugin.init(plugin_node_, model_, data_, []() { return 0; }));
  wait_for_rendering(plugin);
  start_executor();
  EXPECT_EQ(plugin_node_->count_publishers("/camera_plugin/head/depth"), 0u);
  EXPECT_EQ(plugin_node_->count_publishers("/camera_plugin/teacher/depth"), 1u);
  std::atomic<bool> rgb_ok{ false }, teacher_ok{ false }, depth_ok{ false }, info_ok{ false };
  auto rgb = node_->create_subscription<sensor_msgs::msg::Image>(
    "/camera_plugin/head/color", 10, [&](sensor_msgs::msg::Image::SharedPtr msg) {
      rgb_ok = msg->width == 640 && msg->height == 480 && msg->step == 1920 &&
        msg->encoding == "rgb8" && msg->data.size() == 640 * 480 * 3 &&
        msg->header.stamp.sec == 2 && msg->header.stamp.nanosec == 0;
    });
  auto teacher = node_->create_subscription<sensor_msgs::msg::Image>(
    "/camera_plugin/teacher/color", 10, [&](sensor_msgs::msg::Image::SharedPtr msg) {
      teacher_ok = msg->encoding == "rgb8" && msg->data.size() == 640 * 480 * 3 &&
        msg->header.stamp.sec == 2 && msg->header.stamp.nanosec == 0;
    });
  auto depth = node_->create_subscription<sensor_msgs::msg::Image>(
    "/camera_plugin/teacher/depth", 10, [&](sensor_msgs::msg::Image::SharedPtr msg) {
      depth_ok = msg->encoding == "32FC1" && msg->data.size() == 640 * 480 * sizeof(float) &&
        msg->header.stamp.sec == 2 && msg->header.stamp.nanosec == 0;
    });
  auto info = node_->create_subscription<sensor_msgs::msg::CameraInfo>(
    "/camera_plugin/head/camera_info", 10, [&](sensor_msgs::msg::CameraInfo::SharedPtr msg) {
      info_ok = msg->width == 640 && msg->height == 480 && msg->k[0] > 0 &&
        msg->header.frame_id == "head_frame" &&
        msg->header.stamp.sec == 2 && msg->header.stamp.nanosec == 0;
    });
  wait_for_subscriber_match(rgb, teacher, depth, info);
  data_->time = 2.;
  plugin.on_physics_step(model_, data_);
  const auto deadline = std::chrono::steady_clock::now() + WAIT_TIMEOUT;
  while (!(rgb_ok && teacher_ok && depth_ok && info_ok) && std::chrono::steady_clock::now() < deadline)
  {
    plugin.trigger_update();
    std::this_thread::sleep_for(POLL_INTERVAL);
  }
  EXPECT_TRUE(rgb_ok);
  EXPECT_TRUE(teacher_ok);
  EXPECT_TRUE(depth_ok);
  EXPECT_TRUE(info_ok);
  plugin.cleanup();
}
#endif
