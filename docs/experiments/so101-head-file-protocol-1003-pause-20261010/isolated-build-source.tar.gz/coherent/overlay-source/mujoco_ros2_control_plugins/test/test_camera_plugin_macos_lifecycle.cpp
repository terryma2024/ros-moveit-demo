/**
 * Copyright (c) 2026, United States Government, as represented by the
 * Administrator of the National Aeronautics and Space Administration.
 *
 * All rights reserved.
 *
 * This software is licensed under the Apache License, Version 2.0.
 */

#include <gtest/gtest.h>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <cstdlib>
#include <cstdint>
#include <dlfcn.h>
#include <filesystem>
#include <fstream>
#include <memory>
#include <mutex>
#include <pthread.h>
#include <string>
#include <thread>
#include <vector>

#include <GLFW/glfw3.h>
#include <OpenGL/OpenGL.h>
#include <mujoco/mujoco.h>
#include <rclcpp/rclcpp.hpp>
#include <std_srvs/srv/trigger.hpp>

#include "camera_plugin.hpp"

using namespace std::chrono_literals;

namespace
{

struct RecordedCall
{
  std::string name;
  std::thread::id thread_id;
};

std::mutex calls_mutex;
std::condition_variable calls_cv;
std::vector<RecordedCall> calls;
GLFWwindow* injected_window = nullptr;
GLFWwindow* worker_created_window = reinterpret_cast<GLFWwindow*>(static_cast<uintptr_t>(0x2));
CGLPixelFormatObj worker_pixel_format =
    reinterpret_cast<CGLPixelFormatObj>(static_cast<uintptr_t>(0x3));
CGLContextObj worker_cgl_context = reinterpret_cast<CGLContextObj>(static_cast<uintptr_t>(0x4));

std::mutex pthread_hook_mutex;
std::condition_variable pthread_hook_cv;
bool block_next_pthread_create = false;
bool pthread_create_blocked = false;
bool release_pthread_create = false;

std::mutex read_pixels_hook_mutex;
std::condition_variable read_pixels_hook_cv;
bool block_next_read_pixels = false;
bool read_pixels_blocked = false;
bool release_read_pixels = false;

void record_call(const std::string& name)
{
  {
    std::lock_guard<std::mutex> lock(calls_mutex);
    calls.push_back({ name, std::this_thread::get_id() });
  }
  calls_cv.notify_all();
}

bool wait_for_call(const std::string& name)
{
  std::unique_lock<std::mutex> lock(calls_mutex);
  return calls_cv.wait_for(lock, 2s, [&name]() {
    return std::any_of(calls.begin(), calls.end(), [&name](const RecordedCall& call) { return call.name == name; });
  });
}

std::vector<RecordedCall> recorded_calls()
{
  std::lock_guard<std::mutex> lock(calls_mutex);
  return calls;
}

size_t count_calls(const std::string& name)
{
  std::lock_guard<std::mutex> lock(calls_mutex);
  return static_cast<size_t>(
      std::count_if(calls.begin(), calls.end(), [&name](const RecordedCall& call) { return call.name == name; }));
}

}  // namespace

// These fakes let the real CameraPlugin worker and synchronization code run without opening
// Cocoa or requiring a live OpenGL context. The linked MuJoCo library still owns model/data APIs.
extern "C"
{

CGLError CGLChoosePixelFormat(const CGLPixelFormatAttribute*, CGLPixelFormatObj* pixel_format, GLint* count)
{
  *pixel_format = worker_pixel_format;
  *count = 1;
  record_call("cgl:choose_pixel_format");
  return kCGLNoError;
}

CGLError CGLCreateContext(CGLPixelFormatObj, CGLContextObj, CGLContextObj* context)
{
  *context = worker_cgl_context;
  record_call("cgl:create_context");
  return kCGLNoError;
}

CGLError CGLSetCurrentContext(CGLContextObj context)
{
  record_call(context == worker_cgl_context ? "cgl:bind" : "cgl:unbind");
  return kCGLNoError;
}

CGLError CGLLockContext(CGLContextObj)
{
  record_call("cgl:lock");
  return kCGLNoError;
}

CGLError CGLUnlockContext(CGLContextObj)
{
  record_call("cgl:unlock");
  return kCGLNoError;
}

void CGLReleaseContext(CGLContextObj)
{
  record_call("cgl:release_context");
}

void CGLReleasePixelFormat(CGLPixelFormatObj)
{
  record_call("cgl:release_pixel_format");
}

const char* CGLErrorString(CGLError)
{
  return "fake CGL error";
}

int pthread_create(pthread_t* thread, const pthread_attr_t* attr, void* (*start_routine)(void*), void* arg)
{
  using PthreadCreate = int (*)(pthread_t*, const pthread_attr_t*, void* (*)(void*), void*);
  static const auto real_pthread_create = reinterpret_cast<PthreadCreate>(dlsym(RTLD_NEXT, "pthread_create"));
  if (real_pthread_create == nullptr)
  {
    std::abort();
  }

  {
    std::unique_lock<std::mutex> lock(pthread_hook_mutex);
    if (block_next_pthread_create)
    {
      block_next_pthread_create = false;
      pthread_create_blocked = true;
      pthread_hook_cv.notify_all();
      pthread_hook_cv.wait(lock, [] { return release_pthread_create; });
    }
  }

  return real_pthread_create(thread, attr, start_routine, arg);
}

int glfwInit(void)
{
  record_call("glfw_init");
  return GLFW_TRUE;
}

void glfwWindowHint(int, int)
{
  record_call("window_hint");
}

GLFWwindow* glfwCreateWindow(int, int, const char*, GLFWmonitor*, GLFWwindow*)
{
  record_call("create_window");
  return worker_created_window;
}

void glfwDestroyWindow(GLFWwindow*)
{
  record_call("destroy_window");
}

void glfwMakeContextCurrent(GLFWwindow* window)
{
  if (window == injected_window)
  {
    record_call("bind:injected");
  }
  else if (window == nullptr)
  {
    record_call("bind:none");
  }
  else
  {
    record_call("bind:other");
  }
}

void mjv_makeScene(const mjModel*, mjvScene*, int)
{
  record_call("make_scene");
}

void mjv_freeScene(mjvScene*)
{
  record_call("free_scene");
}

void mjv_updateScene(const mjModel*, mjData*, const mjvOption*, const mjvPerturb*, mjvCamera*, int, mjvScene*)
{
  record_call("update_scene");
}

void mjr_makeContext(const mjModel*, mjrContext*, int)
{
  record_call("make_context");
}

void mjr_freeContext(mjrContext*)
{
  record_call("free_context");
}

void mjr_resizeOffscreen(int, int, mjrContext*)
{
  record_call("resize");
}

void mjr_setBuffer(int, mjrContext*)
{
  record_call("set_buffer");
}

void mjr_render(mjrRect, mjvScene*, const mjrContext*)
{
  record_call("render");
}

void mjr_readPixels(unsigned char* rgb, float* depth, mjrRect viewport, const mjrContext*)
{
  const auto pixels = static_cast<size_t>(viewport.width) * static_cast<size_t>(viewport.height);
  std::fill(rgb, rgb + pixels * 3U, static_cast<unsigned char>(0));
  std::fill(depth, depth + pixels, 0.5F);
  record_call("read_pixels");

  std::unique_lock<std::mutex> lock(read_pixels_hook_mutex);
  if (block_next_read_pixels)
  {
    block_next_read_pixels = false;
    read_pixels_blocked = true;
    read_pixels_hook_cv.notify_all();
    read_pixels_hook_cv.wait(lock, [] { return release_read_pixels; });
  }
}

}  // extern "C"

class CameraPluginMacosLifecycleTest : public ::testing::Test
{
protected:
  static void SetUpTestSuite()
  {
    if (!rclcpp::ok())
    {
      rclcpp::init(0, nullptr);
    }
  }

  static void TearDownTestSuite()
  {
    if (rclcpp::ok())
    {
      rclcpp::shutdown();
    }
  }

  void SetUp() override
  {
    std::lock_guard<std::mutex> lock(calls_mutex);
    calls.clear();
    injected_window = reinterpret_cast<GLFWwindow*>(static_cast<uintptr_t>(0x1));

    model_path_ = std::filesystem::temp_directory_path() / "test_camera_plugin_macos_lifecycle.xml";
    std::ofstream model_file(model_path_);
    model_file << R"(<?xml version="1.0"?>
<mujoco model="macos_lifecycle">
  <worldbody>
    <body name="box" pos="0 0 0.1">
      <freejoint/>
      <inertial pos="0 0 0" mass="1.0" diaginertia="0.01 0.01 0.01"/>
      <geom type="box" size="0.05 0.05 0.05"/>
    </body>
    <camera name="test_cam" pos="0 -1 1" xyaxes="1 0 0 0 0.707 0.707"
            fovy="60" resolution="8 6"/>
  </worldbody>
</mujoco>
)";
    model_file.close();

    char error[1000] = "";
    model_.reset(mj_loadXML(model_path_.c_str(), nullptr, error, sizeof(error)));
    ASSERT_NE(model_.get(), nullptr) << error;
    data_.reset(mj_makeData(model_.get()));
    ASSERT_NE(data_.get(), nullptr);
    root_node_ = rclcpp::Node::make_shared("test_camera_plugin_macos_lifecycle");
    node_ = root_node_->create_sub_node("camera_plugin");
  }

  void TearDown() override
  {
    node_.reset();
    root_node_.reset();
    data_.reset();
    model_.reset();
    std::filesystem::remove(model_path_);
  }

  struct ModelDeleter
  {
    void operator()(mjModel* model) const
    {
      mj_deleteModel(model);
    }
  };

  struct DataDeleter
  {
    void operator()(mjData* data) const
    {
      mj_deleteData(data);
    }
  };

  std::filesystem::path model_path_;
  std::unique_ptr<mjModel, ModelDeleter> model_;
  std::unique_ptr<mjData, DataDeleter> data_;
  rclcpp::Node::SharedPtr root_node_;
  rclcpp::Node::SharedPtr node_;
};

TEST_F(CameraPluginMacosLifecycleTest, WorkerBindsInjectedContextOnlyAroundRenderResources)
{
  const auto main_thread = std::this_thread::get_id();
  mujoco_ros2_control_plugins::CameraPlugin plugin;
  plugin.set_platform_render_context(injected_window);

  const bool initialized = plugin.init(node_, model_.get(), data_.get(), []() { return 0; });
  if (!initialized)
  {
    plugin.close_rendering();
    FAIL() << "CameraPlugin rejected the injected macOS context";
  }

  const auto ready_deadline = std::chrono::steady_clock::now() + 2s;
  while (!plugin.is_rendering_available() && std::chrono::steady_clock::now() < ready_deadline)
  {
    std::this_thread::sleep_for(5ms);
  }
  if (!plugin.is_rendering_available())
  {
    plugin.close_rendering();
    FAIL() << "CameraPlugin worker did not finish render-resource initialization";
  }

  plugin.trigger_update();
  EXPECT_TRUE(wait_for_call("read_pixels"));
  plugin.set_rendering_enabled(false);
  EXPECT_FALSE(plugin.is_rendering_available());
  plugin.trigger_update();
  std::this_thread::sleep_for(50ms);
  EXPECT_EQ(count_calls("read_pixels"), 1u);
  plugin.close_rendering();
  plugin.close_rendering();

  const auto observed = recorded_calls();
  std::vector<std::string> names;
  names.reserve(observed.size());
  for (const auto& call : observed)
  {
    names.push_back(call.name);
  }

  const std::vector<std::string> expected_names{ "bind:injected", "make_scene", "make_context", "resize", "bind:none",
                                                  "bind:injected", "set_buffer", "update_scene", "render",
                                                  "read_pixels", "bind:none", "bind:injected", "free_scene",
                                                  "free_context", "bind:none" };
  EXPECT_EQ(names, expected_names);
  for (const auto& call : observed)
  {
    EXPECT_NE(call.thread_id, main_thread) << call.name;
  }
}

TEST_F(CameraPluginMacosLifecycleTest, WorkerOwnsCglContextWhenNoGlfwContextIsInjected)
{
  const auto main_thread = std::this_thread::get_id();
  mujoco_ros2_control_plugins::CameraPlugin plugin;

  const bool initialized = plugin.init(node_, model_.get(), data_.get(), []() { return 0; });
  if (!initialized)
  {
    plugin.close_rendering();
    FAIL() << "CameraPlugin did not select CGL without an injected macOS GLFW context";
  }

  const auto ready_deadline = std::chrono::steady_clock::now() + 2s;
  while (!plugin.is_rendering_available() && std::chrono::steady_clock::now() < ready_deadline)
  {
    std::this_thread::sleep_for(5ms);
  }
  if (!plugin.is_rendering_available())
  {
    plugin.close_rendering();
    FAIL() << "CGL camera worker did not finish render-resource initialization";
  }

  plugin.trigger_update();
  EXPECT_TRUE(wait_for_call("read_pixels"));
  plugin.close_rendering();
  plugin.close_rendering();

  const auto observed = recorded_calls();
  std::vector<std::string> names;
  names.reserve(observed.size());
  for (const auto& call : observed)
  {
    names.push_back(call.name);
    EXPECT_NE(call.thread_id, main_thread) << call.name;
  }

  EXPECT_EQ(names, (std::vector<std::string>{
    "cgl:choose_pixel_format", "cgl:create_context", "cgl:bind", "cgl:lock",
    "make_scene", "make_context", "resize", "set_buffer", "update_scene", "render",
    "read_pixels", "free_scene", "free_context", "cgl:unlock", "cgl:unbind",
    "cgl:release_context", "cgl:release_pixel_format" }));
  EXPECT_EQ(count_calls("create_window"), 0u);
}

TEST_F(CameraPluginMacosLifecycleTest, CloseCannotReturnWhileWorkerConstructionIsInFlight)
{
  mujoco_ros2_control_plugins::CameraPlugin plugin;
  plugin.set_platform_render_context(injected_window);

  std::mutex gate_mutex;
  std::condition_variable gate_cv;
  bool begin_init = false;
  bool begin_close = false;
  std::atomic_bool init_returned{ false };
  std::atomic_bool init_result{ false };
  std::atomic_bool close_entered{ false };
  std::atomic_bool close_returned{ false };

  std::thread init_thread([&]() {
    {
      std::unique_lock<std::mutex> lock(gate_mutex);
      gate_cv.wait(lock, [&] { return begin_init; });
    }
    init_result = plugin.init(node_, model_.get(), data_.get(), []() { return 0; });
    init_returned = true;
    gate_cv.notify_all();
  });
  std::thread close_thread([&]() {
    {
      std::unique_lock<std::mutex> lock(gate_mutex);
      gate_cv.wait(lock, [&] { return begin_close; });
    }
    close_entered = true;
    gate_cv.notify_all();
    plugin.close_rendering();
    close_returned = true;
    gate_cv.notify_all();
  });

  {
    std::lock_guard<std::mutex> lock(pthread_hook_mutex);
    block_next_pthread_create = true;
    pthread_create_blocked = false;
    release_pthread_create = false;
  }
  {
    std::lock_guard<std::mutex> lock(gate_mutex);
    begin_init = true;
  }
  gate_cv.notify_all();

  bool worker_construction_blocked = false;
  {
    std::unique_lock<std::mutex> lock(pthread_hook_mutex);
    worker_construction_blocked = pthread_hook_cv.wait_for(lock, 2s, [] { return pthread_create_blocked; });
  }

  if (!worker_construction_blocked)
  {
    {
      std::lock_guard<std::mutex> lock(pthread_hook_mutex);
      release_pthread_create = true;
    }
    pthread_hook_cv.notify_all();
    {
      std::lock_guard<std::mutex> lock(gate_mutex);
      begin_close = true;
    }
    gate_cv.notify_all();
    init_thread.join();
    close_thread.join();
    FAIL() << "CameraPlugin did not reach worker construction";
  }

  {
    std::lock_guard<std::mutex> lock(gate_mutex);
    begin_close = true;
  }
  gate_cv.notify_all();

  {
    std::unique_lock<std::mutex> lock(gate_mutex);
    EXPECT_TRUE(gate_cv.wait_for(lock, 2s, [&] { return close_entered.load(); }));
    EXPECT_FALSE(gate_cv.wait_for(lock, 100ms, [&] { return close_returned.load(); }))
        << "close_rendering returned before the in-flight worker was assigned and joinable";
  }

  {
    std::lock_guard<std::mutex> lock(pthread_hook_mutex);
    release_pthread_create = true;
  }
  pthread_hook_cv.notify_all();

  init_thread.join();
  close_thread.join();

  EXPECT_TRUE(init_returned.load());
  EXPECT_TRUE(init_result.load());
  EXPECT_TRUE(close_returned.load());
  EXPECT_FALSE(plugin.is_rendering_available());

  // Safe even on the failing implementation: this second close joins a worker that was
  // assigned after the first close incorrectly returned.
  plugin.close_rendering();
}

TEST_F(CameraPluginMacosLifecycleTest, PolledCameraRendersExactlyOncePerTrigger)
{
  node_->declare_parameter("mujoco_plugins.mujoco_camera_plugin.test_cam.policy", std::string("polled"));

  mujoco_ros2_control_plugins::CameraPlugin plugin;
  plugin.set_platform_render_context(injected_window);
  if (!plugin.init(node_, model_.get(), data_.get(), []() { return 0; }))
  {
    plugin.close_rendering();
    FAIL() << "CameraPlugin rejected the injected macOS context";
  }

  const auto ready_deadline = std::chrono::steady_clock::now() + 2s;
  while (!plugin.is_rendering_available() && std::chrono::steady_clock::now() < ready_deadline)
  {
    std::this_thread::sleep_for(5ms);
  }
  if (!plugin.is_rendering_available())
  {
    plugin.close_rendering();
    FAIL() << "CameraPlugin worker did not finish render-resource initialization";
  }

  plugin.trigger_update();
  std::this_thread::sleep_for(50ms);
  EXPECT_EQ(count_calls("read_pixels"), 0u);

  auto client = root_node_->create_client<std_srvs::srv::Trigger>("/camera_plugin/test_cam/trigger");
  if (!client->wait_for_service(2s))
  {
    plugin.close_rendering();
    FAIL() << "Polled camera trigger service was not available";
  }
  auto response = client->async_send_request(std::make_shared<std_srvs::srv::Trigger::Request>());
  rclcpp::executors::SingleThreadedExecutor executor;
  executor.add_node(root_node_);
  const auto future_result = executor.spin_until_future_complete(response, 2s);
  executor.remove_node(root_node_);
  if (future_result != rclcpp::FutureReturnCode::SUCCESS)
  {
    plugin.close_rendering();
    FAIL() << "Polled camera trigger request did not complete";
  }
  if (!response.get()->success)
  {
    plugin.close_rendering();
    FAIL() << "Polled camera rejected trigger request";
  }

  plugin.trigger_update();
  EXPECT_TRUE(wait_for_call("read_pixels"));
  EXPECT_EQ(count_calls("read_pixels"), 1u);

  plugin.trigger_update();
  std::this_thread::sleep_for(50ms);
  EXPECT_EQ(count_calls("read_pixels"), 1u);

  plugin.close_rendering();
  plugin.close_rendering();
}

TEST_F(CameraPluginMacosLifecycleTest, DisableCannotReturnWhileCameraRegistrationIsInFlight)
{
  mujoco_ros2_control_plugins::CameraPlugin plugin;
  plugin.set_platform_render_context(injected_window);

  std::mutex registration_mutex;
  std::condition_variable registration_cv;
  bool registration_blocked = false;
  bool release_registration = false;
  auto callback_handle = node_->add_on_set_parameters_callback(
      [&](const std::vector<rclcpp::Parameter>& parameters) {
        for (const auto& parameter : parameters)
        {
          if (parameter.get_name() == "mujoco_plugins.mujoco_camera_plugin.test_cam.policy")
          {
            std::unique_lock<std::mutex> lock(registration_mutex);
            registration_blocked = true;
            registration_cv.notify_all();
            registration_cv.wait(lock, [&] { return release_registration; });
          }
        }
        rcl_interfaces::msg::SetParametersResult result;
        result.successful = true;
        return result;
      });
  ASSERT_NE(callback_handle, nullptr);

  std::atomic_bool init_result{ false };
  std::atomic_bool disable_entered{ false };
  std::atomic_bool disable_returned{ false };
  std::thread init_thread([&]() { init_result = plugin.init(node_, model_.get(), data_.get(), []() { return 0; }); });

  bool observed_registration_barrier = false;
  {
    std::unique_lock<std::mutex> lock(registration_mutex);
    observed_registration_barrier = registration_cv.wait_for(lock, 2s, [&] { return registration_blocked; });
  }
  if (!observed_registration_barrier)
  {
    {
      std::lock_guard<std::mutex> lock(registration_mutex);
      release_registration = true;
    }
    registration_cv.notify_all();
    init_thread.join();
    plugin.close_rendering();
    FAIL() << "Camera registration did not reach the parameter callback barrier";
  }

  std::thread disable_thread([&]() {
    disable_entered = true;
    registration_cv.notify_all();
    plugin.set_rendering_enabled(false);
    disable_returned = true;
    registration_cv.notify_all();
  });

  {
    std::unique_lock<std::mutex> lock(registration_mutex);
    EXPECT_TRUE(registration_cv.wait_for(lock, 2s, [&] { return disable_entered.load(); }));
    EXPECT_FALSE(registration_cv.wait_for(lock, 100ms, [&] { return disable_returned.load(); }))
        << "set_rendering_enabled(false) raced with mutation of the camera registry";
    release_registration = true;
  }
  registration_cv.notify_all();

  init_thread.join();
  disable_thread.join();

  EXPECT_TRUE(init_result.load());
  EXPECT_TRUE(disable_returned.load());
  EXPECT_FALSE(plugin.is_rendering_available());
  plugin.close_rendering();
  plugin.close_rendering();
}

TEST_F(CameraPluginMacosLifecycleTest, ProducerCannotOverwriteSnapshotWhileWorkerRenders)
{
  mujoco_ros2_control_plugins::CameraPlugin plugin;
  plugin.set_platform_render_context(injected_window);
  if (!plugin.init(node_, model_.get(), data_.get(), []() { return 0; }))
  {
    plugin.close_rendering();
    FAIL() << "CameraPlugin rejected the injected macOS context";
  }

  const auto ready_deadline = std::chrono::steady_clock::now() + 2s;
  while (!plugin.is_rendering_available() && std::chrono::steady_clock::now() < ready_deadline)
  {
    std::this_thread::sleep_for(5ms);
  }
  if (!plugin.is_rendering_available())
  {
    plugin.close_rendering();
    FAIL() << "CameraPlugin worker did not finish render-resource initialization";
  }

  {
    std::lock_guard<std::mutex> lock(read_pixels_hook_mutex);
    block_next_read_pixels = true;
    read_pixels_blocked = false;
    release_read_pixels = false;
  }
  plugin.trigger_update();

  bool observed_render_barrier = false;
  {
    std::unique_lock<std::mutex> lock(read_pixels_hook_mutex);
    observed_render_barrier = read_pixels_hook_cv.wait_for(lock, 2s, [] { return read_pixels_blocked; });
  }
  if (!observed_render_barrier)
  {
    {
      std::lock_guard<std::mutex> lock(read_pixels_hook_mutex);
      release_read_pixels = true;
    }
    read_pixels_hook_cv.notify_all();
    plugin.close_rendering();
    FAIL() << "Camera worker did not reach the readback barrier";
  }

  std::atomic_bool producer_entered{ false };
  std::atomic_bool producer_returned{ false };
  std::thread producer_thread([&]() {
    producer_entered = true;
    read_pixels_hook_cv.notify_all();
    plugin.trigger_update();
    producer_returned = true;
    read_pixels_hook_cv.notify_all();
  });

  {
    std::unique_lock<std::mutex> lock(read_pixels_hook_mutex);
    EXPECT_TRUE(read_pixels_hook_cv.wait_for(lock, 2s, [&] { return producer_entered.load(); }));
    EXPECT_FALSE(read_pixels_hook_cv.wait_for(lock, 100ms, [&] { return producer_returned.load(); }))
        << "producer overwrote the shared snapshot while the worker was rendering it";
    release_read_pixels = true;
  }
  read_pixels_hook_cv.notify_all();

  producer_thread.join();
  EXPECT_TRUE(producer_returned.load());
  plugin.close_rendering();
  plugin.close_rendering();
}
