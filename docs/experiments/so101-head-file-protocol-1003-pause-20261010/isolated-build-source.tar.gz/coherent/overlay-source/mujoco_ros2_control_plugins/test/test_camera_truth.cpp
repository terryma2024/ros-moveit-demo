#include <gtest/gtest.h>
#include <chrono>
#include <thread>
#include "camera_truth.hpp"

using namespace mujoco_ros2_control_plugins;

// Distinct literal pixels catch segid-as-geom-index, wrong background, type loss,
// big-endian output and a missing OpenGL vertical flip.
TEST(CameraTruth, DecodesSameSceneIdsAndFlipsRows)
{
  const std::vector<SegmentationEntry> map{{0, 17, 5}, {3, 91, 6}};
  const std::vector<uint8_t> rgb{1,0,0, 0,0,0, 4,0,0, 1,0,0};
  std::vector<uint8_t> out(32);
  ASSERT_TRUE(decode_instance_image(rgb, 2, 2, map, out));
  const std::vector<uint8_t> expected{
    91,0,0,0,6,0,0,0, 17,0,0,0,5,0,0,0,
    17,0,0,0,5,0,0,0, 255,255,255,255,255,255,255,255};
  EXPECT_EQ(out, expected);
}

TEST(CameraTruth, RejectsDuplicateUnmappedAndInvalidPixelLayouts)
{
  std::vector<uint8_t> out(8);
  EXPECT_FALSE(decode_instance_image({2,0,0}, 1, 1, {{0,17,5}}, out));
  EXPECT_FALSE(decode_instance_image({1,0,0}, 1, 1, {{0,17,5},{0,91,6}}, out));
  EXPECT_FALSE(decode_instance_image({1,0,0}, 0, 1, {{0,17,5}}, out));
  EXPECT_FALSE(decode_instance_image({1,0}, 1, 1, {{0,17,5}}, out));
  EXPECT_FALSE(decode_instance_image({1,0,0}, 1, 1, {{2000,17,5}}, out));
}

TEST(CameraTruth, FixedQueueRejectsNewFrameWithoutOverwritingInFlightOriginal)
{
  FixedTruthQueue<std::vector<uint8_t>> queue;
  for (auto& slot : queue.slots) slot.value.resize(8);
  auto* first = queue.try_begin();
  ASSERT_NE(first, nullptr);
  first->value[0] = 17;
  queue.commit(*first);
  auto* publishing = queue.try_take();
  ASSERT_EQ(publishing, first);
  auto* second = queue.try_begin();
  ASSERT_NE(second, nullptr);
  second->value[0] = 91;
  queue.commit(*second);
  const auto start = std::chrono::steady_clock::now();
  EXPECT_EQ(queue.try_begin(), nullptr);
  EXPECT_LT(std::chrono::steady_clock::now()-start, std::chrono::milliseconds(20));
  EXPECT_EQ(publishing->value[0], 17);
  queue.published(*publishing);
  EXPECT_EQ(queue.try_take(), second);
  queue.published(*second);
  auto facts = queue.watermarks();
  EXPECT_EQ(facts.generated, 3u);
  EXPECT_EQ(facts.enqueued, 2u);
  EXPECT_EQ(facts.published, 2u);
  EXPECT_EQ(facts.dropped, 1u);
  EXPECT_EQ(facts.last_dropped, 3u); // Tail loss with no subsequent frame.
  EXPECT_TRUE(facts.loss);
}

TEST(CameraTruth, ClosingRejectsIngressAndAccountsForQueuedTail)
{
  FixedTruthQueue<int> queue;
  auto* slot = queue.try_begin();
  ASSERT_NE(slot, nullptr);
  queue.commit(*slot);
  queue.stop_ingress();
  EXPECT_EQ(queue.try_begin(), nullptr);
  queue.drop_queued();
  EXPECT_EQ(queue.try_take(), nullptr);
  const auto facts = queue.watermarks();
  EXPECT_EQ(facts.generated, 1u);
  EXPECT_EQ(facts.dropped, 1u);
  EXPECT_EQ(facts.last_dropped, 1u);
  EXPECT_TRUE(facts.loss);
}
