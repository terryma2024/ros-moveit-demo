// Test-only reproduction of original fresh-sampling outer dispatch policy.
#pragma once
#include <cstdint>
#include <rclcpp/time.hpp>
#include <rclcpp/duration.hpp>
namespace mujoco_ros2_control {
enum class CycleOperation {Read, Update, Write};
template<class Manager,class ClockReader,class Begin,class End,class AfterRead>
bool execute_control_cycle(Manager & manager,const rclcpp::Time & cycle_time,
  const rclcpp::Duration & period,bool use_sim_time,ClockReader get_time,
  Begin begin,End end,AfterRead after_read) {
  auto invoke=[&](CycleOperation operation,auto call){
    const auto start=begin(operation);
    const auto argument=get_time();
    call(argument,period);
    end(operation,argument,start);
  };
  invoke(CycleOperation::Read,[&](const auto & time,const auto & dt){manager.read(time,dt);});
  if(!after_read())return false;
  invoke(CycleOperation::Update,[&](const auto & time,const auto & dt){manager.update(time,dt);});
  invoke(CycleOperation::Write,[&](const auto & time,const auto & dt){manager.write(time,dt);});
  return true;
}
}
